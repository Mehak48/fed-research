#!/usr/bin/env python3
"""Build, check or show the FROZEN experiment manifest (owner decision B2; fedkge/manifest.py).

  python scripts/build_manifest.py --check      # rebuild from the configs and compare with the frozen file (exit 1 if
                                                #   anything changed); run by the tests and by every research session
  python scripts/build_manifest.py --write      # (maintainer only) write 10_configs/manifest/FROZEN_MANIFEST.*; the
                                                #   result must be committed - the frozen file is part of the checkpoint
  python scripts/build_manifest.py --summary    # counts by plan, priority and block

The manifest lists exactly the approved cells: 114 tuning cells (99 unique runs), 756 Stage-4 cells (756 unique
runs; 726 if the fixed schedule is selected), 30 legacy replicas. Building it reads only 10_configs and the core code.
"""
from __future__ import annotations

import argparse
import json
import sys

import pandas as pd

from _common import CONFIG_DIR
from fedkge.io import IntegrityError
from fedkge.manifest import build_manifest, load_frozen, verify_frozen, write_manifest


def summary(man: dict) -> str:
    df = pd.DataFrame(man["cells"])
    out = [json.dumps(man["plans"], indent=1), "", "cells by plan x priority:",
           df.groupby(["plan", "priority"]).size().to_string(), "", "cells by plan x block:",
           df.groupby(["plan", "block"]).size().to_string()]
    return "\n".join(out)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--check", action="store_true"); g.add_argument("--write", action="store_true")
    g.add_argument("--summary", action="store_true")
    a = ap.parse_args(argv)
    if a.write:
        man = build_manifest(CONFIG_DIR)
        files = write_manifest(man, CONFIG_DIR / "manifest")
        print(f"wrote {files['json']} (content {man['content_sha256'][:16]}...)")
        print(summary(man))
        return 0
    if a.summary:
        print(summary(load_frozen(CONFIG_DIR)))
        return 0
    try:
        man = verify_frozen(CONFIG_DIR)
    except IntegrityError as e:
        print(f"MANIFEST CHECK FAILED: {e}")
        return 1
    p = man["plans"]
    print(f"frozen manifest OK (content {man['content_sha256'][:16]}...): tune {p['tune']['cells']} cells / "
          f"{p['tune']['unique_runs']} runs; main {p['main']['cells']} cells / {p['main']['unique_runs']} runs "
          f"({p['main']['unique_runs_if_fixed_schedule_selected']} if s* = fixed); legacy {p['legacy']['cells']} runs")
    return 0


if __name__ == "__main__":
    sys.exit(main())
