
## 4. Threshold inventory (master prompt §12)

Every threshold-like parameter in the legacy code, the manuscript and the revision, and how it is handled.
- Parameters that are **not** thresholds are labelled as such and are not swept just to make the matrix bigger.
- Selection uses **validation data on the tuning seed only**. Rules are frozen and hashed before Stage 4.
- The legacy "τ ∈ {0.05…0.40}, 100 % at every value" table was formula-generated (CR-1). It is withdrawn, not reproduced.

