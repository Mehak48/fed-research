"""Phase C - privacy mechanism and accounting (zero-out adjacency, design Q, cross-checks, edge cases,
sensitivity of the implemented clipping, non-finite guard, pure-noise clients, DP3 ablation path)."""
import math

import numpy as np
import pytest
import torch

from fedkge import accountant as A
from fedkge.dp import dp_local_train, per_example_clipped_sum
from fedkge.model import init_params

CASES = [(0.05, 20, 100, 2.9636658868419024), (0.02, 50, 100, 1.95), (0.1, 10, 50, 3.0), (0.0188, 53, 30, 1.2)]


@pytest.mark.parametrize("q,T,R,sigma", CASES)
def test_zero_out_public_api_equals_runtime_rdp(q, T, R, sigma):
    """dp_accounting's PUBLIC RdpAccountant with NeighboringRelation.REPLACE_SPECIAL (zero-out) gives the same
    epsilon as the run-time code path (private RDP function) and as ADD_OR_REMOVE_ONE."""
    ks, sig = [T] * R, [sigma] * R
    e_rt = A.eps_from_rdp(A.composed_rdp(q, ks, sig), 1e-6)
    e_zo = A.rdp_epsilon_public_api(q, ks, sig, 1e-6)
    import dp_accounting
    acc = dp_accounting.rdp.RdpAccountant(list(A.MAIN_ORDERS), dp_accounting.NeighboringRelation.ADD_OR_REMOVE_ONE)
    acc.compose(dp_accounting.PoissonSampledDpEvent(q, dp_accounting.GaussianDpEvent(sigma)), T * R)
    assert abs(e_rt - e_zo) < 1e-9 and abs(e_zo - acc.get_epsilon(1e-6)) < 1e-9


def test_gaussian_mechanism_matches_closed_form():
    """q = 1 (no subsampling): RDP of the Gaussian mechanism is alpha / (2 sigma^2) at every order."""
    for sigma in (0.7, 1.0, 3.0):
        v = A.rdp_vector(1.0, sigma)
        exact = np.array(A.MAIN_ORDERS) / (2 * sigma ** 2)
        assert np.allclose(v, exact, rtol=1e-9)


def test_prv_and_pld_bracket_and_rdp_is_conservative():
    q, T, R = 0.05, 20, 100
    s0 = A.calibrate_sigma0(q, T, R, "fixed", 1.0, 4.0, 1e-6, 5)["sigma0"]
    ks, sig = [T] * R, [s0] * R
    rdp = A.eps_from_rdp(A.composed_rdp(q, ks, sig), 1e-6)
    pld = A.pld_epsilon(q, ks, sig, 1e-6)
    prv = A.prv_epsilon(q, ks, sig, 1e-6)
    assert prv["lower"] - 1e-3 <= pld <= prv["upper"] + 1e-3
    assert pld <= rdp + 1e-9 and prv["upper"] <= rdp + 1e-6
    assert rdp <= 4.0 + 1e-9


def test_heterogeneous_schedule_crosscheck():
    q, T, R = 0.05, 20, 100
    cal = A.calibrate_sigma0(q, T, R, "cosine", 0.25, 4.0, 1e-6, 5)
    ks, sig = [T] * R, cal["sigmas"]
    rdp = A.eps_from_rdp(A.composed_rdp(q, ks, sig), 1e-6)
    assert abs(rdp - A.rdp_epsilon_public_api(q, ks, sig, 1e-6)) < 1e-9
    prv = A.prv_epsilon(q, ks, sig, 1e-6)
    assert prv["upper"] <= rdp + 1e-6 and rdp <= 4.0 + 1e-9


def test_design_q_rates_and_common_sigma():
    a = A.dp_steps_common_rate(27212, 0.05)
    b = A.dp_steps_common_rate(5442, 0.05)
    assert a["steps"] == b["steps"] == 20 and a["q"] == b["q"] == 0.05
    assert abs(a["expected_batch"] - 0.05 * 27212) < 1e-9 and abs(b["expected_batch"] - 0.05 * 5442) < 1e-9
    s1 = A.calibrate_sigma0(a["q"], a["steps"], 100, "fixed", 1.0, 4.0, 1e-6, 5)["sigma0"]
    s2 = A.calibrate_sigma0(b["q"], b["steps"], 100, "fixed", 1.0, 4.0, 1e-6, 5)["sigma0"]
    assert s1 == s2                       # one sigma for every client under design Q
    with pytest.raises(A.AccountantError):
        A.dp_steps_common_rate(100, 1.5)
    with pytest.raises(A.AccountantError):
        A.dp_steps_common_rate(0, 0.05)


def test_skipped_rounds_only_reduce_epsilon():
    q, T, R, s = 0.05, 20, 20, 2.0
    full = A.eps_from_rdp(A.composed_rdp(q, [T] * R, [s] * R), 1e-6)
    skipped = A.eps_from_rdp(A.composed_rdp(q, [T] * 10 + [0] * 10, [s] * R), 1e-6)
    half = A.eps_from_rdp(A.composed_rdp(q, [T] * 10, [s] * 10), 1e-6)
    assert skipped < full and abs(skipped - half) < 1e-12


def test_accountant_edge_cases_raise():
    with pytest.raises(A.AccountantError):
        A.rdp_vector(0.0, 1.0)
    with pytest.raises(A.AccountantError):
        A.rdp_vector(1.2, 1.0)
    with pytest.raises(A.AccountantError):
        A.rdp_vector(0.1, 0.0)
    with pytest.raises(A.AccountantError):
        A.rdp_vector(0.1, float("inf"))
    with pytest.raises(A.AccountantError):
        A.eps_from_rdp(A.rdp_vector(0.1, 1.0), 0.0)
    with pytest.raises(A.AccountantError):
        A.composed_rdp(0.1, [1, 2], [1.0])
    with pytest.raises(A.AccountantError):
        A.composed_rdp(0.1, [-1], [1.0])
    assert not A.composed_rdp(0.1, [0, 0], [1.0, 1.0]).any()


def _toy(n_ent=40, n_rel=4, b=12, k=3, seed=0):
    g = torch.Generator().manual_seed(seed)
    p = init_params(n_ent, n_rel, 8, g, "cpu")
    h = torch.randint(0, n_ent, (b,), generator=g); t = torch.randint(0, n_ent, (b,), generator=g)
    r = torch.randint(0, n_rel, (b,), generator=g)
    nh = torch.randint(0, n_ent, (b, k), generator=g); nt = torch.randint(0, n_ent, (b, k), generator=g)
    return p, h, r, t, nh, nt


@pytest.mark.parametrize("normalize", [True, False])
def test_zero_out_sensitivity_of_implemented_sum(normalize):
    """Replacing one example by a null record (dropping its contribution) changes the clipped sum by <= C."""
    p, h, r, t, nh, nt = _toy()
    C = 0.5
    Ge, Gr, norms, _ = per_example_clipped_sum(p["ent"], p["rel"], h, r, t, nh, nt, C, 1.0, normalize)
    for i in range(len(h)):
        keep = torch.tensor([j for j in range(len(h)) if j != i])
        Ge2, Gr2, _, _ = per_example_clipped_sum(p["ent"], p["rel"], h[keep], r[keep], t[keep], nh[keep], nt[keep],
                                                 C, 1.0, normalize)
        diff = torch.sqrt(((Ge - Ge2) ** 2).sum() + ((Gr - Gr2) ** 2).sum())
        assert float(diff) <= C + 1e-5


def test_non_finite_example_is_zeroed_and_others_unchanged():
    p, h, r, t, nh, nt = _toy()
    C = 1.0
    ent = p["ent"].clone()
    ent[int(h[0])] = float("nan")                         # a crafted non-finite row used by example 0
    Ge, Gr, norms, _ = per_example_clipped_sum(ent, p["rel"], h, r, t, nh, nt, C, 1.0, True)
    assert torch.isfinite(Ge).all() and torch.isfinite(Gr).all()
    bad = [i for i in range(len(h)) if int(h[i]) == int(h[0]) or int(t[i]) == int(h[0])
           or (nh[i] == int(h[0])).any() or (nt[i] == int(h[0])).any()]
    good = torch.tensor([i for i in range(len(h)) if i not in bad])
    Ge_g, Gr_g, _, _ = per_example_clipped_sum(ent, p["rel"], h[good], r[good], t[good], nh[good], nt[good], C, 1.0, True)
    assert torch.allclose(Ge, Ge_g, atol=1e-6) and torch.allclose(Gr, Gr_g, atol=1e-6)
    assert torch.isnan(norms[torch.tensor(bad)]).all()


def test_pure_noise_client_and_no_noise_ablation():
    g = torch.Generator().manual_seed(1)
    p = init_params(30, 3, 8, g, "cpu")
    tcfg = {"lr": 0.01, "neg_samples": 2, "neg_mode": "correct"}
    empty = torch.zeros((0, 3), dtype=torch.long)
    newp, st = dp_local_train(p, empty, 30, tcfg, True, 1.0, 1.5, 1.0, 5, 0.1, 10.0, torch.Generator().manual_seed(2))
    d = torch.cat([(newp[k] - p[k]).reshape(-1) for k in ("ent", "rel")])
    assert torch.isfinite(d).all() and float(d.norm()) > 0 and st["n_examples"] == 0
    trip = torch.tensor([[0, 0, 1], [2, 1, 3], [4, 2, 5]] * 10)
    a, _ = dp_local_train(p, trip, 30, tcfg, True, 1.0, 0.0, float("inf"), 3, 0.5, 15.0, torch.Generator().manual_seed(3))
    b, _ = dp_local_train(p, trip, 30, tcfg, True, 1.0, 0.0, float("inf"), 3, 0.5, 15.0, torch.Generator().manual_seed(3))
    assert all(torch.equal(a[k], b[k]) for k in a) and all(torch.isfinite(a[k]).all() for k in a)


def test_calibration_monotone_and_meets_target_for_all_operating_points():
    for eps in (1.0, 2.0, 4.0, 8.0):
        res = A.calibrate_sigma0(0.05, 20, 100, "fixed", 1.0, eps, 1e-6, 5)
        assert res["eps_at_R"] <= eps + 1e-9
        lower = A.eps_from_rdp(A.composed_rdp(0.05, [20] * 100, [res["sigma0"] / 1.002] * 100), 1e-6)
        assert lower > eps - 1e-6                         # tight: 0.2 % less noise would overshoot
    s = [A.calibrate_sigma0(0.05, 20, 100, "fixed", 1.0, e, 1e-6, 5)["sigma0"] for e in (1.0, 2.0, 4.0, 8.0)]
    assert all(a > b for a, b in zip(s, s[1:]))
