# DP mechanism and accounting (Phases 1–4; Phase C revision)

## Guarantee statement (manuscript wording, pending approval of D2/D11)
Each client runs DP-SGD locally. One local step (i) includes every triple of the client independently with
probability q (Poisson sampling), (ii) computes the gradient of each included triple's loss (the triple and its
k = 64 data-independent negatives) with respect to **all** parameters, summing the rows of an entity that occurs
several times inside one example before the norm is taken, (iii) replaces any per-triple gradient that contains a
non-finite value by 0 and clips every per-triple gradient to L2 norm C, (iv) adds N(0, σ_t² C² I) to the sum over
**every coordinate of every parameter**, (v) divides by the expected batch q·N̂_k, where N̂_k is the client's
public record count, and takes an Adam step with fresh optimiser state each round. A round is T steps
(design Q: T = round(1/q), one q and one σ for every client; design A: expected batch B = 512, q_k = B/N̂_k,
T_k = round(N̂_k/B), σ calibrated per client — tuning step T2d decides, ties → Q).

**Privacy unit:** one training triple of one client. **Neighbouring relation: zero-out** — two datasets of a client
are neighbours if one triple is replaced by a null record whose loss and gradient are identically zero. The client's
record count is therefore the same for neighbours and may be public (it sets the FedAvg weights, the normalisation
q·N̂_k and, under design A, q_k and T_k). Under plain add/remove adjacency publishing the exact N̂_k would reveal a
removal (defect CR-14), so add/remove is not the relation claimed.

**Guarantee:** for every client k, the sequence of its transmitted updates over all executed rounds is
(ε_k, δ)-DP under zero-out adjacency, with ε_k from RDP composition over the steps the client **actually executed**
(a client that rejects a broadcast executes 0 steps that round) with the executed σ_t. We report
**ε = max_k ε_k** (worst client) at δ = 10⁻⁶ (also 10⁻⁵), together with δ × max_k N̂_k.

**Not covered:** entity-level privacy (an entity in g triples gets only group privacy, vacuous for g ≥ 4 at ε = 4);
client-level privacy and participation; the client sizes N̂_k (public); dataset-level properties such as which
relations a client mostly holds; duplicated or correlated facts; the privacy cost of hyperparameter tuning (disclosed,
not accounted); floating-point and PRNG side channels beyond the non-finite guard; the server's validation data
(assumed not to be client data). Clients reject broadcasts that fail integrity verification or contain non-finite
values, so a crafted inf/NaN broadcast cannot break the clipping bound.

## Scope: per-model guarantee, not an end-to-end guarantee (owner decision B5, 2026-11-04)
Every reported ε is the guarantee of ONE trained model's released updates. The research workflow repeatedly uses the
same client data: Stage 3 trains 99 tuning models and selects hyperparameters from their validation scores, and
Stage 4 trains further models under several configurations and seeds. The privacy cost of that adaptive selection and
of releasing several models trained on the same data is **not** included in any reported ε, and no end-to-end
guarantee is claimed for the workflow. (Accounting for private selection, e.g. Papernot & Steinke 2022, would be an
additional design decision and is not part of the approved methodology.) Reports, tables and the results draft state
this next to every ε.

## Why the accounting holds for zero-out adjacency
For Poisson sampling, a null record contributes nothing whether or not it is sampled, so the output distributions
of a step on D (with triple x) and D′ (x replaced by ⊥) are exactly the pair analysed for the Poisson-subsampled
Gaussian mechanism under add/remove adjacency (Mironov, Talwar & Zhang 2019). `dp_accounting` implements this
explicitly: `RdpAccountant(neighboring_relation=REPLACE_SPECIAL)` accepts `PoissonSampledDpEvent` and composes it
with the same RDP. `fedkge.accountant.rdp_epsilon_public_api` uses that public API, and every DP run asserts that it
equals the run-time value (`eps_rdp_public_api_worst_client`). The normalisation q·N̂_k uses the public N̂_k, which
counts null records, so it is identical for neighbours. Negatives are drawn independently of all other data.

## Why best-checkpoint selection does not break the guarantee
DP runs execute all R rounds (no early stopping, C3). The guarantee is computed over **all executed rounds**; choosing
the best-validated checkpoint is post-processing of released models evaluated on server data (V_es ⊂ V_sel).

## Accounting
* RDP of the Poisson-subsampled Gaussian mechanism (`dp_accounting`), composed over every executed step, converted
  with `dp_accounting.rdp.compute_epsilon`. Orders: `MAIN_ORDERS`; any finite set gives a valid upper bound.
  `dp_accounting` bounds fractional orders from above (exact at integer orders), so the reported ε can exceed the
  exact RDP value slightly (≤ 0.15 % in the Phase C grid), never fall below it.
* Cross-checks recorded in every DP run's `accountant.json`: public-API zero-out RDP (must equal), PLD
  (`eps_pld_worst_client`), PRV accountant (`eps_prv_worst_client`, package `prv-accountant`).
* `scripts/check_privacy_accounting.py` validates the whole operating grid five ways, including a numerical
  quadrature of the Rényi divergence that does not use `dp_accounting`, the Gaussian closed form (q = 1), and the
  legacy per-round log.
* Every ε is recomputable from `accountant.json` (`q`, `steps_executed_per_round`, σ trace).
* Legacy replica only: per-round ε with a fresh accountant (Opacus orders) reproduces the old log; the old stopping
  number was a sum of per-round client means, not a valid composition; it is stored as
  `legacy_naive_sum_of_round_means` next to the true RDP value.

## Calibration and schedules (σ_t)
σ_t = σ₀ · g(t). g is deterministic, data-independent, fixed before training, piecewise-constant in blocks of 5
rounds: fixed (g = 1), linear, exponential, cosine with end ratio ρ = σ_last/σ₀ ∈ {0.25, 0.5}. σ₀ is the smallest
value (bisection, rounded up) such that ε(R) ≤ ε*. Every schedule is compared at the same formally accounted ε*.
Each run asserts the executed σ trace equals the configured schedule (`schedule_verified`).

## Ablation without a guarantee
`dp.mode: no_noise` (block DP3 only) runs the DP training settings with σ = 0 (and optionally no clipping) to
decompose the DP cost. Such runs have **no privacy guarantee**: they write `privacy_ablation`, never `privacy` or
`accountant.json`.

## What was removed from the old implementation
`eps = sigma * 0.5` fallback; "Adaptive: IMPLEMENTED" string with σ fixed at 1.0; "WITHIN BUDGET" with 15.53 > 15;
warm start from the non-DP checkpoint (the config key `warm_start` is rejected); unnormalised entities and degenerate
negatives (only in the labelled legacy replica rows); self-reported un-noised losses (not used).

## Implementation checks (tests)
`test_dp_clipping.py`: per-example norms and clipped sums equal Opacus `GradSampleModule` and brute-force
autograd; dense noise with std σC; determinism. `test_phaseC_privacy.py`: zero-out public API = run-time RDP;
Gaussian closed form; PLD/PRV bracketing; design Q gives one σ; skipped rounds only reduce ε; edge cases raise;
replacing one example by a null record changes the clipped sum by ≤ C; non-finite examples contribute exactly 0;
pure-noise (empty) clients; the σ = 0 ablation path.
