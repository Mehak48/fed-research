# Research progress (derived from the run folders)

Updated 2026-11-05T07:37:35.979623Z.

| Plan | Cells | Unique runs COMPLETE | Unique runs total (resolved) | Status of cells |
|---|---|---|---|---|
| legacy | 30 | 0 | 30 | NOT_STARTED 30 |
| main | 756 | 0 | 0 | WAITING_FOR_SELECTIONS 756 |
| tune | 114 | 0 | 63 | NOT_STARTED 63, WAITING_FOR_SELECTIONS 51 |

Stage 4 by priority:

| Priority | Cells | Status |
|---|---|---|
| 1 | 75 | WAITING_FOR_SELECTIONS 75 |
| 2 | 210 | WAITING_FOR_SELECTIONS 210 |
| 3 | 60 | WAITING_FOR_SELECTIONS 60 |
| 5 | 15 | WAITING_FOR_SELECTIONS 15 |
| 6 | 252 | WAITING_FOR_SELECTIONS 252 |
| 7 | 144 | WAITING_FOR_SELECTIONS 144 |
