# 07 — Computational feasibility estimate and staged execution plan (Phase B, item 7)

**Status:** an assumption-based estimate for planning. It is **not** a measured runtime, and it does not assume any particular hardware or plan of yours.
- Every figure comes from `scripts/phaseB_experiment_matrix.py`: `data/run_counts.csv`, `data/cost_estimate.csv`, `data/per_run_time_estimate.csv`, `data/storage_estimate.csv` and `data/priority_cost.csv`. All are **[Calculated – Phase B planning]**.
- Times are for an **assumed T4-class GPU**, the reference class of the cost model. It is not a statement about the GPU you have.
- The Stage-2 pilot replaces the assumptions with measured times before anything large runs.

## 1. Bottom line

- **The core study is feasible on a low budget only if the pilot confirms the lower half of the estimate.**
  - Recommended plan: reduced profile, CoDEx-M as third dataset.
  - Core (Stages 2–4): **837 runs**, about **46.5 to 392.6 GPU-hours** on the assumed GPU class.
- The range is wide because two quantities are unknown until measured:
  - the fixed overhead per optimiser step;
  - the DP sampling rate that tuning will select. A small q such as 0.02 needs 5× more steps per round than q = 0.1.
- **The pilot** (Stage 2: 11 runs, about 1–4 GPU-hours) measures both. The estimate is then recomputed, and only then do you approve the size of Stage 4.
- **CPU only** is enough for Stage 0 (tests), Stage 1 (smoke) and building partitions. It is **not** enough for the experiments.

## 2. How the estimate is built

**Cost per round** = steps × (fixed step overhead + dense parameter work) + per-example work + integrity hashing + periodic evaluation, times an overhead factor.

| Parameter | LOW | HIGH | Basis |
|---|---|---|---|
| Fixed overhead per optimiser step | 8 ms | 20 ms | the legacy Phase 3 run implies ≈ 15 ms per step |
| Per example (64 negatives, d = 100, incl. per-example clipping) | 1.5 µs | 6 µs | memory-traffic estimate |
| Dense work per parameter per step (noise + Adam) | 0.1 ns | 0.4 ns | memory-bandwidth estimate |
| Scoring one (query, candidate) pair in evaluation | 0.5 ns | 2 ns | distance computation |
| SHA-256 throughput | 1 GB/s | 0.3 GB/s | CPU hashing |
| DP sampling rate (steps per round = 10/q) | q = 0.10 | q = 0.02 | to be tuned (T2a) |
| Overhead factor (logging, checkpoints) | 1.2 | 1.5 | assumption |

**Consistency check, not a validation.** The legacy Phase 3 run on your Colab GPU (model not recorded) took **1,204.4 s** for 50 rounds × 3 local epochs [Legacy-measured]. The model's bounds for the same workload are 660 s (LOW) and 1,672 s (HIGH).
- The bounds were chosen with this single measurement in view, so its falling inside them confirms consistency only.
- Nothing about DP steps, 64 negatives or 10 clients has been measured yet. That is the pilot's job.

**Not used as an anchor:** the legacy Phase 4 DP run, at about 140 ms per step. Opacus builds dense per-sample gradients for embedding tables. The revision's DP code avoids that, but this has not been measured yet.

## 3. Hardware requirements

| Stage | Minimum | Recommended | Notes |
|---|---|---|---|
| 0 Tests, 1 Smoke, Phase D partitions | any CPU, Python ≥ 3.10, 8 GB RAM, ~2 GB disk | same | the PyTorch CPU build is enough |
| 2–5 Experiments | NVIDIA GPU with CUDA and ≥ 8 GB memory; ≥ 12 GB system RAM | T4-class 16 GB (the cost model's assumed reference) or better | L4/A100-class GPUs are faster; keep one GPU type per paired comparison |

**Peak GPU memory** (estimate, physical batch 4,096):
- FB15k-237, WN18RR, CoDEx-M: ≤ 2–3 GB.
- YAGO3-10: ≈ 3–5 GB. The update matrix alone is 592 MB, plus a sorted copy for robust aggregation, plus the gathered embedding rows.
- Lowering the physical batch reduces memory without changing the DP mechanism or ε.

**System RAM:** the filtered-evaluation index is roughly 0.1–0.2 GB for FB15k-237 and up to about 0.8 GB for YAGO3-10.

## 4. Time per run (minutes, assumed T4-class GPU, LOW–HIGH)

| Dataset | Non-private FedAvg (≤ 60 rounds, early stopping) | DP, design Q (100 rounds) | DP, design A (B = 512, 100 rounds) | Model size (fp32) |
|---|---|---|---|---|
| FB15k-237 | 5.9–19.6 | 3.1–33.3 | 10.4–35.4 | 5.9 MB |
| WN18RR | 2.2–7.6 | 2.6–32.7 | 4.0–14.1 | 16.4 MB |
| CoDEx-M | 4.1–13.7 | 2.7–31.6 | 7.2–24.8 | 6.8 MB |
| YAGO3-10 | 26.1–92.0 | 8.2–66.7 | 50.4–187.4 | 49.3 MB |

## 5. Totals (GPU-hours, LOW–HIGH)

| Profile | Third dataset | Stage 2 pilot | Stage 3 tuning | Stage 4 core | **Core total** | MIA M1 (D6) | Extended | Optional |
|---|---|---|---|---|---|---|---|---|
| **reduced** | **CoDEx-M** | 11 runs, 0.9–3.7 | 99 runs, 5.5–41.1 | 727 runs, 40.1–347.8 | **837 runs, 46.5–392.6** | 60 runs, 2.8–32.5 | 432 runs, 20.7–234.9 | 15 runs, 0.7–8.1 |
| reduced | YAGO3-10 | 11, 2.3–9.0 | 99, 12.4–70.9 | 727, 75.3–521.9 | 837, 90.0–601.8 | 60, 4.6–44.2 | 432, 34.9–322.5 | 15, 1.1–11.1 |
| full | CoDEx-M | 11, 0.9–3.7 | 99, 5.5–41.1 | 1,375, 72.0–676.6 | 1,485, 78.4–721.4 | 60, 2.8–32.5 | 594, 28.4–323.8 | 15, 0.7–8.1 |
| full | YAGO3-10 | 11, 2.3–9.0 | 99, 12.4–70.9 | 1,375, 134.6–998.9 | 1,485, 149.3–1,078.8 | 60, 4.6–44.2 | 594, 47.7–444.5 | 15, 1.1–11.1 |

- M1 has 5 seeds in **both** profiles, because it carries a hypothesis test (D6, D8).
- Using YAGO3-10 instead of CoDEx-M costs 57–332 GPU-h for that dataset versus 14–122 (2.7–4.2×), and 1.5–2× for the whole reduced core plan. Adding it as a *fourth* dataset on top of the CoDEx-M plan adds about 57–332 GPU-h.
- The robustness blocks R2–R4 are the largest single share of the core cost: 36–49 % in the reduced profile.

## 6. Low-cost execution strategy

**Options**, none of which is assumed to be yours:

| Option | What it offers | Constraints (checked 2026-10-28) |
|---|---|---|
| Kaggle Notebooks (free) | T4 / P100-class GPUs | sessions up to 12 h; the weekly GPU quota is shown in your account and is commonly reported as about 30 h, but Kaggle does not publish a fixed number |
| Google Colab (free) | GPU when available | "very limited" GPU access, sessions of at most 12 h, unpublished usage limits, interruptions when idle |
| A university or lab GPU | usually the most predictable | ask your supervisor or department |
| Paid Colab or a cloud GPU | predictable, pay per hour | only if you decide to spend |
| Your own computer (CPU) | Stages 0–1 and partition building | too slow for the experiments |

**Mechanics already in the revision, to keep** (the runner and Colab runbook):
- each run writes to its own folder and is skipped once complete;
- a checkpoint every 5 rounds, and an interrupted run resumes from it;
- `MAX_RUNS_THIS_SESSION` stops cleanly before a session limit;
- the results root lives on persistent storage (Google Drive, or Kaggle output saved as a dataset). Phase C adds Kaggle and local paths (G13);
- parallel sessions are safe only on **different datasets**.

**Added in Phase B:**
- record the GPU model in every run and keep each paired comparison on one GPU type;
- keep final model weights only for the main-table, schedule and MIA runs (§7);
- delete corruption-test object stores after analysis, keeping only their manifests.

**Priority order within Stage 4**, so that partial completion still gives usable evidence (reduced profile, CoDEx-M; `data/priority_cost.csv`). Stages 2–3 come first (110 runs, 6.4–44.8 GPU-h).

| Priority | Blocks | Answers | Runs | GPU-h | Cumulative GPU-h (incl. Stages 2–3) |
|---|---|---|---|---|---|
| 1 | N1, N2, DP1 and DP2 at ε* = 4, R1p (+ DP1h, DP2h in the full profile) | main table, H1, H2b, HS | 75 | 4.1–31.2 | 10.5–76.0 |
| 2 | R2, R2a, R3, R3a | H2 | 210 | 10.0–115.6 | 20.4–191.6 |
| 3 | L0–L4 | original vs revised (Table 13) | 31 | 4.5–14.5 | 24.9–206.1 |
| 4 | R1q | schedule inside the method (descriptive) | 15 | 0.7–8.1 | 25.6–214.3 |
| 5 | R1, R4, R5, R5a | baselines; trust without DP | 252 | 13.3–114.4 | 38.9–328.7 |
| 6 | DP1 at ε ∈ {1, 2, 8} (and DP2 there in the full profile), DP3, N3, I1, I2 | privacy–utility curve, DP-cost decomposition, heterogeneity, integrity | 144 | 7.6–63.9 | 46.5–392.6 |
| 7 | M1, only if D6 keeps H3 | H3 | 60 | 2.8–32.5 | 49.3–425.1 |
| 8 | Stage 5, as budget allows | sensitivity (descriptive) | 432 | 20.7–234.9 | 70.0–660.0 |

**What the budget means in time.** As an *example only*: at 30 GPU-hours per week (a figure often reported for Kaggle's free tier, not assumed to be yours), the reduced core with CoDEx-M takes about 1.6 weeks at the LOW bound and about 13 weeks at the HIGH bound. That spread is why the pilot comes first.

## 7. Storage

| Item | Size | Policy |
|---|---|---|
| Per-run records (config, final, accountant, rounds, trust, attack, logs) | assumed ≤ 0.5 MB per run: ≤ 0.67 GB for the 1,344 runs of the reduced plan (all tiers), ≤ 1.08 GB for the 2,154 runs of the full plan | keep all |
| Resume checkpoint (global + best model) | 2 × model size (FB15k-237 12 MB; YAGO3-10 99 MB) | deleted automatically when a run completes |
| Final model weights | kept only for N1, N2, DP1 and DP2 at ε* = 4, DP1h, DP2h, R1p, R1q and M1: 150 models ≈ 1.46 GB (reduced) or 225 models ≈ 2.18 GB (full), with CoDEx-M | keep |
| Integrity object store (I2) | a rolling window of 3 rounds × 11 objects × model size (FB15k-237 ≈ 0.2 GB; YAGO3-10 ≈ 1.6 GB per run) | transient: deleted after analysis; manifests kept |
| Dataset caches | ≈ 0.2 GB allowance | keep |
| **Planned persistent total** | **≤ 2.33 GB** (reduced, CoDEx-M) or ≤ 3.46 GB (full, CoDEx-M); 4.45 / 6.64 GB with YAGO3-10 | fits a free Google Drive quota if nothing else uses it |

## 8. Stage gates (declared in advance)

| Gate | Condition to continue | If it fails |
|---|---|---|
| G-A (after Stages 0–1) | all tests pass, **including the 26 PyTorch tests not yet run**; every block completes in smoke; schemas valid; every ε recomputed with RDP and PRV; resume works | fix in Phase C; nothing larger runs |
| G-B (after Stage 2) | measured seconds per round and peak memory recorded; cost model refitted; centralised non-private MRR passes the sanity check (`05_privacy_utility_plan.md` §2) | investigate the trainer; re-cost; you choose the profile and the third dataset with real numbers |
| G-C (after Stage 3) | selections complete for every dataset, frozen and hashed; D15 variant decided before τ* is selected; D10 trigger evaluated on validation | if triggered, you decide on one alternative |
| G-D (before Stage 4) | decisions approved; hypotheses frozen (hash in run configs); budget confirmed | no confirmatory run starts |

## 9. What would change this plan

- **If the measured cost is near the HIGH bound:**
  - use the reduced profile with CoDEx-M;
  - defer Stage 5;
  - accept R = 50 if T2c selects it;
  - run only the reduced robust-baseline grid (R4 with 4 attacks).
- **Never cut to save time:**
  - correct DP and accounting;
  - three datasets;
  - at least 5 seeds for every hypothesis test;
  - non-private references;
  - validation-only selection.

## Sources

- [Free cloud GPUs in 2026 — GPUPerHour (quotes Kaggle and Colab documentation, 21 Sep 2026)](https://gpuperhour.com/blog/free-cloud-gpus-and-credits)
