"""Phase C - local-file dataset loader (PyKEEN-identical ids, unseen-label handling, checksum binding, malformed
files), partition validity, and the pre-registered statistics (one-sided tests, log ratios, H2 contrast with its
testability gate, Holm families with fixed membership, one-run audit bound)."""
import json

import numpy as np
import pytest

from fedkge.data import build_artifact, load_artifact, map_like_pykeen, read_label_triples
from fedkge.io import IntegrityError, sha256_file
from fedkge.mia import one_run_eps_lower_bound, roc_metrics
from fedkge.partition import assign
from fedkge.stats import holm_family, log_ratio_test, one_sided_t, robustness_contrast


def _write_kg(d, train, valid, test):
    d.mkdir(parents=True, exist_ok=True)
    for name, rows in (("train", train), ("valid", valid), ("test", test)):
        (d / f"{name}.txt").write_text("".join("\t".join(r) + "\n" for r in rows))


def test_pykeen_identical_mapping_and_unseen_drop():
    tr = np.array([["b", "r2", "a"], ["c", "r1", "b"]], dtype=object)
    va = np.array([["a", "r1", "c"], ["z", "r1", "a"]], dtype=object)            # 'z' unseen in training
    te = np.array([["c", "r9", "a"], ["b", "r2", "c"]], dtype=object)            # relation r9 unseen
    t, v, e, ent, rel, drops = map_like_pykeen(tr, va, te)
    assert ent == ["a", "b", "c"] and rel == ["r1", "r2"]                        # sorted labels -> ids
    assert t.tolist() == [[1, 1, 0], [2, 0, 1]]
    assert drops == {"valid_dropped_unseen": 1, "test_dropped_unseen": 1}


def test_loader_binds_checksums_and_rejects_malformed(tmp_path):
    rows = [[f"e{i % 40}", f"r{i % 3}", f"e{(i % 40 + i // 40 + 1) % 40}"] for i in range(200)]   # unique triples
    _write_kg(tmp_path / "data" / "wn18rr", rows[:160], rows[160:180], rows[180:])
    man = {"files_sha256": {f"{k}.txt": sha256_file(tmp_path / "data" / "wn18rr" / f"{k}.txt")
                            for k in ("train", "valid", "test")}}
    (tmp_path / "data" / "wn18rr" / "source_manifest.json").write_text(json.dumps(man))
    m = build_artifact({"name": "wn18rr", "source": "local_files"}, tmp_path / "p1", data_dir=tmp_path / "data")
    d = load_artifact(tmp_path / "p1")
    card = json.loads((tmp_path / "p1" / "dataset_card.json").read_text())
    assert card["load_info"]["raw_counts"]["train"] == 160 and len(d.train) == 160
    with open(tmp_path / "data" / "wn18rr" / "test.txt", "a") as f:
        f.write("x\ty\tz\n")                                                      # file changed after fetching
    with pytest.raises(IntegrityError):
        build_artifact({"name": "wn18rr", "source": "local_files"}, tmp_path / "p1b", data_dir=tmp_path / "data")
    (tmp_path / "bad.txt").write_text("a\tb\n")
    with pytest.raises(IntegrityError):
        read_label_triples(tmp_path / "bad.txt")


def test_size_matched_synthetic_generator():
    """Timing stand-in only: exact sizes, unique triples across splits, full train coverage, determinism."""
    from fedkge.data import make_synthetic_sized, validate_splits
    tr, va, te, ent, rel = make_synthetic_sized(3001, 13, 20000, 900, 1100, seed=5)
    assert (len(tr), len(va), len(te), len(ent), len(rel)) == (20000, 900, 1100, 3001, 13)
    allt = np.vstack([tr, va, te])
    assert len({tuple(x) for x in allt.tolist()}) == len(allt) and not (allt[:, 0] == allt[:, 2]).any()
    assert len(np.union1d(tr[:, 0], tr[:, 2])) == 3001 and len(np.unique(tr[:, 1])) == 13
    assert validate_splits(tr, va, te, 3001, 13)["errors"] == []
    again = make_synthetic_sized(3001, 13, 20000, 900, 1100, seed=5)
    assert all(np.array_equal(a, b) for a, b in zip((tr, va, te), again[:3]))
    with pytest.raises(ValueError):
        make_synthetic_sized(100, 5, 40, 10, 10)


def test_smoke_subset_keeps_n_train_and_caps_only_eval():
    """Defect PC-1 (found on the real data in Phase C): the smoke subset cut the TRAINING split to n_eval."""
    from fedkge.data import _subset, make_synthetic_sized
    tr, va, te, ent, rel = make_synthetic_sized(2000, 12, 20000, 3000, 3000, seed=1)
    s_tr, s_va, s_te, s_ent, s_rel = _subset(tr, va, te, ent, rel, n_train=3000, n_eval=300, seed=0)
    assert len(s_tr) == 3000 and 0 < len(s_va) <= 300 and 0 < len(s_te) <= 300
    seen_e = set(s_tr[:, 0]) | set(s_tr[:, 2])
    for a in (s_va, s_te):                                   # eval triples only use entities/relations seen in train
        assert set(a[:, 0]) | set(a[:, 2]) <= seen_e and set(a[:, 1]) <= set(s_tr[:, 1])
    assert s_tr[:, [0, 2]].max() < len(s_ent) and s_tr[:, 1].max() < len(s_rel)        # compact re-indexing
    again = _subset(tr, va, te, ent, rel, n_train=3000, n_eval=300, seed=0)
    assert all(np.array_equal(x, y) for x, y in zip((s_tr, s_va, s_te), again[:3]))


@pytest.mark.parametrize("alpha", [0.1, 0.5, 1.0])
def test_dirichlet_partition_valid_deterministic(alpha):
    rng = np.random.default_rng(0)
    train = np.stack([rng.integers(0, 500, 6000), rng.integers(0, 11, 6000), rng.integers(0, 500, 6000)], 1)
    spec = {"scheme": "dirichlet_relation", "n_clients": 10, "alpha": alpha, "min_client_frac": 0.2,
            "min_client_abs": 50, "max_attempts": 20000}
    a, b = assign(train, spec, 7), assign(train, spec, 7)
    assert np.array_equal(a["client"], b["client"]) and a["attempts"] == b["attempts"]
    sizes = np.bincount(a["client"], minlength=10)
    assert sizes.sum() == len(train) and sizes.min() >= a["min_size"] and set(a["client"]) == set(range(10))


def test_one_sided_and_log_ratio():
    r = one_sided_t(np.array([0.1, 0.2, 0.15, 0.12, 0.18]), "greater")
    assert r["p_one_sided"] < 0.025 and r["bound_97_5"] > 0
    lr = log_ratio_test({1: 0.30, 2: 0.31, 3: 0.29, 4: 0.30, 5: 0.32}, {1: 0.31, 2: 0.31, 3: 0.30, 4: 0.31, 5: 0.32}, 0.9)
    assert lr["p_one_sided"] < 0.025 and 0.9 < lr["ratio_geo_mean"] < 1.01
    with pytest.raises(ValueError):
        log_ratio_test({1: 0.3}, {2: 0.3}, 0.9)


def test_h2_contrast_gate_and_holm_family_fixed_membership():
    ineffective = robustness_contrast({1: 0.0, 2: 0.01, 3: -0.01, 4: 0.0, 5: 0.005},
                                      {1: 0.0, 2: 0.0, 3: 0.0, 4: 0.0, 5: 0.0})
    assert ineffective["testable"] is False and ineffective["p_one_sided"] == 1.0
    eff = robustness_contrast({1: 0.10, 2: 0.12, 3: 0.11, 4: 0.09, 5: 0.10}, {1: 0.01, 2: 0.02, 3: 0.0, 4: 0.01, 5: 0.02})
    assert eff["testable"] and eff["E_ratio_of_means"] > 0.35 and eff["p_one_sided"] < 0.025
    fam = holm_family({"fb:alie": eff["p_one_sided"], "wn:alie": None, "cx:alie": ineffective["p_one_sided"]})
    assert len(fam) == 3 and fam["wn:alie"]["p"] == 1.0 and fam["fb:alie"]["p_holm"] == min(1.0, 3 * eff["p_one_sided"])


def test_one_run_bound_behaviour():
    rng = np.random.default_rng(0)
    member = rng.random(4000) < 0.5
    noise_scores = rng.normal(size=4000)
    lb0 = one_run_eps_lower_bound(noise_scores, member, 1000, 1e-6, 0.05 / 3)
    assert lb0["eps_lb"] < 0.3                         # a non-informative attack proves (almost) nothing
    perfect = member.astype(float) + 0.01 * rng.normal(size=4000)
    lb1 = one_run_eps_lower_bound(perfect, member, 1000, 1e-6, 0.05 / 3)
    assert lb1["accuracy"] == 1.0 and lb1["eps_lb"] > 3.0
    m = roc_metrics(perfect, member)
    assert m["auc"] > 0.99 and m["tpr_at_fpr_1pct"] > 0.99
