# Parallel GPU execution guide (practical)

This guide is for running the approved study on **several GPU environments at once**. The design and the reasons behind it are in `PARALLEL_ARCHITECTURE.md`.

**Nothing has run yet.** The package contains no research result. You start every job yourself.

---

## 0. Do you need this at all? 🎯

| You have | Use | Why |
|---|---|---|
| **1 GPU environment** | the single notebook `RUN_COMPLETE_FEDKGE_RESEARCH.ipynb` (`EXECUTION_GUIDE.md`) | The parallel layer cannot be faster on one GPU. It only adds file hand-overs |
| **2 or more GPU environments you may use at the same time** | this guide | ≈ 60 h with 2 identical T4s, ≈ 40 h with 3, ≈ 30 h with 4 (estimates, section 7) |

**Honest limits:**
- **Colab:** whether one account may run several GPU sessions at the same time depends on your plan. Do **not** use several accounts to get around Colab's limits; Colab does not allow it. Count only environments you are really entitled to use, for example:
  - a paid Colab plan that allows more than one session;
  - a lab or university GPU server;
  - a machine with two GPUs (one worker per GPU);
  - a cloud VM.
- **Mixing GPU types or torch builds** is allowed only *between* datasets, never inside one dataset's comparison (section 1).

---

## 1. Three rules that keep the science intact 💪

1. **One environment per (tier, dataset).** Every run of, for example, FB15k-237's main experiments must come from one environment class: the same GPU name, torch build, CUDA and Python minor version. The plan respects this automatically, and the master refuses anything else. Two T4 sessions with the same torch build are one class.
2. **Each worker writes only into its own folder.** Results travel only as verified bundles and packs, never by copying run folders by hand.
3. **Never run two sessions with the same worker name at the same time.** Different worker names may run simultaneously.

---

## 2. What you need

- **A shared folder `BASE`**, e.g. `MyDrive/FedKGE` on Google Drive. Every Colab session of one Google account sees the same Drive. Environments without that Drive use a manual copy (section 6).
- **The package** `FedKGE_PARALLEL_GPU_EXECUTION.zip` in `BASE`, unchanged. Every session verifies its git commit and the code hashes.
- **The two notebooks** from the zip:
  - `FEDKGE_PARALLEL_WORKER.ipynb`: one copy per GPU environment;
  - `FEDKGE_PARALLEL_MASTER.ipynb`: one, CPU is enough.
- **For terminals** (lab server, cloud VM):
  ```bash
  cd FedKGE_PARALLEL_GPU_EXECUTION/revision
  bash parallel/setup_environment.sh        # pinned packages (keeps the platform's torch)
  export FEDKGE_PARALLEL_BASE=/path/to/shared/folder
  ```

---

## 3. The whole procedure in order

| Step | Where | Notebook cell / command | Wait for |
|---|---|---|---|
| 1 | each GPU environment | WORKER cells 1–3: settings (unique `WORKER_NAME`), setup, **register** | `registered: …/worker_<name>.json` |
| 2 | each GPU environment | WORKER cell 4: datasets and artifacts | `EXIT 0`, P1 hashes printed |
| 3 | master | MASTER cells 1–3: settings, setup, datasets and **master artifacts** | `EXIT 0` |
| 4 | master | MASTER cell 4: **plan** (after every worker registered) | `PLAN: … jobs`; read `exchange/plan/PLAN.md` |
| 5 | each GPU environment | WORKER cell 5: **run my queue** | `QUEUE COMPLETE`, or `PAUSED or waiting for the master` |
| 6 | master | MASTER cell 5: **master cycle** (import → selections, freeze, releases → validation) whenever bundles arrive | `validation: …` |
| 7 | repeat 5 and 6 | until the validation says **COMPLETE AND COMPATIBLE** | |
| 8 | master | MASTER cells 6–7: analysis, report, export | `RESULTS_DRAFT.md`, export zip |

**Every later session:**
- worker: cells 1, 2, 4 (minutes), then 5;
- master: cells 1, 2, 3, then 5.

Finished runs never run twice, and an interrupted run resumes from its checkpoint.

---

## 4. Phase by phase

| Phase | File (`revision/parallel/phases/`) | GPU? | Install | Input artifacts | Command | Expected output | Success check | Saved in | Next |
|---|---|---|---|---|---|---|---|---|---|
| 00 | `phase00_register_worker.py` | checks it | `setup_environment.sh` or notebook setup | package | `--base B --worker W --device cuda --speed 1.0` | `exchange/registry/worker_W.json` | `EXIT 0` | `BASE/exchange/registry` | 01 |
| 01 | `phase01_prepare_data.py` | no | as above | licence note | `--base B --data-dir B/data_cache [--i-confirm-licence --operator-note "…"]` | `data_cache/<ds>/source_manifest.json` | `EXIT 0`, "pinned checksums OK" | `BASE/data_cache` (never exchanged) | 02 |
| 02 | `phase02_build_artifacts.py` | no | as above | data | `--base B --worker W --data-dir B/data_cache` (or `--master`) | `<root>/{tune,final}/artifacts`, `ARTIFACT_HASHES.json` | `EXIT 0` | the worker's or master's root | 04/07 or 08 |
| 03 | `phase03_plan_jobs.py` | no (master) | as above | all registrations | `--base B [--tune-mode chain] [--sync-hours 0.25]` | `PLAN.json/md`, `jobs/`, `QUEUE_<W>.md` | `EXIT 0` | `BASE/exchange/plan` | 04, 07 |
| 04 | `phase04_tuning.py` | **yes** | as above | plan; stage mode: release pack | `--base B --worker W --job T-<ds>-chain --max-hours H` | tune runs + bundle | `EXIT 0` (3 = budget; 4 = gate failed) | `BASE/workers/W`, bundle in `exchange/outbox` | 08 → 05 |
| 05 | `phase05_select_freeze_release.py` | no (master) | as above | imported tune runs | `--base B` | selections, gate, τ, D10, `FROZEN.json`, packs | `SEL-<ds>-…: DONE` | `BASE/master`, packs in `exchange/packs` | 06 (or next stage) |
| 06 | `phase06_main_experiments.py` | **yes** | as above | release pack of the dataset | `--base B --worker W --job M-<ds>-p<p>-<i>of<n> --max-hours H` | final runs + bundle | `EXIT 0` | worker root, outbox | 08 |
| 07 | `phase07_replications.py` | **yes** | as above | plan | `--base B --worker W --job L-fb15k237-<i>of<n> --max-hours H` | final runs + bundle | `EXIT 0` | worker root, outbox | 08 |
| 08 | `phase08_import_results.py` | no (master) | as above | bundles | `--base B` | master runs, `IMPORT_LEDGER.json`, `PROGRESS.md` | no REFUSED lines | `BASE/master` | 05, 09 |
| 09 | `phase09_validate.py` | no (master) | as above | master store | `--base B [--schemas]` | `VALIDATION_REPORT.md`, `RERUN_LIST.csv` | `EXIT 0` = complete; 2 = incomplete; 1 = problem | `BASE/master/results/parallel` | 10 or reruns |
| 10 | `phase10_analysis.py` | no (master) | as above | master store | `--base B` | `final/analysis/` | hypothesis table printed | `BASE/master` | 11 |
| 11 | `phase11_report_export.py` | no (master) | as above | master store | `--base B [--l0-checkpoint …]` | reports, figures, export zip | `RESULTS_DRAFT.md`; `EXPORT:` line | `BASE` | — |

**Shortcuts:**
- `run_worker_queue.py --base B --worker W --max-hours H` runs a worker's planned jobs in order (phases 04/06/07), skipping finished ones and jobs that still wait for a release.
- `master_cycle.py --base B [--watch-minutes N]` runs 08 → 05 → 09.

**Exit codes (every phase):**

| Code | Meaning |
|---|---|
| 0 | complete |
| 1 | run failures, retried on the next call |
| 3 | session budget used, or waiting for the master: run again |
| 4 | gate G-B failed: stop that dataset |
| 5 | environment mismatch |
| 6 | manifest mismatch |
| 7 | input contract violated: a pack or selection disagrees |

---

## 5. Sample execution plans

These are estimates from the T4 upper bounds, with 0.25 h hand-overs (`revision/parallel/PLAN_EXAMPLES.md`). **Your real plan is whatever `phase03` prints for the workers you registered.** After the first jobs, run `phase03 --measured` to re-plan with measured times.

### 1 GPU: ≈ 119 h
Use `RUN_COMPLETE_FEDKGE_RESEARCH.ipynb`. The parallel layer would also take ≈ 119 h.

### 2 GPUs (same class, e.g. two T4 sessions with the same torch): ≈ 60 h

| GPU | Starts with | Then | Est. busy |
|---|---|---|---|
| GPU1 | `T-codex_m-chain`, then `T-wn18rr-chain` | Stage-4 shards of all datasets as they are released, plus 1 legacy shard | ≈ 59.5 h |
| GPU2 | `T-fb15k237-chain` | Stage-4 shards, plus 1 legacy shard | ≈ 59.4 h |

Freezes are estimated at ≈ 4.3 h (CoDEx-M), ≈ 4.8 h (FB15k-237) and ≈ 8.7 h (WN18RR, tuned second on GPU1).

### 3 GPUs (same class): ≈ 40 h

| GPU | Starts with | Then |
|---|---|---|
| GPU1 | `T-codex_m-chain` | legacy shards, then Stage-4 shards |
| GPU2 | `T-fb15k237-chain` | Stage-4 shards |
| GPU3 | `T-wn18rr-chain` | a legacy shard, then Stage-4 shards |

All three datasets are frozen after ≈ 4.3–4.8 h. After that, all three GPUs work through the priorities 1 → 7 of every dataset.

### 4 GPUs (same class): ≈ 30 h
- GPU1–GPU3 each start one tuning chain.
- GPU4 starts with the legacy replications, then joins Stage 4.
- Each GPU ends after ≈ 29.8 h.

### Unequal GPUs (speed factors here are hypothetical inputs)

| Workers | Est. completion | What the planner does |
|---|---|---|
| 2 T4 + 1 GPU twice as fast | ≈ 35 h | The fast GPU takes CoDEx-M and WN18RR; the two T4s take FB15k-237 (tuning, Stage 4, legacy) |
| 1 T4 + 1 T4 with **another torch build** | ≈ 70 h (instead of ≈ 60) | They are two classes, so each dataset's Stage 4 stays on one of them. Keep torch builds equal if you can |
| T4 + 1.5× GPU + 3× GPU | ≈ 26 h | Each class gets whole groups; the T4 only tunes FB15k-237 |

**Unequal memory:** the measured pilot peak was ≤ 1.4 GB per run. Any GPU with ≥ 8 GB can take any job, so memory never limits the plan.

---

## 6. Environments that cannot see the shared Drive

Run the same scripts with a local `--base` folder, and copy files by hand. Never copy run folders.

| Direction | Copy | From → to |
|---|---|---|
| worker → master | the worker's registration | `exchange/registry/worker_<W>.json` → master `BASE/exchange/registry/` |
| master → worker | the plan | `exchange/plan/` (whole folder) → worker `BASE/exchange/plan/` |
| master → worker | new release packs | `exchange/packs/release_*.zip` **and** their `.zip.sha256` → worker `BASE/exchange/packs/` |
| worker → master | new result bundles | `exchange/outbox/*.zip` **and** their `.zip.sha256` → master `BASE/exchange/outbox/` |

Always copy the sidecar `.sha256` **after** the zip. A zip without a matching sidecar is ignored until it arrives intact.

---

## 7. Checking progress and completion

- **Master:**
  - `BASE/master/results/PROGRESS.md` (every approved cell);
  - `BASE/master/results/parallel/VALIDATION_REPORT.md`;
  - `RERUN_LIST.csv`, which lists the job and planned worker of every missing cell.
- **Worker:**
  - `BASE/workers/<W>/results/parallel/receipts/<job>.json` (exit code and run statuses);
  - the bundles in `exchange/outbox/`.
- **The study is complete** when `phase09_validate.py` exits 0: *COMPLETE AND COMPATIBLE*.
- **Partial results** can be analysed at any time. Families become final when their blocks are complete: H1, H2b and HS after priority 1 of all three datasets, H2 after priority 2, H3 after priority 3.

---

## 8. Recovery (parallel-specific)

| Situation | What you see | What to do |
|---|---|---|
| Session ended or PAUSED | EXIT 3 | Next session: worker cells 1, 2, 4, then 5. The same job continues the same runs |
| A job waits for the master | `not startable yet - … waits for its release` | Run the master cycle; the worker picks the job up next time |
| Bundle REFUSED: environment | `environment of final/<ds> differs …` | Rerun that job on a worker of the recorded class. If that class no longer exists (e.g. after a Colab torch update), the whole group must be restarted. Ask before you do that |
| Bundle REFUSED: data hash | `data hash … differs` | Run phase 01–02 on the master, or check that this environment downloaded the pinned bytes |
| Bundle REFUSED: STALE_SELECTION | the worker used other selection values | Should not happen with packs. Send the bundle and the log |
| Conflict quarantined | phase 09: `QUARANTINED_DUPLICATE_EXECUTION` | One run was executed twice. The first copy is used; nothing to do, but find out why (two sessions with one worker name?) |
| EXIT 7 at a job | a pack or selection disagrees | Do not edit any file. Re-copy the newest pack (with its sidecar) |
| Gate G-B FAILED | phase 05: `GATE_FAILED` | Stop that dataset; see `EXECUTION_GUIDE.md`, "Gate G-B failed" |
| A worker disappears for good | its jobs stay unstarted or INCOMPLETE | Re-plan (`phase03`) with the remaining workers. Its unstarted jobs move to another worker of the **same** class. An INCOMPLETE run must be resumed by a worker of that class, from that worker's folder, or restarted from round 1 elsewhere; both are the same experiment |
