#!/usr/bin/env python3
"""One master cycle = phase 08 (import) -> phase 05 (selections, freeze, releases) -> phase 09 (validation).

  python parallel/phases/master_cycle.py --base B [--watch-minutes 0] [--analysis]

Run it whenever a worker has produced a bundle; it does everything that has become possible and nothing else.
--watch-minutes N repeats the cycle every 5 minutes for N minutes (e.g. in a CPU session on the shared folder while
the workers run). --analysis also runs phase 10 and 11 (without the export) at the end of the last cycle.
"""
from __future__ import annotations

import sys
import time

from _cli import layout, parser

from fedkge_parallel.common import frozen_manifest
from fedkge_parallel.master_flow import advance
from fedkge_parallel.store import Master
from fedkge_parallel.validate import validate_store


def cycle(L, mode) -> dict:
    m = Master(L, mode)
    s = m.import_all()
    print(f"import: {len(s['imported'])} bundle(s) imported, {len(s['refused'])} refused, "
          f"{s['skipped_known']} known, {len(s['not_yet_verifiable'])} not yet verifiable")
    for r in s["refused"]:
        print(f"  REFUSED {r['bundle']}: {r['reason']}")
    for x in advance(m):
        print(f"{x['step']}: {x['status']}" + (f" - {x.get('why', '')[:200]}" if x["status"] != "DONE" else ""))
    if mode == "research":
        from fedkge.manifest import write_progress
        write_progress(m.root, frozen_manifest())
    rep = validate_store(L, mode)
    print(f"validation: {rep['verdict']} {rep['cells_by_status']}")
    return rep


def main(argv=None) -> int:
    ap = parser(__doc__)
    ap.add_argument("--watch-minutes", type=float, default=0.0)
    ap.add_argument("--analysis", action="store_true")
    a = ap.parse_args(argv)
    L = layout(a)
    t0 = time.time()
    while True:
        rep = cycle(L, a.mode)
        if rep["exit_code"] == 0 or (time.time() - t0) / 60 >= a.watch_minutes:
            break
        time.sleep(300)
    if a.analysis:
        import phase10_analysis
        import phase11_report_export
        phase10_analysis.main(["--base", str(L.base), "--mode", a.mode])
        phase11_report_export.main(["--base", str(L.base), "--mode", a.mode, "--no-export"])
    return rep["exit_code"]


if __name__ == "__main__":
    sys.exit(main())
