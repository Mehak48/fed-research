# Phase C — privacy implementation audit

**Date:** 2026-11-02 · **Scope:** the privacy model, its match with the code, the accountant, its validation, and the legacy utility gap.
**Companion:** `revision/13_documentation/DP_MECHANISM.md` (manuscript-level statement).
**Labels:**

- **[Calculated]**: computed from parameters, not from training.
- **[Measured]**: produced by executing the code.
- **[Reproduced]**: a historical artifact re-evaluated.

No number here is a utility result of the revised method. No full-length private run has been executed yet.

---

## 1. Privacy model (Phase C instructions §5.1)

| Item | Definition in the implementation |
|---|---|
| Protected unit | One training triple (h, r, t) of one client. |
| Neighbouring relation | **Zero-out.** D′ equals D, except that one triple is replaced by a null record ⊥ whose loss and gradient are identically zero. |
| Fixed record slots, public sizes | Yes. Client k's record count N̂_k includes null records, is fixed before training and is public. It is used for the FedAvg weights, the normaliser q·N̂_k and, in design A, for q_k = B/N̂_k and T_k = round(N̂_k/B). N̂_k is the same for D and D′, so publishing it reveals nothing about the protected triple. Under add/remove adjacency it would (defect CR-14), so add/remove is **not** the relation claimed. |
| Adversary | The server, every other client, and anyone who sees the transmitted updates and the final model. They may know every other record. The guarantee covers, for each client, the whole sequence of its transmitted updates over all executed rounds. |
| Clipping and sensitivity | Per-example clipping to L2 norm C. One example is the triple plus its k negatives, and its gradient is taken over **all** parameters. Rows of an entity that occurs several times are summed **before** the norm. A non-finite per-example gradient is set to 0, so the bound still holds. Zero-out sensitivity of the clipped sum: C. |
| Sampling | Poisson. Each record is included independently with probability q in every step. Design Q: a common q, T = round(1/q) steps per round. Design A: q_k = 512/N̂_k, T_k = round(N̂_k/512). |
| Noise | N(0, σ_t²C²I) added to the clipped sum on **every** coordinate (dense), then divided by the public expected batch q·N̂_k. σ_t = σ₀·g(t): a deterministic, data-independent schedule fixed before training. |
| Optimiser and privacy-relevant steps | The model starts from a seeded, data-independent initialisation; warm starts are rejected by config validation. Each round, Adam starts with fresh state and takes T steps on the noisy gradients (post-processing). The client then sends u = θ_local − θ_received. Clients that reject a broadcast (failed verification or non-finite values) execute 0 steps that round. |
| Accounting and composition | RDP of the Poisson-subsampled Gaussian mechanism (`dp_accounting`), composed per client over the steps it **actually executed** with the executed σ_t, and converted to (ε, δ). The reported ε is max_k ε_k (worst client). Cross-checks: the public-API zero-out accountant (must be equal), PLD, and PRV (a different library). |
| δ | 10⁻⁶ primary; 10⁻⁵ also reported (historical comparison). δ·max_k N̂_k is recorded. On the full data (α = 0.1) the largest client holds ≈ 43,000 FB15k-237 triples, so δ·N̂ ≈ 0.04 and δ < 1/N̂_k for every client. |
| Data-dependent selection | See the list below. |

**Data-dependent selection: what is covered and what is not.**

- **Best-checkpoint selection:** post-processing. It uses V_es, a subset of the benchmark validation split, held by the server and assumed not to be client data. DP runs never stop early.
- **τ selection and the V1 trigger:** post-processing of noisy updates, done on the tuning seed.
- **Hyperparameter tuning:**
  - It uses the same private training data, and **its privacy cost is not accounted.**
  - It is disclosed, with OP-2 (Papernot & Steinke 2022) as the alternative.
  - The partition's rejection sampling depends on relation counts. These are dataset-level properties and are not covered.

## 2. Does the code satisfy the zero-out relation? (verified against the actual code)

The instruction warns that zero-out is not valid just because the record count is constant. The conditions that make the Poisson-subsampled Gaussian analysis apply were each checked in the code:

| Condition | Where | Evidence |
|---|---|---|
| The null record contributes nothing whether sampled or not | `dp.per_example_clipped_sum`; audit-pool exclusions are removed from the client's array, which is distributionally identical under Poisson sampling | `test_zero_out_sensitivity_of_implemented_sum`: replacing one example by a null record changes the clipped sum by ≤ C |
| The normaliser is data-independent | `dp.dp_local_train`: `grad = G / expected_batch`, with expected_batch = q·N̂_k (public) | Code reading; `expected_batch` recorded in the round stats |
| Per-example (not per-batch) clipping over all parameters | `dp.per_example_clipped_sum` | `test_dp_clipping.py`: equals Opacus `GradSampleModule` and brute-force per-example autograd |
| Dense noise (no sparsity leak of which entity rows a batch touched) | `dp.dp_local_train` | `test_noise_is_dense_and_scaled` |
| Non-finite values cannot break the bound | `dp.per_example_clipped_sum` (zeroing); `federated` (clients reject non-finite or unverified broadcasts) | `test_non_finite_example_is_zeroed_and_others_unchanged` |
| No data-dependent stopping | DP runs execute all R rounds (`es_on = early_stopping and not dp_on`) | `test_phaseC_pipeline.py` |
| ε over the steps actually executed | `steps_exec[c][r]`; a skipped round is 0 steps | `test_skipped_rounds_only_reduce_epsilon` |
| Negatives are independent of other records | `sampling.py` (corrupt one side uniformly; never the positive) | `test_correct_negatives_never_copy_positive_and_corrupt_one_side` |
| One σ for all clients in design Q; executed σ trace = configured schedule | `accountant`, `federated` (`schedule_verified`) | `test_design_q_rates_and_common_sigma` |

**Conclusion:** the implemented mechanism is the Poisson-subsampled Gaussian mechanism applied to a sum whose zero-out sensitivity is C, with a public normaliser. The add/remove RDP analysis (Mironov, Talwar & Zhang 2019) therefore applies to zero-out neighbours. `dp_accounting` implements exactly this as `NeighboringRelation.REPLACE_SPECIAL`, and every DP run asserts that its runtime ε equals the public-API value.

## 3. What the guarantee does **not** protect

This list is recorded in every `accountant.json` (`not_covered`):

- **Entity-level privacy.** An entity that appears in g triples gets only group privacy, which is vacuous for g ≥ 4 at ε = 4.
- **Client-level privacy and participation.** Not claimed.
- **Client sizes N̂_k.** These are public.
- **Dataset-level properties**, such as which relations a client mostly holds.
- **Duplicated or correlated facts.**
- **The privacy cost of hyperparameter tuning.** Disclosed, not accounted.
- **Floating-point and PRNG side channels**, beyond the non-finite guard.
- **The server's validation data.** Assumed not to be client data.

## 4. Accountant implementation and cross-checks

`fedkge/accountant.py`:

| Function | Role |
|---|---|
| `composed_rdp` | Run-time RDP |
| `rdp_epsilon_public_api` | Zero-out public-API equality check |
| `pld` | PLD cross-check |
| `prv_epsilon` | PRV cross-check (prv-accountant 0.2.0) |
| `dp_steps_common_rate` | Design Q |
| `calibrate_sigma0` | Bisection; σ is rounded up |

**ε is never hard-coded.** σ₀ is the smallest value for which the executed configuration gives ε(R) ≤ ε\*, and ε is then recomputed from the executed steps.

**Validation over the operating grid** (`scripts/check_privacy_accounting.py`):

- 96 points: ε\* ∈ {1, 2, 4, 8} × δ ∈ {10⁻⁶, 10⁻⁵} × designs A and Q × three datasets' sizes;
- each point is calibrated by the runtime code, then its ε is computed five ways **[Measured]**.

| Check | Result (run 2, 2026-10-28; run 3 with the project venv, 2026-11-02: identical) |
|---|---|
| Runtime RDP vs `dp_accounting` public zero-out API | max \|Δ\| = 1.15 × 10⁻¹⁴ |
| Own numerical quadrature of the Rényi divergence (no `dp_accounting`) | never above runtime ε (minimum runtime − own = −3.3 × 10⁻⁹, within quadrature error); runtime at most 0.143 % higher |
| PLD / RDP | 0.914–0.936 (PLD tighter, as expected) |
| PRV upper bound | ≤ RDP at every point |
| Gaussian mechanism, closed form (q = 1) | error 0 |
| Legacy per-round log (Phase A) | reproduced, max \|Δ\| = 4.05 × 10⁻⁷ |
| Legacy worst client, valid RDP over 16 rounds, δ = 10⁻⁵ | **ε = 1.98054** (the paper reported 15.53 from an invalid naive sum) |
| Failed checks | **0 of 96 points** |

**Why the runtime ε is slightly conservative:** `dp_accounting` is exact at integer orders and an upper bound at fractional orders, so the reported ε is never too small.

**Honest note:** the first validation run (manifest `20261028T164547Z_privacy_accounting.json`, status CHECKS_FAILED) flagged 1 check. The cause was a direction error in my check, which treated the conservative direction as a failure. The check was corrected; the result is in the table above. The first run's CSV was overwritten by the second; the script now timestamps every output.

**Edge cases** (`test_accountant_edge_cases_raise`, `test_small_client_fails_loudly`) raise errors for:

- q ∉ (0, 1);
- size < 1;
- design A with B ≥ N̂_k (the small-client failure, MJ-16).

Also tested:

- pure-noise (empty) clients;
- the σ = 0 ablation, which writes `privacy_ablation` and never `privacy`;
- heterogeneous schedules.

**Requested ε reachable?** Yes. Every target in the grid is met by calibration, so there is no discrepancy to report. Whether utility at these ε is acceptable is a Stage 3–4 question, with the D10 trigger.

## 5. Executed on the real data (smoke tier) [Measured]

| Run (FB15k-237 subset, 3 rounds) | Sampling design | ε worst client (δ = 10⁻⁶) | Public-API equality | `schedule_verified` |
|---|---|---|---|---|
| `dp_q` | Q (q = 0.1) | 3.99693 | equal | true |
| `dp_a` | A (B = 32 in smoke) | 3.99956 | equal | true |

The same holds on WN18RR and CoDEx-M. Smoke runs use 3,000 training triples and 3 rounds. They show the code path, **not** utility.

## 6. Remaining privacy-relevant work

- Full-length private runs: tuning chain (Stage 3), then confirmatory blocks DP1/DP2/DP3.
- Utility at ε ∈ {1, 2, 4, 8}.
- The DP3 no-noise decomposition.
- M1 audit lower bounds on real models.
- PLD and PRV cross-checks are switched off in the smoke tier only. They are on in the pilot, tune and final tiers.

## 7. Warm start and initialisation

- The legacy warm start from the non-private model is not used.
- The key `train.warm_start` is rejected by validation (`test_invalid_configs_fail_loudly[warm_start]`).
- Every run starts from the seeded random initialisation (`model.init_params`).
- Private and non-private runs of the same seed start from the **same** initial parameters.

## 8. The 0.009 vs 0.2858 gap — what is known now

**(a) The comparison was confounded** (verified in the legacy code; `reference/legacy_code_extracted` in the handoff package):

| Setting | Legacy P3 (non-private, 0.2858) | Legacy P4 (DP, 0.009) |
|---|---|---|
| Entity normalisation | yes | **no** |
| Negatives | 1 per triple | 1 per triple, with 25 % identical to the positive (zero gradient) |
| Local epochs × rounds | 3 × 50 | 1 × 16 (stopped by the invalid naive-sum rule) |
| Batch | 512 | 256 (Poisson, `drop_last`) |
| Clipping / noise | `clip_grad_norm` 1 | C = 1, σ = 1 |
| Evaluation | 300 random test triples | 150 random test triples |

Both evaluations were tail-only with optimistic ties, on the last-round model. The claimed warm start was not actually loaded.

**(b) Signal to noise [Calculated, Phase A].** With dense noise on all 1.47 M parameters, the noise norm on the averaged gradient is σC√P/B ≈ 4.74 at B = 256, against a clipped-signal norm ≤ 1. Adam's per-coordinate scaling turns pure noise on untouched rows into steps of about the learning rate. This is a hypothesis; DP3 and the tuning grid test it.

**(c) The non-private reference itself was protocol-inflated — L0 [Reproduced].**

- **Method:** the saved legacy P3 model (`complete/global_transe_final.pt`) was re-evaluated with no training.
  - Its SHA-256 `c29aa45b…` matches the Phase A inventory, so the file is unchanged.
  - Its vocabulary is identical to the PyKEEN mapping (14,505 × 100 entities, 237 relations).
- **Output:** `results/phaseC/pilot/L0_legacy_checkpoint_eval.json`.

| Protocol | MRR | Hits@1 | Hits@3 | Hits@10 |
|---|---|---|---|---|
| Corrected: full filtered test, head + tail, realistic ties (40,876 queries) | **0.197** (95 % CI 0.194–0.200) | 0.123 | 0.218 | 0.340 |
| Corrected, tail only | 0.268 | 0.176 | 0.302 | 0.446 |
| Corrected, head only | 0.126 | 0.070 | 0.133 | 0.235 |
| Corrected, validation V_sel, head + tail | 0.202 | 0.128 | 0.224 | 0.347 |
| Legacy protocol (300 random test triples, tail only, optimistic ties), 5 draws | 0.280, 0.241, 0.253, 0.240, 0.253 | | | |
| Historical reported value | 0.2858 (one draw, last round) | | | |

**Reading:**

- The historical 0.2858 measures **tail prediction on a small random sample**.
- The same model scores **0.197 under the corrected protocol**. That is the honest non-private legacy reference for FB15k-237 with 5 relation-chunk clients.
- No ties occurred, so the optimistic-tie issue did not change this model's numbers.
- Any utility-retention claim must use the corrected protocol on both sides.

**(d) Still to measure** (blocks L1–L4 and DP3, Stage 4): how much of the remaining DP gap is caused by:

- the noise itself;
- clipping;
- the training budget;
- the legacy model and negative defects.
