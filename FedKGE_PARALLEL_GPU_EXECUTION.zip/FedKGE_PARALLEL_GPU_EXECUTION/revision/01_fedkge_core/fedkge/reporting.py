"""Orchestration of the three output steps (final package): statistical analysis, figures, report.
Each step takes a context (context.ResultsContext for real results, fixtures.FixtureContext for software checks) and
an output folder; it writes only into that folder. Re-running a step regenerates its outputs from the records."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Dict, Optional

import pandas as pd

from . import figures as F
from . import paper as P
from .draft import build_draft
from .hypotheses import descriptive_comparisons, evaluate_hypotheses, hypotheses_table
from .io import analysis_code_hash, code_hash, utc_now, write_json


def _hyp_sha(ctx) -> str:
    return hashlib.sha256((Path(ctx.config_dir) / "hypotheses.yaml").read_bytes()).hexdigest()


def run_analysis(ctx, out_dir: Path) -> Dict:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    env_of = ctx.env_of
    res = evaluate_hypotheses(ctx.runs, ctx.hyp, ctx.selection, ctx.tier, env_of)
    res.update({"generated_utc": utc_now(), "hypotheses_sha256": _hyp_sha(ctx), "analysis_code_hash":
                analysis_code_hash(), "core_code_hash": code_hash(), "context": ctx.summary()})
    if ctx.manifest is not None and ctx.manifest.get("hypotheses_sha256") not in (None, res["hypotheses_sha256"]):
        res["WARNING"] = "hypotheses.yaml differs from the frozen manifest: the analysis is NOT the pre-registered one"
    pre = P.prefix(ctx.tier)
    write_json(out_dir / f"{pre}hypotheses.json", res)
    tab = hypotheses_table(res)
    P.write_table(tab, out_dir, "table12_hypotheses", "Table 12 — pre-registered hypothesis families", ctx.tier,
                  "One-sided paired t-tests, alpha = 0.025, Holm within each family; not-testable and missing members "
                  "enter with p = 1. Decisions are exactly the labels below.", latex=True)
    desc = descriptive_comparisons(ctx.runs)
    P.write_table(desc.drop(columns=["a", "b"], errors="ignore"), out_dir, "descriptive_comparisons",
                  "Descriptive paired comparisons (never called significant)", ctx.tier)
    return res


def run_figures(ctx, hyp_res: Dict, out_dir: Path) -> Path:
    R = F.Recorder(out_dir, ctx.tier)
    for fn in (lambda: F.fig_privacy_utility(R, ctx.runs), lambda: F.fig_main(R, ctx.runs),
               lambda: F.fig_robustness(R, hyp_res), lambda: F.fig_aggregators(R, ctx.runs),
               lambda: F.fig_convergence(R, ctx.runs, ctx.rounds_of), lambda: F.fig_mia(R, ctx.runs, ctx.mia_scores_of),
               lambda: F.fig_integrity(R, ctx.runs, ctx.rounds_of, ctx.env_of), lambda: F.fig_ablation(R, ctx.runs),
               lambda: F.fig_3d(R, ctx.runs), lambda: F.fig_fpr_thirds(R, ctx.runs),
               lambda: F.fig_legacy(R, P.table13_legacy(ctx.runs, ctx.provenance_csv, ctx.l0))):
        fn()
    return R.write_manifest({"tier": ctx.tier, "generated_utc": utc_now(), "analysis_code_hash": analysis_code_hash(),
                             "results_root": str(ctx.root), "formats": ["png (300 dpi)", "pdf"],
                             "rule": "figures from recorded runs only; missing cells shown as missing"})


def compute_accounting(ctx) -> pd.DataFrame:
    r = ctx.runs
    if r is None or r.empty or "runtime.total_s" not in r.columns:
        return pd.DataFrame([{"status": P.PENDING}])
    plan = r["phase"].map({"final": "main (Stage 4)", "p3": "legacy", "p4": "legacy", "tune": "tune (Stage 3)"})
    hw = [str((ctx.env_of(x) or {}).get("gpu") or "CPU") for x in r["run_id"]]
    d = pd.DataFrame({"plan": plan, "block": r["block"], "dataset": r["dataset"], "hardware": hw,
                      "hours": r["runtime.total_s"] / 3600.0,
                      "integrity_hours": r.get("runtime.integrity_s", 0) / 3600.0})
    t = d.groupby(["plan", "hardware", "dataset"]).agg(runs=("hours", "size"), hours=("hours", "sum"),
                                                       integrity_hours=("integrity_hours", "sum")).reset_index()
    tot = d.groupby(["plan", "hardware"]).agg(runs=("hours", "size"), hours=("hours", "sum"),
                                              integrity_hours=("integrity_hours", "sum")).reset_index()
    tot["dataset"] = "ALL"
    return pd.concat([t, tot], ignore_index=True)


def reproducibility_record(ctx, extra: Optional[Dict] = None) -> Dict:
    envs = {}
    if ctx.runs is not None and len(ctx.runs):
        for rid in ctx.runs["run_id"]:
            e = ctx.env_of(rid) or {}
            key = json.dumps({k: e.get(k) for k in ("python", "torch", "cuda", "gpu", "numpy", "dp_accounting")},
                             sort_keys=True)
            envs[key] = envs.get(key, 0) + 1
    cards = {}
    for ds in P.DATASETS:
        c = ctx.card_of(ds)
        if c:
            sm = (c.get("load_info") or {}).get("source_manifest", {})
            cards[ds] = {"files_sha256": sm.get("files_sha256"), "fetched_sha256": sm.get("fetched_sha256"),
                         "counts_match_official": sm.get("counts_match_official")}
    return {"generated_utc": utc_now(), "tier": ctx.tier, "results_root": str(ctx.root),
            "core_code_hash": code_hash(), "analysis_code_hash": analysis_code_hash(),
            "frozen_manifest_content_sha256": (ctx.manifest or {}).get("content_sha256"),
            "hypotheses_sha256": _hyp_sha(ctx), "frozen_selection": ctx.frozen,
            "environment_lock": ctx.env_lock, "environments_of_runs": {k: v for k, v in envs.items()},
            "datasets": cards, "seeds": {"tuning": [1001], "confirmatory": ctx.hyp["seed_set"]},
            "determinism": "CPU runs are bitwise reproducible (tested); GPU runs are not bitwise-tested (CUDA "
                           "deterministic mode is off); every comparison uses one environment (environment lock)",
            **(extra or {})}


def run_report(ctx, hyp_res: Dict, out_dir: Path, figure_manifest: Optional[Path] = None,
               extra_record: Optional[Dict] = None) -> Dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    tier = ctx.tier
    T = {"table1_datasets": (P.table1_datasets(ctx.card_of), "Table 1 — dataset statistics"),
         "table2_partitions": (P.table2_partitions(ctx.partition_stats()), "Table 2 — client partition statistics"),
         "table3_main": (P.table3_main(ctx.runs), "Table 3 — main results by dataset"),
         "table4_baselines": (P.table4_baselines(ctx.runs), "Table 4 — baseline comparison (clean, eps* = 4)"),
         "table5_ablation": (P.table5_ablation(ctx.runs), "Table 5 — ablation study"),
         "table6_accounting": (P.table6_accounting(ctx.runs), "Table 6 — DP privacy accounting (per run guarantees)"),
         "table7_privacy_utility": (P.table7_privacy_utility(ctx.runs), "Table 7 — privacy/utility (Pareto)"),
         "table9_attacks": (P.table9_attacks(ctx.runs, hyp_res), "Table 9 — attack and defence evaluation"),
         "table10_integrity": (P.table10_integrity(ctx.runs, ctx.rounds_of, ctx.env_of),
                               "Table 10 — integrity overhead (operational; hardware named)"),
         "table11_runtime": (P.table11_runtime(ctx.runs, ctx.env_of), "Table 11 — runtime and communication"),
         "table12_hypotheses": (hypotheses_table(hyp_res), "Table 12 — statistical uncertainty: hypothesis families"),
         "table13_legacy": (P.table13_legacy(ctx.runs, ctx.provenance_csv, ctx.l0),
                            "Table 13 — original versus revised on FB15k-237"),
         "table14_completion": (P.table14_completion(ctx.progress), "Table 14 — completion and failure status"),
         "table_mia": (P.table_mia(ctx.runs), "Membership-inference audit (block M1, attack A2 primary)"),
         "table_fpr_by_size_third": (P.table_fpr_by_size_third(ctx.runs),
                                     "Benign false-positive rate by client-size third (diagnostic, decision B4)")}
    for k, df in P.table8_tuning(ctx.selection).items():
        T[f"table8_tuning_{k}"] = (df, f"Table 8 — Stage 3 selection ({k}); validation only")
    files = {}
    for name, (df, title) in T.items():
        files[name] = P.write_table(df, out, name, title, tier, latex=name in ("table3_main", "table4_baselines",
                                                                                "table5_ablation", "table12_hypotheses"))
    ca = compute_accounting(ctx)
    files["compute_accounting"] = P.write_table(ca, out, "compute_accounting", "Compute and resource accounting "
                                                "(measured run time; integrity time also shown separately)", tier)
    if ctx.problems is not None and len(ctx.problems):
        files["problems"] = P.write_table(ctx.problems, out, "run_problems", "Runs that are missing, failed or stale "
                                          "(never imputed)", tier)
    pre = P.prefix(tier)
    summ = privacy_robustness_summary(ctx, hyp_res, T)
    (out / f"{pre}PRIVACY_AND_ROBUSTNESS_SUMMARY.md").write_text(summ)
    rec = reproducibility_record(ctx, extra_record)
    write_json(out / f"{pre}REPRODUCIBILITY_RECORD.json", rec)
    prog = None
    if ctx.manifest is not None and ctx.progress is not None:
        from .manifest import write_progress
        prog = write_progress(ctx.root, ctx.manifest)
    draft = build_draft(ctx, hyp_res, {k: v[0] for k, v in T.items()}, prog, utc_now())
    (out / f"{pre}RESULTS_DRAFT.md").write_text(draft)
    index = {"tier": tier, "generated_utc": utc_now(), "tables": files, "figure_manifest": str(figure_manifest)
             if figure_manifest else None, "draft": f"{pre}RESULTS_DRAFT.md",
             "summary": f"{pre}PRIVACY_AND_ROBUSTNESS_SUMMARY.md", "reproducibility": f"{pre}REPRODUCIBILITY_RECORD.json"}
    write_json(out / f"{pre}REPORT_INDEX.json", index)
    return index


def privacy_robustness_summary(ctx, hyp_res: Dict, T: Dict) -> str:
    L = ["# Privacy and robustness summary", ""]
    b = P.banner(ctx.tier)
    if b:
        L += [f"> **{b}**", ""]
    L += ["## Privacy", "", "- Guarantee: worst-client RDP (ε, δ = 1e-6) per trained model; triple-level, zero-out "
          "adjacency; PLD / PRV are cross-checks.",
          "- **Not end-to-end:** the privacy cost of the 99 Stage-3 tuning runs, of hyperparameter selection and of "
          "releasing several models trained on the same client data is NOT included in any reported ε.", ""]
    t6 = T["table6_accounting"][0]
    if "privacy.eps.max" in t6.columns:
        L.append(f"- DP cells recorded: {len(t6)}; largest worst-client ε: {t6['privacy.eps.max'].max():.3f}; "
                 f"budget_ok in every cell: {bool(t6['budget_ok_all'].all())}.")
    else:
        L.append("- " + P.PH.format("no DP runs recorded yet"))
    h3 = hyp_res["families"]["H3"]
    L += ["", "## Membership inference (H3)", "", f"- Holm status: {h3['holm_status']}"]
    for m in h3["members"]:
        L.append(f"- {P.DS_NAME[m['dataset']]}: {m['status']} — {m.get('decision')}")
    L += ["", "## Robustness (H2, H2b)", ""]
    for fam in ("H2b", "H2"):
        f = hyp_res["families"][fam]
        cnt = {}
        for m in f["members"]:
            cnt[m.get("verdict", m["status"])] = cnt.get(m.get("verdict", m["status"]), 0) + 1
        L.append(f"- {fam}: {f['holm_status']}; decisions {json.dumps(cnt)}")
    L += ["", "## Trust-rule diagnostics", ""]
    for ds in P.DATASETS:
        t = (ctx.selection.get(ds) or {}).get("tau") or {}
        L.append(f"- {P.DS_NAME[ds]}: τ* = {(t.get('aggregation') or {}).get('tau', P.PENDING)} — "
                 f"{t.get('label', P.PH.format('tau not selected yet'))}")
    L += ["- Benign FPR per client-size third: see the table 'fpr_by_size_third' (diagnostic only, decision B4).", "",
          "## Flags", "", f"- D10 utility review: {(ctx.d10 or {}).get('label', P.PH.format('D10 not evaluated'))}"]
    return "\n".join(L) + "\n"
