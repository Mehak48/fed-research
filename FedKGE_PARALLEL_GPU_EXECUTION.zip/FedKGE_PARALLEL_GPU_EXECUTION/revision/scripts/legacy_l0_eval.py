#!/usr/bin/env python3
"""Block L0 / defect OP-8: re-evaluate the SAVED legacy Phase 3 model (complete/global_transe_final.pt) under the
corrected protocol (filtered, head+tail, realistic ties, full V_sel and test) and, for continuity, under the legacy
protocol (300 random test triples, tail-only, optimistic ties). No training. The historical file is only read.

  python scripts/legacy_l0_eval.py --checkpoint "/path/to/complete/global_transe_final.pt" --results R --tier pilot
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys

import torch

from _common import Manifest, results_root
from fedkge.data import load_artifact
from fedkge.evaluate import FilterIndex, evaluate, evaluate_legacy
from fedkge.io import Paths


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True); ap.add_argument("--results"); ap.add_argument("--tier", default="pilot")
    ap.add_argument("--legacy-seeds", nargs="+", type=int, default=[42, 123, 256, 512, 1024])
    a = ap.parse_args(argv)
    root = results_root(a.results)
    man = Manifest(root, "legacy_l0_eval")
    raw = open(a.checkpoint, "rb").read()
    sd = torch.load(a.checkpoint, map_location="cpu", weights_only=True)
    params = {"ent": sd["ent_emb.weight"].float(), "rel": sd["rel_emb.weight"].float()}
    data = load_artifact(Paths(root, a.tier).p1("fb15k237"))
    if params["ent"].shape[0] != data.num_entities or params["rel"].shape[0] != data.num_relations:
        man.close("FAILED", error="vocabulary size mismatch")
        raise SystemExit(f"checkpoint vocabulary {tuple(params['ent'].shape)}/{tuple(params['rel'].shape)} != "
                         f"artifact {data.num_entities}/{data.num_relations}")
    filt = FilterIndex(data.all_true)
    val = evaluate(params, data.vsel, filt, True, "cpu", bootstrap=1000, seed=0)
    test = evaluate(params, data.test, filt, True, "cpu", bootstrap=1000, seed=0)
    legacy = [evaluate_legacy(params, data.test, data.all_true, True, "cpu", 300, s) for s in a.legacy_seeds]
    out = {"block": "L0", "label": "Reproduced (historical checkpoint re-evaluated; no training)",
           "checkpoint_sha256": hashlib.sha256(raw).hexdigest(), "normalize": True,
           "corrected_protocol": {"val": {k: v for k, v in val.items()}, "test": {k: v for k, v in test.items()}},
           "legacy_protocol_300_tail_optimistic": [{"seed": s, **r} for s, r in zip(a.legacy_seeds, legacy)],
           "historical_reported_value": "see audit/result_provenance.csv (Phase 3 final MRR, label Reported)",
           "note": ("The historical value was the last-round MRR on 300 random test triples (tail-only, optimistic "
                    "ties). The legacy-protocol rows show the spread of that protocol across random draws.")}
    p = root / a.tier / "L0_legacy_checkpoint_eval.json"
    p.write_text(json.dumps(out, indent=2, default=float)); man.output(p)
    man.close("COMPLETE")
    print(json.dumps({"val_mrr": val["mrr"], "test_mrr": test["mrr"], "test_hits@10": test["hits@10"],
                      "legacy_protocol_mrr": [round(r["mrr"], 4) for r in legacy]}, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
