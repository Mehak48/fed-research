"""File-based exchange between independent environments: result bundles and release packs.

RESULT BUNDLE (worker -> master): exchange/outbox/<job>__<worker>__<UTC>.zip + .zip.sha256. Contains BUNDLE.json
(job, worker, environment signature, code hash, frozen-manifest hash, data hash, selection hashes, and the SHA-256 of
every file), the COMPLETE run folders of the job, and the worker's records (environment lock, index rows; for a tuning
chain also its selections and gate files). Incomplete runs are listed, never included. The zip is written under a
temporary name and renamed when complete; the sidecar is written last, so a reader never sees a half-written bundle.

RELEASE PACK (master -> workers): exchange/packs/release_<tier>_<ds>_<label>__<UTC>.zip + .zip.sha256. Contains
PACK.json, the selection files the next jobs need (frozen ones on the research tiers) and the materialised job specs
(explicit run ids). A worker installs the selection files into its own root under an append-only rule.
"""
from __future__ import annotations

import io
import json
import os
import zipfile
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

from .common import (BUNDLE_SCHEMA, PACK_SCHEMA, CONFIG_DIR, IntegrityError, Layout, Paths, RunDir, code_hash,
                     read_json, read_json_or, sha256_bytes, sha256_file, stamp, utc_now)

NEVER = {"triples.npz", "labels.json", "train.txt", "valid.txt", "test.txt", "checkpoint.pt"}


def keep_run_file(p: Path) -> bool:
    """Run-folder files that travel in a bundle: every record and the requested final weights; never dataset files,
    checkpoints, integrity object stores or temporary files (same exclusions as scripts/export_artifacts.py, but the
    final weights and the MIA scores are kept because they are part of a COMPLETE run's outputs)."""
    if p.name in NEVER or p.suffix in (".npz", ".tmp") or "integrity_store" in p.parts or p.name.startswith("."):
        return False
    if p.suffix == ".pt":
        return p.name == "final_weights.pt"
    return True


def _safe_member(name: str) -> bool:
    return not (name.startswith("/") or ".." in name.split("/") or "\\" in name or ":" in name)


def write_zip_atomically(path: Path, members: Dict[str, bytes]) -> str:
    """Write the zip as <path>.part, fsync, rename; then the sidecar <path>.sha256 (also atomic). Returns the sha."""
    path.parent.mkdir(parents=True, exist_ok=True)
    part = path.with_name(path.name + ".part")
    with open(part, "wb") as fh:
        with zipfile.ZipFile(fh, "w", zipfile.ZIP_DEFLATED) as z:
            for name in sorted(members):
                z.writestr(name, members[name])
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(part, path)
    sha = sha256_file(path)
    side = path.with_name(path.name + ".sha256")
    tmp = side.with_name(side.name + ".part")
    tmp.write_text(f"{sha}  {path.name}\n")
    os.replace(tmp, side)
    return sha


def verified(path: Path) -> Tuple[bool, str, str]:
    """(ok, sha, reason). A zip without its sidecar, or whose bytes differ from it, is not (yet) usable."""
    side = path.with_name(path.name + ".sha256")
    if not path.exists() or not side.exists():
        return False, "", "no sidecar yet (still being written or synced)"
    want = side.read_text().split()[0]
    have = sha256_file(path)
    if want != have:
        return False, have, "SHA-256 differs from the sidecar (incomplete sync or modified file)"
    return True, have, ""


def open_zip(path: Path) -> Tuple[zipfile.ZipFile, Dict]:
    z = zipfile.ZipFile(path)
    bad = [n for n in z.namelist() if not _safe_member(n)]
    if bad:
        raise IntegrityError(f"{path.name}: unsafe member names {bad[:3]}")
    head = "BUNDLE.json" if "BUNDLE.json" in z.namelist() else "PACK.json"
    meta = json.loads(z.read(head))
    for name, h in meta.get("files_sha256", {}).items():
        if sha256_bytes(z.read(name)) != h:
            raise IntegrityError(f"{path.name}: member {name} differs from its recorded SHA-256")
    extra = set(z.namelist()) - set(meta.get("files_sha256", {})) - {head}
    if extra:
        raise IntegrityError(f"{path.name}: unlisted members {sorted(extra)[:3]}")
    return z, meta


# ---------------------------------------------------------------------------------------------------------- bundles
def export_bundle(layout: Layout, worker: str, spec: Dict, exit_code: int, run_ids: Iterable[str],
                  extra_files: Optional[Dict[str, Path]] = None, log=print) -> Optional[Path]:
    """Bundle the COMPLETE, current runs of one job from the worker's root into the outbox."""
    from .common import environment_signature  # noqa: F401  (signature is read from the worker's lock)
    tier, ds = spec["tier"], spec["dataset"]
    root = layout.worker(worker)
    paths = Paths(root, tier)
    members: Dict[str, bytes] = {}
    runs, incomplete = {}, {}
    for rid in sorted(set(run_ids)):
        rd = RunDir(paths.run(rid))
        if not rd.is_complete_and_current():
            st = rd.status()
            incomplete[rid] = (st or {}).get("status", "NOT_STARTED")
            continue
        files = {}
        for p in sorted(rd.path.rglob("*")):
            if p.is_file() and keep_run_file(p.relative_to(rd.path)):
                rel = str(p.relative_to(rd.path)).replace(os.sep, "/")
                data = p.read_bytes()
                members[f"runs/{rid}/{rel}"] = data
                files[rel] = sha256_bytes(data)
        runs[rid] = {"files": files}
    for arc, src in (extra_files or {}).items():
        if Path(src).exists():
            members[arc] = Path(src).read_bytes()
    lock = read_json_or(paths.base / "ENVIRONMENT_LOCK.json", {"datasets": {}})
    sig = ((lock.get("datasets") or {}).get(ds) or {}).get("signature")
    p1m = paths.p1(ds) / "manifest.json"
    sel = {p.stem: sha256_file(p) for p in sorted((paths.base / "selection").glob("*.json"))} \
        if (paths.base / "selection").exists() else {}
    man_sha = None
    if tier in ("tune", "final"):
        man_sha = read_json(CONFIG_DIR / "manifest" / "FROZEN_MANIFEST.json")["content_sha256"]
    meta = {"schema": BUNDLE_SCHEMA, "kind": "result_bundle", "job_id": spec["job_id"], "job_kind": spec["kind"],
            "plan": spec["plan"], "tier": tier, "dataset": ds, "worker": worker, "created_utc": utc_now(),
            "exit_code": int(exit_code), "env_signature": sig, "code_hash": code_hash(),
            "frozen_manifest_content_sha256": man_sha,
            "data_hash": read_json(p1m)["content_hash"] if p1m.exists() else None,
            "worker_selection_sha256": sel, "job_spec_sha256": sha256_bytes(json.dumps(spec, sort_keys=True).encode()),
            "runs": runs, "incomplete": incomplete}
    meta["files_sha256"] = {n: sha256_bytes(b) for n, b in members.items()}
    members["BUNDLE.json"] = json.dumps(meta, indent=1, sort_keys=True).encode()
    out = layout.outbox / f"{spec['job_id']}__{worker}__{stamp()}.zip"
    sha = write_zip_atomically(out, members)
    log(f"bundle {out.name}: {len(runs)} complete run(s), {len(incomplete)} not complete, sha256 {sha[:12]}")
    return out


def list_verified(folder: Path, prefix: str = "") -> List[Tuple[Path, str]]:
    out = []
    for p in sorted(Path(folder).glob(f"{prefix}*.zip")):
        ok, sha, _ = verified(p)
        if ok:
            out.append((p, sha))
    return out


# ------------------------------------------------------------------------------------------------------------ packs
def export_pack(layout: Layout, tier: str, dataset: str, label: str, files: Dict[str, Path], specs: List[Dict],
                info: Dict, log=print) -> Path:
    members = {arc: Path(src).read_bytes() for arc, src in files.items()}
    for s in specs:
        members[f"jobs/{s['job_id']}.json"] = json.dumps(s, indent=1, sort_keys=True).encode()
    meta = {"schema": PACK_SCHEMA, "kind": "release_pack", "tier": tier, "dataset": dataset, "label": label,
            "created_utc": utc_now(), "code_hash": code_hash(), "jobs": [s["job_id"] for s in specs], **info}
    meta["files_sha256"] = {n: sha256_bytes(b) for n, b in members.items()}
    members["PACK.json"] = json.dumps(meta, indent=1, sort_keys=True).encode()
    out = layout.packs / f"release_{tier}_{dataset}_{label}__{stamp()}.zip"
    write_zip_atomically(out, members)
    log(f"release pack {out.name}: jobs {meta['jobs']}")
    return out


def find_release(layout: Layout, job_id: str) -> Optional[Tuple[Path, Dict, Dict]]:
    """The newest verified release pack that contains this job: (path, PACK.json, job spec)."""
    best = None
    for p, _ in list_verified(layout.packs, "release_"):
        try:
            z, meta = open_zip(p)
        except IntegrityError:
            continue
        if job_id in meta.get("jobs", []):
            spec = json.loads(z.read(f"jobs/{job_id}.json"))
            if best is None or meta["created_utc"] > best[1]["created_utc"]:
                best = (p, meta, spec)
    return best


def _selection_entries_compatible(old: Dict, new: Dict) -> List[str]:
    """Append-only rule: every dataset entry present in `old` must be contained in `new` with identical values."""
    bad = []
    for ds, v in old.items():
        if ds.startswith("_"):
            continue
        nv = new.get(ds)
        if nv is None:
            bad.append(f"{ds}: missing in the pack")
            continue
        for rule, val in v.items():
            if rule in nv and nv[rule] != val:
                bad.append(f"{ds}.{rule}: worker has {val!r}, pack has {nv[rule]!r}")
            elif rule not in nv:
                bad.append(f"{ds}.{rule}: missing in the pack")
    return bad


def _merge_selection(old: Dict, new: Dict, where: str) -> Dict:
    """Union of two selection files (per dataset, per rule); a value present in both must be identical."""
    out = dict(old)
    for ds, v in new.items():
        if ds.startswith("_"):
            out[ds] = v
            continue
        cur = dict(out.get(ds) or {})
        for rule, val in v.items():
            if rule in cur and cur[rule] != val:
                raise IntegrityError(f"{where}: {ds}.{rule} is {cur[rule]!r} here but {val!r} in the pack")
            cur[rule] = val
        out[ds] = cur
    return out


def _merge_gate(old: Dict, new: Dict, where: str) -> Dict:
    if old.get("rule_sha256") and new.get("rule_sha256") and old["rule_sha256"] != new["rule_sha256"]:
        raise IntegrityError(f"{where}: the sanity-gate rule differs")
    out = dict(new)
    ds_old, ds_new = old.get("datasets") or {}, new.get("datasets") or {}
    for ds in set(ds_old) & set(ds_new):
        if ds_old[ds].get("status") != ds_new[ds].get("status"):
            raise IntegrityError(f"{where}: gate status of {ds} differs ({ds_old[ds].get('status')} here)")
    out["datasets"] = {**ds_old, **ds_new}
    return out


def _write(dst: Path, data: bytes) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name(f".{dst.name}.part")
    tmp.write_bytes(data)
    os.replace(tmp, dst)


def install_pack(pack: Path, worker_root: Path, log=print) -> Dict:
    """Install the selection and gate files of a release pack into a worker's root, never losing or changing a value
    the worker already has (the worker would otherwise silently run a different experiment):
      * a FROZEN selection (research final tier) is installed byte for byte and only over an older frozen file whose
        datasets it keeps unchanged (append-only, as scripts/freeze_selections.py);
      * any other selection or gate file is merged per dataset; a value present on both sides must be identical."""
    z, meta = open_zip(pack)
    tier = meta["tier"]
    installed = []
    for name in sorted(meta["files_sha256"]):
        if name.startswith("jobs/") or not name.endswith(".json"):
            continue
        dst = Path(worker_root) / name
        data = z.read(name)
        if dst.exists() and dst.read_bytes() == data:
            continue
        frozen_file = bool(meta.get("frozen_sha256")) and name in (f"{tier}/selection/tuning.json",
                                                                    f"{tier}/selection/FROZEN.json")
        if frozen_file:
            if dst.exists():
                if dst.name == "tuning.json":
                    bad = _selection_entries_compatible(read_json(dst), json.loads(data))
                    if bad:
                        raise IntegrityError(f"release pack {pack.name} conflicts with {dst}: {bad[:3]}")
                elif not set(read_json(dst).get("datasets", [])) <= set(json.loads(data).get("datasets", [])):
                    raise IntegrityError(f"release pack {pack.name}: FROZEN.json would drop frozen datasets")
            _write(dst, data)
        elif dst.exists() and dst.parent.name == "selection" and dst.stem == "tuning":
            merged = _merge_selection(read_json(dst), json.loads(data), str(dst))
            _write(dst, json.dumps(merged, indent=1, sort_keys=True, default=str).encode())
        elif dst.exists() and dst.name == "sanity_gate.json":
            merged = _merge_gate(read_json(dst), json.loads(data), str(dst))
            _write(dst, json.dumps(merged, indent=1, sort_keys=True, default=str).encode())
        elif dst.exists():
            continue                        # informational record already present (e.g. d10_trigger.json)
        else:
            _write(dst, data)
        installed.append(name)
    if meta.get("frozen_sha256"):
        fz = Path(worker_root) / meta["tier"] / "selection" / "tuning.json"
        if sha256_file(fz) != meta["frozen_sha256"]:
            raise IntegrityError("installed tuning.json does not match the pack's frozen SHA-256")
    log(f"installed release pack {pack.name}: {installed or 'nothing new'}")
    return meta
