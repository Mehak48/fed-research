# Table 8 — Stage 3 selection (T1_central); validation only

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| dataset | train.lr | train.batch_size | val_mrr_mean | chosen | tied_within_tolerance |
|---|---|---|---|---|---|
| codex_m | 0.001 | 512 | 0.002792 | False | False |
| codex_m | 0.001 | 4096 | 0.001813 | False | False |
| codex_m | 0.003 | 512 | 0.01724 | False | False |
| codex_m | 0.003 | 4096 | 0.00207 | False | False |
| codex_m | 0.01 | 512 | 0.0747 | True | True |
| codex_m | 0.01 | 4096 | 0.005157 | False | False |
| fb15k237 | 0.001 | 512 | 0.003465 | False | False |
| fb15k237 | 0.001 | 4096 | 0.002705 | False | False |
| fb15k237 | 0.003 | 512 | 0.01153 | False | False |
| fb15k237 | 0.003 | 4096 | 0.003093 | False | False |
| fb15k237 | 0.01 | 512 | 0.1015 | True | True |
| fb15k237 | 0.01 | 4096 | 0.006229 | False | False |
| wn18rr | 0.001 | 512 | 0.0008546 | False | False |
| wn18rr | 0.001 | 4096 | 0.0008397 | False | False |
| wn18rr | 0.003 | 512 | 0.001115 | False | False |
| wn18rr | 0.003 | 4096 | 0.0008479 | False | False |
| wn18rr | 0.01 | 512 | 0.008293 | True | True |
| wn18rr | 0.01 | 4096 | 0.001023 | False | False |
