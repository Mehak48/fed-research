# Master store validation (smoke)

Checked 2026-11-07T12:51:28.780773Z. **COMPLETE AND COMPATIBLE**

Approved cells: 312 · by status: {'COMPLETE': 312}

| Plan | Status counts |
|---|---|
| legacy | {'COMPLETE': 6} |
| main | {'COMPLETE': 192} |
| tune | {'COMPLETE': 114} |

## Problems (0)

None.

## Jobs that still have missing cells

None.

Bundles verified but not imported yet: 0; refused bundles: 0 (see IMPORT_LEDGER.json).
