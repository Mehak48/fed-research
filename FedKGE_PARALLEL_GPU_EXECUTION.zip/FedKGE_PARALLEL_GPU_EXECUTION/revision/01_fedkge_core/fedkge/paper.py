"""Paper tables 1-14, privacy / robustness summaries, compute accounting, reproducibility record and the results
draft (Phase B 06 section 5; final package, section H of the owner's final directive).

Every table is computed from recorded run outputs (analysis.collect rows, run folders, artifacts, selections, the
frozen manifest). Nothing is typed by hand and nothing is filled in: a value that does not exist yet is shown as
PENDING (tables) or as a marked placeholder (the draft). Every per-configuration cell keeps its per-seed values next
to the mean and its 95 % t-interval. Outputs of any tier other than 'final' carry a NOT_FOR_MANUSCRIPT prefix and a
banner; fixture outputs (software checks of this module) carry a FIXTURE prefix and banner.
"""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
from typing import Callable, Dict, List, Optional

import numpy as np
import pandas as pd

from .stats import pareto_front, summarize

PENDING = "PENDING"
PH = "⟦PENDING: {}⟧"                      # placeholder marker in the draft
DATASETS = ("fb15k237", "wn18rr", "codex_m")
DS_NAME = {"fb15k237": "FB15k-237", "wn18rr": "WN18RR", "codex_m": "CoDEx-M"}
EPS4 = {"cfg.dp.target_epsilon": 4.0}


def banner(tier: str) -> Optional[str]:
    if tier == "final":
        return None
    if tier == "fixture":
        return "FIXTURE: SYNTHETIC NUMBERS FOR A SOFTWARE CHECK - NOT RESULTS, NEVER CITE"
    return f"{tier.upper()} TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT"


def prefix(tier: str) -> str:
    return "" if tier == "final" else ("FIXTURE_SYNTHETIC_NOT_RESULTS_" if tier == "fixture"
                                       else f"{tier.upper()}_NOT_FOR_MANUSCRIPT_")


# ------------------------------------------------------------------------------------------------ helpers
def select(runs: pd.DataFrame, block: str, ds: Optional[str] = None, where: Optional[Dict] = None) -> pd.DataFrame:
    if runs is None or runs.empty or "block" not in runs.columns:
        return pd.DataFrame()
    g = runs[runs["block"] == block]
    if ds is not None:
        g = g[g["dataset"] == ds]
    for k, v in (where or {}).items():
        if k not in g.columns:
            return g.iloc[0:0]
        g = g[g[k].isna()] if v is None else g[g[k] == v]
    return g


def seedsum(g: pd.DataFrame, metric: str) -> Dict:
    """mean, sd, 95 % t-interval and every per-seed value (never only the mean). PENDING if no value exists."""
    if g is None or g.empty or metric not in g.columns or g[metric].isna().all():
        return {"n": 0, "status": PENDING}
    gg = g.dropna(subset=[metric])
    s = summarize(gg[metric].astype(float).values)
    return {"n": s["n"], "mean": s["mean"], "sd": s["sd"], "ci95_low": s["ci95_low"], "ci95_high": s["ci95_high"],
            "per_seed": {int(k): float(v) for k, v in sorted(zip(gg["seed"], gg[metric]))}, "status": "OK"}


def fmt(s: Dict, nd: int = 3) -> str:
    if not s or s.get("status") != "OK":
        return PENDING
    if s["n"] < 2 or not np.isfinite(s["ci95_low"]):
        return f"{s['mean']:.{nd}f} (n={s['n']})"
    return f"{s['mean']:.{nd}f} [{s['ci95_low']:.{nd}f}, {s['ci95_high']:.{nd}f}] (n={s['n']})"


def _row(label: str, g: pd.DataFrame, metrics: List[str], **extra) -> Dict:
    rec = {"system": label, **extra, "run_ids": ";".join(sorted(g["run_id"])) if len(g) else ""}
    for m in metrics:
        s = seedsum(g, m)
        rec[m] = fmt(s, 2 if m.startswith("privacy.") else 3)
        rec[f"{m}.mean"] = s.get("mean")
        rec[f"{m}.n"] = s.get("n", 0)
        rec[f"{m}.per_seed"] = json.dumps(s.get("per_seed", {}))
    return rec


MRR_METRICS = ["test.mrr", "test.hits@1", "test.hits@3", "test.hits@10"]


# ------------------------------------------------------------------------------------------------ tables 1-2
def table1_datasets(card_of: Callable[[str], Optional[Dict]]) -> pd.DataFrame:
    rows = []
    for ds in DATASETS:
        c = card_of(ds)
        if not c:
            rows.append({"dataset": DS_NAME[ds], "status": PENDING}); continue
        raw = (c.get("load_info") or {}).get("raw_counts", {})
        sm = (c.get("load_info") or {}).get("source_manifest", {})
        rows.append({"dataset": DS_NAME[ds], "entities": c["num_entities"], "relations": c["num_relations"],
                     "train": c["n_train"], "valid (official)": raw.get("valid"), "test (official)": raw.get("test"),
                     "valid used": c["n_valid"], "test used": c["n_test"], "V_sel": c["n_vsel"], "V_root": c["n_vroot"],
                     "valid dropped (unseen entities)": (c.get("load_info") or {}).get("valid_dropped_unseen"),
                     "test dropped (unseen entities)": (c.get("load_info") or {}).get("test_dropped_unseen"),
                     "counts match official": sm.get("counts_match_official"), "licence": c.get("licence"),
                     "citation": c.get("citation"), "status": "OK"})
    return pd.DataFrame(rows)


def table2_partitions(stats_rows: List[Dict]) -> pd.DataFrame:
    if not stats_rows:
        return pd.DataFrame([{"status": PENDING, "note": "no final-tier partition statistics yet"}])
    df = pd.DataFrame(stats_rows)
    agg = df.groupby(["dataset", "partition"]).agg(
        seeds=("seed", lambda x: ",".join(str(int(v)) for v in sorted(x))), n_clients=("n_clients", "first"),
        size_gini_mean=("size_gini", "mean"), size_max_share_mean=("size_max_share", "mean"),
        mean_relation_js=("mean_relation_js", "mean"), mean_pairwise_entity_jaccard=("mean_pairwise_entity_jaccard", "mean"),
        attempts_max=("attempts", "max"), min_size_min=("min_size", "min")).reset_index()
    agg["dataset"] = agg["dataset"].map(DS_NAME)
    return agg


# ------------------------------------------------------------------------------------------------ tables 3-5
def table3_main(runs: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for ds in DATASETS:
        for lab, blk, w in (("Centralised TransE (non-private)", "N1", None), ("FedAvg (non-private)", "N2", None),
                            ("DP-FedAvg, eps* = 4 (selected schedule)", "DP2", EPS4),
                            ("Complete method, eps* = 4", "R1p", None)):
            g = select(runs, blk, ds, w)
            rows.append(_row(lab, g, MRR_METRICS + ["privacy.eps"], dataset=DS_NAME[ds], block=blk))
    return pd.DataFrame(rows)


def table4_baselines(runs: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for ds in DATASETS:
        spec = [("Centralised (non-private)", "N1", None), ("FedAvg (non-private)", "N2", None),
                ("DP-FedAvg fixed sigma, eps* = 4", "DP1", EPS4), ("DP-FedAvg selected schedule, eps* = 4", "DP2", EPS4)]
        spec += [(f"{a}, eps* = 4 (clean)", "R1", {"cfg.aggregation.method": a})
                 for a in ("trimmed_mean", "median", "krum", "fltrust")]
        spec += [("Proposed trust rule, eps* = 4 (clean)", "R1p", None)]
        for lab, blk, w in spec:
            rows.append(_row(lab, select(runs, blk, ds, w), ["test.mrr", "test.hits@10"], dataset=DS_NAME[ds],
                             block=blk, seeds_planned={"R1": 3}.get(blk, 5)))
    return pd.DataFrame(rows)


def table5_ablation(runs: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for ds in DATASETS:
        spec = [("Complete method (DP + trust + integrity, s*)", "R1p", None),
                ("- noise schedule (fixed sigma)", "R1q", None),
                ("- trust (DP-FedAvg, s*)", "DP2", EPS4),
                ("- DP (trust only, non-private)", "R5", {"cfg.aggregation.method": "proposed", "cfg.attack.type": "none"}),
                ("- integrity verification (complete method, off)", "I1", {"cfg.dp.enabled": True}),
                ("DP training settings only (no clipping, no noise)", "DP3", {"cfg.dp.clip": None}),
                ("DP training settings + clipping only", "DP3", {"cfg.dp.clip_is_set": True})]
        r = runs.copy()
        if len(r) and "cfg.dp.clip" in r.columns:
            r["cfg.dp.clip_is_set"] = r["cfg.dp.clip"].notna()
        for lab, blk, w in spec:
            rows.append(_row(lab, select(r, blk, ds, w), ["test.mrr", "test.hits@10"], dataset=DS_NAME[ds],
                             block=blk))
    return pd.DataFrame(rows)


# ------------------------------------------------------------------------------------------------ tables 6-8
DP_COLS = ["privacy.eps", "privacy.eps_at.1e-05", "privacy.eps_pld", "privacy.eps_prv_upper", "privacy.sigma0_worst",
           "privacy.q_worst", "privacy.rounds_executed", "privacy.delta_times_largest_size"]


def table6_accounting(runs: pd.DataFrame) -> pd.DataFrame:
    if runs is None or runs.empty or "privacy.eps" not in runs.columns:
        return pd.DataFrame([{"status": PENDING}])
    dp = runs[runs["privacy.eps"].notna()].copy()
    if dp.empty:
        return pd.DataFrame([{"status": PENDING}])
    dp["cell"] = dp["block"] + ":" + dp["name"]
    rows = []
    for (ds, cell), g in dp.groupby(["dataset", "cell"]):
        rec = {"dataset": DS_NAME.get(ds, ds), "cell": cell, "n_runs": len(g),
               "target_eps": g["cfg.dp.target_epsilon"].iloc[0] if "cfg.dp.target_epsilon" in g else None,
               "delta": g["privacy.delta"].iloc[0], "sampling_design": g["privacy.sampling_design"].iloc[0],
               "clip": g["privacy.clip"].iloc[0], "schedule": f"{g['cfg.dp.schedule.shape'].iloc[0]}"
               f"(rho={g['cfg.dp.schedule.rho'].iloc[0]})", "adjacency": g["privacy.adjacency"].iloc[0],
               "budget_ok_all": bool(g["privacy.budget_ok"].fillna(False).astype(bool).all())
               if "privacy.budget_ok" in g else None}
        for c in DP_COLS:
            if c in g.columns and g[c].notna().any():
                rec[f"{c}.max"] = float(g[c].max()); rec[f"{c}.mean"] = float(g[c].mean())
        rows.append(rec)
    return pd.DataFrame(rows)


def table7_privacy_utility(runs: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for ds in DATASETS:
        pts = []
        for eps in (1.0, 2.0, 4.0, 8.0):
            g = select(runs, "DP1", ds, {"cfg.dp.target_epsilon": eps})
            pts.append(("DP-FedAvg fixed sigma", eps, g))
        pts.append(("DP-FedAvg selected schedule", 4.0, select(runs, "DP2", ds, EPS4)))
        pts.append(("Complete method", 4.0, select(runs, "R1p", ds)))
        recs = []
        for lab, eps, g in pts:
            u, e = seedsum(g, "test.mrr"), seedsum(g, "privacy.eps")
            recs.append({"dataset": DS_NAME[ds], "system": lab, "target_eps": eps, "measured_eps_worst_client":
                         e.get("mean"), "test_mrr": fmt(u), "test_mrr.mean": u.get("mean"), "n": u.get("n", 0)})
        ok = [r for r in recs if r["test_mrr.mean"] is not None and r["measured_eps_worst_client"] is not None]
        if ok:
            front = pareto_front([r["measured_eps_worst_client"] for r in ok], [r["test_mrr.mean"] for r in ok])
            for r, f in zip(ok, front):
                r["pareto"] = bool(f)
        n2 = seedsum(select(runs, "N2", ds), "test.mrr")
        recs.append({"dataset": DS_NAME[ds], "system": "FedAvg non-private (eps = inf)", "target_eps": float("inf"),
                     "measured_eps_worst_client": float("inf"), "test_mrr": fmt(n2), "test_mrr.mean": n2.get("mean"),
                     "n": n2.get("n", 0)})
        rows += recs
    return pd.DataFrame(rows)


def table8_tuning(selection: Optional[Dict]) -> Dict[str, pd.DataFrame]:
    if not selection:
        return {"tuning_candidates": pd.DataFrame([{"status": PENDING}])}
    out = {}
    for k, v in selection.items():
        if k.startswith("_") and isinstance(v, dict) and v.get("candidates"):
            out[k.strip("_").replace("_rule", "")] = pd.DataFrame(v["candidates"])
    chosen = []
    for ds in DATASETS:
        s = selection.get(ds) or {}
        tau = s.get("tau") or {}
        chosen.append({"dataset": DS_NAME[ds],
                       "T1_central (lr, B)": json.dumps((s.get("T1_central") or {}).get("train")),
                       "T1_nonprivate (lr, B)": json.dumps((s.get("T1_nonprivate") or {}).get("train")),
                       "q*, lr*": json.dumps(s.get("T2a")), "C*": json.dumps(s.get("T2b")),
                       "R*": json.dumps(s.get("T2c")), "design": json.dumps(s.get("T2d")),
                       "s*": json.dumps(s.get("T3")), "tau*": (tau.get("aggregation") or {}).get("tau"),
                       "tau rule": tau.get("status"), "benign FPR at tau*": tau.get("benign_fpr_at_selected_tau"),
                       "tau label": tau.get("label")})
    out["selected"] = pd.DataFrame(chosen)
    return out


# ------------------------------------------------------------------------------------------------ table 9
ATTACKS = ("gaussian", "signflip", "alie", "ipm", "targeted", "sybil", "adaptive")


def table9_attacks(runs: pd.DataFrame, hyp_res: Optional[Dict] = None) -> pd.DataFrame:
    rows = []
    h2 = {m["member"]: m for m in ((hyp_res or {}).get("families", {}).get("H2", {}).get("members", []))}
    for ds in DATASETS:
        for att in ATTACKS:
            if att == "adaptive":
                fa, me = select(runs, "R2a", ds), select(runs, "R3a", ds)
            else:
                fa = select(runs, "R2", ds, {"cfg.attack.type": att}); me = select(runs, "R3", ds, {"cfg.attack.type": att})
            metric = "targeted.target_hits@10" if att == "targeted" else "test.mrr"
            rec = {"dataset": DS_NAME[ds], "attack": att, "metric": metric,
                   "FedAvg clean": fmt(seedsum(select(runs, "DP2", ds, EPS4), metric)),
                   "FedAvg attacked": fmt(seedsum(fa, metric)),
                   "method clean": fmt(seedsum(select(runs, "R1p", ds), metric)),
                   "method attacked": fmt(seedsum(me, metric)),
                   "method TPR (mean)": seedsum(me, "attack.mean_tpr").get("mean"),
                   "method benign FPR (mean)": seedsum(me, "attack.mean_fpr").get("mean"),
                   "malicious weight share FedAvg": seedsum(fa, "attack.mean_malicious_weight_share").get("mean"),
                   "malicious weight share method": seedsum(me, "attack.mean_malicious_weight_share").get("mean")}
            m = h2.get(f"{ds}:{att}")
            if m:
                est = m.get("estimate") or {}
                rec.update({"Delta FedAvg": est.get("mean_delta_fedavg"), "Delta method": est.get("mean_delta_method"),
                            "E_a (ratio of means)": est.get("E_ratio_of_means"), "H2 status": m["status"],
                            "H2 decision": m.get("decision")})
            rows.append(rec)
        for att in ("signflip", "alie", "ipm", "targeted"):
            metric = "targeted.target_hits@10" if att == "targeted" else "test.mrr"
            for agg in ("trimmed_mean", "median", "krum", "fltrust"):
                g = select(runs, "R4", ds, {"cfg.attack.type": att, "cfg.aggregation.method": agg})
                rows.append({"dataset": DS_NAME[ds], "attack": att, "metric": metric, "baseline": agg,
                             "baseline attacked": fmt(seedsum(g, metric)), "descriptive_only": True})
    return pd.DataFrame(rows)


# ------------------------------------------------------------------------------------------------ tables 10-11
def table10_integrity(runs: pd.DataFrame, rounds_of: Callable[[str], Optional[pd.DataFrame]],
                      env_of: Callable[[str], Optional[Dict]]) -> pd.DataFrame:
    """Operational integrity overhead, measured per round and SEPARATED from training time; hardware named."""
    rows = []
    for ds in DATASETS:
        for lab, blk, w in (("FedAvg non-private, integrity ON (hash_only)", "N2", None),
                            ("FedAvg non-private, integrity OFF", "I1", {"cfg.dp.enabled": False}),
                            ("Complete method, integrity ON (hash_only)", "R1p", None),
                            ("Complete method, integrity OFF", "I1", {"cfg.dp.enabled": True})):
            g = select(runs, blk, ds, w)
            per = []
            for rid in g["run_id"] if len(g) else []:
                rr = rounds_of(rid)
                if rr is None or rr.empty:
                    continue
                per.append({"t_local": rr["t_local_s"].mean(), "t_agg": rr["t_agg_s"].mean(),
                            "t_int": rr["t_integrity_s"].mean(),
                            "bytes": rr["integrity_bytes"].mean() if "integrity_bytes" in rr else 0.0})
            hw = sorted({str((env_of(r) or {}).get("gpu") or "CPU") for r in (g["run_id"] if len(g) else [])})
            if not per:
                rows.append({"dataset": DS_NAME[ds], "configuration": lab, "status": PENDING}); continue
            p = pd.DataFrame(per)
            train = p["t_local"].mean() + p["t_agg"].mean()
            rows.append({"dataset": DS_NAME[ds], "configuration": lab, "n_runs": len(p),
                         "training+aggregation s/round": float(train), "integrity s/round": float(p["t_int"].mean()),
                         "integrity share of round": float(p["t_int"].mean() / (train + p["t_int"].mean()))
                         if train + p["t_int"].mean() > 0 else None,
                         "integrity bytes/round": float(p["bytes"].mean()), "hardware": "; ".join(hw), "status": "OK"})
        for mode in ("hash_only", "transport_only"):
            g = select(runs, "I2", ds, {"cfg.integrity.mode": mode})
            rows.append({"dataset": DS_NAME[ds], "configuration": f"I2 corruption in transit p=0.1, {mode}",
                         "test.mrr": fmt(seedsum(g, "test.mrr")),
                         "corrupted objects (mean)": seedsum(g, "integrity.n_corrupted").get("mean"),
                         "rejected objects (mean)": seedsum(g, "integrity.n_rejected").get("mean"),
                         "corrupted and consumed (mean)": seedsum(g, "integrity.n_corrupted_and_consumed").get("mean"),
                         "detection rate (mean)": seedsum(g, "integrity.detection_rate").get("mean"),
                         "status": "OK" if len(g) else PENDING,
                         "note": "verification is not a poisoning defence; a poisoned update hashes correctly"})
    return pd.DataFrame(rows)


def table11_runtime(runs: pd.DataFrame, env_of: Callable[[str], Optional[Dict]]) -> pd.DataFrame:
    if runs is None or runs.empty:
        return pd.DataFrame([{"status": PENDING}])
    r = runs.copy()
    r["hardware"] = [str((env_of(x) or {}).get("gpu") or "CPU") for x in r["run_id"]]
    cols = {"runtime.total_s": "sum", "runtime.per_round_s": "mean", "rounds_executed": "mean",
            "runtime.gpu_peak_allocated_mb": "max", "communication.bytes_up_total": "mean",
            "runtime.integrity_s": "sum", "runtime.local_training_s": "sum"}
    cols = {k: v for k, v in cols.items() if k in r.columns}
    t = r.groupby(["phase", "block", "dataset", "hardware"]).agg({**cols, "run_id": "count"}).reset_index()
    t = t.rename(columns={"run_id": "n_runs"})
    if "runtime.total_s" in t:
        t["gpu_or_cpu_hours"] = t["runtime.total_s"] / 3600.0
    return t


# ------------------------------------------------------------------------------------------------ 13, 14, MIA, FPR
def table13_legacy(runs: pd.DataFrame, provenance_csv: Optional[Path], l0: Optional[Dict]) -> pd.DataFrame:
    rows = []
    if provenance_csv and Path(provenance_csv).exists():
        seen = set()
        for r in csv.DictReader(open(provenance_csv)):
            if r["claim_id"] in ("C01", "C14", "C15") and r["claim_id"] not in seen:
                seen.add(r["claim_id"])
                rows.append({"source": "Reported (original manuscript)", "item": r["claim"],
                             "value": r["reported_value"], "validity (Phase A)": r["validity"], "n": 1})
    if l0:
        rows.append({"source": "Reproduced (L0: saved legacy model, corrected protocol)", "item": "test MRR",
                     "value": f"{(l0.get('test') or {}).get('mrr', float('nan')):.3f}", "n": 1})
    else:
        rows.append({"source": "Reproduced (L0)", "item": "test MRR", "value": PENDING,
                     "note": "needs the owner's checkpoint complete/global_transe_final.pt"})
    for blk, lab in (("R3_legacy", "L1 exact old Phase 3"), ("R3_fixed", "L2 old partition, corrected trainer"),
                     ("R4_legacy", "L3 exact old Phase 4"), ("L1_legacy", "L4a legacy mechanism, main partition"),
                     ("L2_trainer_fixed", "L4b trainer fixed"), ("L3_accounting_fixed", "L4c formal accounting")):
        g = select(runs, blk, "fb15k237")
        rec = {"source": f"Reproduced ({lab})", "item": "test MRR (corrected protocol)", "value": fmt(seedsum(g, "test.mrr")),
               "legacy-protocol MRR": fmt(seedsum(g, "test_legacy_protocol.mrr")),
               "eps RDP worst client": fmt(seedsum(g, "privacy.eps"), 2),
               "legacy naive eps sum": fmt(seedsum(g, "privacy.legacy_naive_sum"), 2), "n": len(g)}
        rows.append(rec)
    for lab, blk, w in (("Newly measured: FedAvg non-private", "N2", None),
                        ("Newly measured: DP-FedAvg eps* = 4 (fixed)", "DP1", EPS4),
                        ("Newly measured: DP-FedAvg eps* = 4 (s*)", "DP2", EPS4),
                        ("Newly measured: complete method eps* = 4", "R1p", None)):
        g = select(runs, blk, "fb15k237", w)
        rows.append({"source": lab, "item": "test MRR", "value": fmt(seedsum(g, "test.mrr")),
                     "eps RDP worst client": fmt(seedsum(g, "privacy.eps"), 2), "n": len(g)})
    return pd.DataFrame(rows)


def table14_completion(progress: Optional[pd.DataFrame]) -> pd.DataFrame:
    if progress is None or progress.empty:
        return pd.DataFrame([{"status": PENDING}])
    t = progress.pivot_table(index=["plan", "priority", "block", "dataset"], columns="status", values="cell_id",
                             aggfunc="count", fill_value=0).reset_index()
    t["cells"] = progress.groupby(["plan", "priority", "block", "dataset"]).size().values
    if "attempt" in progress.columns:
        retried = progress[pd.to_numeric(progress["attempt"], errors="coerce").fillna(1) > 1]
        t["cells_with_retries_or_resumes"] = t.apply(lambda r: int(((retried["block"] == r["block"]) &
                                                                    (retried["dataset"] == r["dataset"])).sum()), axis=1)
    return t


def table_mia(runs: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for ds in DATASETS:
        for lab, w in (("FedAvg non-private", {"cfg.dp.enabled": False}),
                       ("FedAvg + DP eps* = 1", {"cfg.dp.enabled": True, "cfg.dp.target_epsilon": 1.0}),
                       ("FedAvg + DP eps* = 4", {"cfg.dp.enabled": True, "cfg.dp.target_epsilon": 4.0}),
                       ("FedAvg + DP eps* = 8", {"cfg.dp.enabled": True, "cfg.dp.target_epsilon": 8.0})):
            g = select(runs, "M1", ds, w)
            rows.append({"dataset": DS_NAME[ds], "configuration": lab, "A2 AUC": fmt(seedsum(g, "mia.auc")),
                         "TPR at FPR 1 %": fmt(seedsum(g, "mia.tpr_at_fpr_1pct")),
                         "TPR at FPR 0.1 %": fmt(seedsum(g, "mia.tpr_at_fpr_0_1pct")),
                         "empirical eps lower bound (max)": float(g["mia.eps_lower_bound"].max())
                         if len(g) and "mia.eps_lower_bound" in g and g["mia.eps_lower_bound"].notna().any() else None,
                         "accountant eps (max)": float(g["privacy.eps"].max()) if len(g) and "privacy.eps" in g and
                         g["privacy.eps"].notna().any() else None,
                         "red line (lower bound > accountant)": bool(g["mia.lower_bound_exceeds_accountant"].fillna(False)
                                                                     .astype(bool).any())
                         if len(g) and "mia.lower_bound_exceeds_accountant" in g else None, "n": len(g)})
    return pd.DataFrame(rows)


def table_fpr_by_size_third(runs: pd.DataFrame) -> pd.DataFrame:
    """Diagnostic (owner decision B4): benign false-positive rate of the frozen rule per declared-size third."""
    rows = []
    for ds in DATASETS:
        for lab, blk, w in (("complete method, clean (tau*)", "R1p", None),
                            ("DP-FedAvg clean, scores at its configured tau", "DP2", EPS4)):
            g = select(runs, blk, ds, w)
            rec = {"dataset": DS_NAME[ds], "runs": lab, "n": len(g)}
            for k in ("0", "1", "2"):
                c = f"anomaly_scores.benign_fpr_at_cfg_tau_by_size_third.{k}"
                rec[f"benign FPR third {k} ({['small', 'middle', 'large'][int(k)]})"] = fmt(seedsum(g, c))
            rec["benign FPR overall"] = fmt(seedsum(g, "anomaly_scores.benign_fpr_at_cfg_tau"))
            rows.append(rec)
    return pd.DataFrame(rows)


# ------------------------------------------------------------------------------------------------ writers
def to_markdown(df: pd.DataFrame, title: str, tier: str, note: str = "") -> str:
    lines = [f"# {title}", ""]
    b = banner(tier)
    if b:
        lines += [f"> **{b}**", ""]
    if note:
        lines += [note, ""]
    show = df[[c for c in df.columns if not c.endswith((".mean", ".n", ".per_seed")) and c != "run_ids"]]
    if show.empty:
        return "\n".join(lines + ["(no rows)"]) + "\n"
    cols = list(show.columns)
    lines.append("| " + " | ".join(str(c) for c in cols) + " |")
    lines.append("|" + "---|" * len(cols))
    for _, r in show.iterrows():
        lines.append("| " + " | ".join("" if (isinstance(v, float) and np.isnan(v)) else
                                      (f"{v:.4g}" if isinstance(v, float) else str(v)) for v in r.values) + " |")
    return "\n".join(lines) + "\n"


def write_table(df: pd.DataFrame, out_dir: Path, name: str, title: str, tier: str, note: str = "",
                latex: bool = False) -> Dict[str, str]:
    from .io import write_csv
    out_dir = Path(out_dir)
    stem = prefix(tier) + name
    write_csv(out_dir / f"{stem}.csv", df)
    (out_dir / f"{stem}.md").write_text(to_markdown(df, title, tier, note))
    files = {"csv": str(out_dir / f"{stem}.csv"), "md": str(out_dir / f"{stem}.md")}
    if latex and not df.empty:
        show = df[[c for c in df.columns if not c.endswith((".mean", ".n", ".per_seed")) and c != "run_ids"]]
        try:
            tex = show.to_latex(index=False, escape=True)
            if banner(tier):
                tex = f"% {banner(tier)}\n" + tex
            (out_dir / f"{stem}.tex").write_text(tex)
            files["tex"] = str(out_dir / f"{stem}.tex")
        except Exception as e:                       # LaTeX export is a convenience; CSV/MD are the record
            files["tex_error"] = repr(e)
    return files


def sha256_obj(obj) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, default=str).encode()).hexdigest()
