#!/usr/bin/env python3
"""Build the consolidated defect register (Phase B item 1) as CSV + Markdown from one list (no hand-copied tables).

Sources merged: Phase A critical/major/minor/optional defects (CR/MJ/MN/OP), Phase A review of the revision package
(G1-G15), contradictions X01-X24 (linked, not duplicated), and new Phase B design-review findings (CR-13, MJ-15..,
MN-10.., OP-9..). Status columns describe DESIGN status only: nothing in the revision package has been executed.
"""
from __future__ import annotations

import argparse
import csv
import sys
from collections import Counter

A, P, N, NA = "Addressed by design (unexecuted)", "Partially addressed", "Not addressed", "n/a"

R = []


def d(id, sev, src, area, title, evidence, legacy, rev, fix, dec, phase, verify, related=""):
    R.append(dict(id=id, severity=sev, source=src, area=area, title=title, evidence=evidence, legacy_effect=legacy,
                  revision_status=rev, resolution=fix, decisions=dec, phase=phase, verification=verify,
                  related=related))


PA, RV, PB = "Phase A audit", "Phase A review of revision (File 2)", "Phase B design review"

# ------------------------------------------------------------------ CRITICAL
d("CR-1", "Critical", PA, "Result provenance", "Hard-coded, formula-derived and simulated numbers presented as findings",
  "Phases 5-8 notebooks; result_provenance.csv C08-C13, C22-C36", "Tables II-V, most of Figs. 15-34 invalid",
  P, "Withdraw all; every table/figure generated only from saved run records; provenance label on every number",
  "-", "C-F", "linter test_no_hardcoded_results; Table 14 completion status; provenance column in every table", "X12,X22; CL-02")
d("CR-2", "Critical", PA, "Privacy", "Invalid epsilon (sum of per-round client means, delta not composed) and invalid stop rule",
  "Section 4 of Phase A; phaseA_epsilon_check.json", "eps=15.53 is not a guarantee; run stopped at round 16",
  A, "Per-client RDP over all executed steps; worst-client eps; PLD cross-check; calibration to eps*",
  "D3", "C", "test_accountant; Phase B checks: same-library cross-check (within 0.2 %), own numerical quadrature "
  "(agrees to 1e-3), PRV accountant (different library) brackets the PLD value", "X06; CL-14")
d("CR-3", "Critical", PA, "Claims", "Headline row combines non-private utility with mechanisms never active in that model",
  "C41, C44, C45", "'Proposed system' MRR 0.2858 is non-private", A,
  "Complete-method runs (DP + trust + integrity active together, block R1p); separate rows for each configuration",
  "D9", "E-F", "Table 3 rows built from one run configuration each", "X23; CL-03, CL-04")
d("CR-4", "Critical", PA, "Evaluation", "Invalid protocol described as full-test evaluation",
  "300/150 random tail-only queries, optimistic ties, test evaluated every round", "All legacy MRRs protocol-limited",
  A, "Full filtered head+tail ranking, realistic ties, selection on V_sel only, test evaluated once",
  "-", "C", "test_filtered_head_tail_realistic_matches_bruteforce, test_ties_are_not_optimistic", "X05; CL-12")
d("CR-5", "Critical", PA, "Statistics", "Statistics computed over rounds of single runs (pseudo-replication)",
  "Wilcoxon p=3.05e-5, d=6.21, CI over rounds", "All significance claims invalid", A,
  "Seed-level paired statistics; per-seed values; Holm within families", "D8,D9", "E-F", "stats tests; Table 12", "X22; CL-25")
d("CR-6", "Critical", PA, "Trust/robustness", "Trust described as cosine of updates; implemented from un-noised client losses",
  "phase6 TrustScorer", "Poisoning/Sybil numbers invalid; un-noised loss release outside the accountant",
  "Addressed in code; not executed", "Update-based trust on transmitted (DP-noised) updates only; real attack experiments",
  "D14,D15,D16", "C,E", "R1-R5 blocks; detection TPR/FPR logged", "X01; CL-17")
d("CR-7", "Critical", PA, "Privacy", "Warm start from the non-private checkpoint in DP code and claimed in tables",
  "phase4 warm-start code; C43", "Would void DP (not triggered: file not found)", A,
  "Config validation rejects warm_start", "-", "C", "test_config_guards", "X08; CL-11")
d("CR-8", "Critical", PA, "Data/partition", "Partition misreported (74.26 %, 'semantic clustering')",
  "C38-C39; trained partition = relation IDs in ID order (30.81 % largest)", "Heterogeneity claims invalid", A,
  "Report the partition actually trained, with measured per-client statistics", "D4", "D", "partition audit report (Table 2)",
  "X03,X04; CL-09, CL-10")
d("CR-9", "Critical", PA, "Integrity", "'IPFS integrity' stored random tensors, used fake CIDs and a literal latency",
  "phase6 SimulatedIPFS; phase7 0.8 ms literal", "Integrity/overhead claims invalid", A,
  "Honest SHA-256 content-addressed layer; measured overhead; no IPFS claim unless real IPFS is used", "D7", "C,E",
  "I1/I2 blocks; tamper tests", "X13,X15; CL-22")
d("CR-10", "Critical", PA, "Privacy", "'Adaptive DP' claimed but never run; schedule ablation fabricated",
  "phase4 sigma fixed 1.0; phase5 simulate_schedule formula", "Table III invalid", "Addressed in code (4C); not executed",
  "Deterministic schedules calibrated to equal eps, executed for all R rounds; claim depends on decision D12",
  "D12,D13", "C,E", "T3 + DP2/DP2h blocks; schedule_verified assertion", "X02; CL-15")
d("CR-11", "Critical", PA, "Implementation", "Executed configuration differs from the stated one",
  "1 negative (P3); 25 % degenerate negatives and no entity normalisation (P4)", "Confounds every comparison", A,
  "One corrected trainer for all conditions; legacy behaviour only in labelled replica rows", "-", "C",
  "test_correct_negatives_*, test_legacy_p4_bug_is_reproduced", "CL-11")
d("CR-12", "Critical", PA, "Privacy", "DP vs non-DP comparison confounded (model, negatives, epochs, batch, evaluation)",
  "C16", "'-96.85 % privacy cost' is not a DP cost", A, "DP ladder on the same partition/trainer, paired by seed (L4, DP3)",
  "-", "E", "L4 and DP3 blocks", "CL-16")
d("CR-13", "Critical", PB, "Integrity", "Integrity verification is not in the data path of the revision",
  "federated.py: store.process_round hashes U[c] and immediately re-hashes the same in-memory bytes; aggregate() then "
  "uses the in-memory tensors U, not the verified bytes", "-",
  "Not addressed (verification can never fail during training)",
  "serialize -> store -> fetch -> verify -> deserialize -> aggregate the verified tensor; reject on mismatch; "
  "tamper-injection experiment with integrity on/off", "D7", "C,E", "I2 block (detection rate must be 1.0; utility "
  "with/without verification under corruption); unit test that a corrupted object never reaches aggregate()",
  "CL-22")
d("CR-14", "Critical", PB + " (independent review)", "Privacy",
  "Add/remove adjacency is inconsistent with publishing exact client sizes",
  "revision DP_MECHANISM.md: add/remove adjacency and 'client dataset sizes (treated as public)'; N_k sets FedAvg "
  "weights, the normalisation q*N_k and, in design A, q_k = B/N_k and T_k; an adversary who knows the other triples "
  "learns membership from N_k", "-", "Not addressed (statement as written is false)",
  "Use zero-out adjacency (one triple replaced by a null record with zero gradient; size public and unchanged); the "
  "Poisson-subsampled Gaussian bounds and every eps value stay the same; the guarantee hides which triples a client "
  "holds, not how many", "D2", "B,C", "03 section 7.2; accountant metadata states the adjacency", "")
# ------------------------------------------------------------------ MAJOR
d("MJ-1", "Major", PA, "Benchmark", "One dataset only (three required)", "Paper uses FB15k-237 only", "-", P,
  "FB15k-237 + WN18RR + third dataset (D5) under one pipeline", "D5", "D", "dataset cards + Table 1", "CL-07")
d("MJ-2", "Major", PA, "Statistics", "Single seed", "-", "No uncertainty", A, "5 seeds; 10 for headline blocks", "D8",
  "E", "Table 12", "CL-25")
d("MJ-3", "Major", PA, "Baselines", "No measured centralised baseline, no real aggregation or DP baselines",
  "0.094 constant; FedAvg/Krum/StdDP as multiples", "-", P, "N1, N2, DP1, R1, R4 blocks", "D17", "E", "Table 4", "X12; CL-21")
d("MJ-4", "Major", PA, "Trust/robustness", "No threat model, no real attacks, no success definitions, no benign FPR",
  "phase6 simulate_* functions", "-", P, "THREAT_MODEL (03a); 7 attacks with success metrics; benign FPR by client size",
  "D16", "B,E", "R2-R5 blocks; Table 9", "X20; CL-19")
d("MJ-5", "Major", PA, "Thresholds", "No threshold sweeps with validation-only selection; no tau selection rule",
  "Legacy tau ablation hard-coded", "-", P, "Threshold inventory; pre-registered rules incl. FPR-calibrated tau",
  "D13,D14", "B,E", "T2b, T3, X1-X4; selection files with rule hashes", "CL-18")
d("MJ-6", "Major", PA, "Ablations", "No ablations (DP-only, trust-only, full, -integrity, -defence)", "-", "-", P,
  "Ablation set mapped to MP 13 items 1-9 (06_experiment_matrix.md)", "-", "E", "Table 5", "CL-21")
d("MJ-7", "Major", PA, "Data/partition", "'Non-IID' measured on the global graph, not across clients",
  "Gini 0.675 / skewness 34.39 are global statistics", "-", A, "Across-client statistics (JS, Hellinger, Gini of sizes)",
  "D4", "D", "Table 2", "CL-10")
d("MJ-8", "Major", PA, "Data/partition", "5 relation-disjoint clients make robust aggregation ill-posed and leak relation ownership",
  "Legacy partition", "-", A, "10 Dirichlet clients; legacy split kept for replicas only", "D4", "D", "Table 2", "CL-09")
d("MJ-9", "Major", PA, "Privacy", "Privacy claims under-specified (unit, adjacency, threat model, exclusions)",
  "Paper Section on DP", "-", P, "Formal statement in 03 section 7 and 03a; exclusions listed", "D2", "B", "review of 03/03a",
  "CL-13")
d("MJ-10", "Major", PA, "Privacy", "DP utility collapse not investigated", "MRR 0.009", "-", P,
  "DP ladder + pre-registered tuning of q, lr, C, R; decomposition (DP3)", "D10,D11,D13", "E", "T2a-T2d, DP3, L4", "CL-16")
d("MJ-11", "Major", PA, "Claims", "Hypotheses H1-H3 not formally defined", "'accuracy >= 90 %' etc.", "-", P,
  "Formal hypotheses with decision rules (03 section 13)", "D9", "B", "pre-registration before Stage 4", "CL-24")
d("MJ-12", "Major", PA, "Overhead", "Overheads hard-coded; no integrity on/off comparison", "0.8 ms, 2.3 ms literals", "-", A,
  "Measured hash/verify/store/aggregation times; I1/I2 blocks", "D7", "E", "Tables 10-11", "CL-22")
d("MJ-13", "Major", PA, "Positioning", "Contribution weakly positioned; prior-work numbers unverified and protocol-mismatched",
  "Table II literals", "-", N, "Position against FedE, FedR, FedLU, DP-Flames; never mix protocols in one table",
  "D12,D17", "manuscript phase", "related-work check", "CL-31")
d("MJ-14", "Major", PA, "Planning", "No experiment matrix or cost estimate for Phases 5-8; no 3D plots; most tables missing",
  "-", "-", P, "Full matrix + cost model (06, 07); table/figure traceability", "D18", "B,F", "experiment_matrix.csv", "CL-26..28")
d("MJ-15", "Major", PB, "Privacy (MIA)", "MIA design compares training triples with official test triples",
  "mia.py: non-members = data.test; FB15k-237 valid/test exclude triples whose entity pairs are directly linked in "
  "training (Toutanova & Chen 2015), so members and non-members differ in distribution; members = whole federation; "
  "no threat model", "-", "Not addressed (module disabled)",
  "Audit pool drawn from each client's training triples, each candidate included in training with probability 1/2 "
  "(members and non-members from the same distribution); pre-registered primary attack and pooling; TPR at low FPR; "
  "one-run audit lower bound (Steinke, Nasr & Jagielski 2023); testability rule", "D6", "C,E",
  "M1 block; unit test that non-members are never trained on", "CL-23")
d("MJ-16", "Major", PB, "Privacy", "Fixed-batch design fails for small clients when the batch is enlarged",
  "accountant.dp_steps_and_rate raises if N_k < B; q_k = B/N_k grows towards 0.5 for small clients (weak "
  "amplification); per-client sigma 4.07 vs 1.90 at eps 4 on FB15k-237 (phaseB_sigma_plan.csv). Both designs leave a "
  "~5x per-epoch signal-to-noise gap between smallest and mean client", "-", "Not addressed",
  "Offer design Q (one shared sigma and sampling rate, no N_k >= B constraint) next to design A; T2d decides on "
  "validation MRR; benign FPR by client-size third measured for both", "D11", "C,E", "P2.3, T2d", "G8")
d("MJ-17", "Major", PB, "Privacy", "DP utility levers (sampling rate, lr, rounds) fixed a priori",
  "Per-step noise-to-clip ratio sigma*sqrt(P)/(q*N_mean) at eps 4, R 100, tuning grid q 0.02-0.10: 1.3 (YAGO3-10, "
  "q 0.10) to 22.7 (WN18RR, q 0.02) (phaseB_sigma_plan.csv)", "-", N,
  "Pre-registered DP tuning on a tuning seed (T2a-T2d), validation only, disclosed", "D13", "E", "T2a-T2d blocks", "G9")
d("MJ-18", "Major", PB, "Statistics", "Selection and final reporting use the same seeds",
  "selection_rules.yaml selects C/schedule on the 5 final seeds' validation MRR", "-", N,
  "Separate tuning seed(s) from confirmatory seeds; freeze selections (hashes) before Stage 4", "D13", "E",
  "selection files reference S_TUNE only", "")
d("MJ-19", "Major", PB, "Baselines", "Asymmetric tuning budget: DP settings tuned, non-private settings fixed",
  "p3.yaml has no tuning; p4.yaml sweeps C and schedules", "-", N,
  "Same grid for the shared optimiser settings (lr x batch) for centralised and FedAvg (T1); the remaining "
  "DP-specific tuning (21 cells vs 6 per dataset) is disclosed", "D13", "E", "T1 block", "")
d("MJ-20", "Major", PB, "Positioning", "Closest prior work not addressed",
  "DP-Flames (Hu et al., WWW 2023): triple-level DP for FKGE with validation-driven adaptive noise and triple-membership "
  "attacks; FedE (IJCKG 2021) defines relation-partitioned FKGE benchmarks with per-client test sets",
  "'Adaptive DP' novelty overstated", N,
  "Reposition the contribution; define 'adaptive' precisely (D12); do not compare numbers across protocols", "D12,D17",
  "B, manuscript", "related-work section check", "")
d("MJ-21", "Major", PB, "Benchmark", "YAGO3-10 leakage and duplicated facts",
  "Akrami et al. 2020: isAffiliatedTo/playsFor near-duplicates; 2,561 of 5,000 test triples have duplicates in training",
  "-", "n/a (dataset choice)",
  "Default third dataset CoDEx-M; YAGO3-10 only as an extension with the leakage caveat", "D5", "D", "dataset card", "")
# ------------------------------------------------------------------ MINOR
d("MN-1", "Minor", PA, "Data/partition", "Legacy Gini formula slightly biased", "missing 1/n correction", "-", A,
  "Revision formula", "-", "C", "unit test", "")
d("MN-2", "Minor", PA, "Documentation", "Phase 4 notebook header contradicts its configuration", "eps 8 / sigma 2->0.5 vs 15 / 1.0",
  "-", A, "Legacy frozen; new configs only", "-", "C", "-", "X02")
d("MN-3", "Minor", PA, "Documentation", "Figure numbering collisions; captions describe what plots do not show", "Figs. 5,7,9,13,14",
  "-", N, "Regenerate all figures from records", "-", "F", "figure manifest", "X07")
d("MN-4", "Minor", PA, "Implementation", "Silent fallbacks (eps = sigma*0.5; stub result dictionaries)", "phase4, phase6-8", "-",
  A, "Failures raise; no defaults in except-blocks", "-", "C", "linter", "")
d("MN-5", "Minor", PA, "Evaluation", "Legacy evaluation subsample drawn from the global RNG", "evaluate_mrr_hits", "-", A,
  "Purpose-specific seeded generators", "-", "C", "determinism test", "")
d("MN-6", "Minor", PA, "Documentation", "Manuscript wording errors", "10 clients, round-7 MRR, '~2x' etc.", "-", N,
  "Manuscript phase", "-", "manuscript", "-", "X09,X11,X24")
d("MN-7", "Minor", RV, "Reporting", "plotting.py imports a non-existent fedkge.tables; PNG at 200 dpi only", "plotting.py",
  "-", N, "Fix import; PNG+PDF+SVG", "-", "C,F", "plot smoke test", "G5")
d("MN-8", "Minor", RV, "Reproducibility", "Deprecated datetime.utcnow(); no scripts/ entry points; PyKEEN download without licence gate",
  "io.py; README", "-", N, "Timezone-aware timestamps; scripts/; explicit licence confirmation flag", "-", "C",
  "test for the gate", "G12,G13")
d("MN-9", "Minor", RV, "Data/partition", "Re-drawing until the minimum size holds yields a truncated Dirichlet",
  "partition.assign", "-", "Documented",
  "Report attempts and acceptance rate; compare heterogeneity by measured statistics, not by alpha",
  "D4", "D", "phaseB_partition_feasibility.csv (WN18RR alpha 0.1: about 96 % of draws rejected)", "G15")
d("MN-10", "Minor", PB, "Threat model", "FedAvg weights use self-reported client sizes", "Sybil identities claim the median size",
  "-", N, "Sizes declared and registered before training; misreporting is an attack parameter", "D16", "B", "03a", "")
d("MN-11", "Minor", PB, "Privacy", "Client-level DP is not feasible with 10 clients",
  "phaseB_sigma_plan.json: z = 12.7 for eps 4 (100 rounds); averaged-update noise ~1,540x the clip on FB15k-237", "-",
  "n/a", "Do not run client-level DP; state as limitation (changes Phase A D2)", "D2", "B", "-", "OP-4")
d("MN-12", "Minor", PB, "Data", "20 % of the official validation split is reserved as FLTrust root data", "data.py vroot_fraction 0.2",
  "-", "Documented in code", "Disclose; V_sel = 80 % used for all selection", "-", "D", "dataset card", "")
d("MN-13", "Minor", PB, "Statistics", "Query-bootstrap CI is within-run uncertainty only", "evaluate(bootstrap=1000)", "-", P,
  "Label it as such; seed-level CI is the primary uncertainty", "D8", "F", "Table 12 column names", "")
d("MN-14", "Minor", PB, "Privacy", "Floating-point / PRNG side channels not addressed",
  "torch PRNG Gaussian noise (Mironov 2012)", "-", N, "Limitation statement; no side-channel claim", "-", "G", "-", "G11")
d("MN-15", "Minor", PB, "Evaluation", "Metric averaging conventions not stated in outputs",
  "micro over 2|T| queries vs per-relation macro", "-", P, "Explicit convention fields in final.json and tables", "-", "C",
  "schema field", "")
d("MN-16", "Minor", PB, "Implementation", "Checkpoints loaded with torch.load(weights_only=False)", "federated.py resume",
  "-", N, "Save tensors/JSON so weights_only=True works", "-", "C", "resume test", "")
d("MN-17", "Minor", PB, "Data/partition", "Dirichlet over relations models relation skew only",
  "MP 9: Dirichlet does not model every non-IID form", "-", "Documented",
  "State scope; optional entity-community partition (OP-10)", "D4", "D", "-", "")
d("MN-18", "Minor", PB, "Baselines", "Robust-aggregator assumptions depend on f",
  "trimmed mean needs floor(beta*n) >= f; Krum needs n > 2f+2; revision uses Krum f >= 1 even without attackers", "-", P,
  "Robustness parameters at the design value f = 0.2 (beta 0.2, Krum f 2), also in clean runs; the true attacker "
  "count if larger; violations flagged", "D16", "C", "assumption flags", "")
d("MN-19", "Minor", PB, "Attacks", "One strength s = 3 for every attack, fixed a priori", "base.yaml attack.strength", "-",
  P, "Keep s = 3 (fixed before any result) for the scaled attacks; ALIE's z and the adaptive gamma follow their own "
  "rules; justification recorded in attack.json; no strength is tuned after results", "D16", "B,C", "attack.json", "")
d("MN-20", "Minor", PB, "Data", "PyKEEN vocabularies differ from official counts",
  "FB15k-237: 14,505 entities (PyKEEN) vs 14,541 (official)", "-", "Documented in dataset card",
  "Report before/after-loader counts and removed triples", "D5", "D", "Table 1", "")
d("MN-21", "Minor", PB + " (independent review)", "Attacks", "KG-targeted attack draws its target queries from the test set",
  "federated.py make_targets(data.test, ...): beyond a black-box attacker's knowledge", "-", N,
  "Draw (h, r) target pairs from the attacker's own training triples; the evaluator still checks that t* is false",
  "D16", "C", "attack.json records the target source", "")
d("MN-22", "Minor", PB + " (independent review)", "Privacy/robustness", "No guard against non-finite broadcasts or gradients",
  "a crafted inf/NaN global model could break per-example clipping (NaN norms)", "-", N,
  "Clients reject non-finite broadcasts and zero any non-finite per-example gradient before clipping; behaviour on a "
  "failed broadcast verification specified", "-", "C", "unit tests", "")
# ------------------------------------------------------------------ OPTIONAL
d("OP-1", "Optional", PA, "Privacy", "Phase A proposed PLD epsilon as the primary figure",
  "PLD ~7 % tighter than RDP at the operating points (phaseB_sigma_plan.csv)", "-", A,
  "CHANGED in Phase B: RDP is primary (it drives calibration and the tested code), PLD and PRV are reported next to it",
  "D3", "C", "-", "")
d("OP-2", "Optional", PA, "Privacy", "Privacy-aware hyperparameter tuning (Papernot & Steinke 2022)", "-", "-", N,
  "Disclose tuning cost (default) or account for it", "D13", "B", "-", "G10")
d("OP-3", "Optional", PA, "Privacy", "Design alternative if DP utility is unacceptable", "e.g. sparsity-preserving DP, relation-only sharing",
  "-", N, "Only via D10 trigger", "D10", "E", "-", "")
d("OP-4", "Optional", PA, "Privacy", "Client-level DP regime", "-", "-", N, "Withdrawn: infeasible at K=10 (MN-11)", "D2",
  "-", "-", "MN-11")
d("OP-5", "Optional", PA, "Integrity", "Real IPFS CIDs or a local IPFS node", "-", "-", N, "Only if D7 option (b)", "D7", "C,E",
  "-", "")
d("OP-6", "Optional", PA, "Statistics", "More seeds for headline comparisons", "-", "-", N, "Full profile (10 seeds)", "D8",
  "E", "-", "G14")
d("OP-7", "Optional", PA, "Model", "Second KGE model (RotatE/ComplEx)", "-", "-", N, "Not in core; possible extension", "-",
  "E", "-", "")
d("OP-8", "Optional", PA, "Continuity", "Re-evaluate the saved legacy checkpoint under the corrected protocol", "-", "-", N,
  "Block L0 (cheap)", "-", "C", "-", "CL-06")
d("OP-9", "Optional", PB, "Privacy", "Validation-adaptive noise with an RDP filter (DP-Flames-inspired)", "Feldman & Zrnic 2021",
  "-", N, "Block O1 if D12 option (b)", "D12", "C,E", "-", "")
d("OP-10", "Optional", PB, "Data/partition", "Entity-community partition as a second non-IID form", "-", "-", N,
  "Possible extension", "D4", "D", "-", "")
d("OP-11", "Optional", PB, "Privacy", "Calibrate sigma with PLD instead of RDP", "PLD eps ~0.93x RDP at the RDP-calibrated sigma",
  "-", N, "Not default (RDP is conservative and already tested)", "D3", "C", "-", "")
# ------------------------------------------------------------------ REVISION GAPS (G)
G = [
 ("G1", "Major", "Revision never executed: no smoke, dev or final outputs", "No revised result can be cited yet",
  "Stage 0-4 execution plan with gates", "D18", "C-E", "Table 14"),
 ("G2", "Major", "Phases 5-8 not delivered (no matrices for trust/attacks/baselines/integrity/MIA, no tau rule)",
  "Most paper claims live there", "Matrix blocks R*, I*, M1, X*; tau rule D14", "D14", "C,E", "experiment_matrix.csv"),
 ("G3", "Major", "THREAT_MODEL.md referenced but missing", "Robustness claims need it", "Draft in 03a_threat_model.md",
  "D16", "B", "03a"),
 ("G4", "Major", "alpha in {0.1, 1.0} only", "Master prompt requires 0.5 too", "alpha {0.1,0.5,1.0} + IID", "D4", "D", "N3, X1"),
 ("G5", "Minor", "2D plots only; PNG only", "3D surfaces from real data required", "Plot families A-E mapped to blocks", "-",
  "F", "figure manifest"),
 ("G6", "Major", "Early stopping vs calibrated schedules", "Decaying schedules never reach low-noise rounds",
  "DP runs execute all R rounds; checkpoint selection is post-processing", "D13", "C", "rounds_executed = R in DP runs"),
 ("G7", "Major", "Attackers skip DP noise (targeted, Sybil)", "Robustness overstated", "Noise modes inherit/matched (main), none (X5)",
  "D16", "C,E", "attack.json noise_mode"),
 ("G8", "Major", "Per-client sigma vs magnitude anomaly", "Honest small clients may be flagged",
  "Benign FPR by client-size third measured for both sampling designs (P2.3, T2d); variant trigger (D15)",
  "D11,D15", "E", "trust_rounds.csv"),
 ("G9", "Major", "DP batch/optimiser/lr fixed a priori", "Main DP-utility levers untested", "T2a-T2d tuning blocks",
  "D13", "E", "T2a-T2d blocks"),
 ("G10", "Major", "Tuning privacy cost not discussed", "Each candidate run consumed client privacy",
  "Disclose (default) or account (OP-2)", "D13", "B,G", "limitations"),
 ("G11", "Minor", "Dataset-level leakage, logged losses, secure-mode RNG not discussed", "Privacy statement incomplete",
  "Exclusions listed in 03 section 7.6 and 03a", "D2", "B", "03a"),
 ("G12", "Minor", "Automatic PyKEEN download without a licence gate", "MP 18", "Explicit confirmation flag", "D5", "C",
  "unit test"),
 ("G13", "Minor", "No scripts/ entry points; Colab-only README", "MP 18-20", "scripts/ + local commands", "-", "C,G",
  "README"),
 ("G14", "Major", "n = 5 cannot give exact p < 0.05", "Roadmap asks for Wilcoxon across seeds",
  "Effect sizes + CIs primary; 10 seeds for headline (full profile)", "D8", "E", "Table 12"),
 ("G15", "Major", "WN18RR partition feasibility at alpha 0.1", "Truncated or failed partitions",
  "Simulation with unverified WN18RR counts: feasible, but ~96 % of draws rejected; binding check in Phase D; fallback rule pre-approved", "D4", "D",
  "phaseB_partition_feasibility.csv"),
]
for gid, sev, title, effect, fix, dec, phase, verify in G:
    d(gid, sev, RV, "Revision package", title, "Phase A Section 9.2", effect,
      "Gap in revision", fix, dec, phase, verify)


def md_escape(s: str) -> str:
    return str(s).replace("|", "/").replace("\n", " ")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-csv", required=True)
    ap.add_argument("--out-md-table", required=True)
    a = ap.parse_args(argv)
    ids = [r["id"] for r in R]
    if len(ids) != len(set(ids)):
        raise SystemExit("duplicate ids")
    with open(a.out_csv, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(R[0].keys()))
        w.writeheader(); w.writerows(R)
    order = ["Critical", "Major", "Minor", "Optional"]
    lines = []
    for sev in order:
        rows = [r for r in R if r["severity"] == sev]
        lines.append(f"\n### {sev} ({len(rows)})\n")
        lines.append("| ID | Area | Defect | Revision status | Resolution | Decision | Phase | Verification |")
        lines.append("|---|---|---|---|---|---|---|---|")
        for r in rows:
            lines.append("| " + " | ".join(md_escape(r[k]) for k in
                         ("id", "area", "title", "revision_status", "resolution", "decisions", "phase", "verification"))
                         + " |")
    with open(a.out_md_table, "w") as f:
        f.write("\n".join(lines) + "\n")
    c = Counter(r["severity"] for r in R)
    s = Counter(r["source"] for r in R)
    print("total", len(R), dict(c), dict(s))
    return 0


if __name__ == "__main__":
    sys.exit(main())
