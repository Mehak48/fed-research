"""Content-addressed integrity layer IN THE DATA PATH (Phase C repair of defect CR-13; Phase B decision D7 option a).

WHAT THIS IS
  Every transmitted object (each client's update U_k^t, and the global model theta^t that the server broadcasts)
  is serialised canonically and identified by  'sha256-' + hex(SHA-256(bytes)).  The identifier travels over the
  (assumed) authenticated channel; the bytes travel through an UNTRUSTED content store / transport.
  The receiver fetches the bytes, recomputes the hash, compares it with the identifier and checks the header
  (object name, round, dtype, shape). ONLY bytes that pass are deserialised, and ONLY the deserialised tensor is
  used: the server aggregates exactly the verified bytes, and each client trains from exactly its verified copy
  of the broadcast. (The revision as delivered hashed the bytes and then aggregated an unchecked in-memory copy,
  so verification could never fail and never protected anything.)
  Each round has a manifest {round, object ids, id of the previous manifest}: a hash chain, so rewriting history
  is detectable.

MODES
  off                 no transport simulation: tensors are passed in memory (no serialisation, no hashing).
  transport_only      serialise -> store -> (in-transit corruption, if configured) -> fetch -> deserialise,
                      WITHOUT any hashing or verification ("integrity off" arm of the corruption experiment I2).
  hash_only           transport_only + hashing at the sender + verification at the receiver (in-memory store).
  full_store_last_k   hash_only + the objects and manifests of the last k rounds persisted on disk.

CORRUPTION MODEL (experiment I2 only; corrupt_p = 0 everywhere else)
  Each transmitted object instance (every upload, and every client's download of the broadcast) is independently
  corrupted with probability corrupt_p: one uniformly chosen PAYLOAD byte is XOR-ed with 0xFF.

WHAT IT GUARANTEES
  Any change to covered bytes (header + payload) is detected before use, assuming SHA-256 second-preimage
  resistance and an authentic identifier.
WHAT IT DOES NOT DO (must not be claimed)
  * it is NOT a poisoning defence: a malicious client hashes its poisoned update correctly;
  * no authenticity of the identifier itself without an authenticated channel or signatures (not implemented);
  * no availability, replication, pinning or content routing; no network latency measurement;
  * no IPFS: identifiers are NOT CIDs (no multihash/multibase/CIDv1, no UnixFS chunking).
"""
from __future__ import annotations

import hashlib
import json
import shutil
import struct
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch

PREFIX = "sha256-"
MODES = ("off", "transport_only", "hash_only", "full_store_last_k")


def serialize(t: torch.Tensor, meta: Dict) -> bytes:
    """Canonical serialisation: 4-byte header length | JSON header (sorted keys) | little-endian float32 payload.

    The payload is joined straight from the array's buffer (one copy of the payload instead of two); the bytes are
    identical to header + arr.tobytes() (test_integrity_fast_path_is_byte_identical)."""
    arr = t.detach().to("cpu", torch.float32).contiguous().numpy().astype("<f4", copy=False)
    header = json.dumps({"dtype": "float32-le", "shape": list(arr.shape), **meta}, sort_keys=True).encode()
    return b"".join((struct.pack("<I", len(header)), header, arr))


def object_id(data: bytes) -> str:
    return PREFIX + hashlib.sha256(data).hexdigest()


def parse(data: bytes) -> Tuple[Dict, np.ndarray]:
    """Header + payload view. Raises ValueError on malformed bytes."""
    if len(data) < 4:
        raise ValueError("object shorter than its length prefix")
    hl = struct.unpack("<I", data[:4])[0]
    if 4 + hl > len(data):
        raise ValueError("header length exceeds object size")
    header = json.loads(data[4:4 + hl])
    if header.get("dtype") != "float32-le":
        raise ValueError(f"unexpected dtype {header.get('dtype')}")
    shape = [int(x) for x in header["shape"]]
    n = int(np.prod(shape))
    if len(data) - (4 + hl) != 4 * n:
        raise ValueError("payload size does not match the header shape")
    # read-only view on the received bytes (no copy of the payload); receive() copies it once into a fresh tensor
    return header, np.frombuffer(data, dtype="<f4", count=n, offset=4 + hl).reshape(shape)


def deserialize(data: bytes) -> np.ndarray:
    return parse(data)[1]


def payload_offset(data: bytes) -> int:
    return 4 + struct.unpack("<I", data[:4])[0]


@dataclass
class Envelope:
    """What travels over the authenticated channel: name, round and (when hashing) the identifier."""
    name: str
    round: int
    shape: Tuple[int, ...]
    oid: Optional[str]
    nbytes: int
    key: str                      # storage key in the untrusted store


@dataclass
class Receipt:
    accepted: bool
    reason: str
    corrupted_in_transit: bool    # ground truth from the corruption model (unknown to the receiver)
    seconds_verify: float = 0.0


@dataclass
class _RoundLog:
    round: int
    sent: int = 0
    bytes: int = 0
    hash_s: float = 0.0
    store_s: float = 0.0
    verify_s: float = 0.0
    received: int = 0
    rejected: int = 0
    corrupted: int = 0
    corrupted_and_rejected: int = 0
    corrupted_and_consumed: int = 0
    rejected_uploads: List[str] = field(default_factory=list)
    rejected_downloads: List[str] = field(default_factory=list)
    ids: Dict[str, str] = field(default_factory=dict)


class IntegrityLayer:
    """Sender: send(name, rnd, tensor) -> Envelope.  Receiver: receive(env, receiver) -> (tensor | None, Receipt).

    The returned tensor is constructed ONLY from bytes fetched from the store (and verified, when the mode
    verifies); it never aliases the sender's in-memory tensor."""

    def __init__(self, mode: str, root: Optional[Path] = None, keep_last_k: int = 3, corrupt_p: float = 0.0,
                 rng: Optional[np.random.Generator] = None):
        if mode not in MODES:
            raise ValueError(f"integrity mode must be one of {MODES}")
        if not (0.0 <= float(corrupt_p) <= 1.0):
            raise ValueError("corrupt_p must be in [0, 1]")
        if corrupt_p and mode == "off":
            raise ValueError("corruption injection needs a transport (mode transport_only, hash_only or full_store_last_k)")
        self.mode, self.k = mode, int(keep_last_k)
        self.transport = mode != "off"
        self.verify = mode in ("hash_only", "full_store_last_k")
        self.corrupt_p = float(corrupt_p)
        self.rng = rng if rng is not None else np.random.default_rng(0)
        self.root = Path(root) if root else None
        if mode == "full_store_last_k":
            if self.root is None:
                raise ValueError("full store needs a directory")
            self.root.mkdir(parents=True, exist_ok=True)
        self._store: Dict[str, bytes] = {}
        self._persist: Dict[str, bytes] = {}
        self.prev_manifest_id = PREFIX + "0" * 64
        self.stats: List[Dict] = []
        self._log: Optional[_RoundLog] = None

    # ------------------------------------------------------------------ round bookkeeping
    def begin_round(self, rnd: int) -> None:
        self._log = _RoundLog(round=int(rnd))
        self._store = {}
        self._persist = {}

    def end_round(self) -> Dict:
        lg = self._log
        if lg is None:
            raise RuntimeError("end_round without begin_round")
        rec = {"round": lg.round, "mode": self.mode, "n_objects": lg.sent, "bytes": lg.bytes,
               "hash_seconds": lg.hash_s, "store_seconds": lg.store_s, "verify_seconds": lg.verify_s,
               "n_received": lg.received, "n_rejected": lg.rejected, "n_corrupted": lg.corrupted,
               "n_corrupted_and_rejected": lg.corrupted_and_rejected,
               "n_corrupted_and_consumed": lg.corrupted_and_consumed,
               "rejected_uploads": lg.rejected_uploads, "rejected_downloads": lg.rejected_downloads}
        if self.verify:
            manifest = {"round": lg.round, "objects": lg.ids, "prev_manifest": self.prev_manifest_id}
            mbytes = json.dumps(manifest, sort_keys=True).encode()
            mid = object_id(mbytes)
            self.prev_manifest_id = mid
            rec["manifest_id"] = mid
            if self.mode == "full_store_last_k":
                t0 = time.perf_counter()
                rdir = self.root / f"round_{lg.round:04d}"
                rdir.mkdir(parents=True, exist_ok=True)
                for oid, data in self._persist.items():
                    (rdir / oid).write_bytes(data)
                (rdir / "manifest.json").write_bytes(mbytes)
                (rdir / "manifest.id").write_text(mid)
                old = sorted(self.root.glob("round_*"))[:-self.k] if self.k > 0 else []
                for d in old:
                    shutil.rmtree(d)
                rec["store_seconds"] += time.perf_counter() - t0
        self.stats.append(rec)
        self._log = None
        self._store = {}
        self._persist = {}
        return rec

    # ------------------------------------------------------------------ sender
    def send(self, name: str, rnd: int, tensor: torch.Tensor) -> Envelope:
        lg = self._log
        if lg is None or lg.round != int(rnd):
            raise RuntimeError("send() outside the current round")
        shape = tuple(int(x) for x in tensor.shape)
        if not self.transport:
            env = Envelope(name, int(rnd), shape, None, int(tensor.numel() * 4), key=name)
            self._store[name] = tensor           # in-memory hand-over (mode off)
            lg.sent += 1
            return env
        t0 = time.perf_counter()
        data = serialize(tensor, {"name": name, "round": int(rnd)})
        oid = object_id(data) if self.verify else None
        lg.hash_s += time.perf_counter() - t0
        t1 = time.perf_counter()
        key = f"{name}@{int(rnd)}"
        self._store[key] = data                   # untrusted store holds the bytes
        if self.mode == "full_store_last_k":
            self._persist[oid] = data
        lg.store_s += time.perf_counter() - t1
        lg.sent += 1
        lg.bytes += len(data)
        if oid is not None:
            lg.ids[name] = oid
        return Envelope(name, int(rnd), shape, oid, len(data), key=key)

    # ------------------------------------------------------------------ receiver
    def _fetch(self, env: Envelope) -> Tuple[bytes, bool]:
        data = self._store[env.key]
        corrupted = False
        if self.corrupt_p and self.rng.random() < self.corrupt_p:
            b = bytearray(data)
            off = payload_offset(data)
            i = off + int(self.rng.integers(len(b) - off))
            b[i] ^= 0xFF
            data, corrupted = bytes(b), True
        return data, corrupted

    def receive(self, env: Envelope, receiver: str, device=None) -> Tuple[Optional[torch.Tensor], Receipt]:
        """Fetch, verify (if the mode verifies) and deserialise. Returns (tensor or None, receipt)."""
        lg = self._log
        if lg is None or lg.round != env.round:
            raise RuntimeError("receive() outside the round of the envelope")
        lg.received += 1
        if not self.transport:
            return self._store[env.key], Receipt(True, "in-memory (integrity off)", False)
        data, corrupted = self._fetch(env)
        lg.corrupted += int(corrupted)
        t0 = time.perf_counter()
        reason = "accepted"
        ok = True
        if self.verify:
            if object_id(data) != env.oid:
                ok, reason = False, "hash mismatch"
        try:
            header, arr = parse(data)
            if ok and (header.get("name") != env.name or int(header.get("round", -1)) != env.round
                       or tuple(header["shape"]) != env.shape):
                ok, reason = False, "header does not match the envelope (name/round/shape)"
        except (ValueError, KeyError, json.JSONDecodeError) as e:
            ok, reason, arr = False, f"malformed object: {e}", None
        dt = time.perf_counter() - t0
        lg.verify_s += dt
        if not ok:
            lg.rejected += 1
            lg.corrupted_and_rejected += int(corrupted)
            (lg.rejected_uploads if env.name.startswith("client") else lg.rejected_downloads).append(
                f"{env.name}->{receiver}")
            return None, Receipt(False, reason, corrupted, dt)
        lg.corrupted_and_consumed += int(corrupted)
        t = torch.from_numpy(arr.copy())          # a fresh tensor built from the received bytes
        if device is not None:
            t = t.to(device)
        return t, Receipt(True, reason, corrupted, dt)

    # ------------------------------------------------------------------ persistence for resume
    def state_dict(self):
        return {"prev_manifest_id": self.prev_manifest_id, "stats": self.stats,
                "rng": self.rng.bit_generator.state}

    def load_state_dict(self, d):
        self.prev_manifest_id, self.stats = d["prev_manifest_id"], d["stats"]
        if d.get("rng") is not None:
            self.rng.bit_generator.state = d["rng"]


def summarize_stats(stats: List[Dict]) -> Dict:
    """Run-level integrity summary for integrity.json / final.json."""
    if not stats:
        return {}
    tot = lambda k: int(sum(s.get(k, 0) for s in stats))
    corrupted = tot("n_corrupted")
    rep = {"rounds": len(stats), "mode": stats[0]["mode"],
           "mean_bytes_per_round": float(np.mean([s["bytes"] for s in stats])),
           "mean_hash_s": float(np.mean([s["hash_seconds"] for s in stats])),
           "mean_verify_s": float(np.mean([s["verify_seconds"] for s in stats])),
           "mean_store_s": float(np.mean([s["store_seconds"] for s in stats])),
           "n_received": tot("n_received"), "n_rejected": tot("n_rejected"), "n_corrupted": corrupted,
           "n_corrupted_and_rejected": tot("n_corrupted_and_rejected"),
           "n_corrupted_and_consumed": tot("n_corrupted_and_consumed"),
           "detection_rate": (tot("n_corrupted_and_rejected") / corrupted) if corrupted else None,
           "false_rejections": tot("n_rejected") - tot("n_corrupted_and_rejected")}
    return rep


def tamper_test(root: Path, p_flip: float, rng: np.random.Generator) -> Dict:
    """Flip one random byte in max(1, round(p_flip * n)) randomly chosen PERSISTED objects, then re-verify every
    object and every manifest chain link. Detection rate MUST be 1.0 (SHA-256): this is a correctness check of
    the implementation, not an empirical security result."""
    root = Path(root)
    objs = [p for d in sorted(root.glob("round_*")) for p in d.iterdir() if p.name.startswith(PREFIX)]
    n_t = max(1, int(round(p_flip * len(objs)))) if objs else 0
    chosen = set(int(i) for i in rng.choice(len(objs), size=n_t, replace=False)) if n_t else set()
    tampered = set()
    for j, p in enumerate(objs):
        if j in chosen:
            b = bytearray(p.read_bytes())
            i = int(rng.integers(len(b)))
            b[i] ^= 0xFF
            p.write_bytes(bytes(b))
            tampered.add(p)
    detected = {p for p in objs if object_id(p.read_bytes()) != p.name}
    chain_ok = True
    for d in sorted(root.glob("round_*")):
        m = (d / "manifest.json").read_bytes()
        if object_id(m) != (d / "manifest.id").read_text().strip():
            chain_ok = False
    return {"n_objects": len(objs), "n_tampered": len(tampered), "n_detected": len(detected & tampered),
            "false_alarms": len(detected - tampered),
            "detection_rate": (len(detected & tampered) / len(tampered)) if tampered else float("nan"),
            "manifest_chain_intact": chain_ok, "p_flip": p_flip}
