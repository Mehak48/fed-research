"""Paper-ready experimental-results draft generated from recorded results (final package, section H).

Every number in the draft comes from the analysis outputs of recorded runs. Where a value does not exist yet the
draft prints a marked placeholder ⟦PENDING: ...⟧ that names exactly what is missing. Sentences about hypotheses are
generated from their decision labels with fixed, neutral wording: 'supported' only when the Holm-adjusted one-sided
p <= alpha; otherwise 'not supported at this level (inconclusive)'. The draft is a starting point for the authors,
not a substitute for reading the tables.
"""
from __future__ import annotations

import json
from typing import Dict, List, Optional

import numpy as np

from .paper import DATASETS, DS_NAME, PH, banner

FAMILY_TITLE = {"H1": "H1 — utility retention under privacy", "H2": "H2 — robustness to poisoning",
                "H2b": "H2b — no harm in clean conditions (non-inferiority)", "H3": "H3 — membership leakage",
                "HS": "HS — scheduled noise"}


def _p(x) -> str:
    if x is None or (isinstance(x, float) and not np.isfinite(x)):
        return "n/a"
    return f"{x:.3g}" if x >= 0.001 else f"{x:.1e}"


def _ci(v, nd=3) -> str:
    if not v or v[0] is None or not np.isfinite(v[0]):
        return "n/a"
    return f"[{v[0]:.{nd}f}, {v[1]:.{nd}f}]"


def _member_sentence(fam: str, m: Dict, alpha: float) -> str:
    ds = DS_NAME.get(m["dataset"], m["dataset"])
    who = f"{ds}" + (f", {m['attack']} attack" if m.get("attack") else "")
    if m["status"] == "MISSING_RUNS":
        return PH.format(f"{fam} {who}: runs missing ({m['reason']})")
    if m["status"] != "TESTED":
        return f"{fam} ({who}) is not tested: {m['decision']}."
    e = m["estimate"]
    verdict = ("supported" if m.get("verdict") == "SUPPORTED" else
               f"not supported at the one-sided {alpha} level after Holm correction (inconclusive)")
    if not m.get("evidence", False):
        verdict += " [not evidence: software-check tier]"
    tail = f"one-sided p = {_p(m['p_one_sided'])}, Holm-adjusted p = {_p(m['p_holm'])}, n = {m['n_pairs']} paired seeds"
    if fam in ("H1", "H2b"):
        what = "centralised non-private" if fam == "H1" else "DP-FedAvg under the same DP settings"
        s = (f"On {ds}, the complete method reached a geometric-mean {100 * e['ratio_geo_mean']:.1f} % of the "
             f"{what} test MRR (95 % CI {100 * e['ratio_ci95'][0]:.1f}–{100 * e['ratio_ci95'][1]:.1f} %; "
             f"one-sided 97.5 % lower bound {100 * e['ratio_lower_one_sided_97_5']:.1f} %; threshold "
             f"{100 * m['threshold']:.0f} %; {tail}): {fam} is {verdict}.")
        if fam == "H2b" and m.get("verdict") != "SUPPORTED":
            s += " A point estimate above the margin is not evidence of non-inferiority."
        return s
    if fam == "H2":
        return (f"{who}: mean damage {e['mean_delta_fedavg']:.4f} for FedAvg and {e['mean_delta_method']:.4f} for the "
                f"complete method (effectiveness E = {e['E_ratio_of_means']:.2f}; contrast 95 % CI "
                f"{_ci(e['contrast_ci95'], 4)}; {tail}): {verdict}.")
    if fam == "H3":
        rr = e.get("relative_reduction")
        return (f"On {ds}, the A2 attack advantage (AUC − 0.5) was {e['mean_advantage_np']:.4f} without DP and "
                f"{e['mean_advantage_dp_eps4']:.4f} with DP at ε* = 4 (relative reduction "
                f"{'n/a' if rr is None else f'{100 * rr:.0f} %'}; {tail}): H3 is {verdict}.")
    if fam == "HS":
        return (f"On {ds}, the selected schedule changed test MRR by {e['mean_difference']:+.4f} relative to fixed σ "
                f"(95 % CI {_ci(e['difference_ci95'], 4)}; {tail}): HS is {verdict}.")
    return ""


def _sel_line(sel: Dict, ds: str) -> str:
    s = sel.get(ds) or {}
    if not s:
        return PH.format(f"Stage 3 selections for {DS_NAME[ds]}")
    t = s.get("tau") or {}
    tau = (t.get("aggregation") or {}).get("tau")
    return (f"{DS_NAME[ds]}: q* = {s.get('T2a', {}).get('dp', {}).get('q')}, lr* = "
            f"{s.get('T2a', {}).get('train', {}).get('lr')}, C* = {s.get('T2b', {}).get('dp', {}).get('clip')}, "
            f"R* = {s.get('T2c', {}).get('train', {}).get('rounds_max')}, design = "
            f"{s.get('T2d', {}).get('dp', {}).get('sampling')}, s* = {json.dumps(s.get('T3', {}).get('dp', {}).get('schedule'))}, "
            f"τ* = {tau} ({t.get('label', PH.format('tau rule outcome'))}); non-private FedAvg (lr, B) = "
            f"{json.dumps(s.get('T1_nonprivate', {}).get('train'))}, centralised (lr, B) = "
            f"{json.dumps(s.get('T1_central', {}).get('train'))}")


def build_draft(ctx, hyp_res: Dict, tables: Dict, progress_summary: Optional[Dict], generated_utc: str) -> str:
    tier = ctx.tier
    alpha = hyp_res["alpha_one_sided"]
    L: List[str] = []
    L += ["# Experimental results — draft generated from recorded runs", ""]
    b = banner(tier)
    if b:
        L += [f"> **{b}.** Nothing below may be cited.", ""]
    L += [f"Generated {generated_utc} from `{ctx.root}` ({tier} tier). Every number comes from a recorded run; "
          "every ⟦PENDING: …⟧ marks a value that does not exist yet. Regenerate after more runs complete "
          "(`scripts/build_report.py`).", ""]
    if progress_summary:
        u = progress_summary.get("unique_runs_by_plan_status", {})
        done = sum(v.get("COMPLETE", 0) for v in u.values())
        L += [f"**Completion:** {done} of {progress_summary['approved_budget']['total_runs']} approved runs are "
              f"complete ({json.dumps(u)}).", ""]
    # ------------------------------------------------------------------ setup
    L += ["## 1. Experimental setup", "",
          "Datasets: FB15k-237, WN18RR and CoDEx-M with their official splits (triples whose entities never occur in "
          "training are removed from validation and test). Ten clients per federation built by a Dirichlet "
          "distribution over relations (α = 0.1 main setting; α = 0.5, 1.0 and IID for the heterogeneity study). "
          "Model: TransE, d = 100, L2-normalised entities, margin loss with 64 data-independent negatives, Adam. "
          "Privacy: triple-level DP-SGD per client (Poisson sampling, per-example clipping, Gaussian noise) under "
          "zero-out adjacency, RDP accountant with PLD and PRV cross-checks, δ = 10⁻⁶, ε* ∈ {1, 2, 4, 8}, primary "
          "ε* = 4 declared in advance. Integrity: SHA-256 verification in the data path (not a poisoning defence; no "
          "IPFS). Seeds: tuning seed 1001 (selection on validation only); confirmatory seeds {42, 123, 256, 512, 1024} "
          "(3 for descriptive blocks).", "", "Selections frozen after Stage 3 (validation only):", ""]
    for ds in DATASETS:
        L.append(f"- {_sel_line(ctx.selection, ds)}")
    L.append("")
    gate = ctx.sanity_gate or {}
    L += ["## 2. Pre-registered gates and flags", ""]
    if gate.get("datasets"):
        for ds in DATASETS:
            d = gate["datasets"].get(ds)
            L.append(f"- Gate G-B (accuracy sanity) on {DS_NAME[ds]}: " + (
                f"{d['status']} (validation MRR {d['selected_val_mrr']:.3f} vs threshold {d['threshold']:.3f})"
                if d and "selected_val_mrr" in d else PH.format("gate G-B not evaluated")))
    else:
        L.append("- " + PH.format("gate G-B (Stage 3 stage 0) not evaluated yet"))
    d10 = ctx.d10 or {}
    L.append("- D10 utility review flag: " + (d10.get("label") if d10.get("label") else PH.format("D10 not evaluated")))
    for ds in DATASETS:
        t = ((ctx.selection.get(ds) or {}).get("tau") or {})
        if t and not t.get("rule_met"):
            L.append(f"- {DS_NAME[ds]}: {t.get('label')}. Every robustness result on this dataset uses this τ and is "
                     "reported with this label.")
    L.append("")
    # ------------------------------------------------------------------ main results
    L += ["## 3. Main results (Table 3)", ""]
    t3 = tables.get("table3_main")
    for ds in DATASETS:
        if t3 is None or t3.empty:
            L.append(PH.format(f"Table 3 for {DS_NAME[ds]}")); continue
        rows = t3[t3["dataset"] == DS_NAME[ds]]
        parts = [f"{r['system']}: {r['test.mrr']}" for _, r in rows.iterrows()]
        if all(r["test.mrr"] == "PENDING" for _, r in rows.iterrows()):
            L.append(PH.format(f"Table 3 for {DS_NAME[ds]} (no recorded runs)"))
        else:
            L.append(f"- {DS_NAME[ds]} — test MRR, mean [95 % CI] (n): " + "; ".join(parts) + ".")
    L.append("")
    # ------------------------------------------------------------------ hypotheses
    L += ["## 4. Pre-registered hypotheses (Table 12)", "",
          f"One-sided paired t-tests at α = {alpha} with Holm correction within each family; members that could not "
          "be tested enter with p = 1. A family whose members are not all computed is marked provisional.", ""]
    for fam in ("H1", "H2b", "HS", "H2", "H3"):
        f = hyp_res["families"][fam]
        L += [f"### {FAMILY_TITLE[fam]}", "", f"Holm status: **{f['holm_status']}**.", ""]
        if fam == "H2":
            cnt: Dict[str, int] = {}
            for m in f["members"]:
                cnt[m["status"]] = cnt.get(m["status"], 0) + 1
            sup = sum(1 for m in f["members"] if m.get("verdict") == "SUPPORTED")
            L += [f"Of the 21 members (3 datasets × 7 attacks): {sup} supported; status counts {json.dumps(cnt)}.", ""]
        for m in f["members"]:
            L.append(f"- {_member_sentence(fam, m, alpha)}")
        L.append("")
    # ------------------------------------------------------------------ privacy, integrity, legacy
    L += ["## 5. Privacy accounting and its scope", "",
          "Each reported ε is the worst-client RDP guarantee (δ = 10⁻⁶) of one trained model, computed from the "
          "steps every client actually executed; PLD and PRV values are cross-checks, not the guarantee. The "
          "guarantee covers one training triple of one client (zero-out adjacency). It does not cover entities, "
          "clients, client sizes, or which relations a client holds.", "",
          "**The workflow as a whole has no end-to-end DP guarantee.** Stage 3 trained 99 tuning models on the same "
          "client data and selected hyperparameters from their validation scores; Stage 4 trains further models on "
          "the same data under several configurations and seeds. Neither the selection step nor the release of many "
          "models is included in the per-run ε (accounting for it, e.g. with the private-selection results of "
          "Papernot & Steinke 2022, is not done here). Per-run ε values must therefore be read as per-model "
          "guarantees only.", ""]
    t6 = tables.get("table6_accounting")
    if t6 is not None and not t6.empty and "privacy.eps.max" in t6.columns:
        mx = t6["privacy.eps.max"].max()
        L.append(f"Largest accounted worst-client ε over all DP runs: {mx:.3f} (Table 6; every run's budget_ok flag is "
                 f"{'true' if bool(t6['budget_ok_all'].all()) else 'NOT true for every cell - see Table 6'}).")
    else:
        L.append(PH.format("Table 6 privacy accounting"))
    L += ["", "## 6. Integrity overhead (Table 10)", ""]
    t10 = tables.get("table10_integrity")
    if t10 is not None and not t10.empty and "integrity s/round" in t10.columns and t10["integrity s/round"].notna().any():
        for _, r in t10[t10["integrity s/round"].notna()].iterrows():
            L.append(f"- {r['dataset']}, {r['configuration']}: integrity {r['integrity s/round']:.3f} s per round vs "
                     f"{r['training+aggregation s/round']:.3f} s training + aggregation ({r['hardware']}).")
    else:
        L.append(PH.format("Table 10: integrity overhead from blocks N2, R1p and I1 (name the hardware)"))
    L += ["", "## 7. Original versus revised results on FB15k-237 (Table 13)", "",
          "Reported values come from the original manuscript under its own protocol (Phase A provenance); they are "
          "listed for transparency and are not comparable with the corrected protocol.", ""]
    t13 = tables.get("table13_legacy")
    if t13 is not None and not t13.empty:
        for _, r in t13.iterrows():
            L.append(f"- {r['source']}: {r['item']} = {r['value'] if r['value'] != 'PENDING' else PH.format(r['source'])}")
    L += ["", "## 8. Limitations and deviations recorded by the pipeline", "",
          "- Stage 5 (sensitivity and extended blocks) is deferred (owner decision B2); no τ or α surface is reported.",
          "- Variant V1 of the trust rule was removed before any result (owner decision B4); benign false-positive "
          "rates per client-size third are reported as a diagnostic (Table FPR-by-size).",
          "- Non-private references in Stage 4 use the tuned protocol (early stopping, R_max = 100); an earlier "
          "60-round cap was a cost-model assumption and was removed before any result (RC-1).",
          "- WN18RR partitions at α = 0.1 are a heavily truncated Dirichlet (about 3 % of draws accepted); partition "
          "heterogeneity is compared through measured statistics (Table 2).",
          "- GPU runs are not bitwise deterministic; paired comparisons use one environment per dataset and tier "
          "(environment lock).",
          "- L0 (the saved legacy model) needs the owner's original checkpoint; " +
          ("evaluated." if ctx.l0 else PH.format("L0 not evaluated")),
          "- Hyperparameters selected at ε* = 4 are reused at ε* ∈ {1, 2, 8}; this may understate utility at those "
          "levels and never changes their ε.", ""]
    fails = [] if ctx.problems is None or ctx.problems.empty else ctx.problems[ctx.problems["problem"] == "FAILED"]
    if len(fails):
        L.append(f"- {len(fails)} run(s) FAILED and are listed in Table 14; nothing was filled in for them.")
    L += ["", "## 9. Reproducibility", "",
          "Code, configurations, the frozen run manifest and the pre-registered hypotheses are fixed by the git "
          "checkpoint and their SHA-256 values (REPRODUCIBILITY_RECORD.json). Every run records its configuration "
          "hash, code hash, data hash, partition hash, selection values and environment.", ""]
    return "\n".join(L) + "\n"
