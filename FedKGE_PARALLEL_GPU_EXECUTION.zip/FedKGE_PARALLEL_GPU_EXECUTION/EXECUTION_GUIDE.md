# Execution guide — how to run the approved FedKGE research

This guide is for the person running the experiments (the operator). It covers the setup, every step in order, the timings, what to check, and what to do when something goes wrong. The method itself is in `revision/13_documentation/FINAL_METHODOLOGY.md`; the deadline arithmetic is in `DEADLINE_PLAN.md`.

**Nothing has run yet.** The package contains no research result. You start the schedule yourself.

---

## 1. One-time setup (about 15 minutes)

1. **Drive folder.** Create `MyDrive/FedKGE/` on Google Drive.
2. **Upload the package.** Put `FedKGE_PARALLEL_GPU_EXECUTION.zip` into that folder as it is (do not unzip it).
3. **Open the notebook.**
   - Take `RUN_COMPLETE_FEDKGE_RESEARCH.ipynb` out of the zip on your computer.
   - In Colab, use `File → Upload notebook`, or put it in the same Drive folder and open it from there.
4. **Select a GPU.** `Runtime → Change runtime type → T4 GPU`.
5. **Edit the settings cell (Step 1a), once.**
   - Read the licence terms that Step 2 prints for each dataset.
   - Set `LICENCE_CONFIRMED` to `True` for the three datasets.
   - Write `LICENCE_NOTE`: who confirmed, when, and for what use. Nothing is downloaded without it.
6. **Optional: L0.** To re-evaluate the original model, upload your `complete/global_transe_final.pt` as `MyDrive/FedKGE/global_transe_final.pt`.

| Location | Contents | Survives a disconnect? |
|---|---|---|
| `MyDrive/FedKGE/results/` | every run folder, selections, gates, logs, progress, reports | yes |
| `MyDrive/FedKGE/data_cache/` | the three datasets (your copy; never exported) | yes |
| `/content/fedkge_pkg/` | the code, unpacked fresh each session and checked against its git commit | no (not needed) |

---

## 2. The exact sequence in Colab

**First session:**
Step 1 (1a → 1d) → Step 2 → Step 3 → Step 4 → Step 5 → Step 6 → Step 7 → Step 8 → Step 9.

**Every later session:**
Step 1 → Step 2 (minutes; nothing is downloaded or rebuilt twice) → the first step that has not printed `STEP n COMPLETE` → onwards.

| Step | What it does | Runs | T4 upper bound | Stops if | Done when |
|---|---|---|---|---|---|
| 1 | settings; Python, torch, GPU check; Drive; unpack and verify the git commit; pinned packages; core code hash; frozen manifest; environment record | — | minutes | no GPU; Python outside 3.10–3.13; wrong or changed zip; a version, the code hash or the manifest differs | `STEP 1 COMPLETE` |
| 2 | licence gate, download, pinned-checksum check, preprocessing — **only what is missing** | — | minutes (first session) | licence not confirmed; checksum mismatch | `STEP 2 COMPLETE` |
| 3 | **accuracy sanity gate G-B** (centralised TransE, 6 settings × 3 datasets, fully trained) | 18 | ≈ 1.7 GPU-h | **the gate fails** (the main workflow stops with a diagnostic report) | `results/tune/gates/SANITY_GATE_REPORT.md` shows PASSED for each dataset |
| 4 | tuning stages 1–6 (τ with the B3 fallback; D10 flag), then **freeze** (G-C) automatically | 81 more (99 in total) | ≈ 10.8 GPU-h | a run fails twice | τ\* and its label per dataset are printed; `results/final/selection/FROZEN.json` exists |
| 5 | main experiments, priorities 1 → 7 (the replications run at priority 4) | 756 + 30 | ≈ 106 GPU-h | a run fails twice | `STEP 5 COMPLETE`; `results/PROGRESS.md` shows every plan COMPLETE |
| 6 | status of the replications L1–L4 (completes any that are missing) + optional L0 | (30) | — | — | `replications L1-L4 COMPLETE` |
| 7 | statistical analysis (paired tests, Holm, CIs, effect sizes, non-inferiority) | — | minutes | — | the hypothesis table is printed |
| 8 | tables, 2D/3D figures (PNG + PDF), summaries, results draft | — | minutes | — | `results/final/reports/RESULTS_DRAFT.md` |
| 9 | export | — | minutes | — | `MyDrive/FedKGE/fedkge_results_export_<UTC>.zip` |
| App. A | status and recovery | — | — | — | lists FAILED or INCOMPLETE runs |
| App. B | optional CPU test suite (`RUN_CPU_CHECKS = True`) | — | 3–5 min CPU | a test fails | test counts printed |

**When a step prints PAUSED (session budget):** start a new session, run Step 1 → Step 2, then the same step again. Finished runs are never repeated. An interrupted run resumes from its last checkpoint (every 5 rounds, written atomically).

**Steps 7–9 can run at any time.** With partial results, they produce partial tables in which everything not yet computed appears as **⟦PENDING: …⟧**. Nothing is filled in.

**Priority order of Step 5** (essential hypotheses first):

| Priority | Content | Answers |
|---|---|---|
| 1 | N1, N2, DP1 and DP2 at ε = 4, R1p | main table; H1, H2b, HS |
| 2 | R2, R2a, R3, R3a | H2 |
| 3 | M1 | H3 |
| 4 | L1–L4 | replications |
| 5 | R1q | descriptive |
| 6 | R1, R4, R5, R5a | baselines |
| 7 | DP1 at other ε, DP3, N3, I1, I2 | descriptive |

**Rules for splitting the work:**
- **Several GPUs at the same time:** use the parallel route instead (`PARALLEL_EXECUTION_GUIDE.md`). Every worker there has its own results folder, and a master merges verified results, so the rules below stay true.
- **One session at a time per results folder.** Selections and gate records are shared files, and Drive syncs between machines with a delay.
- `DATASETS = ["fb15k237"]` in Step 1a works on one dataset per session. All steps accept this, and gate G-B applies to each dataset you run.
- Keep one GPU type and one torch build per dataset (see "Environment changed" below).
- **Do not use several Colab accounts to get around Colab's limits.** Colab's terms do not allow it. Use paid compute units instead (`DEADLINE_PLAN.md` §5).

---

## 3. Exact commands outside the notebook (local GPU or a terminal)

```bash
cd FedKGE_PARALLEL_GPU_EXECUTION/revision
python3 -m venv ../.venv && . ../.venv/bin/activate && pip install -r requirements-phaseC.txt
export FEDKGE_RESULTS=$PWD/../results_gpu          # one results root per environment
python scripts/build_manifest.py --check
for ds in fb15k237 wn18rr codex_m; do
  python scripts/prepare_data.py --dataset $ds --data-dir ../data_cache --i-confirm-licence --operator-note "<who, when>"
done
python scripts/build_artifacts.py --tier tune  --datasets fb15k237 wn18rr codex_m --data-dir ../data_cache --seeds 1001 --alphas 0.1 --central
python scripts/build_artifacts.py --tier final --datasets fb15k237 wn18rr codex_m --data-dir ../data_cache --seeds 42 123 256 512 1024 --alphas 0.1 --central
python scripts/run_plan.py --plan tune --tier tune --datasets fb15k237 wn18rr codex_m --device cuda --stages 0   # Step 3: gate G-B
python scripts/run_plan.py --plan tune --tier tune --datasets fb15k237 wn18rr codex_m --device cuda             # Step 4: Stage 3
python scripts/freeze_selections.py                                                                              # Step 4: G-C
for p in 1 2 3; do python scripts/run_plan.py --plan confirm --tier final --datasets fb15k237 wn18rr codex_m --device cuda --priorities $p; done
python scripts/run_legacy_blocks.py --tier final --device cuda                                                   # priority 4
for p in 5 6 7; do python scripts/run_plan.py --plan confirm --tier final --datasets fb15k237 wn18rr codex_m --device cuda --priorities $p; done
python scripts/legacy_l0_eval.py --checkpoint /path/to/global_transe_final.pt --tier final                       # optional L0
python scripts/status.py --show-failed
python scripts/analyze_results.py --tier final                                                                   # Step 7
python scripts/build_report.py --tier final --with-figures                                                       # Step 8
python scripts/export_artifacts.py                                                                               # Step 9
python scripts/run_tests.py --name local                                                                         # optional CPU checks
```

Add `--max-hours H` to any run command to stop cleanly before a time limit. Exit code 3 means "run the same command again".

---

## 4. Recovery playbook

| Situation | What you see | What to do | Why it is safe |
|---|---|---|---|
| **Disconnect / runtime reset** | the cell stopped mid-run | Reconnect; run Step 1 → Step 2; run the same step again | Finished runs are COMPLETE in their folders on Drive. The interrupted run is INCOMPLETE and resumes from its last checkpoint (written atomically, never half-written) |
| **PAUSED (session budget)** | `PAUSED: … run Step 1 and Step 2, then Step n again` | Next session: Step 1 → Step 2 → the same step | No new run started after the budget; nothing is marked complete that is not |
| **A run FAILED** | the step stops with "run(s) failed" | Appendix A shows the error. Run the step again: the failed run is retried and its first traceback is kept as `error_attempt1.txt` | If it fails again with the same error, it is a real problem: send `results/<tier>/runs/<run_id>/` (error.txt, log.txt, config.json). Nothing is skipped or filled in |
| **Gate G-B failed** | Step 3: "GATE G-B FAILED" | **Stop.** Do not edit any threshold. Send `results/tune/gates/SANITY_GATE_REPORT.md`, `sanity_gate.json` and the T1C run folders (`results/tune/runs/tune_*`) | The gate is a pre-registered prerequisite: a weak trainer would make every later number meaningless |
| **τ rule not met** | Step 4: "tau rule NOT met (benign FPR = x %)" | Nothing; continue | Pre-declared response B3: the largest grid τ is used, the label goes into every report, and the dataset stays in H2 |
| **D10 flag triggered** | Step 4: "D10 FLAG: DP utility r = … < 0.25" | Nothing; continue. Mention it in the paper's discussion | B5: a diagnostic flag only; no extra tuning and no mechanism change |
| **Environment changed** | "STOP: environment differs from the one recorded …" (exit 5) | Reconnect until Colab gives the recorded GPU type (usually a T4). If torch changed after a Colab update, install the recorded version (`pip install torch==<recorded version>`) and restart the runtime. If neither works, set a new `DRIVE_ROOT` for the affected dataset and rerun that dataset from Step 3 there | One comparison never mixes GPU types or torch builds |
| **No GPU assigned** | Step 1b stops | Wait and reconnect, or try later | The study never falls back to CPU silently |
| **Dataset checksum mismatch** | Step 2: "STOP: the downloaded bytes differ from the pinned SHA-256 values" | Do not continue; report it | Different data would silently change every result |
| **Manifest mismatch** | Step 1d or a step: "MANIFEST CHECK FAILED" / exit 6 | Re-upload the original package zip | The approved schedule may not change silently |
| **Wrong or changed zip** | Step 1c assertion | Upload the original `FedKGE_PARALLEL_GPU_EXECUTION.zip` | The notebook only runs the committed code |
| **Something looks broken in the code** | an unexpected error in several runs | Set `RUN_CPU_CHECKS = True`, run Appendix B, and send the test report | The test suite checks the code on the CPU without touching your results |
| **Drive full** | write errors | Free space; old exports can be moved elsewhere. Never delete run folders | Every run folder is evidence |

**What "status" means** (Appendix A, `results/PROGRESS.md`):

| Status | Meaning |
|---|---|
| COMPLETE | the run folder says COMPLETE with the current code hash, and `final.json` exists |
| INCOMPLETE | interrupted; resumes on the next call |
| FAILED | an error; retried on the next call |
| NOT_STARTED | not run yet |
| WAITING_FOR_SELECTIONS | needs Step 4 (tuning and freeze) first |
| STALE_CODE | the code changed since the run; it is run again |

---

## 5. What to send to a maintainer or co-author

- **For a check of progress or results:** the export zip from Step 9. It contains every record, analysis, figure and report, but no dataset files and no weights.
- **For a failure:** the failing run folder and the latest `results/logs/notebook_session_*.log`.

---

## 6. What the package does **not** contain, and what needs your input

| Item | Status | What to do |
|---|---|---|
| Dataset files | never included (licences; no redistribution) | Step 2 downloads them after your confirmation |
| L0 checkpoint `complete/global_transe_final.pt` | yours; not in the package | optional upload (§1, item 6); without it, Table 13 shows L0 as PENDING |
| GPU time | ≈ 118 GPU-hours upper bound | see `DEADLINE_PLAN.md` |
| Stage 5 | deferred (B2) | nothing; the code refuses it |
| The professor's review, a repository link | never supplied | add them to the paper yourself; nothing was invented |
