# 05 — Privacy–utility evaluation plan (Phase B, item 5)

**Status:** plan only. Every number is **[Calculated – Phase B planning]** from `data/phaseB_sigma_plan.csv` / `.json`. Nothing is an experimental result.
**Principles** (master prompt §7):
- Never weaken or remove DP to raise MRR.
- Never report an ε without a valid derivation.
- Never pick a privacy configuration because it makes a good graph.
- Report the trade-off as measured, including near-zero utility.

## 1. Questions this plan answers

1. How much utility does federation cost without privacy? (N2 vs N1)
2. How much does correctly accounted triple-level DP cost, at ε ∈ {1, 2, 4, 8}? (DP1/DP2 vs N2)
3. Which part of that cost comes from changed training settings, which from clipping, and which from noise? (DP3)
4. Does a noise schedule help at the same ε? (HS: DP2 vs DP1; also R1p vs R1q, descriptively)
5. How do the answers vary across the three datasets and across heterogeneity levels? (X1)
6. Optional (D6): does DP measurably reduce membership leakage? (§10)

## 2. Reference points (non-private)

| Reference | Block | Use |
|---|---|---|
| Centralised TransE, tuned non-private settings | N1 | H1 denominator; "federation cost" |
| FedAvg, α = 0.1, tuned non-private settings | N2 | "privacy cost" denominator |
| FedAvg with the **DP training settings** (q, lr, R), no clipping, no noise | DP3-a | separates "settings" from "DP" |
| FedAvg with clipping only (σ = 0) | DP3-b | separates clipping from noise |

**Tuning budget (D13; fixes MJ-19, with one disclosed asymmetry).**
- Non-private training gets the **same grid for the shared optimiser settings** (learning rate × batch size; T1) as the DP runs get for theirs.
- The DP-specific parameters (q, C, R, sampling design, schedule) have no non-private counterpart: 21 DP tuning cells per dataset versus 6 for non-private FedAvg. If this asymmetry biases anything, it makes the measured privacy cost look *smaller*, not larger. It is disclosed in the paper.

**Sanity gate, investigation only:** if the centralised non-private MRR is below about ⅔ of a published, well-tuned TransE value for the same dataset, the trainer is investigated before anything else runs. These values come from other protocols and are **never targets and never compared in tables**:

| Dataset | Published TransE MRR | Source |
|---|---|---|
| FB15k-237 | 0.313 | LibKGE |
| WN18RR | 0.228 | LibKGE |
| CoDEx-M | 0.303 | CoDEx paper |

## 3. Privacy operating points (D3)

**Grid:** ε* ∈ {1, 2, 4, 8}, δ = 1e-6 (also reported at 1e-5), plus non-private. The primary ε* = 4 was declared before any result.
- **Adjacency:** zero-out (one triple replaced by a null record; client size public and unchanged; `03` §7.2). The ε values are those of the Poisson-subsampled Gaussian mechanism and do not depend on this choice.
- **δ check:** δ × largest client size ≈ 0.04 (FB15k-237) and ≈ 0.025 (WN18RR) in the partition simulation. YAGO3-10, if used, would need δ = 1e-7.

σ₀ calibrated by RDP (design Q, one local epoch per round):

| q (steps/round) | R | ε* = 1 | 2 | 4 | 8 |
|---|---|---|---|---|---|
| 0.02 (50) | 100 | 6.48 | 3.47 | 1.95 | 1.21 |
| 0.05 (20) | 100 | 10.20 | 5.42 | 2.96 | 1.72 |
| 0.10 (10) | 100 | 14.41 | 7.63 | 4.13 | 2.34 |
| 0.05 (20) | 50 | 7.27 | 3.90 | 2.18 | 1.33 |

Per-step noise-to-clip ratio $\sigma\sqrt P/(q\bar N)$ for the mean client (q = 0.05, R = 100):

| Dataset | ε* = 1 | 2 | 4 | 8 |
|---|---|---|---|---|
| FB15k-237 | 9.1 | 4.8 | 2.6 | 1.5 |
| WN18RR | 47.6 | 25.3 | 13.8 | 8.0 |
| CoDEx-M | 14.4 | 7.6 | 4.2 | 2.4 |
| YAGO3-10 | 6.6 | 3.5 | 1.9 | 1.1 |

How to read these:
- Larger q lowers the per-step ratio but means fewer steps per round. Per epoch, the trade-off is roughly neutral to first order, so **q is tuned, not assumed** (T2a).
- The smallest permitted client (20 % of the mean) has a ratio 5× larger under design Q.
- At the RDP-calibrated σ, PLD gives ε ≈ 0.93 × the target (for example 3.73 for ε* = 4). **The RDP value is the guarantee reported**; PLD and PRV are shown next to it.
- Calibrating σ with PLD instead would lower σ by 4.0–6.6 % across the tuning grid (`pld_noise_saving_pct`). This is not adopted (D3; reverses Phase A's OP-1).
- **Expected:** ε* = 1 is likely to give very low utility, especially on WN18RR. It is still run and reported (RK-1).

## 4. Validating the accounting independently (your requirement)

| Check | What it is | How | Status |
|---|---|---|---|
| Legacy per-round ε reproduced | two libraries | Opacus analysis code + `dp_accounting`, 5 clients | **done in Phase A** (agreement < 10⁻⁶) |
| Calibration cross-check | **same library, different code path** | `scripts/phaseB_sigma_plan.py` (public `dp_accounting` API) vs the revision's `calibrate_sigma0`, 4 configurations | **done in Phase B**: σ within 0.2 %; the revision always rounds up (conservative) |
| Numerical RDP | **independent of `dp_accounting`** | my own log-space quadrature of the subsampled-Gaussian Rényi divergence (scipy), orders ≤ 256 | **done in Phase B**: ε equals `dp_accounting` RDP within 1.4·10⁻⁴ at 4 operating points |
| PRV accountant | **different library and method** | `prv-accountant` 0.2.0 (Gopi et al. 2021), ε error ±0.01 | **done in Phase B**: its interval contains the `dp_accounting` PLD value at all 4 points, e.g. [3.719, 3.739] vs 3.730 when RDP = 4.000 |
| PLD vs RDP | tightness | PLD ≤ RDP | **done in Phase B**: ratio 0.929–0.935 at the 4 points |
| Per-example clipping = Opacus = brute-force autograd | implementation | revision `test_dp_clipping.py` (3 tests) | **not yet run** (needs PyTorch) — Stage 0 gate |
| Noise is dense, with std σC | implementation | revision test | not yet run — Stage 0 gate |
| Every reported ε recomputed from the logged (q, T, σ trace, rounds executed) | per run | Phase C validation script: RDP (`dp_accounting`) and PRV, plus the Opacus RDP analysis as a third code path | Phase C |
| Executed σ trace equals the configured schedule | per run | `schedule_verified` assertion in every run | in the revision |
| Empirical audit: the measured lower bound on ε must not exceed ε | per run | one-run audit (§10), if D6 keeps H3 | Phase E |

## 5. Implementation checks against wrong, redundant or excessive noise (master prompt §7, items 4 and 6)

| Possible defect | Check | Revision design |
|---|---|---|
| Noise added per example instead of to the sum | code review + test (std of the sum = σC) | correct (noise added once per step to the sum) |
| Noise added twice (client and server) | code review | server adds none ✓ |
| Normalisation by the realised batch size (data-dependent) | code review | uses the expected batch qN̂ ✓ |
| Composition over more steps than executed, or per-round fresh accountants | accountant log vs steps executed | composes the executed steps ✓ (legacy bug CR-2 removed) |
| Mean over clients reported instead of the worst client | `accountant.json` | worst client ✓ |
| Noise applied to the wrong object (for example only some rows, or after release) | dense noise before release | dense, inside each step ✓ |
| Warm start from a non-private model | config validation | rejected ✓ |
| Data-dependent negatives (would break the sensitivity argument) | sampling code | uniform and data-independent ✓ |
| Published exact sizes under add/remove adjacency (CR-14) | adjacency statement | revision says add/remove → **[Phase C]** zero-out stated in `DP_MECHANISM.md` and every `accountant.json` (C17) |
| Non-finite values breaking the clipping bound (MN-22) | client-side guards | missing → **[Phase C]** clients reject non-finite broadcasts; non-finite per-example gradients are zeroed (C16) |
| Adam turning pure-noise coordinates into steps of about lr | **diagnostic only:** one optional DP-SGD-with-momentum run at the selected settings (FB15k-237, tuning seed) if DP utility is low | not in the core matrix |

## 6. Legitimate levers on utility — pre-registered tuning (Stage 3, tuning seed 1001, validation only)

| Step | Grid (at ε* = 4, FedAvg, α = 0.1) | Selection rule (frozen and hashed before use) |
|---|---|---|
| T2a | design Q: q ∈ {0.02, 0.05, 0.10} × lr ∈ {1e-3, 3e-3, 1e-2}, C = 1, R = 100, fixed σ | highest validation MRR; ties (difference < 0.002) → larger q, then smaller lr |
| T2b | C ∈ {0.25, 0.5, 1, 2, 4} at the selected (q, lr) | highest validation MRR; ties → smaller C |
| T2c | R ∈ {50, 100} (σ recalibrated for each) | highest validation MRR; ties → R = 50 (cheaper) |
| T2d | design A (B = 512, per-client σ) vs design Q at the selected settings | **decides the sampling design** (D11): highest validation MRR; ties → design Q |
| T3 | schedules {linear, exponential, cosine} × ρ ∈ {0.25, 0.5}, plus fixed | highest validation MRR; ties → fixed |
| T1 (non-private, same shared-setting grid) | {centralised, FedAvg} × lr ∈ {1e-3, 3e-3, 1e-2} × B ∈ {512, 4096} | highest validation MRR; ties → B = 512, smaller lr |

- Selections are made **per dataset**. Dataset-specific values are recorded with their reasons.
- Confirmatory runs (Stage 4) use different seeds and never re-select (D13).
- **Reuse across ε (disclosed):** settings selected at ε* = 4 are reused at ε = 1, 2 and 8. This may understate utility at those levels; it never changes their ε.
- **Tuning privacy cost:** every tuning run trained on the clients' data. Its privacy cost is **not** included in the reported ε. This is the usual practice, and it is **disclosed** in the paper (G10). Accounting for it (Papernot & Steinke 2022, OP-2) is an option, not the default.

## 7. Privacy–utility frontier (Tables 6–7, Fig. family B)

- **Points:** each DP configuration gives (worst-client ε actually reached, mean test MRR ± 95 % CI over seeds) per dataset. Non-private runs are plotted at ε = ∞ on a broken axis.
- **Frontier:** the non-dominated points (lower ε and higher MRR), using the revision's `stats.pareto_front`. Points are never removed because they look bad.
- **Primary point:** ε* = 4 is marked as *pre-declared*, not "optimal". The old "ε* = 9.28 optimum" is withdrawn.
- **3D surfaces:** MRR over (ε, α) per dataset from DP1 + X1 + N2/N3. ε is the **calculated** value, not σ. Missing cells are shown as missing.

## 8. Reporting per DP configuration (Table 6 columns)

dataset · block · seed · adjacency (zero-out) · ε_RDP worst client (δ 1e-6) · ε_RDP worst client (δ 1e-5) · ε_PLD and ε_PRV (upper) worst client · ε per client (min / median / max) · δ · δ × largest N̂_k · design (Q or A) · q (or q_k range) · T · R planned / executed · total steps per client · σ₀ · schedule (shape, ρ) · C · smallest and largest N̂_k · accountant and orders · library versions · tuning-cost and ε-reuse disclosure flags.

## 9. Decision trigger for design alternatives (D10)

- **Measured after Stage 3, on validation only:** r = (best FedAvg + DP validation MRR at ε* = 4) / (non-private FedAvg validation MRR), on FB15k-237.
- **If r < 0.25** (value adjustable by you **now**): you choose whether to add one alternative (relation-only sharing, or sparsity-preserving DP), evaluated as a separately labelled variant.
- **Otherwise:** none is added.

## 10. Membership-inference audit (only if D6 keeps H3)

| Element | Specification |
|---|---|
| Runs | block M1, **5 seeds in both profiles** (it carries a hypothesis test). Configurations: FedAvg non-private and FedAvg + DP at ε* ∈ {1, 4, 8}; 3 datasets → 60 runs. Audit runs change the training data, so they cannot reuse other runs |
| Audit pool | before training, each client draws an audit pool of 10 % of its own training triples (run-seeded; proposed size). Each candidate is **included in training independently with probability ½**. Included candidates are members; excluded ones are non-members (≈ 5 % of the training data is withheld in expectation) |
| Size handling | an excluded candidate is replaced by a **null record** (zero gradient), so $\hat N_k$ does not depend on the coin flips. The audit therefore targets exactly the zero-out guarantee of `03` §7.2 |
| Why this design | members and non-members come from the same distribution, so no test-set construction effect enters (fixes MJ-15). Official test triples are never used as non-members |
| Attack A1 (model user, black-box) | score = $f(h,r,t)$ on the final global model; the threshold is swept to get the ROC |
| **Attack A2 (primary, pre-registered)** | A1's score standardised per relation with statistics from $V_{root}$, which removes relation-level differences; **pooled over all clients' audit pools** |
| Attack A3 (server, white-box, per client; secondary) | score change $f_{\theta_k}(x) - f_{\theta^{t-1}}(x)$ between client k's last local model and the global model it started from |
| Metrics | AUC (primary, used by H3), TPR at FPR = 1 % and 0.1 %, balanced accuracy |
| Uncertainty | seed-level 95 % intervals (primary); bootstrap over candidates (within-run only, labelled as such) |
| DP bound | overlay TPR ≤ e^ε·FPR + δ on every ROC |
| Empirical lower bound on ε | **one-run audit** (Steinke, Nasr & Jagielski 2023): the attack guesses membership on its most confident candidates and abstains on the rest; the bound is the largest ε that the number of correct guesses rejects at 95 % confidence. Valid with a single training run because the inclusion coins are independent. The number of guesses is fixed in advance at {100, 300, 1000} (proposed); the reported bound is the largest of the three, each computed at confidence 1 − 0.05/3 (Bonferroni), so choosing the count cannot inflate it |
| Red line | if the lower bound exceeds the accountant's ε in any DP run, the implementation is **presumed wrong** and investigated before any result is used |
| Expectation | black-box one-run bounds are usually far below the true ε, so a small bound is a sanity check, not evidence that ε is loose |
| Decision | H3 rule in `03` §13.3, including the testability condition |
| Interpretation | an empirical lower bound under specific attacks; the guarantee remains the accountant's (ε, δ). Results are attributed to DP only (FedAvg vs FedAvg + DP) |

## Sources

- [LibKGE results tables](https://github.com/uma-pi1/kge)
- [CoDEx paper, arXiv 2009.07810](https://arxiv.org/abs/2009.07810)
- [DP-Flames (Hu et al., WWW '23), arXiv 2304.02932](https://arxiv.org/pdf/2304.02932v1.pdf)
- Steinke, Nasr & Jagielski 2023, "Privacy Auditing with One (1) Training Run", NeurIPS *[standard; not re-fetched in this session]*
- Gopi, Lee & Wutschitz 2021, "Numerical Composition of Differential Privacy", NeurIPS *[standard; the library was used in Phase B]*
