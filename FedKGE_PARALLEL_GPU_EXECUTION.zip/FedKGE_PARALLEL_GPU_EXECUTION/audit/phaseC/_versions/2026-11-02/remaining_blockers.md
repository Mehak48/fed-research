# Phase C — remaining blockers, risks and decisions

**Date:** 2026-11-02 · Each item says who has to act. "Owner" means Mehak; "next step" means work that can continue without a decision.

## A. Blockers before Stage 3 (tuning)

**B1 — GPU pilot (gate G-B).** **Owner.**

- This environment has no GPU. The CPU pilot here gives upper bounds only (`pilot_plan.md`).
- The owner can use **free Google Colab**. The kit is `revision/colab/phaseC_pilot_colab.ipynb` plus `fedkge_code_phaseC.zip`, about 45–75 minutes on a T4.
- Its results zip comes back for analysis.
- Gate G-B also needs the centralised non-private MRR sanity check (`audit/phaseB/05_privacy_utility_plan.md` §2). That check needs converged runs (the T1C tuning runs), so it comes after the pilot, not from it.

**B2 — Compute budget on free Colab.** **Owner decides after B1.**

- Phase B estimated 46–393 GPU-hours for the reduced core plan (837 runs). These are unverified numbers.
- Measured here on 2 CPU cores (upper bounds; `pilot_plan.md`): tuning ≤ 112 CPU-hours, reduced Stage 4 ≤ 874, Stage 5 ≤ 583. Per run, this CPU takes 1.4–3.9× Phase B's HIGH GPU estimate.
- Free Colab's GPU time is limited and its limits are not published. In practice it is often a few hours per day, with no guarantee.
- If the LOW estimate (46.5 GPU-hours) holds, that is roughly two to four weeks of daily free sessions. The HIGH estimate (393 GPU-hours) is not realistic on the free tier. The GPU pilot decides which end is true.
- After the GPU pilot, choose one or more of the options below. ✂️ They are listed in the order that protects the core claims best:

| # | Option | Saving |
|---|---|---|
| (a) | Defer Stage 5 (extended blocks) | 432 runs |
| (b) | Drop H3 / M1 (the MIA audit) | 60 runs; rely on the formal guarantee |
| (c) | Accept R = 50 if T2c selects it | — |
| (d) | Use the R4 reduced grid | — |
| (e) | A short paid GPU rental | — |

**Never cut:** correct DP, three datasets, ≥ 5 seeds per hypothesis test, the non-private references.

**B3 — τ rule (D14) may have no feasible value.** **Owner decides now, before seeing data.**

- If no τ on the grid gives benign FPR ≤ 5 % in the clean TAU run, the pipeline stops, by design.
- On the synthetic probe this happened, because the V1 trigger fired on noise (B4). On the real smoke run (3 rounds) the rule did find a feasible τ for all three datasets, but 3 rounds say little about the real tuning run.
- Pre-declare the response. Options:
  - (i) report the method as failing its own rule on that dataset;
  - (ii) use the largest τ on the grid and label it;
  - (iii) drop the dataset from H2.

  Do **not** extend the grid after seeing data.

**B4 — Variant V1 is statistically weak with 10 clients (new finding PC-2).** **Owner decides before Stage 3.**

- **The problem:**
  - V1 compares each update's norm with the median of its *size third*. With 10 clients a third has 3–4 members.
  - The MAD-based scale is very noisy at that size.
  - In the synthetic probe, benign clients reached A_v1 = 9.1, so V1's benign false positives were *higher* than the frozen rule's.
  - The trigger itself also fired on 1 of 8 observations.
- **Options:**
  - (a) keep V1 exactly as pre-registered (with the risk above);
  - (b) **recommended, smallest change:** remove the V1 switch and report the benign FPR per size third descriptively, keeping only the frozen rule;
  - (c) redesign V1. This is new method design and would need justification.
- Its trigger constants are Phase C details, also pending approval: `reference_tau` = 3.0, `min_fpr_for_ratio` = 0.05.

**B5 — Decisions never answered.** **Owner.**

- D10 trigger: 25 % of non-private validation MRR at ε\* = 4 on FB15k-237. Fix it before results exist.
- H2b "no harm" bound: clean MRR ≥ 95 % of FedAvg under the same DP settings. This is a new threshold.
- MIA settings: audit pool 10 % per client, inclusion ½, guesses {100, 300, 1000}, confidence 0.95.
- Folder restructuring to `src/`, `scripts/`, `configs/`, `tests/` was **not** done; the layout was kept and `scripts/` added. Is that acceptable?
- **Commit the Phase C changes to git?** Recommended before any Colab run, so that every result points to a commit. Today, runs are identified by the core code hash and the code zip's SHA-256.

## B. Open items that do not block the pilot

| ID | Item | Status / next step |
|---|---|---|
| B6 | WN18RR α = 0.1 partitions are a heavily truncated Dirichlet (3.1 % of draws accepted on the real counts) | Feasible, so no fallback. State it in the paper; compare heterogeneity by measured statistics (G15 resolved) |
| B7 | WN18RR drops 210 validation and 210 test triples with entities unseen in training (PyKEEN convention) | Keep, as designed (D5 / `04`). State it, because some papers rank all 3,134 test triples |
| B8 | Gate G-A "every block completes in smoke" on the real data | **Met (2026-11-02).** Tuning chain: 6 stages, every rule applied. Confirmatory matrix (reduced): 26 blocks, 322 runs, 0 failures. Schemas: 0 failures. Noise warning: the V1 trigger fired on CoDEx-M from a single flag among about 12 observations (3 smoke rounds), which supports B4 |
| B9 | Builders for the paper's Tables 1–14 and the 2D/3D figures (C10) are **not implemented** for the new matrices | Next step. Needed before Stage 4 analysis, not before the pilot. Figures only from executed runs |
| B10 | Not implemented: X6 (local-only baseline), O1 (validation-triggered σ decay with an RDP filter) | Out of Phase C (Phase B: optional). No IPFS, by decision D7 |
| B11 | Privacy cost of hyperparameter tuning is not accounted | Disclosed in `accountant.json` and `DP_MECHANISM.md`; OP-2 is the alternative |
| B12 | Missing inputs: the professor's review (M1), the owner's additional roadmap changes (M2), confirmation that `fedkge_revision_P1-P4.zip` is "Proprietary Learning Reveal" (M3), a repository link (M6) | **Owner.** Nothing was invented in their place |
| B13 | Different torch versions across environments (2.14.1 here; Colab's own build there) | Never mix environments inside one comparison; `env.json` records the version per run |
| B14 | `MASTER_EXECUTION_ORDER.md`, `COLAB_RUNBOOK.md`, `EXECUTION_PLAN.md` still describe the original notebooks | Next step (documentation only) |
| B15 | The GPU code path has never executed (no GPU here) | The Colab kit runs a GPU smoke before the pilot |

## C. What Phase C has resolved since the handoff brief (2026-11-02)

- Datasets downloaded with the owner's recorded licence confirmation. Split counts equal the official counts.
- Real-data smoke: 33 of 33 runs complete (11 profiles × 3 datasets).
- Partition feasibility measured on the real counts (G15).
- L0 executed. The legacy non-private model scores **MRR 0.197** under the corrected protocol, against the reported 0.2858.
- Defect PC-1 found and fixed. Schemas added for every Phase C output, and schema defect PC-5 fixed.
- **Gate G-A met:** every block of the tuning chain and of the confirmatory matrix ran on the real data subsets with 0 failures; 496 outputs are schema-valid.
- Measured CPU pilot on the full data (`pilot_plan.md`). Free-Colab GPU kit prepared.
