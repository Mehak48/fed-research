#!/usr/bin/env python3
"""Validated small-run experiment script (Phase C deliverable 11): one or more named configurations of the approved
pipeline on one dataset, on the smoke tier (subset) or on the full data with few rounds. NEVER evidence: smoke
outputs are watermarked by tier and partial runs carry partial_run = true.

  python scripts/small_run.py --dataset fb15k237 --tier smoke --profiles np_fed dp_q complete --rounds 3
  python scripts/small_run.py --dataset synthetic --tier smoke --tier-file offline --profiles np_fed dp_q   (software
         check on the synthetic KG: never evidence about the benchmarks)
"""
from __future__ import annotations

import argparse
import json
import resource
import sys
import time

import pandas as pd

from _common import CONFIG_DIR, Manifest, results_root
from fedkge.config import deep_merge, load_yaml, run_id
from fedkge.federated import run_experiment
from fedkge.io import Paths

DPQ = {"enabled": True, "sampling": "common_rate", "q": 0.1, "target_epsilon": 4.0, "clip": 1.0,
       "schedule": {"shape": "fixed", "rho": 1.0, "update_every": 5}}
PROFILES = {
    "np_central": {"partition": {"scheme": "centralized", "n_clients": 1}},
    "np_fed": {},
    "np_fed_iid": {"partition": {"scheme": "iid"}},
    "dp_a": {"dp": {"enabled": True, "sampling": "fixed_batch", "target_epsilon": 4.0}},
    "dp_q": {"dp": DPQ},
    "complete": {"dp": DPQ, "aggregation": {"method": "proposed"}, "integrity": {"mode": "hash_only"}},
    "attack_alie": {"dp": DPQ, "aggregation": {"method": "proposed"},
                    "attack": {"type": "alie", "fraction": 0.2, "knowledge": "white"}},
    "attack_targeted": {"dp": DPQ, "aggregation": {"method": "proposed"}, "attack": {"type": "targeted", "fraction": 0.2}},
    "integrity_corrupt": {"dp": DPQ, "aggregation": {"method": "proposed"},
                          "integrity": {"mode": "hash_only", "corrupt_p": 0.1}},
    "mia": {"dp": DPQ, "mia": {"enabled": True}},
    "dp3_no_noise": {"dp": {**DPQ, "mode": "no_noise", "stop_rule": "none", "clip": None, "pld_crosscheck": False,
                            "prv_crosscheck": False}},
}


def make_cfg(dataset: str, tier: str, profile: str, seed: int, rounds: int, extra: dict | None = None,
             stop_after: int | None = None, tier_file: str | None = None) -> dict:
    base = load_yaml(CONFIG_DIR / "base.yaml")
    t = load_yaml(CONFIG_DIR / "tiers" / f"{tier_file or tier}.yaml")
    ds = load_yaml(CONFIG_DIR / "datasets" / f"{dataset}.yaml")
    cfg = deep_merge(base, ds.get("run_overrides", {}), PROFILES[profile], t.get("run_overrides", {}), extra or {})
    cfg["train"]["rounds_max"] = int(rounds)
    if stop_after:
        cfg["train"]["stop_after_rounds"] = int(stop_after)
    elif cfg["train"].get("stop_after_rounds") is not None and int(cfg["train"]["stop_after_rounds"]) >= int(rounds):
        cfg["train"].pop("stop_after_rounds")             # the tier's cut is longer than the run: run every round
    cfg.update({"tier": tier, "phase": "phasec", "seed": int(seed), "block": f"PHASEC_{profile}", "name": profile})
    cfg["dataset"] = {"name": dataset}
    return cfg


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results"); ap.add_argument("--dataset", required=True)
    ap.add_argument("--tier", default="smoke"); ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--tier-file", help="tier settings file (e.g. 'offline' for the synthetic KG); default = --tier")
    ap.add_argument("--profiles", nargs="+", default=["np_fed", "dp_q"]); ap.add_argument("--rounds", type=int, default=3)
    ap.add_argument("--stop-after", type=int); ap.add_argument("--device", default=None)
    ap.add_argument("--extra", default="{}", help="JSON overlay applied last (e.g. '{\"train\": {\"eval_every\": 1}}')")
    a = ap.parse_args(argv)
    root = results_root(a.results)
    paths = Paths(root, a.tier)
    man = Manifest(root, f"small_run_{a.tier}_{a.dataset}")
    rows = []
    for prof in a.profiles:
        cfg = make_cfg(a.dataset, a.tier, prof, a.seed, a.rounds, json.loads(a.extra), a.stop_after, a.tier_file)
        t0 = time.time()
        rec = {"dataset": a.dataset, "tier": a.tier, "profile": prof, "run_id": run_id(cfg)}
        try:
            fin = run_experiment(cfg, paths, a.device, force=True)
            rec.update({"status": "COMPLETE", "rounds_executed": fin["rounds_executed"],
                        "stop_reason": fin["stop_reason"], "val_mrr": fin["val"]["mrr"], "test_mrr": fin["test"]["mrr"],
                        "eps": (fin.get("privacy") or {}).get("eps"), "per_round_s": fin["runtime"]["per_round_s"],
                        "total_s": fin["runtime"]["total_s"], "partial_run": fin.get("partial_run", False)})
        except Exception as e:
            rec.update({"status": "FAILED", "error": repr(e)})
            man.warn(f"{prof} failed: {e!r}")
        rec["wall_s"] = time.time() - t0
        rec["peak_rss_mb"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
        rows.append(rec)
        man.output(paths.run(rec["run_id"]))
        print(json.dumps(rec))
    out = root / a.tier / f"small_runs_{a.dataset}.csv"
    df = pd.DataFrame(rows)
    if out.exists():
        df = pd.concat([pd.read_csv(out), df], ignore_index=True)
    df.to_csv(out, index=False); man.output(out)
    failed = [r for r in rows if r["status"] != "COMPLETE"]
    man.close("COMPLETE" if not failed else "SOME_FAILED", n_runs=len(rows), n_failed=len(failed))
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
