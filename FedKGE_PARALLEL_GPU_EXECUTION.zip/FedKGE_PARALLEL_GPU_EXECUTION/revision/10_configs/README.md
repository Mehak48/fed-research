# Configuration
Resolution per run (later wins): `base.yaml` → `datasets/<ds>.yaml:run_overrides` → matrix block `base` → grid point →
`tiers/<tier>.yaml:run_overrides` (except keys a block lists in `tier_exempt`). `${sel:dp_selection.{dataset}.clip}`
placeholders are filled from `RESULTS_ROOT/<tier>/selection/`; a missing selection is an error, never a default.
Files: `base.yaml`; `datasets/{fb15k237,wn18rr,yago310,synthetic}.yaml`; `tiers/{smoke,dev,final,offline}.yaml`;
`matrices/{p3,p4}.yaml` (legacy replicas = blocks `R3_legacy`, `R4_legacy`, `L1_legacy`); `selection_rules.yaml`.
`synthetic`/`offline` exist only for the test-suite and cannot be used in the final tier.
