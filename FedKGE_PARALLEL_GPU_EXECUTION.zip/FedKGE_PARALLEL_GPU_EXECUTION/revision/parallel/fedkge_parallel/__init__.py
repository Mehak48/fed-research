"""fedkge_parallel - dependency-aware, file-based parallel execution of the frozen FedKGE study.

This package adds NO methodology. Every run is executed by the unchanged core (revision/01_fedkge_core/fedkge) through
the same functions the sequential entry points use (runner.expand / run_entries, scripts/run_plan.py,
scripts/freeze_selections.py, fedkge.selection, fedkge.gates). What it adds is execution architecture:

  * cells.py     the approved cells (frozen manifest on the research tiers) and their GPU-hour estimates
  * jobs.py      the job graph: which cells form which job, which job waits for which, run-id materialisation
  * schedule.py  environment-lock-aware assignment of jobs to GPU workers, simulated timeline, waves, critical path
  * execute.py   running one job inside one worker's private results root
  * bundles.py   atomic result bundles (worker -> master) and release packs (master -> workers)
  * store.py     the master store: validated import, cross-worker environment lock, selection replay, freeze
  * validate.py  completeness and compatibility of the master store against the approved cells
"""
__version__ = "1.0.0"
