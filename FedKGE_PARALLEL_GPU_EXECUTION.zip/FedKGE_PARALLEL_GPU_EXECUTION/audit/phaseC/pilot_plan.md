# Phase C — measured pilot and staged plan

**Date:** 2026-11-02, updated 2026-11-04 with the GPU pilot · **Gate:** G-B (`audit/phaseB/07_compute_feasibility.md` §8). The 2026-11-02 version is kept in `_versions/2026-11-02/`.

The pilot's MRR values are **not** results: runs stop after 2 rounds and are flagged `partial_run`.

**In short:**
- The pilot now ran on the owner's free-Colab **T4 GPU** (2026-11-04): 2 × 18 configurations, 0 failures, after 9 GPU smoke runs (§4).
- **Upper bounds on a T4:**
  - tuning (Stage 3) **≈ 12.4 GPU-hours**;
  - reduced core (Stage 4) **≈ 92 GPU-hours**;
  - extended blocks (Stage 5) **≈ 57 GPU-hours** (§5).
- Per run, every configuration is inside Phase B's estimated range or below its LOW end. None is above HIGH.

## 1. What the pilot measures and how

- **Script:** `scripts/pilot.py`.
- **Configurations:** 6 per dataset, each run on the **full** dataset for 2 rounds with the real configuration: true σ and q, steps, clipping, dense noise, integrity, trust.

| Label | Configuration | Planned rounds R |
|---|---|---|
| `np_central` | Non-private, centralised | 60 |
| `np_fed` | Non-private FedAvg, 10 clients, α = 0.1 | 60 |
| `dp_fedA_B512` | DP-FedAvg, design A (expected batch 512, per-client σ) | 100 |
| `dp_fed_q0.10` / `dp_fed_q0.02` | DP-FedAvg, design Q at the ends of the q grid | 100 |
| `complete_q0.10` | Proposed aggregation + hash-only integrity + DP | 100 |

**Measurement rules:**

- **One subprocess per run,** so peak memory belongs to that run. CPU uses peak RSS; CUDA uses peak allocated memory.
- **Storage** is the size of the run directory, with the final weights kept.
- **Per-run hours** = (R × seconds per round + R/5 validation passes + final evaluation) / 3600. This is an upper bound: every run executes R rounds, while non-private runs may stop early.
- **Plan-level hours:**
  - every **unique** run of the tuning matrix and of the confirmatory matrix is expanded exactly as the runner expands it, with placeholder selections (q = 0.05, R = 100, design Q, τ = 3);
  - each run gets the measured cost of its class;
  - design Q at q = 0.05 is interpolated with cost(q) = a + b/q through the q = 0.10 and q = 0.02 measurements;
  - the proposed method adds its measured overhead over DP-FedAvg.
- **Not in the estimate:**
  - The *extra* cost of these runs is not measured, though their **training cost is included**:
    - attack crafting;
    - robust aggregators other than the proposed one;
    - the MIA audit.

    Each is expected to be small next to training.
  - The **legacy replicas L1–L4** are not counted at all. They are 30 FB15k-237 runs in the `p3` / `p4` matrices, outside `confirm.yaml` (§5).

## 2. Measured on this machine (CPU, 2 cores; full real data; 2 rounds per run; 2026-11-02) — upper bounds

| Dataset | Configuration | Params | Local s/round | Aggregation s/round | Integrity s/round | **Total s/round** | Validation pass s | Final evaluation s | **Per-run hours (upper)** | Peak RSS (GB) | Run directory (MB) | Note |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| fb15k237 | np_central | 1,474,200 | 48.5 | 0.00 | 0.03 | **48.5** | 0.82 | 13.8 | **0.82** | 1.1 | 5.9 |  |
| fb15k237 | np_fed | 1,474,200 | 78.3 | 0.02 | 0.18 | **78.5** | 0.83 | 14.2 | **1.32** | 1.3 | 5.9 | overlapped a test run; superseded |
| fb15k237 | dp_fedA_B512 | 1,474,200 | 45.1 | 0.01 | 0.18 | **45.3** | 0.74 | 12.6 | **1.27** | 1.4 | 6.0 |  |
| fb15k237 | dp_fed_q0.10 | 1,474,200 | 74.5 | 0.02 | 0.20 | **74.7** | 0.66 | 11.9 | **2.08** | 1.9 | 6.0 |  |
| fb15k237 | dp_fed_q0.02 | 1,474,200 | 47.9 | 0.01 | 0.19 | **48.1** | 0.74 | 13.6 | **1.34** | 1.4 | 6.0 |  |
| fb15k237 | complete_q0.10 | 1,474,200 | 78.0 | 0.21 | 0.22 | **78.4** | 0.73 | 12.3 | **2.19** | 1.9 | 6.0 |  |
| wn18rr | np_central | 4,057,000 | 18.1 | 0.01 | 0.07 | **18.2** | 1.08 | 3.8 | **0.31** | 1.3 | 16.2 |  |
| wn18rr | np_fed | 4,057,000 | 18.3 | 0.10 | 0.58 | **19.0** | 1.48 | 2.8 | **0.32** | 2.2 | 16.2 |  |
| wn18rr | dp_fedA_B512 | 4,057,000 | 19.8 | 0.06 | 0.56 | **20.4** | 1.17 | 2.8 | **0.57** | 2.0 | 16.3 |  |
| wn18rr | dp_fed_q0.10 | 4,057,000 | 26.6 | 0.06 | 0.57 | **27.2** | 1.19 | 3.0 | **0.76** | 2.2 | 16.3 |  |
| wn18rr | dp_fed_q0.02 | 4,057,000 | 32.9 | 0.05 | 0.58 | **33.5** | 1.25 | 3.6 | **0.94** | 2.0 | 16.3 |  |
| wn18rr | complete_q0.10 | 4,057,000 | 25.6 | 0.57 | 0.58 | **26.8** | 1.18 | 3.1 | **0.75** | 2.1 | 16.3 |  |
| codex_m | np_central | 1,710,100 | 31.7 | 0.00 | 0.03 | **31.7** | 1.22 | 11.3 | **0.54** | 1.0 | 6.9 |  |
| codex_m | np_fed | 1,710,100 | 31.6 | 0.02 | 0.20 | **31.8** | 1.18 | 10.5 | **0.54** | 1.3 | 6.9 |  |
| codex_m | dp_fedA_B512 | 1,710,100 | 30.9 | 0.02 | 0.20 | **31.1** | 1.07 | 10.2 | **0.87** | 1.4 | 6.9 |  |
| codex_m | dp_fed_q0.10 | 1,710,100 | 48.3 | 0.02 | 0.25 | **48.5** | 1.20 | 11.2 | **1.36** | 2.0 | 6.9 |  |
| codex_m | dp_fed_q0.02 | 1,710,100 | 35.6 | 0.02 | 0.20 | **35.8** | 1.26 | 11.5 | **1.00** | 1.4 | 6.9 |  |
| codex_m | complete_q0.10 | 1,710,100 | 47.3 | 0.29 | 0.26 | **47.9** | 1.13 | 11.1 | **1.34** | 1.9 | 6.9 |  |
| fb15k237 | np_fed | 1,474,200 | 45.5 | 0.02 | 0.18 | **45.7** | 0.67 | 13.4 | **0.77** | 1.3 | 5.9 | clean re-measurement (used) |

**Notes on the measurements:**

- **Completeness:** all 18 runs plus 1 re-measurement completed, with 0 failures.
  - Files: `results/phaseC/pilot/pilot_measurements_20261102T130753Z.csv` and `…T133807Z.csv`.
  - Manifests: `manifests/*_pilot*.json`.
  - Per-run logs: `logs/pilot_*`.
- **FB15k-237 `np_fed`:**
  - The first measurement (78.5 s/round) overlapped a test-suite run on the same 2 cores.
  - The clean re-measurement gives 45.7 s/round. The extrapolation uses the clean value, and both measurement files are kept.
  - **Defect PC-6, found on 2026-11-04:** the re-measurement wrote into the first measurement's run folder. Nothing measured was lost: the first measurement's numbers are in its CSV row and its log. The folder now holds the second run, and its `log.txt` holds both. Fixed; see `code_changes.md`.
- **Where the time goes:**
  - Local training dominates.
  - Aggregation takes ≤ 0.6 s per round.
  - Integrity (hash and verify 20 objects per round) takes 0.03–0.6 s per round, which is ≤ 3 % of a round on this CPU.
- **The proposed method plus hash-only integrity** costs at most about 5 % more than DP-FedAvg at q = 0.10: FB15k-237 +3.7 s/round; WN18RR and CoDEx-M within measurement noise.
- **Effect of the sampling rate:**
  - On this CPU, q = 0.10 (10 large steps) is *slower* than q = 0.02 (50 small steps) on FB15k-237 and CoDEx-M, where big per-example batches are memory-bound.
  - It is faster on WN18RR, where dense noise on 4.06 M parameters per step dominates.
  - The GPU behaves differently (§4).
- **Memory:** peak RSS is 1.1–2.2 GB per run.
- **Storage:**
  - A run directory is about the model weights plus about 0.1 MB of records: FB15k-237 6.0 MB, WN18RR 16.3 MB, CoDEx-M 6.9 MB (with weights).
  - Planned kept weights: 150 models in the reduced plan, ≈ 50 × (5.9 + 16.2 + 6.8) MB ≈ 1.45 GB. This matches Phase B's 1.46 GB.
  - Records for the reduced plan: about 0.1–0.2 GB.
- **Privacy:** ε after 2 of 100 planned rounds is 0.54–0.68, with σ calibrated so that ε(R = 100) ≤ 4. This is an accountant check, not a result.
- **WN18RR parameters:** 4,057,000 = (40,559 training entities + 11 relations) × 100. Phase B assumed 40,943 entities.

## 3. Plan-level extrapolation from the CPU measurements (upper bounds)

| Plan | Stage | Unique runs | CPU-hours (upper bound) |
|---|---|---|---|
| Tuning chain (tune tier, seed 1001) | 1 (T1C, T1F, T2a) | 63 | 67.1 |
| Tuning chain | 2 (T2b) | 12 | 15.9 |
| Tuning chain | 3 (T2c) | 3 | 2.0 |
| Tuning chain | 4 (T2d) | 3 | 2.7 |
| Tuning chain | 5 (T3) | 18 | 23.8 |
| | **Total** (TAU reuses the T3 winner: 0 new runs) | **99** | **111.6** |
| Confirmatory, **reduced** profile | 4 (core blocks + M1) | 756 | 874.0 |
| Confirmatory, **reduced** profile | 5 (extended, deferrable) | 423 | 582.5 |
| Confirmatory, full profile | 4 (core blocks + M1) | 1,404 | 1,676.6 |
| Confirmatory, full profile | 5 (extended, deferrable) | 585 | 800.2 |

**How to read this table:**

- Runs shared by several blocks are counted once.
- Every run is assumed to execute rounds_max (an upper bound).

**Per run, this 2-core CPU takes:**

- **1.4–3.9×** Phase B's *HIGH* GPU estimate;
- **7–42×** its *LOW* estimate.

**This CPU cannot run the plan.** The measured T4 is about 9.5–10× faster at plan level (§5).

## 4. Measured on the owner's Colab T4 GPU (2026-11-04) — upper bounds

**Sources:**

- The full session record is `results/phaseC/colab/session_20261104T163226Z/`. Its `PROVENANCE.md` gives the environment, the steps, and the zip and code hashes.
- Derived comparison files: `results/phaseC/colab/analysis_20261104/gpu_pilot_per_config.csv` and `…/gpu_pilot_by_stage.csv`.

**Environment:**

| Item | Value |
|---|---|
| GPU | Tesla T4 |
| Software | torch 2.11.0+cu130, CUDA 13.0, Python 3.13.16 |
| Code | The same core code as the CPU pilot (hash `94105bac…`) |

**Why there are two runs.** The pilot ran twice in the session; the cell was most likely run a second time. Both runs are kept. Planning numbers use the **slower** of the two.

| Dataset | Configuration | GPU s/round (run 1 / run 2) | Integrity s/round (share) | CPU s/round | Speed-up | GPU min per run (upper) | Phase B min per run (LOW–HIGH) | GPU peak MB | Host RSS GB |
|---|---|---|---|---|---|---|---|---|---|
| fb15k237 | np_central | 3.92 / 3.87 | 0.11 (3 %) | 48.5 | 12.4× | 4.2 | 5.8–19.3 (below LOW) | 208 | 1.5 |
| fb15k237 | np_fed | 4.82 / 4.84 | 0.77 (16 %) | 45.7 | 9.4× | 5.1 | 5.9–19.6 (below LOW) | 375 | 1.6 |
| fb15k237 | dp_fedA_B512 | 5.57 / 5.33 | 0.65 (12 %) | 45.3 | 8.1× | 9.7 | 10.4–35.4 (below LOW) | 395 | 1.7 |
| fb15k237 | dp_fed_q0.10 | 4.73 / 4.59 | 0.78 (17 %) | 74.7 | 15.8× | 8.3 | 3.1–33.3 (inside) | 1,161 | 1.7 |
| fb15k237 | dp_fed_q0.02 | 5.37 / 5.34 | 0.75 (14 %) | 48.1 | 8.9× | 9.3 | 3.1–33.3 (inside) | 421 | 1.7 |
| fb15k237 | complete_q0.10 | 4.58 / 4.61 | 0.73 (16 %) | 78.4 | 17.0× | 8.1 | 3.1–33.3 (inside) | 1,161 | 1.7 |
| wn18rr | np_central | 2.50 / 2.50 | 0.30 (12 %) | 18.2 | 7.3× | 2.5 | 2.1–7.3 (inside) | 393 | 1.5 |
| wn18rr | np_fed | 4.31 / 4.43 | 2.29 (52 %) | 19.0 | 4.3× | 4.5 | 2.2–7.6 (inside) | 1,013 | 1.7 |
| wn18rr | dp_fedA_B512 | 4.36 / 4.67 | 2.20 (47 %) | 20.4 | 4.4× | 7.8 | 4.0–14.1 (inside) | 1,011 | 1.8 |
| wn18rr | dp_fed_q0.10 | 4.02 / 4.54 | 2.02 (44 %) | 27.2 | 6.0× | 7.6 | 2.6–32.7 (inside) | 1,352 | 1.8 |
| wn18rr | dp_fed_q0.02 | 6.35 / 6.47 | 1.91 (29 %) | 33.5 | 5.2× | 10.8 | 2.6–32.7 (inside) | 1,010 | 1.8 |
| wn18rr | complete_q0.10 | 4.33 / 4.13 | 1.88 (46 %) | 26.8 | 6.2× | 7.3 | 2.6–32.7 (inside) | 1,352 | 1.8 |
| codex_m | np_central | 3.00 / 3.00 | 0.10 (3 %) | 31.7 | 10.6× | 3.4 | 4.0–13.4 (below LOW) | 222 | 1.5 |
| codex_m | np_fed | 3.80 / 3.91 | 0.74 (19 %) | 31.8 | 8.2× | 4.3 | 4.1–13.7 (inside) | 439 | 1.6 |
| codex_m | dp_fedA_B512 | 4.33 / 4.42 | 0.73 (17 %) | 31.1 | 7.0× | 7.9 | 7.2–24.8 (inside) | 444 | 1.7 |
| codex_m | dp_fed_q0.10 | 3.60 / 3.95 | 0.77 (19 %) | 48.5 | 12.3× | 7.1 | 2.7–31.6 (inside) | 1,201 | 1.7 |
| codex_m | dp_fed_q0.02 | 4.89 / 5.02 | 0.77 (15 %) | 35.8 | 7.1× | 8.9 | 2.7–31.6 (inside) | 478 | 1.7 |
| codex_m | complete_q0.10 | 3.71 / 3.98 | 0.79 (20 %) | 47.9 | 12.0× | 7.1 | 2.7–31.6 (inside) | 1,201 | 1.7 |

**How to read the columns:**

- *Integrity* is from run 2.
- *Speed-up* is CPU s/round ÷ the slower GPU run.
- *GPU min per run* uses the slower run.
- *Phase B* is `audit/phaseB/data/per_run_time_estimate.csv`. The design-Q range covers q = 0.10 to 0.02.

**What the GPU numbers show:**

- **Completeness:** 9 / 9 GPU smoke runs, then 18 / 18 configurations in each pilot run, with 0 failures. **The CUDA code path works.**
- **Timing repeatability:**
  - Between the two runs, per-configuration timings differ by −4.7 % to +12.8 % (median |2.7 %|).
  - Plan totals differ by 2.6–2.8 %.
- **Same seed twice on the same T4:** the logged loss, ε and MRR are identical to 4 decimals in 18 of 18 configurations. This is **not a bitwise test**; the code does not switch on CUDA's deterministic mode. Do not claim bitwise GPU reproducibility.
- **Speed-up over the 2-core CPU:** 4.3–17× per configuration (median 8.1×), and about 9.5–10× at plan level.
- **Against Phase B's per-run estimates:**
  - 14 configurations are inside the LOW–HIGH range;
  - 4 are below LOW;
  - **none is above HIGH.**

  Phase B's HIGH end was too pessimistic for this code on a T4.
- **GPU memory:** peak allocated memory is 0.2–1.35 GB. A T4 has 16 GB, and Phase B estimated ≤ 2–3 GB. Host RAM is 1.5–1.8 GB.
- **Integrity costs relatively more on the GPU:**
  - In federated runs, hashing and verifying 20 objects per round takes 0.65–0.8 s on FB15k-237 and CoDEx-M, and 1.9–2.3 s on WN18RR (16 MB per object).
  - That is 12–52 % of a federated round, against ≤ 3 % on the CPU. Training became 4–17× faster; serialisation and SHA-256 still run on the host CPU.
  - **Any statement in the paper about integrity overhead must name the hardware.**
- **The proposed method's overhead** over DP-FedAvg at q = 0.10 is −0.41 to +0.31 s per round, within run-to-run noise.
- **Sampling rate on the GPU:**
  - q = 0.02 is slower than q = 0.10 on all three datasets: 4.9–6.5 s against 3.6–4.7 s per round. That is 50 small steps against 10 large ones.
  - On the CPU it was the reverse for FB15k-237 and CoDEx-M.

## 5. Plan-level GPU estimate (T4, upper bounds; from both runs)

| Plan | Stage | Unique runs | GPU-hours, run 1 / run 2 | CPU-hours (§3) | Phase B estimate (GPU-h, LOW–HIGH) |
|---|---|---|---|---|---|
| Tuning chain | 1 (T1C, T1F, T2a) | 63 | 7.6 / 7.8 | 67.1 | |
| Tuning chain | 2 (T2b) | 12 | 1.6 / 1.6 | 15.9 | |
| Tuning chain | 3 (T2c) | 3 | 0.2 / 0.2 | 2.0 | |
| Tuning chain | 4 (T2d) | 3 | 0.4 / 0.4 | 2.7 | |
| Tuning chain | 5 (T3) | 18 | 2.3 / 2.4 | 23.8 | |
| | **Total** (TAU: 0 new runs) | **99** | **12.1 / 12.4** | 111.6 | 99 runs, 5.5–41.1 |
| Confirmatory, **reduced** | 4 (core + M1) | 756 | **89.3 / 91.9** | 874.0 | 727 + 60 runs, 42.9–380.3, incl. 31 L0–L4 runs |
| Confirmatory, **reduced** | 5 (extended) | 423 | **56.2 / 57.3** | 582.5 | 432 runs, 20.7–234.9 |
| Confirmatory, full | 4 (core + M1) | 1,404 | 169.4 / 174.6 | 1,676.6 | 1,375 + 60 runs, 74.8–709.1 |
| Confirmatory, full | 5 (extended) | 585 | 77.6 / 79.2 | 800.2 | 594 runs, 28.4–323.8 |

**What is not in these numbers:**

- **Legacy replicas L1–L4:** 30 FB15k-237 runs.
  - They are blocks of the `p3` / `p4` matrices, run by `scripts/run_legacy_blocks.py`, and are not costed.
  - If they cost like the measured DP runs (≤ 0.18 h each), they add **≤ 5.4 GPU-hours**.
  - Phase B put L0–L4 at 4.5–14.5 GPU-hours.
- **Extra costs not measured** (training cost included):
  - attack crafting: 714 runs in the reduced plan;
  - other robust aggregators: 180 runs;
  - the MIA audit: 60 runs.
- **Early stopping:** every run is costed at its round limit. Non-private runs stop early, so their real cost is lower.
- **The selected sampling rate:** the estimate assumes the placeholder q = 0.05.
  - If tuning selects q = 0.02, DP runs cost about 12–29 % more per round.
  - If it selects q = 0.10, they cost 4–10 % less.

**Bottom line for the budget:**

| Scope | Upper bound |
|---|---|
| Stage 3 + reduced Stage 4 + L1–L4 | **≈ 110 GPU-hours** |
| Stage 5 | +57 |

Phase B's whole range for the core was 46.5–392.6 GPU-hours. The measured upper bound sits in its lower third.

## 6. What this means in calendar time (assumption-based arithmetic, not a forecast)

Free Colab does **not** publish its GPU limits. The rows below only divide the upper bounds by an assumed weekly GPU time.

| Work | GPU-h (upper) | at 10 GPU-h per week | at 20 | at 30 |
|---|---|---|---|---|
| Stage 3 tuning (99 runs) | 12.4 | ≈ 1.2 weeks | ≈ 0.6 | ≈ 0.4 |
| Stage 4 reduced core (756 runs) + L1–L4 (30) | 91.9 + ≤ 5.4 | ≈ 9.7 weeks | ≈ 4.9 | ≈ 3.2 |
| Stage 5 reduced extended (423 runs) | 57.3 | ≈ 5.7 weeks | ≈ 2.9 | ≈ 1.9 |

**Reference options (facts checked 2026-11-04; none is assumed to be yours):**

| Option | What the sources say |
|---|---|
| **Free Colab** | "Very limited" GPU access; sessions of at most 12 hours; limits not published |
| **Kaggle Notebooks (free)** | T4 / P100-class GPUs; 12-hour sessions. The weekly GPU quota is shown in your account; it is commonly reported as about 30 hours, but Kaggle does not state a number |
| **Colab Pay As You Go** | $9.99 for 100 compute units (US price, retrieved 21 Sep 2026; the units expire after 90 days). A T4 was measured at about 1.19 units per hour in March 2026 and 1.58 in October 2024, so 100 units ≈ 63–84 T4-hours |

**If you pay for Colab units:**

- Stage 3 + reduced Stage 4 + L1–L4 (≈ 110 GPU-hours, upper bound) would need about 131–173 units.
- Stage 5 adds about 68–91 units.
- Prices in Pakistan may differ, so check the price shown in your account.

**Rule for any platform:** all runs that are compared with each other stay in one environment. That means:

- the same GPU type and the same torch version;
- Stage 3 per dataset in one environment;
- all of Stage 4 for one dataset in one environment.

## 7. Gate G-B status

| Condition (Phase B `07` §8) | Status |
|---|---|
| Measured seconds per round and peak memory recorded | **Met:** CPU on 2026-11-02, T4 GPU on 2026-11-04 |
| Cost model refitted | **Met:** §5 is computed from the measured T4 costs |
| Centralised non-private MRR passes the sanity check (`05_privacy_utility_plan.md` §2: ≥ about ⅔ of the published TransE MRR; investigation only, never a target) | **Not yet.** It needs converged runs, so it comes from the first runs of Stage 3: T1C, centralised non-private, using validation MRR. **If it fails, Stage 3 stops** and the trainer is investigated before anything else runs |

## 8. Decisions and next steps

**Decisions (owner; see `remaining_blockers.md`):**

- **B2, budget and profile.** Recommended:
  - the reduced profile;
  - Stage 5 deferred until Stage 4 is done;
  - the run order of `audit/phaseB/07_compute_feasibility.md` §6 (priorities 1 → 7), so that a partial Stage 4 still answers the main hypotheses.
- **B3–B5,** before Stage 3.

**Stage order** (unchanged from Phase B; run counts from the implemented matrices):

| Stage | What | Runs (reduced profile, three datasets) | GPU-h (upper) |
|---|---|---|---|
| 3 | Tuning chain T1 → T2a → T2b → T2c → T2d → T3 → τ (tuning seed 1001; validation only). It begins with the G-B sanity check on T1C | 99 | 12.4 |
| — | `freeze_selections.py` (hash recorded); hypotheses frozen (gate G-D); budget confirmed | — | — |
| 4 | Core confirmatory blocks (N, DP, R, I, M1; 5–10 seeds) plus L1–L4 (`run_legacy_blocks.py`) | 756 + 30 | 91.9 + ≤ 5.4 |
| 5 | Extended / sensitivity (X blocks) | 423 (deferrable) | 57.3 |

**What Claude prepares after the owner's decisions:** a session-safe Stage 3 notebook for Colab. It will:

- check the code fingerprint;
- record and check the environment (GPU type, torch version) at every session, and refuse to continue a dataset's stage in a different environment;
- resume interrupted runs and skip completed ones, with results on Drive;
- stop cleanly before a session limit;
- run the G-B sanity check first.
