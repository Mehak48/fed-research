# Table 8 — Stage 3 selection (T2a); validation only

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| dataset | dp.q | train.lr | val_mrr_mean | chosen | tied_within_tolerance |
|---|---|---|---|---|---|
| codex_m | 0.02 | 0.001 | 0.0017 | False | True |
| codex_m | 0.02 | 0.003 | 0.001567 | False | False |
| codex_m | 0.02 | 0.01 | 0.001487 | False | False |
| codex_m | 0.05 | 0.001 | 0.001725 | False | True |
| codex_m | 0.05 | 0.003 | 0.002035 | False | True |
| codex_m | 0.05 | 0.01 | 0.002183 | False | True |
| codex_m | 0.1 | 0.001 | 0.002008 | True | True |
| codex_m | 0.1 | 0.003 | 0.002383 | False | True |
| codex_m | 0.1 | 0.01 | 0.003636 | False | True |
| fb15k237 | 0.02 | 0.001 | 0.002586 | False | True |
| fb15k237 | 0.02 | 0.003 | 0.002723 | False | True |
| fb15k237 | 0.02 | 0.01 | 0.002598 | False | True |
| fb15k237 | 0.05 | 0.001 | 0.002589 | False | True |
| fb15k237 | 0.05 | 0.003 | 0.002596 | False | True |
| fb15k237 | 0.05 | 0.01 | 0.002726 | False | True |
| fb15k237 | 0.1 | 0.001 | 0.002598 | True | True |
| fb15k237 | 0.1 | 0.003 | 0.002796 | False | True |
| fb15k237 | 0.1 | 0.01 | 0.002854 | False | True |
| wn18rr | 0.02 | 0.001 | 0.0008397 | False | True |
| wn18rr | 0.02 | 0.003 | 0.000842 | False | True |
| wn18rr | 0.02 | 0.01 | 0.000857 | False | True |
| wn18rr | 0.05 | 0.001 | 0.000842 | False | True |
| wn18rr | 0.05 | 0.003 | 0.0008483 | False | True |
| wn18rr | 0.05 | 0.01 | 0.0008594 | False | True |
| wn18rr | 0.1 | 0.001 | 0.0008416 | True | True |
| wn18rr | 0.1 | 0.003 | 0.0008413 | False | True |
| wn18rr | 0.1 | 0.01 | 0.00086 | False | True |
