# history/ — superseded material, kept for the record (never deleted)

`phaseC_handoff_2026-11-04/` holds the top level of the Phase C handoff package as it was on 2026-11-04, the baseline
of this final package (git commit 6e2ea67 in `revision/`):

| Item | What it was | Superseded by |
|---|---|---|
| `HANDOFF_PHASE_C*.md` | handoff briefs of 2026-11-02 and 2026-11-04 (status: waiting for decisions B2-B5) | `../README.md`, `../EXECUTION_GUIDE.md`, `../audit/final/` |
| `phaseC_changes.patch`, `phaseC_git_status.txt` | the uncommitted Phase C diff before the B2-B5 checkpoint commit | git history of `revision/` |
| `colab_kit/` | the GPU pilot kit exactly as the owner ran it on 2026-11-04 (code zip `4fb27cf8...`; predates fix PC-6) | `../RUN_COMPLETE_FEDKGE_RESEARCH.ipynb` |
| `phaseC_dev_probes/` | early synthetic probes from Phase C development (not results) | — |

Nothing here is a research result, and nothing here is used by the final code.
