# Phase 3 — Corrected federated TransE baseline (non-DP)
**Notebook:** `phase3_federated.ipynb` · **Inputs:** P1 + P2 artifacts · **GPU:** yes (dev/final) · **Runs:** 70 (final)

Config: TransE d = 100, margin 1, L2-normalised entities, Adam 1e-3, batch 512, 64 correct negatives, 10 clients,
1 local epoch/round, R_max = 100, early stopping on the fixed V_sel subset (eval every 5, patience 4), final
full filtered head+tail realistic evaluation on V_sel and test for the selected checkpoint (test once).
Blocks: `P3_central`, `P3_iid`, `P3_dir` (α 1.0 / 0.1), `R3_legacy` (exact old Phase 3, FB only, isolated in its
own block with `neg_mode: p3_legacy` etc.), `R3_fixed`.

**Per run:** `runs/<run_id>/{config.json, env.json, status.json, rounds.csv, weights_rounds.csv, integrity.json,
final.json, per_relation_test_mrr.json, log.txt}`. `final.json` has dataset, seed, clients, partition spec, full
config, config hash, code/data/partition hashes, rounds executed/selected/stop reason, val + test MRR, Hits@1/3/10
(head, tail, both; realistic + optimistic/pessimistic MRR; bootstrap CI), runtime, communication.
**Reports:** `reports/p3/{p3_reference, p3_fl_gap_paired, p3_legacy_replica, p3_all_runs}.csv`.
**Next:** Phase 4 (needs P3 complete: L0 of the DP ladder).
