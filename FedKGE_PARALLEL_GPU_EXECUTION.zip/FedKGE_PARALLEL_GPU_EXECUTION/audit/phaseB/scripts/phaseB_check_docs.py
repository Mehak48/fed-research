#!/usr/bin/env python3
"""Phase B self-check (no experiments): consistency of the planning documents and integrity of existing inputs.

Checks
  1. Markdown tables: every row has the same number of cells as its header.
  2. Every referenced local file (`data/...`, `scripts/...`, `drafts/...`, `0X_*.md`) exists.
  3. Every defect ID mentioned in the documents exists in data/defect_register.csv.
  4. Every block ID mentioned exists in data/experiment_matrix.csv; decision IDs are within D1..D18.
  5. Key numbers quoted in the documents equal the values recomputed from the data files (rounded as displayed).
  6. No placeholder text (TODO, TBD, FIXME, XXX, '??') and no stale wording from superseded drafts.
  7. The assembled documents (01, 06) contain the current generated table fragments.
  8. Phase A deliverables are byte-identical to the delivered Phase A zip (nothing overwritten).
  9. Supplied inputs (uploads + attachments) still have the SHA-256 recorded in the Phase A inventory.
Exit code 0 only if every check passes.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path

DOCS = ["README.md", "01_defect_register.md", "02_design_decisions.md", "03_methodology_specification.md",
        "03a_threat_model.md", "04_dataset_benchmark.md", "05_privacy_utility_plan.md", "06_experiment_matrix.md",
        "07_compute_feasibility.md", "08_open_questions.md"]
BLOCK_RE = re.compile(r"\b(P2\.[123]|T[1-3][a-d]?|L[0-4]|N[1-3]|DP[1-3]h?|R[1-5][apq]?|I[12]|M1|X[1-7][ab]?|O1)\b")
DEFECT_RE = re.compile(r"\b(CR-\d+|MJ-\d+|MN-\d+|OP-\d+|G\d{1,2})\b")
DEC_RE = re.compile(r"\bD(\d{1,2})\b")
# wording from superseded drafts that must not survive (block names before the DP rename, old numbers, old rules)
STALE = {
    r"\bD[123]h\b": "old block name (now DP1h/DP2h)",
    r"\bD3-[ab]\b": "old block name (now DP3-a/DP3-b)",
    r"Clopper": "Clopper-Pearson MIA bound (replaced by the one-run audit)",
    r"\b3\.7 ?%": "WN18RR acceptance (is 3.75 %)",
    r"46–384|1,455\b|\b822\b": "superseded run/cost totals",
    r"\bV2\b": "trust variant V2 (removed)",
    r"\(80:|80 defects|\b13 critical|\b24 minor": "superseded defect counts",
    r"C1–C15": "superseded Phase C change list (now C1–C17)",
    r"36–60": "superseded M1 run count",
}


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def table_problems(text: str):
    probs, lines = [], text.splitlines()
    i = 0
    while i < len(lines):
        if lines[i].startswith("|") and i + 1 < len(lines) and re.match(r"^\|[\s:\-|]+\|$", lines[i + 1]):
            n = lines[i].count("|")
            j = i + 2
            while j < len(lines) and lines[j].startswith("|"):
                if lines[j].count("|") != n:
                    probs.append((i + 1, j + 1, n, lines[j].count("|")))
                j += 1
            i = j
        else:
            i += 1
    return probs


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--phaseb", required=True)
    ap.add_argument("--phasea-zip", required=True)
    ap.add_argument("--uploads", required=True)
    ap.add_argument("--attachments", required=True)
    a = ap.parse_args(argv)
    root = Path(a.phaseb).resolve()
    audit = root.parent
    fails, report = [], []

    def ok(name, cond, detail=""):
        report.append(("PASS" if cond else "FAIL", name, detail))
        if not cond:
            fails.append(name)

    texts = {d: (root / d).read_text() for d in DOCS if (root / d).exists()}
    ok("all documents present", len(texts) == len(DOCS), str(sorted(set(DOCS) - set(texts))))
    T = texts

    # 1 tables
    for d, t in texts.items():
        p = table_problems(t)
        ok(f"tables well-formed: {d}", not p, str(p[:3]))

    # 2 referenced files
    missing = []
    for d, t in texts.items():
        for m in re.findall(r"`((?:data|scripts|drafts)/[A-Za-z0-9_.\-/]+)`", t):
            if not (root / m).exists():
                missing.append((d, m))
        for m in re.findall(r"`(0\d[a-z]?_[A-Za-z0-9_\-]+\.md)`", t):
            if not (root / m).exists():
                missing.append((d, m))
    ok("referenced local files exist", not missing, str(missing[:10]))

    # 3 defect ids
    reg = {r["id"] for r in csv.DictReader(open(root / "data/defect_register.csv"))}
    bad = sorted({(d, m) for d, t in texts.items() for m in DEFECT_RE.findall(t) if m not in reg})
    ok("defect IDs resolve", not bad, str(bad[:10]))

    # 4 block ids and decisions
    blocks = {r["block"] for r in csv.DictReader(open(root / "data/experiment_matrix.csv"))}
    badb = sorted({(d, m) for d, t in texts.items() for m in BLOCK_RE.findall(t) if m not in blocks})
    ok("block IDs resolve", not badb, str(badb[:10]))
    badd = sorted({(d, m) for d, t in texts.items() for m in DEC_RE.findall(t) if not (1 <= int(m) <= 18)})
    ok("decision IDs within D1..D18", not badd, str(badd[:10]))

    # 5 key numbers, recomputed from the data files
    def quoted(s, *docs):
        miss = [d for d in docs if s not in T[d]]
        ok(f"'{s}' quoted in {', '.join(d[:3] for d in docs)}", not miss, str(miss))

    rc = list(csv.DictReader(open(root / "data/run_counts.csv")))

    def stage_sum(profile, third, col, tiers=("core",), stages=("2", "3", "4")):
        return sum(float(r[col]) for r in rc if r["profile"] == profile and r["third_dataset"] == third
                   and r["tier"] in tiers and r["stage"] in stages)
    lo, hi = stage_sum("reduced", "codex_m", "gpu_hours_LOW"), stage_sum("reduced", "codex_m", "gpu_hours_HIGH")
    quoted(f"{lo:.1f}–{hi:.1f}", "07_compute_feasibility.md", "README.md")
    quoted(f"{int(stage_sum('reduced', 'codex_m', 'runs')):,} runs", "07_compute_feasibility.md")
    quoted(f"{int(stage_sum('full', 'codex_m', 'runs')):,}", "07_compute_feasibility.md", "02_design_decisions.md")
    m1 = [r for r in rc if r["tier"] == "decision-D6" and r["third_dataset"] == "codex_m"]
    ok("M1 identical in both profiles", len({(r["runs"], r["gpu_hours_LOW"], r["gpu_hours_HIGH"]) for r in m1}) == 1)
    quoted(f"{m1[0]['runs']} runs, {float(m1[0]['gpu_hours_LOW']):.1f}–{float(m1[0]['gpu_hours_HIGH']):.1f}",
           "07_compute_feasibility.md")

    ce = list(csv.DictReader(open(root / "data/cost_estimate.csv")))

    def ds_sum(col, bound):
        return sum(float(r[col]) for r in ce if r["profile"] == "reduced" and r["tier"] == "core"
                   and r["bound"] == bound and r[col])
    yg = (ds_sum("gpu_hours_YG", "LOW"), ds_sum("gpu_hours_YG", "HIGH"))
    cx = (ds_sum("gpu_hours_CX", "LOW"), ds_sum("gpu_hours_CX", "HIGH"))
    ratio = sorted((yg[0] / cx[0], yg[1] / cx[1]))
    quoted(f"{yg[0]:.0f}–{yg[1]:.0f}", "02_design_decisions.md", "04_dataset_benchmark.md", "07_compute_feasibility.md")
    quoted(f"{cx[0]:.0f}–{cx[1]:.0f}", "02_design_decisions.md", "04_dataset_benchmark.md", "07_compute_feasibility.md")
    quoted(f"{ratio[0]:.1f}–{ratio[1]:.1f}", "02_design_decisions.md", "04_dataset_benchmark.md", "07_compute_feasibility.md")

    pc = [r for r in csv.DictReader(open(root / "data/priority_cost.csv"))
          if r["profile"] == "reduced" and r["third_dataset"] == "codex_m"]
    for r in pc:
        if r["priority"] in ("1", "2", "6"):
            quoted(f"{r['cumulative_LOW']}–{r['cumulative_HIGH']}", "07_compute_feasibility.md")
    st = {(r["profile"], r["third_dataset"]): r for r in csv.DictReader(open(root / "data/storage_estimate.csv"))}
    for key in (("reduced", "codex_m"), ("full", "codex_m")):
        quoted(f"{float(st[key]['kept_weights_GB']):.2f} GB", "07_compute_feasibility.md")
        quoted(f"{float(st[key]['total_persistent_GB_upper']):.2f} GB", "07_compute_feasibility.md")

    sig = list(csv.DictReader(open(root / "data/phaseB_sigma_plan.csv")))
    for q, R in (("0.05", "100"), ("0.02", "100"), ("0.1", "100"), ("0.05", "50")):
        for r in sig:
            if r["design"] == "Q_common_rate" and r["dataset"] == "fb15k237" and r["q"] == q and r["rounds"] == R:
                v = f'{float(r["sigma_rdp"]):.2f}'
                ok(f"05 quotes sigma {v} (q={q}, R={R}, eps={r['eps_target']})", v in T["05_privacy_utility_plan.md"])
    sav = [float(r["pld_noise_saving_pct"]) for r in sig if r["pld_noise_saving_pct"] and r["rounds"] == "100"
           and r["q"] in ("0.02", "0.05", "0.1")]
    quoted(f"{min(sav):.1f}–{max(sav):.1f} %", "05_privacy_utility_plan.md")
    names = {"fb15k237": "FB15k-237", "wn18rr": "WN18RR", "codex_m": "CoDEx-M", "yago310": "YAGO3-10",
             "codex_l": "CoDEx-L", "codex_s": "CoDEx-S"}
    grid = {}
    for r in sig:
        if r["design"] == "Q_common_rate" and r["rounds"] == "100" and r["eps_target"] == "4.0" \
                and r["q"] in ("0.02", "0.05", "0.1"):
            grid.setdefault(r["dataset"], []).append(float(r["noise_norm_over_C"]))
    for ds, v in grid.items():
        ok(f"04 quotes noise/clip range for {names[ds]}", f"({min(v):.1f}–{max(v):.1f})" in T["04_dataset_benchmark.md"])
    allv = [x for v in grid.values() for x in v if True]
    main3 = [x for ds in ("fb15k237", "wn18rr", "codex_m", "yago310") for x in grid[ds]]
    quoted(f"{min(main3):.1f} (YAGO3-10) to {max(main3):.1f} (WN18RR)", "01_defect_register.md")
    quoted(f"{min(grid['wn18rr']):.1f}–{max(grid['wn18rr']):.1f}", "01_defect_register.md", "04_dataset_benchmark.md")
    del allv

    js = json.load(open(root / "data/phaseB_sigma_plan.json"))
    cl = js["client_level_dp_reference"]
    z4 = [c for c in cl if c["rounds"] == 100 and c["eps_target"] == 4.0][0]
    ok("02 quotes client-level z ~ 12.7", f'{z4["noise_multiplier_z"]:.1f}' == "12.7" and "12.7" in T["02_design_decisions.md"])
    ok("02 quotes ~1,540x", round(z4["noise_norm_over_S_fb15k237"], -1) == 1540 and "1,540" in T["02_design_decisions.md"])
    ic = js["independent_checks"]
    e4 = [c for c in ic if c["eps_target"] == 4.0][0]
    quoted(f"[{e4['eps_prv_lower']:.3f}, {e4['eps_prv_upper']:.3f}]", "03_methodology_specification.md",
           "05_privacy_utility_plan.md")
    ok("PRV interval contains PLD at every check", all(c["eps_prv_lower"] <= c["eps_dp_accounting_pld"] <= c["eps_prv_upper"]
                                                       for c in ic))
    dq = max(abs(c["eps_numeric_rdp_quadrature"] - c["eps_dp_accounting_rdp"]) for c in ic)
    ok(f"quadrature vs dp_accounting max |diff| {dq:.2e} quoted as 1.4·10⁻⁴",
       f"{dq:.1e}" == "1.4e-04" and "1.4·10⁻⁴" in T["05_privacy_utility_plan.md"] and "1.4·10⁻⁴" in T["README.md"])
    pr = [c["eps_dp_accounting_pld"] / c["eps_dp_accounting_rdp"] for c in ic]
    quoted(f"{min(pr):.3f}–{max(pr):.3f}", "05_privacy_utility_plan.md")
    xr = max(c["relative_difference"] for c in js["crosscheck_revision"])
    ok(f"cross-check max relative difference {xr:.4f} < 0.002 and quoted as 0.2 %",
       xr < 0.002 and "0.2 %" in T["05_privacy_utility_plan.md"] and "0.2 %" in T["03_methodology_specification.md"])

    pf = list(csv.DictReader(open(root / "data/phaseB_partition_feasibility.csv")))
    wn01 = [r for r in pf if r["dataset"].startswith("wn18rr") and r["alpha"] == "0.1"][0]
    fb01 = [r for r in pf if r["dataset"].startswith("fb15k237") and r["alpha"] == "0.1"][0]
    quoted(f"{100 * float(wn01['accept_prob']):.2f} %", "02_design_decisions.md", "04_dataset_benchmark.md")
    dfb = 1e-6 * float(fb01["max_share_median"]) * float(fb01["n_train"])
    dwn = 1e-6 * float(wn01["max_share_median"]) * float(wn01["n_train"])
    quoted(f"≈ {dfb:.2f}", "02_design_decisions.md", "04_dataset_benchmark.md", "05_privacy_utility_plan.md")
    quoted(f"≈ {dwn:.3f}", "02_design_decisions.md", "04_dataset_benchmark.md", "05_privacy_utility_plan.md")

    dr = list(csv.DictReader(open(root / "data/defect_register.csv")))
    counts = {s: sum(1 for r in dr if r["severity"] == s) for s in ("Critical", "Major", "Minor", "Optional")}
    total = len(dr)
    ok(f"every defect has a severity ({total} entries)", sum(counts.values()) == total, str(counts))
    t01 = T["01_defect_register.md"]
    ok("01 counts table matches the register",
       all(re.search(rf"\| {s} \| {n} \|", t01) for s, n in counts.items()) and f"| **Total** | **{total}** |" in t01,
       str(counts))
    quoted(f"({total}: {counts['Critical']} critical, {counts['Major']} major, {counts['Minor']} minor, "
           f"{counts['Optional']} optional)", "README.md")

    # 6 placeholders and stale wording
    ph = sorted({(d, m) for d, t in texts.items() for m in re.findall(r"\b(TODO|TBD|FIXME|XXX)\b|\?\?", t)})
    ok("no placeholder text", not ph, str(ph[:5]))
    for pat, why in STALE.items():
        hits = sorted({d for d, t in texts.items() if re.search(pat, t)})
        ok(f"no stale wording: {why}", not hits, str(hits))

    # 7 assembled documents are current
    part = lambda n: (root / "drafts" / n).read_text()
    ok("01 = header + generated defect tables + footer",
       t01 == part("01_header.md") + part("defect_tables.md.part") + part("01_footer.md"))
    ok("06 = header + generated matrix + footer + generated thresholds + footer2",
       T["06_experiment_matrix.md"] == part("06_header.md") + part("matrix_table.md.part") + part("06_footer.md")
       + part("threshold_table.md.part") + part("06_footer2.md"))

    # 8 Phase A deliverables unchanged
    z = zipfile.ZipFile(a.phasea_zip)
    diff = []
    for info in z.infolist():
        if info.is_dir():
            continue
        p = audit.parent / info.filename
        if not p.exists() or hashlib.sha256(z.read(info)).hexdigest() != sha256(p):
            diff.append(info.filename)
    ok("Phase A files byte-identical to delivered zip", not diff, str(diff[:5]))

    # 9 inputs unchanged vs Phase A inventory
    inv = list(csv.DictReader(open(audit / "data/artifact_inventory.csv")))
    known = {r["sha256"] for r in inv}
    newer = {sha256(p) for p in Path(a.attachments).iterdir() if p.is_file()} - known   # files sent after Phase A
    checked, mism, reused = 0, [], []
    for r in inv:
        if r["group"] == "UPLOADS":
            p = Path(a.uploads) / r["path"]
        elif r["group"] == "ATTACH":
            p = Path(a.attachments) / r["path"]
        else:
            continue
        if p.exists():
            checked += 1
            h = sha256(p)
            if h != r["sha256"]:
                (reused if h in newer else mism).append(r["path"])
    ok(f"supplied inputs unchanged ({checked} files present and checked)", checked > 0 and not mism, str(mism[:5]))
    report.append(("INFO", f"upload names reused by newer messages (not modifications): {reused}", ""))

    for status, name, detail in report:
        print(f"{status}  {name}" + (f"  -> {detail}" if status == "FAIL" and detail else ""))
    n_checks = sum(1 for r in report if r[0] != "INFO")
    print(f"\n{n_checks - len(fails)} passed, {len(fails)} failed")
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main())
