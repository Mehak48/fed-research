# Experimental results — draft generated from recorded runs

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT.** Nothing below may be cited.

Generated 2026-11-05T02:48:57.328210Z from `/home/claude/fedkge_work/results_local/smoke_final` (smoke tier). Every number comes from a recorded run; every ⟦PENDING: …⟧ marks a value that does not exist yet. Regenerate after more runs complete (`scripts/build_report.py`).

## 1. Experimental setup

Datasets: FB15k-237, WN18RR and CoDEx-M with their official splits (triples whose entities never occur in training are removed from validation and test). Ten clients per federation built by a Dirichlet distribution over relations (α = 0.1 main setting; α = 0.5, 1.0 and IID for the heterogeneity study). Model: TransE, d = 100, L2-normalised entities, margin loss with 64 data-independent negatives, Adam. Privacy: triple-level DP-SGD per client (Poisson sampling, per-example clipping, Gaussian noise) under zero-out adjacency, RDP accountant with PLD and PRV cross-checks, δ = 10⁻⁶, ε* ∈ {1, 2, 4, 8}, primary ε* = 4 declared in advance. Integrity: SHA-256 verification in the data path (not a poisoning defence; no IPFS). Seeds: tuning seed 1001 (selection on validation only); confirmatory seeds {42, 123, 256, 512, 1024} (3 for descriptive blocks).

Selections frozen after Stage 3 (validation only):

- FB15k-237: q* = 0.1, lr* = 0.001, C* = 0.25, R* = 50, design = common_rate, s* = {"shape": "fixed", "rho": 1.0}, τ* = 2.0 (tau rule met); non-private FedAvg (lr, B) = {"lr": 0.001, "batch_size": 512}, centralised (lr, B) = {"lr": 0.01, "batch_size": 512}
- WN18RR: q* = 0.1, lr* = 0.001, C* = 0.25, R* = 50, design = common_rate, s* = {"shape": "fixed", "rho": 1.0}, τ* = 3.0 (tau rule met); non-private FedAvg (lr, B) = {"lr": 0.001, "batch_size": 512}, centralised (lr, B) = {"lr": 0.01, "batch_size": 512}
- CoDEx-M: q* = 0.1, lr* = 0.001, C* = 0.25, R* = 50, design = common_rate, s* = {"shape": "fixed", "rho": 1.0}, τ* = 5.0 (tau rule met); non-private FedAvg (lr, B) = {"lr": 0.01, "batch_size": 512}, centralised (lr, B) = {"lr": 0.01, "batch_size": 512}

## 2. Pre-registered gates and flags

- Gate G-B (accuracy sanity) on FB15k-237: FAILED (validation MRR 0.101 vs threshold 0.209)
- Gate G-B (accuracy sanity) on WN18RR: FAILED (validation MRR 0.008 vs threshold 0.152)
- Gate G-B (accuracy sanity) on CoDEx-M: FAILED (validation MRR 0.075 vs threshold 0.202)
- D10 utility review flag: D10 not triggered: r = 0.937 >= 0.25 on fb15k237

## 3. Main results (Table 3)

- FB15k-237 — test MRR, mean [95 % CI] (n): Centralised TransE (non-private): 0.112 (n=1); FedAvg (non-private): 0.005 (n=1); DP-FedAvg, eps* = 4 (selected schedule): 0.005 (n=1); Complete method, eps* = 4: 0.005 (n=1).
- WN18RR — test MRR, mean [95 % CI] (n): Centralised TransE (non-private): 0.015 (n=1); FedAvg (non-private): 0.001 (n=1); DP-FedAvg, eps* = 4 (selected schedule): 0.001 (n=1); Complete method, eps* = 4: 0.001 (n=1).
- CoDEx-M — test MRR, mean [95 % CI] (n): Centralised TransE (non-private): 0.102 (n=1); FedAvg (non-private): 0.004 (n=1); DP-FedAvg, eps* = 4 (selected schedule): 0.002 (n=1); Complete method, eps* = 4: 0.002 (n=1).

## 4. Pre-registered hypotheses (Table 12)

One-sided paired t-tests at α = 0.025 with Holm correction within each family; members that could not be tested enter with p = 1. A family whose members are not all computed is marked provisional.

### H1 — utility retention under privacy

Holm status: **PROVISIONAL (incomplete family)**.

- ⟦PENDING: H1 FB15k-237: runs missing (numerator missing seeds [123, 256, 512, 1024]; denominator missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H1 WN18RR: runs missing (numerator missing seeds [123, 256, 512, 1024]; denominator missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H1 CoDEx-M: runs missing (numerator missing seeds [123, 256, 512, 1024]; denominator missing seeds [123, 256, 512, 1024])⟧

### H2b — no harm in clean conditions (non-inferiority)

Holm status: **PROVISIONAL (incomplete family)**.

- ⟦PENDING: H2b FB15k-237: runs missing (numerator missing seeds [123, 256, 512, 1024]; denominator missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2b WN18RR: runs missing (numerator missing seeds [123, 256, 512, 1024]; denominator missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2b CoDEx-M: runs missing (numerator missing seeds [123, 256, 512, 1024]; denominator missing seeds [123, 256, 512, 1024])⟧

### HS — scheduled noise

Holm status: **FINAL**.

- HS (FB15k-237) is not tested: NOT EVIDENCE (smoke tier): NOT TESTABLE (the selected schedule s* is fixed (DP2 = DP1)); enters Holm with p = 1.
- HS (WN18RR) is not tested: NOT EVIDENCE (smoke tier): NOT TESTABLE (the selected schedule s* is fixed (DP2 = DP1)); enters Holm with p = 1.
- HS (CoDEx-M) is not tested: NOT EVIDENCE (smoke tier): NOT TESTABLE (the selected schedule s* is fixed (DP2 = DP1)); enters Holm with p = 1.

### H2 — robustness to poisoning

Holm status: **PROVISIONAL (incomplete family)**.

Of the 21 members (3 datasets × 7 attacks): 0 supported; status counts {"MISSING_RUNS": 21}.

- ⟦PENDING: H2 FB15k-237, gaussian attack: runs missing (fedavg_clean missing seeds [123, 256, 512, 1024]; fedavg_attacked missing seeds [123, 256, 512, 1024]; method_clean missing seeds [123, 256, 512, 1024]; method_attacked missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2 FB15k-237, signflip attack: runs missing (fedavg_clean missing seeds [123, 256, 512, 1024]; fedavg_attacked missing seeds [123, 256, 512, 1024]; method_clean missing seeds [123, 256, 512, 1024]; method_attacked missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2 FB15k-237, alie attack: runs missing (fedavg_clean missing seeds [123, 256, 512, 1024]; fedavg_attacked missing seeds [123, 256, 512, 1024]; method_clean missing seeds [123, 256, 512, 1024]; method_attacked missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2 FB15k-237, ipm attack: runs missing (fedavg_clean missing seeds [123, 256, 512, 1024]; fedavg_attacked missing seeds [123, 256, 512, 1024]; method_clean missing seeds [123, 256, 512, 1024]; method_attacked missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2 FB15k-237, targeted attack: runs missing (fedavg_clean missing seeds [123, 256, 512, 1024]; fedavg_attacked missing seeds [123, 256, 512, 1024]; method_clean missing seeds [123, 256, 512, 1024]; method_attacked missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2 FB15k-237, sybil attack: runs missing (fedavg_clean missing seeds [123, 256, 512, 1024]; fedavg_attacked missing seeds [123, 256, 512, 1024]; method_clean missing seeds [123, 256, 512, 1024]; method_attacked missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2 FB15k-237, adaptive attack: runs missing (fedavg_clean missing seeds [123, 256, 512, 1024]; fedavg_attacked missing seeds [123, 256, 512, 1024]; method_clean missing seeds [123, 256, 512, 1024]; method_attacked missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2 WN18RR, gaussian attack: runs missing (fedavg_clean missing seeds [123, 256, 512, 1024]; fedavg_attacked missing seeds [123, 256, 512, 1024]; method_clean missing seeds [123, 256, 512, 1024]; method_attacked missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2 WN18RR, signflip attack: runs missing (fedavg_clean missing seeds [123, 256, 512, 1024]; fedavg_attacked missing seeds [123, 256, 512, 1024]; method_clean missing seeds [123, 256, 512, 1024]; method_attacked missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2 WN18RR, alie attack: runs missing (fedavg_clean missing seeds [123, 256, 512, 1024]; fedavg_attacked missing seeds [123, 256, 512, 1024]; method_clean missing seeds [123, 256, 512, 1024]; method_attacked missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2 WN18RR, ipm attack: runs missing (fedavg_clean missing seeds [123, 256, 512, 1024]; fedavg_attacked missing seeds [123, 256, 512, 1024]; method_clean missing seeds [123, 256, 512, 1024]; method_attacked missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2 WN18RR, targeted attack: runs missing (fedavg_clean missing seeds [123, 256, 512, 1024]; fedavg_attacked missing seeds [123, 256, 512, 1024]; method_clean missing seeds [123, 256, 512, 1024]; method_attacked missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2 WN18RR, sybil attack: runs missing (fedavg_clean missing seeds [123, 256, 512, 1024]; fedavg_attacked missing seeds [123, 256, 512, 1024]; method_clean missing seeds [123, 256, 512, 1024]; method_attacked missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2 WN18RR, adaptive attack: runs missing (fedavg_clean missing seeds [123, 256, 512, 1024]; fedavg_attacked missing seeds [123, 256, 512, 1024]; method_clean missing seeds [123, 256, 512, 1024]; method_attacked missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2 CoDEx-M, gaussian attack: runs missing (fedavg_clean missing seeds [123, 256, 512, 1024]; fedavg_attacked missing seeds [123, 256, 512, 1024]; method_clean missing seeds [123, 256, 512, 1024]; method_attacked missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2 CoDEx-M, signflip attack: runs missing (fedavg_clean missing seeds [123, 256, 512, 1024]; fedavg_attacked missing seeds [123, 256, 512, 1024]; method_clean missing seeds [123, 256, 512, 1024]; method_attacked missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2 CoDEx-M, alie attack: runs missing (fedavg_clean missing seeds [123, 256, 512, 1024]; fedavg_attacked missing seeds [123, 256, 512, 1024]; method_clean missing seeds [123, 256, 512, 1024]; method_attacked missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2 CoDEx-M, ipm attack: runs missing (fedavg_clean missing seeds [123, 256, 512, 1024]; fedavg_attacked missing seeds [123, 256, 512, 1024]; method_clean missing seeds [123, 256, 512, 1024]; method_attacked missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2 CoDEx-M, targeted attack: runs missing (fedavg_clean missing seeds [123, 256, 512, 1024]; fedavg_attacked missing seeds [123, 256, 512, 1024]; method_clean missing seeds [123, 256, 512, 1024]; method_attacked missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2 CoDEx-M, sybil attack: runs missing (fedavg_clean missing seeds [123, 256, 512, 1024]; fedavg_attacked missing seeds [123, 256, 512, 1024]; method_clean missing seeds [123, 256, 512, 1024]; method_attacked missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H2 CoDEx-M, adaptive attack: runs missing (fedavg_clean missing seeds [123, 256, 512, 1024]; fedavg_attacked missing seeds [123, 256, 512, 1024]; method_clean missing seeds [123, 256, 512, 1024]; method_attacked missing seeds [123, 256, 512, 1024])⟧

### H3 — membership leakage

Holm status: **PROVISIONAL (incomplete family)**.

- ⟦PENDING: H3 FB15k-237: runs missing (np missing seeds [123, 256, 512, 1024]; dp_eps4 missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H3 WN18RR: runs missing (np missing seeds [123, 256, 512, 1024]; dp_eps4 missing seeds [123, 256, 512, 1024])⟧
- ⟦PENDING: H3 CoDEx-M: runs missing (np missing seeds [123, 256, 512, 1024]; dp_eps4 missing seeds [123, 256, 512, 1024])⟧

## 5. Privacy accounting and its scope

Each reported ε is the worst-client RDP guarantee (δ = 10⁻⁶) of one trained model, computed from the steps every client actually executed; PLD and PRV values are cross-checks, not the guarantee. The guarantee covers one training triple of one client (zero-out adjacency). It does not cover entities, clients, client sizes, or which relations a client holds.

**The workflow as a whole has no end-to-end DP guarantee.** Stage 3 trained 99 tuning models on the same client data and selected hyperparameters from their validation scores; Stage 4 trains further models on the same data under several configurations and seeds. Neither the selection step nor the release of many models is included in the per-run ε (accounting for it, e.g. with the private-selection results of Papernot & Steinke 2022, is not done here). Per-run ε values must therefore be read as per-model guarantees only.

Largest accounted worst-client ε over all DP runs: 7.330 (Table 6; every run's budget_ok flag is NOT true for every cell - see Table 6).

## 6. Integrity overhead (Table 10)

- FB15k-237, FedAvg non-private, integrity ON (hash_only): integrity 0.042 s per round vs 0.075 s training + aggregation (CPU).
- FB15k-237, FedAvg non-private, integrity OFF: integrity 0.000 s per round vs 0.088 s training + aggregation (CPU).
- FB15k-237, Complete method, integrity ON (hash_only): integrity 0.039 s per round vs 0.404 s training + aggregation (CPU).
- FB15k-237, Complete method, integrity OFF: integrity 0.000 s per round vs 0.491 s training + aggregation (CPU).
- WN18RR, FedAvg non-private, integrity ON (hash_only): integrity 0.051 s per round vs 0.089 s training + aggregation (CPU).
- WN18RR, FedAvg non-private, integrity OFF: integrity 0.000 s per round vs 0.085 s training + aggregation (CPU).
- WN18RR, Complete method, integrity ON (hash_only): integrity 0.052 s per round vs 0.483 s training + aggregation (CPU).
- WN18RR, Complete method, integrity OFF: integrity 0.000 s per round vs 0.466 s training + aggregation (CPU).
- CoDEx-M, FedAvg non-private, integrity ON (hash_only): integrity 0.036 s per round vs 0.077 s training + aggregation (CPU).
- CoDEx-M, FedAvg non-private, integrity OFF: integrity 0.000 s per round vs 0.071 s training + aggregation (CPU).
- CoDEx-M, Complete method, integrity ON (hash_only): integrity 0.036 s per round vs 0.381 s training + aggregation (CPU).
- CoDEx-M, Complete method, integrity OFF: integrity 0.000 s per round vs 0.401 s training + aggregation (CPU).

## 7. Original versus revised results on FB15k-237 (Table 13)

Reported values come from the original manuscript under its own protocol (Phase A provenance); they are listed for transparency and are not comparable with the corrected protocol.

- Reported (original manuscript): Phase 3 MRR = 0.2858
- Reported (original manuscript): epsilon 15.53 (budget 15.0, delta 1e-5) = 15.53
- Reported (original manuscript): Phase 4 MRR 0.009 / Hits@10 0.020 = 0.009/0.02
- Reproduced (L0): test MRR = ⟦PENDING: Reproduced (L0)⟧
- Reproduced (L1 exact old Phase 3): test MRR (corrected protocol) = 0.005 (n=1)
- Reproduced (L2 old partition, corrected trainer): test MRR (corrected protocol) = 0.005 (n=1)
- Reproduced (L3 exact old Phase 4): test MRR (corrected protocol) = 0.009 (n=1)
- Reproduced (L4a legacy mechanism, main partition): test MRR (corrected protocol) = 0.009 (n=1)
- Reproduced (L4b trainer fixed): test MRR (corrected protocol) = 0.005 (n=1)
- Reproduced (L4c formal accounting): test MRR (corrected protocol) = 0.005 (n=1)
- Newly measured: FedAvg non-private: test MRR = 0.005 (n=1)
- Newly measured: DP-FedAvg eps* = 4 (fixed): test MRR = 0.005 (n=1)
- Newly measured: DP-FedAvg eps* = 4 (s*): test MRR = 0.005 (n=1)
- Newly measured: complete method eps* = 4: test MRR = 0.005 (n=1)

## 8. Limitations and deviations recorded by the pipeline

- Stage 5 (sensitivity and extended blocks) is deferred (owner decision B2); no τ or α surface is reported.
- Variant V1 of the trust rule was removed before any result (owner decision B4); benign false-positive rates per client-size third are reported as a diagnostic (Table FPR-by-size).
- Non-private references in Stage 4 use the tuned protocol (early stopping, R_max = 100); an earlier 60-round cap was a cost-model assumption and was removed before any result (RC-1).
- WN18RR partitions at α = 0.1 are a heavily truncated Dirichlet (about 3 % of draws accepted); partition heterogeneity is compared through measured statistics (Table 2).
- GPU runs are not bitwise deterministic; paired comparisons use one environment per dataset and tier (environment lock).
- L0 (the saved legacy model) needs the owner's original checkpoint; ⟦PENDING: L0 not evaluated⟧
- Hyperparameters selected at ε* = 4 are reused at ε* ∈ {1, 2, 8}; this may understate utility at those levels and never changes their ε.


## 9. Reproducibility

Code, configurations, the frozen run manifest and the pre-registered hypotheses are fixed by the git checkpoint and their SHA-256 values (REPRODUCIBILITY_RECORD.json). Every run records its configuration hash, code hash, data hash, partition hash, selection values and environment.

