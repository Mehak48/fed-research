# 01 — Consolidated register of methodological defects (Phase B, item 1)

**Status:** Phase B planning document. Nothing here was implemented, executed or retrained.
**Machine-readable version:** `data/defect_register.csv`. The tables below are generated from the same list by `scripts/phaseB_defect_register.py`, so the two cannot disagree.

## How to read this register

- **Merged sources.**
  - Phase A defects: CR-1…12, MJ-1…14, MN-1…6, OP-1…8.
  - Phase A review of the revision package: G1–G15, MN-7…9.
  - New findings from the Phase B design review: CR-13, MJ-15…21, MN-10…20, OP-9…11.
  - Three more found by the independent review of the Phase B drafts: CR-14, MN-21, MN-22.
- **Contradictions.** X01–X24 are kept as evidence links in the `related` column, not as separate defects; the mapping is at the end.
- **Severity classes** follow master prompt §5: Critical correctness defect, Major experimental deficiency, Minor implementation issue, Optional improvement.
- **"Revision status"** describes the *design* of `fedkge_revision_P1-P4.zip` only.
  - "Addressed by design (unexecuted)" means the code contains a fix. No experiment has run it, and only 27 of 53 tests could be run in Phase A (no PyTorch available).
  - Nothing in this column is evidence of a result.
- **"Decision"** points to `02_design_decisions.md`. **"Phase"** is the phase that implements or verifies the fix (C repair, D datasets, E experiments, F tables and figures, G freeze).
- **Naming:** experiment blocks are named P2.x, T, L, N, DP, R, I, M, X, O (`06`). D1–D18 always refer to *decisions*.

## Counts

| Severity | Total | From Phase A | From the revision review | New in Phase B |
|---|---|---|---|---|
| Critical | 14 | 12 | 0 | 2 (CR-13, CR-14) |
| Major | 32 | 14 | 11 (G1–G4, G6–G10, G14–G15) | 7 (MJ-15…21) |
| Minor | 26 | 6 | 7 (MN-7…9, G5, G11–G13) | 13 (MN-10…22) |
| Optional | 11 | 8 | 0 | 3 (OP-9…11) |
| **Total** | **83** | **40** | **18** | **25** |

## The Phase B findings that matter most

1. **CR-14: the privacy statement as written was false.**
   - The revision declares add/remove-one-triple adjacency but publishes each client's exact size. The size sets the FedAvg weights and the gradient normalisation, and, in design A, also the sampling rate and the number of steps.
   - Neighbouring datasets have different sizes, so an adversary who knows the other triples can read membership off the size.
   - Fix: **zero-out adjacency**. One triple is replaced by a null record with zero gradient, so the size stays the same and stays public.
   - The Poisson-subsampled Gaussian bounds, and therefore every ε value, are unchanged. The guarantee then hides *which* triples a client holds, not *how many*.
2. **CR-13: integrity verification is not in the data path.**
   - In the revision's round loop, the server hashes each update and then re-hashes the same in-memory bytes. Aggregation then uses the in-memory tensors, not the verified bytes.
   - So verification can never fail during training, and an "integrity on/off" comparison would measure hashing time only.
   - Fix: aggregate only tensors deserialised from bytes that passed verification, and test it with injected corruption (block I2).
3. **MJ-15: the planned membership-inference audit compares two different distributions.**
   - FB15k-237's validation and test sets were built by *removing* triples whose entity pairs are directly linked in training (Toutanova & Chen 2015).
   - Using test triples as non-members therefore measures that construction difference as well as memorisation.
   - Fix: an audit pool drawn from each client's own training triples, each candidate included in training with probability ½.
4. **MJ-16 / MJ-17: the DP settings that decide utility were fixed in advance.**
   - The Phase B σ calculation (`data/phaseB_sigma_plan.csv`) shows the per-step noise-to-clip ratio at ε = 4, across the tuning grid q = 0.02–0.10, ranges from 1.3 (YAGO3-10) to 22.7 (WN18RR).
   - The sampling rate, learning rate and number of rounds must therefore be tuned under a pre-registered, validation-only rule, not fixed.
5. **MJ-18 / MJ-19: two sources of selection bias.**
   - The revision selects settings on the same seeds whose test results it reports.
   - It also tunes DP settings but not the non-private reference.
   - Both bias comparisons in the method's favour.
6. **MJ-20: DP-Flames already exists.**
   - DP-Flames (Hu et al., WWW 2023) already proposes triple-level DP for federated KGE, with validation-driven adaptive noise and triple-membership attacks.
   - The "adaptive DP" contribution must be repositioned and defined precisely (decision D12).
7. **MJ-21: YAGO3-10 has documented leakage.**
   - 2,561 of its 5,000 test triples have duplicates in training through two near-duplicate relations (Akrami et al. 2020).
   - This is why Phase B now recommends CoDEx-M as the default third dataset (decision D5).
8. **MN-11: client-level DP is infeasible with 10 clients.**
   - At ε = 4 over 100 rounds, the noise on the averaged update is about 1,540 times the clipping bound on FB15k-237 (`data/phaseB_sigma_plan.json`).
   - The Phase A suggestion to add it as an optional regime is withdrawn.

## Risks (not defects — outcomes the experiments may show and that must then be reported)

| ID | Risk | Why it is plausible | How the plan handles it |
|---|---|---|---|
| RK-1 | DP utility near zero at ε ≤ 4 on WN18RR | WN18RR has ≈ 47 parameters per training triple. Its noise-to-clip ratio at ε = 4 is 9.6–22.7 across the tuning grid (q = 0.10–0.02), versus 1.8–4.4 for FB15k-237 | Report it; no dataset is dropped for low MRR; D10 trigger |
| RK-2 | Trust-based detection loses power under DP noise | Dense noise dominates single-step updates. Per-round updates average it out only partly | H2 is tested under DP; trust without DP (R5) is reported; failure is reported |
| RK-3 | Non-IID and size-related false positives | At α = 0.1, honest clients hold very different relation mixes (median mean JS divergence ≈ 0.51 on FB15k-237, `data/phaseB_partition_feasibility.csv`). Smaller clients have noisier updates under both sampling designs | Benign FPR by client-size third; FPR-calibrated τ (D14); D15 trigger |
| RK-4 | Compute exceeds a free-tier budget | Core estimate 47–393 GPU-h (reduced profile, CoDEx-M; `07_compute_feasibility.md`) | Stage-2 pilot (1–4 GPU-h) measures real costs before committing |
| RK-5 | H3 not testable | A well-regularised TransE may show no measurable membership advantage even without DP | Pre-registered testability rule (03, §13.3) |
| RK-6 | FLTrust and Krum degenerate under DP | FLTrust's server update is noise-free while client updates are noisy, so cosine scores may all be near 0 | Report rejection and fallback rates; no tuning toward a win |
| RK-7 | Non-bit-reproducible GPU runs | `index_add_` and scatter operations are non-deterministic on GPUs | Record the device; keep a paired comparison on one platform where possible |
| RK-8 | Contribution judged incremental | The components are individually standard | Contribution framed as a rigorous, correctly accounted three-dataset evaluation (04, 02-D12) |

## Register
