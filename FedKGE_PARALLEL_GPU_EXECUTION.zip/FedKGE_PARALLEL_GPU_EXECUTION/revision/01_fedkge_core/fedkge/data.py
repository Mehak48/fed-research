"""Dataset loading, preprocessing, validation and the Phase 1 artifact.

Supported: FB15k-237, WN18RR, CoDEx-M (Phase B decision D5), YAGO3-10 (optional), and 'synthetic' (offline, for
tests only; config validation rejects it in the final tier).

Sources (Phase C):
  local_files (default): label triples in <data_dir>/<dataset>/{train,valid,test}.txt, fetched beforehand by
      scripts/prepare_data.py behind an explicit licence confirmation (G12) and recorded with SHA-256 checksums in
      <data_dir>/<dataset>/source_manifest.json. Vocabulary construction replicates PyKEEN exactly: entity and
      relation ids are positions in the SORTED label sets of the TRAINING split; validation/test triples with an
      entity or relation unseen in training are dropped and counted. (This keeps ids identical to the legacy runs,
      which used PyKEEN, so the saved legacy checkpoint can be re-evaluated - block L0.)
  pykeen: PyKEEN's own downloader (needs network access to the original hosts; used on Colab if preferred).

Split conventions (fixed per dataset, independent of the run seed):
  train       official training split
  vsel        80% of the official validation split  -> early stopping / model selection
  vroot       20% of the official validation split  -> FLTrust server root data only
  test        official test split                   -> evaluated ONCE per run, on the selected checkpoint
  es_subset   fixed subset of vsel (size from config) used for per-round early stopping
Filtered evaluation uses train + valid(full) + test as the known-true set (standard protocol).
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional

import numpy as np

from .io import IntegrityError, read_json, sha256_arrays, sha256_file, write_json

PYKEEN_CLASSES = {"fb15k237": "FB15k237", "wn18rr": "WN18RR", "yago310": "YAGO310", "codex_m": "CoDExMedium"}


@dataclass
class KGData:
    name: str
    num_entities: int
    num_relations: int
    train: np.ndarray          # (N,3) int64 [h, r, t]
    valid: np.ndarray          # full official validation
    vsel: np.ndarray
    vroot: np.ndarray
    test: np.ndarray
    es_subset: np.ndarray
    content_hash: str

    @property
    def all_true(self) -> np.ndarray:
        return np.vstack([self.train, self.valid, self.test])


# --------------------------------------------------------------------------------------------- loading
def _load_pykeen(name: str):
    try:
        import pykeen.datasets as pd_
    except ImportError as e:
        raise ImportError("pykeen is required for real datasets: pip install 'pykeen>=1.10,<2'") from e
    ds = getattr(pd_, PYKEEN_CLASSES[name])()
    tr = ds.training.mapped_triples.numpy().astype(np.int64)
    va = ds.validation.mapped_triples.numpy().astype(np.int64)
    te = ds.testing.mapped_triples.numpy().astype(np.int64)
    ent = [None] * ds.training.num_entities
    for k, v in ds.training.entity_to_id.items():
        ent[v] = k
    rel = [None] * ds.training.num_relations
    for k, v in ds.training.relation_to_id.items():
        rel[v] = k
    return tr, va, te, ent, rel


def read_label_triples(path: Path) -> np.ndarray:
    """Tab-separated (h, r, t) label triples; blank lines ignored; any malformed line raises."""
    rows = []
    with open(path, encoding="utf-8") as f:
        for ln, line in enumerate(f, 1):
            line = line.rstrip("\n").rstrip("\r")
            if not line.strip():
                continue
            parts = line.split("\t")
            if len(parts) != 3 or any(p == "" for p in parts):
                raise IntegrityError(f"{path}:{ln}: expected 3 tab-separated fields, got {len(parts)}")
            rows.append(parts)
    if not rows:
        raise IntegrityError(f"{path}: no triples")
    return np.array(rows, dtype=object)


def map_like_pykeen(tr_l: np.ndarray, va_l: np.ndarray, te_l: np.ndarray):
    """PyKEEN-identical id mapping (sorted training labels) + removal of eval triples with unseen labels."""
    ent = sorted(set(tr_l[:, 0].tolist()) | set(tr_l[:, 2].tolist()))
    rel = sorted(set(tr_l[:, 1].tolist()))
    e2i, r2i = {e: i for i, e in enumerate(ent)}, {r: i for i, r in enumerate(rel)}

    def mp(a, drop):
        keep = [(h in e2i and r in r2i and t in e2i) for h, r, t in a.tolist()]
        kept = a[np.array(keep, dtype=bool)]
        if not drop and len(kept) != len(a):
            raise IntegrityError("training split cannot contain unseen labels")
        out = np.array([[e2i[h], r2i[r], e2i[t]] for h, r, t in kept.tolist()], dtype=np.int64).reshape(-1, 3)
        return out, int(len(a) - len(kept))
    tr, _ = mp(tr_l, False)
    va, dva = mp(va_l, True)
    te, dte = mp(te_l, True)
    return tr, va, te, ent, rel, {"valid_dropped_unseen": dva, "test_dropped_unseen": dte}


def _load_local(name: str, data_dir: Path):
    d = Path(data_dir) / name
    files = {k: d / f"{k}.txt" for k in ("train", "valid", "test")}
    missing = [str(p) for p in files.values() if not p.exists()]
    if missing:
        raise IntegrityError(f"dataset files missing: {missing}. Fetch them with scripts/prepare_data.py "
                             f"--dataset {name} --i-confirm-licence (after reading the licence it prints), or place "
                             "the official files there yourself.")
    man_p = d / "source_manifest.json"
    man = read_json(man_p) if man_p.exists() else {"note": "no source manifest (files placed manually)"}
    for k, p in files.items():
        exp = (man.get("files_sha256") or {}).get(f"{k}.txt")
        if exp is not None and sha256_file(p) != exp:
            raise IntegrityError(f"{p} differs from the checksum recorded when it was fetched")
    tr_l, va_l, te_l = (read_label_triples(files[k]) for k in ("train", "valid", "test"))
    raw = {"train": len(tr_l), "valid": len(va_l), "test": len(te_l),
           "entities_all_splits": len(set(np.concatenate([tr_l[:, 0], tr_l[:, 2], va_l[:, 0], va_l[:, 2], te_l[:, 0], te_l[:, 2]]).tolist())),
           "relations_all_splits": len(set(np.concatenate([tr_l[:, 1], va_l[:, 1], te_l[:, 1]]).tolist()))}
    tr, va, te, ent, rel, drops = map_like_pykeen(tr_l, va_l, te_l)
    return tr, va, te, ent, rel, {"raw_counts": raw, **drops, "source_manifest": man,
                                  "files_sha256": {f"{k}.txt": sha256_file(p) for k, p in files.items()}}


def make_synthetic(n_entities: int = 300, n_relations: int = 8, n_triples: int = 6000, dim: int = 8,
                   seed: int = 0):
    """TransE-structured synthetic KG (learnable), used only by unit tests / offline smoke checks."""
    rng = np.random.default_rng(seed)
    E = rng.normal(size=(n_entities, dim)); E /= np.linalg.norm(E, axis=1, keepdims=True)
    Rv = rng.normal(scale=0.5, size=(n_relations, dim))
    rel_p = rng.dirichlet(np.ones(n_relations) * 0.7)
    trip = set()
    while len(trip) < n_triples:
        h = int(rng.integers(n_entities)); r = int(rng.choice(n_relations, p=rel_p))
        target = E[h] + Rv[r]
        d = np.linalg.norm(E - target, axis=1)
        cand = np.argsort(d)[:3]
        t = int(rng.choice(cand))
        if t != h:
            trip.add((h, r, t))
    arr = np.array(sorted(trip), dtype=np.int64)
    arr = arr[rng.permutation(len(arr))]
    n = len(arr); ntr = int(0.8 * n); nva = int(0.1 * n)
    tr, va, te = arr[:ntr], arr[ntr:ntr + nva], arr[ntr + nva:]
    seen_e = set(tr[:, 0]) | set(tr[:, 2]); seen_r = set(tr[:, 1])
    keep = lambda a: a[[x[0] in seen_e and x[2] in seen_e and x[1] in seen_r for x in a]]
    return tr, keep(va), keep(te), [f"e{i}" for i in range(n_entities)], [f"r{i}" for i in range(n_relations)]


def make_synthetic_sized(n_entities: int, n_relations: int, n_train: int, n_valid: int, n_test: int,
                         seed: int = 0, zipf_rel: float = 1.1, zipf_ent: float = 0.8):
    """SIZE-MATCHED synthetic KG for runtime / memory / storage measurement only (Phase C pilot without benchmark
    data). Relation frequencies and entity degrees are Zipf-like; triples are unique; every valid/test entity and
    relation occurs in training. Its link-prediction metrics are meaningless and are never reported."""
    if n_entities < 2 or n_relations < 1 or min(n_valid, n_test) < 1:
        raise ValueError("make_synthetic_sized needs >= 2 entities, >= 1 relation and non-empty valid/test splits")
    if n_train < (n_entities + 1) // 2 + n_relations:
        raise ValueError("n_train is too small to cover every entity and relation")
    if n_train + n_valid + n_test > 0.5 * n_entities * (n_entities - 1) * n_relations:
        raise ValueError("too many triples requested for this many entities and relations")
    rng = np.random.default_rng(seed)
    pr = 1.0 / np.arange(1, n_relations + 1) ** zipf_rel; pr /= pr.sum()
    pe = 1.0 / np.arange(1, n_entities + 1) ** zipf_ent; pe /= pe.sum()
    perm_e = rng.permutation(n_entities)                   # which entity ids are frequent
    seen = set()

    def add(dst, h, r, t, limit):
        for x in zip(h.tolist(), r.tolist(), t.tolist()):
            if len(dst) >= limit:
                return
            if x[0] != x[2] and x not in seen:
                seen.add(x); dst.append(x)

    def draw(k):
        return (perm_e[rng.choice(n_entities, k, p=pe)], rng.choice(n_relations, k, p=pr),
                perm_e[rng.choice(n_entities, k, p=pe)])

    # 1) coverage by construction: pair the entities of a random order (every entity occurs in training), then
    #    one triple for every relation the pairs did not use (every relation occurs in training)
    order = rng.permutation(n_entities)
    if len(order) % 2:
        order = np.append(order, order[0])
    train = []
    r0 = rng.choice(n_relations, len(order) // 2, p=pr)
    add(train, order[0::2], r0, order[1::2], n_train)
    for r in np.setdiff1d(np.arange(n_relations), r0).tolist():
        before = len(train)
        while len(train) == before:
            h, _, t = draw(1)
            add(train, h, np.array([r]), t, n_train)
    # 2) fill training, then valid and test, with unique Zipf-distributed triples (no overlap between splits)
    while len(train) < n_train:
        add(train, *draw(int((n_train - len(train)) * 1.1) + 100), n_train)
    evals = []
    while len(evals) < n_valid + n_test:
        add(evals, *draw(int((n_valid + n_test - len(evals)) * 1.1) + 100), n_valid + n_test)
    tr = np.array(train, dtype=np.int64)[rng.permutation(n_train)]
    ev = np.array(evals, dtype=np.int64)
    return tr, ev[:n_valid], ev[n_valid:], [f"e{i}" for i in range(n_entities)], [f"r{i}" for i in range(n_relations)]


def _subset(tr, va, te, ent, rel, n_train: int, n_eval: int, seed: int):
    """Smoke-tier subset: sample train triples, keep eval triples whose entities/relations are covered,
    re-index compactly. Never used in the final tier."""
    rng = np.random.default_rng(seed)
    tr = tr[rng.choice(len(tr), size=min(n_train, len(tr)), replace=False)]
    ents = np.unique(np.concatenate([tr[:, 0], tr[:, 2]])); rels = np.unique(tr[:, 1])
    emap = -np.ones(len(ent), dtype=np.int64); emap[ents] = np.arange(len(ents))
    rmap = -np.ones(len(rel), dtype=np.int64); rmap[rels] = np.arange(len(rels))

    def remap(a, cap=None):
        a = a[(emap[a[:, 0]] >= 0) & (emap[a[:, 2]] >= 0) & (rmap[a[:, 1]] >= 0)]
        if cap is not None:                       # only the evaluation splits are capped
            a = a[rng.permutation(len(a))[:cap]]
        return np.stack([emap[a[:, 0]], rmap[a[:, 1]], emap[a[:, 2]]], 1)

    # Phase C fix (defect PC-1): the original capped the TRAINING split at n_eval too (3000 -> 300 triples)
    return (remap(tr), remap(va, n_eval), remap(te, n_eval), [ent[i] for i in ents], [rel[i] for i in rels])


# --------------------------------------------------------------------------------------------- validation
def _as_set(a: np.ndarray):
    return set(map(tuple, a.tolist()))


def validate_splits(tr, va, te, n_ent: int, n_rel: int) -> Dict:
    rep: Dict = {"errors": [], "warnings": []}
    for nm, a in (("train", tr), ("valid", va), ("test", te)):
        if a.ndim != 2 or a.shape[1] != 3:
            rep["errors"].append(f"{nm}: shape {a.shape} is not (N,3)")
            continue
        if len(a) == 0:
            rep["errors"].append(f"{nm}: empty split")
            continue
        if a[:, [0, 2]].min() < 0 or a[:, [0, 2]].max() >= n_ent:
            rep["errors"].append(f"{nm}: entity id out of range")
        if a[:, 1].min() < 0 or a[:, 1].max() >= n_rel:
            rep["errors"].append(f"{nm}: relation id out of range")
        dup = len(a) - len(_as_set(a))
        rep[f"{nm}_duplicates"] = int(dup)
        if dup:
            rep["warnings"].append(f"{nm}: {dup} duplicate triples")
    S_tr, S_va, S_te = _as_set(tr), _as_set(va), _as_set(te)
    rep["train_test_overlap"] = len(S_tr & S_te)
    rep["train_valid_overlap"] = len(S_tr & S_va)
    rep["valid_test_overlap"] = len(S_va & S_te)
    for k in ("train_test_overlap", "train_valid_overlap", "valid_test_overlap"):
        if rep[k]:
            rep["errors"].append(f"leakage: {k} = {rep[k]} identical triples")
    seen = set(tr[:, 0].tolist()) | set(tr[:, 2].tolist())
    rep["test_triples_with_unseen_entity"] = int(sum(1 for h, _, t in te.tolist() if h not in seen or t not in seen))
    rep["valid_triples_with_unseen_entity"] = int(sum(1 for h, _, t in va.tolist() if h not in seen or t not in seen))
    # inverse-leakage statistic (reported, not an error): test (h,r,t) with some (t,r',h) in train
    rev = set(zip(tr[:, 2].tolist(), tr[:, 0].tolist()))
    rep["test_inverse_pair_in_train_frac"] = float(np.mean([(h, t) in rev for h, _, t in te.tolist()]))
    rep["n_train"], rep["n_valid"], rep["n_test"] = len(tr), len(va), len(te)
    rep["num_entities"], rep["num_relations"] = n_ent, n_rel
    rep["relations_in_train"] = int(len(np.unique(tr[:, 1])))
    rep["ok"] = not rep["errors"]
    return rep


# --------------------------------------------------------------------------------------------- artifact
def build_artifact(ds_cfg: Dict, out_dir: Path, subset: Optional[Dict] = None,
                   data_dir: Optional[Path] = None) -> Dict:
    """Phase 1: load, (subset for smoke), split vsel/vroot, validate, save artifact + manifest."""
    name = ds_cfg["name"]
    load_info: Dict = {}
    source = ds_cfg.get("source", "local_files")
    if name == "synthetic":
        tr, va, te, ent, rel = make_synthetic(**ds_cfg.get("synthetic", {}))
        source = "synthetic"
    elif name.startswith("synthetic_"):
        tr, va, te, ent, rel = make_synthetic_sized(**ds_cfg["synthetic_sized"])
        source = "synthetic_size_matched (timing only; not benchmark data)"
    elif source == "local_files":
        if data_dir is None:
            raise IntegrityError(f"{name}: data_dir is required for source=local_files")
        tr, va, te, ent, rel, load_info = _load_local(name, data_dir)
    elif source == "pykeen":
        tr, va, te, ent, rel = _load_pykeen(name)
    else:
        raise IntegrityError(f"unknown dataset source {source}")
    source_counts = {"train": len(tr), "valid": len(va), "test": len(te), "entities": len(ent), "relations": len(rel)}
    if subset:
        tr, va, te, ent, rel = _subset(tr, va, te, ent, rel, subset["n_train"], subset["n_eval"], subset.get("seed", 0))
    n_ent, n_rel = len(ent), len(rel)
    rep = validate_splits(tr, va, te, n_ent, n_rel)
    if not rep["ok"]:
        raise IntegrityError(f"dataset {name} failed validation: {rep['errors']}")

    split_rng = np.random.default_rng(int(ds_cfg.get("split_seed", 0)))
    perm = split_rng.permutation(len(va))
    n_root = int(round(ds_cfg.get("vroot_fraction", 0.2) * len(va)))
    vroot, vsel = va[perm[:n_root]], va[perm[n_root:]]
    es_n = min(int(ds_cfg.get("es_subset_size", 2000)), len(vsel))
    es_subset = vsel[split_rng.permutation(len(vsel))[:es_n]]

    out_dir.mkdir(parents=True, exist_ok=True)
    arrays = dict(train=tr, valid=va, vsel=vsel, vroot=vroot, test=te, es_subset=es_subset)
    np.savez_compressed(out_dir / "triples.npz", **arrays)
    write_json(out_dir / "labels.json", {"entities": ent, "relations": rel})
    content_hash = sha256_arrays(*(arrays[k] for k in sorted(arrays)), np.array([n_ent, n_rel]))
    card = {"dataset": name, "num_entities": n_ent, "num_relations": n_rel,
            **{f"n_{k}": int(len(v)) for k, v in arrays.items()},
            "source_counts_before_subset": source_counts, "subset": subset,
            "split_seed": int(ds_cfg.get("split_seed", 0)), "vroot_fraction": ds_cfg.get("vroot_fraction", 0.2),
            "source": ("pykeen." + PYKEEN_CLASSES[name]) if source == "pykeen" else source,
            "load_info": load_info,
            "licence": ds_cfg.get("licence"), "citation": ds_cfg.get("citation"),
            "relations_with_lt10_train_triples": int((np.bincount(tr[:, 1], minlength=n_rel) < 10).sum()),
            "note": ("Vocabulary from the training split (PyKEEN-identical sorted-label ids); validation/test triples "
                     "with labels unseen in training are dropped and counted in load_info (counts above are "
                     "post-loader). The benchmark splits are otherwise used unchanged.")}
    write_json(out_dir / "dataset_card.json", card)
    write_json(out_dir / "validation_report.json", rep)
    files = {f: sha256_file(out_dir / f) for f in ("triples.npz", "labels.json", "dataset_card.json",
                                                   "validation_report.json")}
    manifest = {"artifact": "p1_dataset", "dataset": name, "content_hash": content_hash, "files": files}
    from .io import code_hash, environment
    manifest["code_hash"] = code_hash()
    manifest["environment"] = environment()
    write_json(out_dir / "manifest.json", manifest)
    return manifest


def load_artifact(p1_dir: Path, expected_hash: Optional[str] = None) -> KGData:
    from .io import verify_artifact
    man = verify_artifact(Path(p1_dir) / "manifest.json", expected_hash)
    card = read_json(Path(p1_dir) / "dataset_card.json")
    z = np.load(Path(p1_dir) / "triples.npz")
    return KGData(name=card["dataset"], num_entities=card["num_entities"], num_relations=card["num_relations"],
                  train=z["train"], valid=z["valid"], vsel=z["vsel"], vroot=z["vroot"], test=z["test"],
                  es_subset=z["es_subset"], content_hash=man["content_hash"])


# --------------------------------------------------------------------------------------------- OLAP / descriptive
def gini(x: np.ndarray) -> float:
    x = np.sort(np.asarray(x, dtype=float))
    if x.sum() == 0:
        return 0.0
    n = len(x)
    return float((2 * np.arange(1, n + 1) - n - 1).dot(x) / (n * x.sum()))


def olap_summary(train: np.ndarray, n_ent: int, n_rel: int) -> Dict:
    """Descriptive OLAP-style roll-ups kept from the original Phase 1/2 (head x relation x tail cube).
    Each (h,r,t) cell has count 1 (triples are unique); measures are degree-normalised weight and IDF."""
    import scipy.stats as st
    h, r, t = train[:, 0], train[:, 1], train[:, 2]
    out_deg = np.bincount(h, minlength=n_ent); in_deg = np.bincount(t, minlength=n_ent)
    deg = out_deg + in_deg
    rel_cnt = np.bincount(r, minlength=n_rel)
    weight = 1.0 / np.sqrt(np.maximum(deg[h], 1) * np.maximum(deg[t], 1))
    idf = np.log(len(train) / np.maximum(rel_cnt, 1))
    srt = np.sort(rel_cnt)[::-1]
    return {
        "n_cells": int(len(train)),
        "cube_sparsity_pct": float((1 - len(train) / (float(n_ent) ** 2 * n_rel)) * 100),
        "degree_skewness": float(st.skew(deg)), "degree_kurtosis": float(st.kurtosis(deg, fisher=False)),
        "in_degree_skewness": float(st.skew(in_deg)), "out_degree_skewness": float(st.skew(out_deg)),
        "weight_skewness": float(st.skew(weight)), "weight_kurtosis": float(st.kurtosis(weight, fisher=False)),
        "relation_count_gini": gini(rel_cnt), "entity_degree_gini": gini(deg),
        "top1_relation_share_pct": float(srt[:1].sum() / len(train) * 100),
        "top25_relation_share_pct": float(srt[:25].sum() / len(train) * 100),
        "hub_top1pct_degree_share_pct": float(np.sort(deg)[::-1][:max(1, n_ent // 100)].sum() / deg.sum() * 100),
        "idf_min": float(idf[rel_cnt > 0].min()), "idf_max": float(idf[rel_cnt > 0].max()),
        "relation_counts": rel_cnt.tolist(),
    }
