"""Derive the per-run GPU-hour table used by the parallel planner (parallel/cost_table_T4_upper.csv).

Same source and method as provenance/deadline_cost_model/compute_costs.py (DEADLINE_PLAN.md):
  * the owner's measured T4 pilot extrapolation (pilot_extrapolation_20261104T164854Z.csv inside
    provenance/phaseC_gpu_pilot_session_20261104/colab_pilot_results_20261104T165553Z_pilot_done.zip; run 2 = slower);
  * non-private Stage-4 references raised from 60 to 100 rounds by RC-1 are scaled by 100/60;
  * legacy L1-L4: <= 0.18 GPU-h per run (the measured DP-run maximum).
These are UPPER BOUNDS from 2-round measurements on a Tesla T4, not measurements of complete runs.

  python -I build_cost_table.py <pilot_zip> <out.csv>
"""
import io
import sys
import zipfile

import pandas as pd

zp, out = sys.argv[1:3]
with zipfile.ZipFile(zp) as z:
    name = next(n for n in z.namelist() if n.endswith("pilot_extrapolation_20261104T164854Z.csv"))
    x = pd.read_csv(io.BytesIO(z.read(name)))
x["hours_now"] = x["hours_upper"] * x["rounds"].map(lambda r: 100 / 60 if r == 60 else 1.0)
x.loc[x.plan == "tune", "hours_now"] = x.loc[x.plan == "tune", "hours_upper"]
rows = []
for (b, ds), g in x[x.plan == "tune"].groupby(["block", "dataset"]):
    rows.append({"plan": "tune", "block": b, "dataset": ds, "hours_per_run": float(g["hours_now"].max()),
                 "basis": "max over the block's pilot rows"})
for (b, ds), g in x[(x.plan == "confirm_reduced") & (x.stage == 4)].groupby(["block", "dataset"]):
    rows.append({"plan": "main", "block": b, "dataset": ds, "hours_per_run": float(g["hours_now"].mean()),
                 "basis": "mean over the block's pilot rows (as compute_costs.py)"})
for b in ("R3_legacy", "R3_fixed", "R4_legacy", "L1_legacy", "L2_trainer_fixed", "L3_accounting_fixed"):
    rows.append({"plan": "legacy", "block": b, "dataset": "fb15k237", "hours_per_run": 0.18,
                 "basis": "measured DP-run maximum (pilot_plan.md section 5)"})
d = pd.DataFrame(rows)
d["hours_per_run"] = d["hours_per_run"].round(4)
d.to_csv(out, index=False)
print(d.to_string(index=False))
