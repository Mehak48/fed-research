#!/usr/bin/env python3
"""Phase A artifact inventory: one row per supplied file (size, SHA-256, duplicates) + audit metadata.

Usage: python3 -I phaseA_inventory.py --out <csv> --root LABEL=PATH [--root LABEL=PATH ...]
Metadata (purpose / status / dependencies / reproducible / provenance class) comes from the RULES table below,
written during the Phase A reading of every file; the first matching rule wins. Rows with no rule are marked
'UNCLASSIFIED' so nothing is silently dropped.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import os
import re
from pathlib import Path

# provenance classes used in the audit
M, D, F, H, S, X, U, NA = ("Measured", "Descriptive (computed from data)", "Formula-derived", "Hardcoded/manual",
                          "Simulated (no model trained)", "Mixed", "Unverified", "Not applicable")

# (regex on 'LABEL/relative/path', purpose, status, depends_on, reproducible, provenance_class)
RULES = [
    # ------------------------------------------------------------------ File 5 / files (original code)
    (r"FILE5/files/phase1\.ipynb$", "Phase 1: load FB15k-237 (PyKEEN), OLAP-style cube statistics, figs 1-6",
     "original code; NO outputs stored in this copy", "pykeen FB15k237 download; numpy/pandas/scipy/matplotlib/plotly",
     "likely (deterministic statistics); not re-run in Phase A", D),
    (r"FILE5/files/phase2\.ipynb$", "Phase 2: global graph heterogeneity statistics; 5-client partition PREVIEW "
     "(relations sorted by frequency, then np.array_split) - this preview is NOT the partition trained later",
     "original code; NO outputs stored in this copy", "phase1_results.json; pykeen", "likely (deterministic)", D),
    (r"FILE5/files/phase3_updated\.ipynb$", "Phase 3: FedAvg TransE, 5 clients = relation-ID chunks, 50 rounds x 3 local "
     "epochs, 1 negative per triple (neg_samples=64 unused), Adam 1e-3, grad clip 1.0; eval = 300 random test triples, "
     "tail-only, optimistic ties, re-drawn every round, last round reported", "executed (outputs stored); produced "
     "phase3_results.json and global_transe_final.pt", "pykeen; torch (GPU); phase1/phase2 JSON not required",
     "approximately (seeded; GPU + global-RNG evaluation subsample)", M),
    (r"FILE5/files/phase4_ready \(1\)\.ipynb$", "Phase 4: Opacus DP-SGD per client (sigma=1 fixed, C=1, B=256 Poisson, "
     "1 local epoch/round, NO entity normalisation, buggy negatives), FedAvg, stop when sum of mean per-round eps > 15; "
     "eval = 150 random tail queries", "executed: 16/20 rounds, random init (warm-start checkpoint NOT found); "
     "produced phase4_results.json", "phase3_results.json; opacus 1.6.0; optional P3 checkpoint (warm start)",
     "approximately", X),
    (r"FILE5/files/phase5 \(1\)\.ipynb$", "Phase 5 'evaluation & ablation': hypotheses, centralised reference, "
     "schedule ablation, privacy-utility surface", "executed; CENTRALISED_MRR=0.0940 hard-coded; ablation and surface "
     "are formulas", "phase1-4 JSON", "yes (deterministic formulas) - not evidence", F),
    (r"FILE5/files/phase6_h2fixed_\(1\)\.ipynb$", "Phase 6: SHA-256 'Qm' pseudo-CID store, loss-based trust scorer, "
     "attack 'simulations'", "executed; no KGE training; random tensors stored; MRRs and attack metrics are formulas",
     "phase1-5 JSON (stub fallbacks if missing)", "yes (formulas) - not evidence", S),
    (r"FILE5/files/phase7 \(1\)\.ipynb$", "Phase 7: baselines as fixed multiples of P3/P4 MRR, simulated tau ablation, "
     "synthetic eps* optimum, statistics over rounds of one run", "executed; values formula-derived/hard-coded",
     "phase1-6 JSON (stub fallbacks)", "yes (formulas) - not evidence", F),
    (r"FILE5/files/phase8 \(1\)\.ipynb$", "Phase 8: final dashboards/tables aggregating P1-P7; synthetic 3D surfaces; "
     "literature constants", "executed", "phase1-7 JSON (stub fallbacks)", "yes (formulas) - not evidence", F),
    # ------------------------------------------------------------------ File 5 / complete (legacy results)
    (r"complete/phase1_results\.json$", "P1 dataset statistics (14,505 ent / 237 rel / 272,115 train)",
     "legacy result; unverified until re-run", "files/phase1.ipynb", "likely", D),
    (r"complete/phase2_results\.json$", "P2 global heterogeneity metrics + partition_preview (Client-0 74.26% = "
     "frequency-sorted PREVIEW, never trained)", "legacy; identical to uploads/phase2_results.json except timestamp",
     "files/phase2.ipynb", "likely", D),
    (r"complete/phase3_results\.json$", "P3 non-private FedAvg run: final (round-50) MRR 0.2858 / H@10 0.4533, "
     "per-round history (peak 0.3073 @49), client sizes 83,830/56,322/41,261/50,033/40,669",
     "legacy MEASURED, single seed, legacy evaluation protocol", "files/phase3_updated.ipynb",
     "approximately", M),
    (r"complete/phase4_results\.json$", "P4 DP run: 16 rounds, MRR 0.009 (round 16), eps 15.5304 = naive sum of "
     "client-mean per-round eps", "legacy: MRR MEASURED (150-query legacy protocol); eps INVALID as a guarantee "
     "(see phaseA_epsilon_check.json)", "files/phase4_ready (1).ipynb", "approximately", X),
    (r"complete/phase5_results\.json$", "P5 hypotheses (304.04% = 0.2858/0.094), inference resistance 8.76 (formula), "
     "schedule ablation (formula)", "legacy; NOT evidence", "files/phase5 (1).ipynb", "formulas only", F),
    (r"complete/phase6_results\.json$", "P6 trust 'training' (MRR = 0.009*(1+0.12*round)), pseudo-CIDs, attack table "
     "(100% / 82.85% / 30.56%)", "legacy; NOT evidence", "files/phase6_h2fixed_(1).ipynb", "formulas only", S),
    (r"complete/phase7_results\.json$", "P7 baselines (FedAvg=0.92xP3, Krum=0.78xP3, StdDP=1.35xP4), overheads "
     "(2.3 ms, 0.8 ms hard-coded), eps*=9.28 (synthetic), stats over rounds", "legacy; NOT evidence",
     "files/phase7 (1).ipynb", "formulas only", F),
    (r"complete/phase8_results\.json$", "P8 final summary ('all_hypotheses_met': true)", "legacy; NOT evidence",
     "files/phase8 (1).ipynb + P1-P7 JSON", "formulas only", X),
    (r"complete/ablation_results\.csv$", "P5 schedule ablation table (paper Table III)", "legacy; formula "
     "(mrr = P4_MRR*(1+0.05(2-s)/2)*(r/T)^0.3; eps = s*0.45*r - eps grows WITH noise)", "phase5 (1).ipynb", "formulas", F),
    (r"complete/trust_threshold_ablation\.csv$", "P7 trust threshold ablation (paper Table V)", "legacy; simulated "
     "(hard-coded base losses; poisoned loss = 2x -> excluded at every tau by construction)", "phase7 (1).ipynb",
     "formulas", S),
    (r"complete/ieee_comparison_table\.csv$", "P7 literature comparison table", "legacy; prior-work values are typed "
     "constants with no source in any artifact; 'This Work' row pairs the NON-private MRR with ADP/Trust/IPFS",
     "phase7 (1).ipynb", "n/a", H),
    (r"complete/ieee_final_comparison_table\.csv$", "P8 literature comparison table (paper Table II)",
     "legacy; same issues; Hoang et al. IPFS flag differs from the P7 table", "phase8 (1).ipynb", "n/a", H),
    (r"complete/pipeline_summary\.csv$", "P8 cross-phase summary (paper Table I)", "legacy; contains false "
     "'Warm-start from P3' (log says checkpoint NOT found), '20.0 rounds' (16 executed), '304% of centralised'",
     "phase8 (1).ipynb", "n/a", X),
    (r"complete/entity_features\.csv$", "per-entity degree features (Phase 1 column layout)", "legacy descriptive",
     "phase1.ipynb", "likely", D),
    (r"complete/rollup_by_relation\.csv$", "per-relation counts/IDF (used in Phase A to re-derive both partitions)",
     "legacy descriptive; consistent with phase2/phase3 JSON", "phase1/phase2", "likely", D),
    (r"complete/global_transe_final\.pt$", "Phase 3 final global model state_dict (ent 14505x100, rel 237x100, saved "
     "from cuda:0)", "legacy MEASURED artifact; can be re-evaluated with the corrected protocol", "phase3_updated.ipynb",
     "yes (file present)", M),
    (r"complete/(fig[123]_|fig4_3d_cube_scatter|fig5_3d_surface_plot)", "Phase 1 dataset figures", "legacy; descriptive",
     "phase1.ipynb", "likely", D),
    (r"complete/fig6_interactive_3d_cube\.html$", "Phase 1 interactive cube (plotly)", "legacy; descriptive",
     "phase1.ipynb", "likely", D),
    (r"complete/fig(4_degree|5_top25|6_lorenz|7_3d_noniid|8_3d_hetero)", "Phase 2 global-graph figures (NOT per-client)",
     "legacy; descriptive", "phase2.ipynb", "likely", D),
    (r"complete/fig(9|10|11)_", "Phase 3 training curves / client-loss surface", "legacy; measured (single run)",
     "phase3_updated.ipynb", "approximately", M),
    (r"complete/fig12_", "Phase 4 DP training dashboard", "legacy; measured MRR/loss, eps axis = naive sum",
     "phase4_ready (1).ipynb", "approximately", X),
    (r"complete/fig13_", "Phase 4 3D sigma x eps_cum x MRR trajectory (16 points, sigma constant)",
     "legacy; eps axis invalid", "phase4_ready (1).ipynb", "approximately", X),
    (r"complete/fig14_", "Phase 4 schedule comparison (analytic curves; title says 2.0->0.5, plotted 1.0->1.0 flat)",
     "legacy; analytic, mislabeled", "phase4_ready (1).ipynb", "yes", F),
    (r"complete/fig6_3d_kg_cube", "Phase 4 copy of cube scatter", "legacy; descriptive", "phase4_ready (1).ipynb", "likely", D),
    (r"complete/fig1[5-9]_", "Phase 5 dashboards/surfaces/Pareto (centralised 0.094 constant; formula surface and curves)",
     "legacy; NOT evidence", "phase5 (1).ipynb", "formulas", F),
    (r"complete/fig2[0-6]_", "Phase 6 security figures (simulated losses, formula surfaces, pseudo-CID sizes)",
     "legacy; NOT evidence (fig21 listed in phase6_results.json but absent from complete/)", "phase6_h2fixed_(1).ipynb",
     "formulas", S),
    (r"complete/fig(2[7-9]|3[0-2])_", "Phase 7 figures (formula baselines/surfaces, simulated trust)",
     "legacy; NOT evidence", "phase7 (1).ipynb", "formulas", F),
    (r"complete/fig3[3-8]_", "Phase 8 final dashboards/surfaces", "legacy; NOT evidence", "phase8 (1).ipynb", "formulas", F),
    # ------------------------------------------------------------------ File 2 (revision package, assumed)
    (r"FILE2/fedkge_revision/01_fedkge_core/fedkge/accountant\.py$", "RDP accountant (dp_accounting), PLD cross-check, "
     "sigma calibration, deterministic schedules, legacy replica", "implemented; 9 unit tests PASS in Phase A",
     "numpy, dp-accounting", "yes", NA),
    (r"FILE2/fedkge_revision/01_fedkge_core/fedkge/dp\.py$", "custom per-example clipped DP-SGD for TransE "
     "(dense noise, Adam)", "implemented; tests need torch (not run in Phase A)", "torch", "untested here", NA),
    (r"FILE2/fedkge_revision/01_fedkge_core/fedkge/federated\.py$", "round-loop orchestrator: training, attacks, "
     "integrity, aggregation, accountant, early stopping on V_sel, final test once", "implemented; not executed in "
     "Phase A (torch)", "torch + all modules", "untested here", NA),
    (r"FILE2/fedkge_revision/01_fedkge_core/fedkge/(trust|aggregators|attacks|integrity|mia)\.py$", "later-phase modules "
     "(update-based MAD trust, FedAvg/Krum/TrimmedMean/Median/FLTrust, 7 attacks, sha256 store, score MIA)",
     "implemented interfaces; NO experiment matrix or tests for them in the delivery", "torch", "untested", NA),
    (r"FILE2/fedkge_revision/01_fedkge_core/", "fedkge core module", "implemented", "see module", "see tests", NA),
    (r"FILE2/fedkge_revision/0[2-5]_phase\d_[a-z0-9]+/.*\.ipynb$", "revision notebook (Colab driver)",
     "NO outputs stored - never executed in the supplied copy", "fedkge package, Drive", "not run", NA),
    (r"FILE2/fedkge_revision/10_configs/", "revision configuration (base/datasets/tiers/matrices/selection rules)",
     "present; P5-P8 matrices absent", "-", "-", NA),
    (r"FILE2/fedkge_revision/11_experiment_schemas/", "JSON schema for a P1-P4 output", "present", "-", "-", NA),
    (r"FILE2/fedkge_revision/12_validation_tests/", "pytest validation test", "see audit/data/revision_tests_phaseA.log",
     "pytest; some need torch/opacus", "-", NA),
    (r"FILE2/fedkge_revision/", "revision documentation / README", "read in Phase A", "-", "-", NA),
    # ------------------------------------------------------------------ top-level uploads / attachments
    (r"(attachment-b054a11d\.txt|b054a11d-attachment\.txt)$", "FILE 1 - master research-engineering prompt", "read in full",
     "-", "-", NA),
    (r"(UPLOADS/attachment\.txt|3294075b-attachment\.txt)$", "Clarification of the five artifacts (text ends mid-sentence)",
     "read in full", "-", "-", NA),
    (r"fedkge_revision_P1-P4\.zip$", "FILE 2 (ASSUMED - no file named 'Proprietary Learning Reveal' was supplied): "
     "revision package for Phases 1-4", "extracted; read; partially tested", "-", "-", NA),
    (r"Mehak_IEEE_Revision_Roadmap\.docx$", "FILE 3 - IEEE revision roadmap (9 steps, from the professor's review; "
     "the review itself is not supplied)", "read in full", "-", "-", NA),
    (r"Privacy-Preserving_Federated_Knowledge_Graph_Embedding.*\.docx$", "FILE 4 - original manuscript "
     "('final version 1.1 (2)', modified 2026-08-04, 39 images)", "read in full; historical reference", "-", "-", NA),
    (r"orignial_on_one_data_set\.zip$", "FILE 5 - project folder (complete/ 57 files, files/ 8 notebooks)",
     "extracted; read", "-", "-", NA),
    (r"complete\.zip$", "older upload of the complete/ folder", "byte-identical to FILE 5 complete/ (checked)", "-", "-", NA),
    (r"IEEE_Federated_KGE_Research_Paper\.pdf$", "earlier 12-page manuscript version (Google Docs render; still uses the "
     "'304%' wording)", "superseded by FILE 4; historical", "-", "-", NA),
    (r"methodology_diagram__1_\.html$", "original methodology diagram (design intent: 10-20 Flower clients, "
     "FB15k-237/WN18RR/NELL-995 as different clients, TransE/RotatE, Opacus ADP, IPFS with access control)",
     "historical design reference; several planned components were never implemented", "-", "-", NA),
    (r"1272c771-attachment\.txt|attachment-1272c771\.txt", "console log of a Phase 4 run with sigma=1.2 (20 rounds, "
     "naive eps 12.47, final MRR 0.0309); notebook = uploads/phase4_fixed_sigma__1_.ipynb", "legacy MEASURED run "
     "not stored in complete/", "-", "-", X),
    (r"(22738872|30955248)-attachment\.txt|attachment-(22738872|30955248)\.txt", "console log of the Phase 3 run "
     "(identical copies)", "matches complete/phase3_results.json", "-", "-", M),
    (r"(5385b1e1|574b8148|c07e3dae)-attachment\.txt|attachment-(5385b1e1|c07e3dae)\.txt", "earlier prompt asking for a "
     "Phase 6/7/8 notebook to be generated", "historical (explains how P6-P8 were produced)", "-", "-", NA),
    (r"(961df9f6|cbca1712|f3e65fc2)-attachment\.txt|attachment-961df9f6\.txt", "pasted notebook cell (Phase 6 export / "
     "load-with-stubs)", "historical", "-", "-", NA),
    (r"ecd4a8cf-phase3_results\.json$", "earlier P3 pilot (3 rounds, dim 32, MRR 0.0016)", "superseded legacy", "-", "-", M),
    (r"692d8135-phase4_results\.json$", "earlier P4 pilot (5 rounds, exponential 2.0->0.5, naive eps 10.63 > 8)",
     "superseded legacy", "-", "-", X),
    (r"688501ba-phase5_results\.json$", "earlier P5 (H1 1.7%, built on the pilots)", "superseded legacy", "-", "-", F),
    (r"(ff2024cf-phase6_results\.json|phase6_results-ff2024cf\.json)$", "earlier P6 (poisoning defence 19% -> later "
     "redefined to 100% in the 'h2fixed' version)", "superseded legacy", "-", "-", S),
    (r"(68d8c5f5-phase6|UPLOADS/phase6_results|786dbfb6-phase7|UPLOADS/phase7_results|b8780d2b-phase8|"
     r"UPLOADS/phase8_results)", "copy of a complete/ result JSON", "duplicate (see duplicate_of)", "-", "-", NA),
    (r"UPLOADS/phase2_results\.json$", "earlier copy of phase2_results.json (differs only in timestamp)", "duplicate in "
     "content", "-", "-", D),
    (r"UPLOADS/phase3\.ipynb$", "earlier Phase 3 notebook version (3 rounds; no outputs)", "superseded", "-", "-", NA),
    (r"UPLOADS/phase4_fixed_sigma__1_\.ipynb$", "Phase 4 notebook, sigma=1.2 run WITH outputs (naive eps 12.47)",
     "legacy measured run not in complete/", "-", "-", X),
    (r"UPLOADS/phase4[a-z_]*\.ipynb$", "earlier Phase 4 notebook version (no outputs)", "superseded", "-", "-", NA),
    (r"UPLOADS/phase6_h2fixed__1_\.ipynb$", "copy of files/phase6_h2fixed_(1).ipynb", "duplicate", "-", "-", S),
    (r"UPLOADS/phase6[a-z_0-9]*\.ipynb$", "earlier Phase 6 notebook version (no outputs)", "superseded", "-", "-", NA),
    (r"(CONFERENCE\.pptx|SafeMind_)", "unrelated to this project", "out of scope (not used)", "-", "-", NA),
    (r"8db9c0c6-IEEE|8f51f8dd-Mehak|ccc23239-Privacy|024055ba-fedkge", "attachment copy of an upload", "duplicate", "-", "-", NA),
]


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def classify(key: str):
    for pat, *meta in RULES:
        if re.search(pat, key):
            return meta
    return ["UNCLASSIFIED", "", "", "", ""]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", action="append", required=True, help="LABEL=PATH")
    ap.add_argument("--out", required=True)
    ap.add_argument("--top-level-only", action="append", default=[], help="labels whose root is scanned non-recursively")
    a = ap.parse_args()
    rows = []
    for spec in a.root:
        label, path = spec.split("=", 1)
        root = Path(path)
        it = root.iterdir() if label in a.top_level_only else root.rglob("*")
        for p in sorted(it):
            if not p.is_file():
                continue
            rel = p.relative_to(root).as_posix()
            key = f"{label}/{rel}"
            rows.append({"group": label, "path": rel, "bytes": p.stat().st_size, "sha256": sha256(p), "key": key})
    first = {}
    for r in rows:
        r["duplicate_of"] = first.get(r["sha256"], "")
        first.setdefault(r["sha256"], r["key"])
        purpose, status, deps, repro, prov = classify(r["key"])
        r.update(purpose=purpose, status=status, depends_on=deps, reproducible=repro, provenance_class=prov)
    cols = ["group", "path", "bytes", "sha256", "duplicate_of", "purpose", "status", "depends_on", "reproducible",
            "provenance_class"]
    with open(a.out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    n_uncl = sum(r["purpose"] == "UNCLASSIFIED" for r in rows)
    print(f"{len(rows)} files, {sum(1 for r in rows if r['duplicate_of'])} duplicates, {n_uncl} unclassified")
    for r in rows:
        if r["purpose"] == "UNCLASSIFIED":
            print("  UNCLASSIFIED:", r["key"])


if __name__ == "__main__":
    main()
