# Descriptive paired comparisons (never called significant)

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| comparison | dataset | metric | n_pairs | seeds | descriptive_only | status |
|---|---|---|---|---|---|---|
| federation cost: FedAvg vs centralised (non-private) | fb15k237 | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| privacy cost: complete method (eps* = 4) vs FedAvg non-private | fb15k237 | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| DP cost: DP-FedAvg (eps* = 4, s*) vs FedAvg non-private | fb15k237 | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| schedule inside the method: R1p (s*) vs R1q (fixed sigma) | fb15k237 | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| DP3-a settings only (no clip, no noise) vs FedAvg non-private | fb15k237 | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| DP3-b clipping only vs DP3-a settings only | fb15k237 | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| noise: DP-FedAvg (eps* = 4, s*) vs DP3-b clipping only | fb15k237 | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| heterogeneity: FedAvg non-private at alpha = 0.5 vs alpha = 0.1 | fb15k237 | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| heterogeneity: FedAvg non-private at alpha = 1.0 vs alpha = 0.1 | fb15k237 | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| heterogeneity: FedAvg non-private at IID vs alpha = 0.1 | fb15k237 | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| clean utility: trimmed_mean vs the proposed rule (both eps* = 4) | fb15k237 | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| clean utility: median vs the proposed rule (both eps* = 4) | fb15k237 | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| clean utility: krum vs the proposed rule (both eps* = 4) | fb15k237 | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| clean utility: fltrust vs the proposed rule (both eps* = 4) | fb15k237 | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| federation cost: FedAvg vs centralised (non-private) | wn18rr | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| privacy cost: complete method (eps* = 4) vs FedAvg non-private | wn18rr | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| DP cost: DP-FedAvg (eps* = 4, s*) vs FedAvg non-private | wn18rr | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| schedule inside the method: R1p (s*) vs R1q (fixed sigma) | wn18rr | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| DP3-a settings only (no clip, no noise) vs FedAvg non-private | wn18rr | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| DP3-b clipping only vs DP3-a settings only | wn18rr | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| noise: DP-FedAvg (eps* = 4, s*) vs DP3-b clipping only | wn18rr | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| heterogeneity: FedAvg non-private at alpha = 0.5 vs alpha = 0.1 | wn18rr | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| heterogeneity: FedAvg non-private at alpha = 1.0 vs alpha = 0.1 | wn18rr | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| heterogeneity: FedAvg non-private at IID vs alpha = 0.1 | wn18rr | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| clean utility: trimmed_mean vs the proposed rule (both eps* = 4) | wn18rr | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| clean utility: median vs the proposed rule (both eps* = 4) | wn18rr | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| clean utility: krum vs the proposed rule (both eps* = 4) | wn18rr | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| clean utility: fltrust vs the proposed rule (both eps* = 4) | wn18rr | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| federation cost: FedAvg vs centralised (non-private) | codex_m | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| privacy cost: complete method (eps* = 4) vs FedAvg non-private | codex_m | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| DP cost: DP-FedAvg (eps* = 4, s*) vs FedAvg non-private | codex_m | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| schedule inside the method: R1p (s*) vs R1q (fixed sigma) | codex_m | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| DP3-a settings only (no clip, no noise) vs FedAvg non-private | codex_m | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| DP3-b clipping only vs DP3-a settings only | codex_m | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| noise: DP-FedAvg (eps* = 4, s*) vs DP3-b clipping only | codex_m | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| heterogeneity: FedAvg non-private at alpha = 0.5 vs alpha = 0.1 | codex_m | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| heterogeneity: FedAvg non-private at alpha = 1.0 vs alpha = 0.1 | codex_m | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| heterogeneity: FedAvg non-private at IID vs alpha = 0.1 | codex_m | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| clean utility: trimmed_mean vs the proposed rule (both eps* = 4) | codex_m | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| clean utility: median vs the proposed rule (both eps* = 4) | codex_m | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| clean utility: krum vs the proposed rule (both eps* = 4) | codex_m | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
| clean utility: fltrust vs the proposed rule (both eps* = 4) | codex_m | test.mrr | 1 | [42] | True | INSUFFICIENT_PAIRS |
