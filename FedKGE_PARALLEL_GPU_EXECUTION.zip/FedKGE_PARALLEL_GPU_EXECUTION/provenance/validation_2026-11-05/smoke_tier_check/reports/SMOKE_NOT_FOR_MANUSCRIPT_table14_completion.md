# Table 14 — completion and failure status

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| status |
|---|
| PENDING |
