# 02 — Design decisions D1–D10 (exact Phase A text) and new decisions D11–D18 (Phase B, item 2)

**Status:** every decision below is **PENDING YOUR APPROVAL**. None is implemented, and nothing has been run.
**Sources for numbers:**
- `data/phaseB_sigma_plan.csv` / `.json` — noise multipliers, noise ratios and accountant cross-checks
- `data/phaseB_partition_feasibility.csv` — partition simulation
- `data/run_counts.csv`, `data/cost_estimate.csv`, `data/storage_estimate.csv` — run counts, GPU-hours and storage

All of these are **[Calculated – Phase B planning]**, not experimental results.

Each decision gives:
- the **Phase A text, quoted verbatim** from Section 12 of `initial_methodology_audit.md`;
- the **Phase B recommended default**, marked *unchanged*, *refined* (same direction, more precise) or **changed** (different recommendation, with the reason);
- the rationale, implications and alternatives.

"Implications" covers privacy guarantee, benchmark, threat model and scientific claims where relevant, plus compute. **Naming:** D1–D18 are decisions; experiment blocks are named P2.x, T, L, N, DP, R, I, M, X, O (`06`).

---

## Part 1 — The ten decisions from Phase A

### D1 — Code base

**Phase A (verbatim).** Decision: *"Code base"*. My recommendation: *"extend the revision package; keep the original notebooks frozen in `legacy/` for replicas"*

**Phase B default — unchanged, with one condition.**
- Extend `fedkge_revision_P1-P4.zip` and restructure it into the master-prompt layout (`src/…`, `scripts/…`, `configs/…`) without rewriting working logic.
- Copy the original notebooks and results unchanged into `legacy/`, with SHA-256 checksums.
- **Condition:** File 2's identity is unconfirmed (`08_open_questions.md` §1). If the "Proprietary Learning Reveal" document turns out to be a different artifact with a different method, D1 must be revisited before Phase C.

**Rationale.**
- The revision already has the things the legacy code lacks: correct per-example DP-SGD, a formal accountant, the corrected evaluation, provenance/staleness checks, legacy replicas and a linter against hard-coded results.
- In Phase A, all 27 tests that could run here passed. The other 26 need PyTorch.
- The legacy notebooks contain hard-coded results. Their Opacus embedding DP cost ≈ 140 ms per step [Legacy-measured: 148 s per round, ≈ 1,061 steps].
- Master prompt §18 asks to adapt the existing repository rather than build parallel implementations.

**Implications.**
- *Claims:* every new number comes from one code base. Legacy numbers are reproduced only by labelled replica blocks (L0–L4).
- *Compute:* none extra.
- *Gate:* Phase C must first run the 26 PyTorch tests (Stage 0). Nothing may run before they pass.

**Alternatives.**

| Option | For | Against |
|---|---|---|
| Repair the legacy notebooks | Familiar to you | Hard-coded results throughout; slow DP; no provenance — rejected |
| Rebuild on PyKEEN + Flower | Standard ecosystem; real client processes | Duplicates validated work; new bugs; weeks of delay; Flower is not required by the master prompt |
| **Extend the revision (recommended)** | Validated design; tests exist | Unexecuted; gaps G1–G15, CR-13 and CR-14 must be fixed first |

---

### D2 — Privacy unit

**Phase A (verbatim).** Decision: *"Privacy unit"*. My recommendation: *"example (triple) level per client as primary; client-level DP optional extra"*

**Phase B default — CHANGED** (two changes).
1. **Client-level DP is withdrawn**, even as an optional extra.
   - With all 10 clients participating each round there is no client subsampling to amplify privacy.
   - Reaching ε = 4 over 100 rounds needs a server noise multiplier z ≈ 12.7.
   - On the averaged update, that noise has norm ≈ z·√P / K ≈ **1,540 times the clipping bound** on FB15k-237, and about 4,450 times on YAGO3-10 (`data/phaseB_sigma_plan.json`, `client_level_dp_reference`).
   - It becomes a stated limitation instead.
2. **The neighbouring relation is "zero-out"** (CR-14).
   - Two client datasets are neighbours if one triple is replaced by a null record that contributes zero gradient. The client's size stays the same and is public.
   - Plain add/remove adjacency does not work here, because the protocol publishes each client's exact size (FedAvg weights and gradient normalisation), and the size would reveal a removal.
   - The Poisson-subsampled Gaussian bounds are the standard ones for this mechanism, so **every ε value is unchanged**.

**Rationale for triple-level DP.**
- In a KG, the private records are facts (triples).
- Triple-level DP is the standard DP-SGD unit, matches the legacy implementation (continuity), and matches the one-triple neighbouring relation of the closest prior work, DP-Flames (Hu et al., WWW 2023, Definition 4.1).

**Implications.**
- *Privacy guarantee, in plain words:* "whether a given triple is in client k's training data" is (ε, δ)-protected, given the public size. This holds against **anyone who sees client k's messages**: the server, other clients, colluding groups and users of the final model. The noise is added on the client, so the server need not be trusted for privacy.
- *Not protected:*
  - **Entities, effectively.** An entity in g triples gets only group privacy: (gε, g·e^((g−1)ε)·δ). At ε = 4, δ = 1e-6, that is (8, 1.1e-4) for g = 2 and (12, 8.9e-3) for g = 3, and vacuous for g ≥ 4. FB15k-237 entities appear in about 37.5 training triples on average.
  - how many triples a client holds;
  - client participation;
  - which relations a client mostly holds;
  - duplicated or correlated facts;
  - the privacy cost of hyperparameter tuning (disclosed).
- *Claims:* the paper must say "triple-level (example-level) DP under zero-out adjacency", never "client privacy" or "entity privacy".

**Alternatives.**

| Option | For | Against |
|---|---|---|
| **Triple-level DP, zero-out adjacency (recommended)** | Standard; continuity; ε unchanged; client sizes can stay public | No meaningful protection for entities |
| Triple-level DP, add/remove, with a noised or data-independent size | Classic definition | Every place the protocol uses N_k would need a privatised or declared size |
| Entity-level DP | Protects everything about an entity | Needs per-entity contribution bounds; much more noise; not implemented anywhere here |
| Client-level DP-FedAvg | Protects whole datasets | Infeasible with K = 10 (≈ 1,540× noise) |

---

### D3 — Operating points

**Phase A (verbatim).** Decision: *"Operating points"*. My recommendation: *"primary ε\* = 4, δ = 1e-6; regimes {1, 2, 4, 8} + non-private"*

**Phase B default — unchanged in substance, refined.**
- **Calibrate σ with the RDP accountant**, which is conservative.
- This **reverses Phase A's OP-1**, which proposed PLD as the primary figure. The reason: calibration and the tested code use RDP. PLD (≈ 0.93 × the RDP value at the calibrated σ) and the PRV accountant are reported next to it.
- Calibrating with PLD instead would cut σ by about 4–7 % across the tuning grid (`sigma_pld_calibrated`, `pld_noise_saving_pct`).
- Also report ε at δ = 1e-5, for continuity with the original paper.
- ε* = 4 stays the pre-declared primary point. The whole frontier is reported, and no point is chosen because it looks good (master prompt §7).

**Rationale.**
- **δ against the largest client.** The usual rule is δ ≪ 1/N for the *largest* client.
  - δ × (largest client size) ≈ 0.04 on FB15k-237 and ≈ 0.025 on WN18RR at α = 0.1 (medians of the partition simulation).
  - CoDEx-M is measured in Phase D.
  - YAGO3-10's largest client would hold ≥ 10⁵ triples, so δ = 1e-7 would be used there.
- ε from 1 to 8 spans strong to moderate privacy, the range usually reported for DP-SGD.
- Noise needed (q = 0.05, 100 rounds, δ = 1e-6):

| ε* | 1 | 2 | 4 | 8 |
|---|---|---|---|---|
| σ | 10.20 | 5.42 | 2.96 | 1.72 |

**Implications.**
- *Claims:* H1 is judged at ε* = 4.
- *Expected utility:* ε = 1 needs σ ≈ 6.5–14.4 over the tuning grid (100 rounds). It will probably give very low utility on every dataset. It is still run, because it is the strong-privacy end of the curve.
- *Legacy budget:* the old budget of 15 appears only in replica rows, never as a target.

**Alternatives.**
- Primary ε* = 8: more utility, weaker guarantee.
- Primary ε* = 2: stronger guarantee, likely near-zero utility.
- δ = 1e-5 as primary: continuity with the paper, but weaker.
- Calibrating with PLD: about 4–7 % less noise; OP-11.

---

### D4 — Partition grid

**Phase A (verbatim).** Decision: *"Partition grid"*. My recommendation: *"10 clients, α ∈ {0.1, 0.5, 1.0}, plus IID and legacy references"*

**Phase B default — unchanged, refined.**
- **Partition algorithm:** Dirichlet allocation over relations. For each relation, its training triples are split across the 10 clients with proportions drawn from Dir(α). A draw is accepted only if every client gets ≥ 20 % of the mean client size and ≥ 1,024 triples; otherwise it is redrawn, and the number of attempts is logged.
- **Comparing datasets:** heterogeneity is compared using **measured** statistics (Jensen–Shannon divergence of relation mixes, size Gini, largest share), not using α alone.
- **Pre-approved fallback:** if a partition proves infeasible in Phase D, (i) report it, then (ii) relax the minimum size to 10 % of the mean for that dataset only, documented. K is never changed.

**Planning simulation** (`data/phaseB_partition_feasibility.csv`; 4,000 draws; statistics are **medians over accepted draws**; FB15k-237 counts are legacy-measured, WN18RR counts are unverified):

| Dataset | α | Draws accepted | Size Gini | Largest share | Mean JS divergence |
|---|---|---|---|---|---|
| FB15k-237 | 0.1 | 100 % | 0.16 | 15 % | 0.51 |
| WN18RR | 0.1 | **3.75 %** | 0.44 | 29 % | 0.43 |
| WN18RR | 0.5 | 73 % | 0.32 | 22 % | 0.19 |

So WN18RR at α = 0.1 is feasible only by rejecting about 96 % of draws (G15). The accepted partitions come from a heavily *truncated* Dirichlet, and this must be stated.

**Rationale.**
- K = 10 is the master-prompt candidate and the revision default. It allows 1–3 attackers (f = 0.1–0.3) while Krum's condition n > 2f + 2 still holds.
- Dirichlet allocation over relations is the KG analogue of label skew and can be reproduced exactly from a seed.
- α = 0.5 is required by the master prompt.

**Implications.**
- *Benchmark:* only training triples are partitioned. Validation and test stay the global benchmark splits, so evaluation is not corrupted. The flip side is that results are **not comparable** with FedE-style per-client test sets.
- *Privacy:* which relations a client mostly holds is a dataset-level property. DP does not hide it.
- *Compute:* α = 0.5, 1.0 and IID add blocks N3 and X1.

**Alternatives.**
- Random relation-disjoint split into 10 clients (FedE-style, α → 0): robust aggregation becomes ill-posed.
- Entity-community partition (OP-10): models a different kind of skew; extra cost.
- K = 5 (legacy continuity): too few clients for robustness experiments.
- K = 20: more realistic, but smaller clients mean more DP noise per client and more compute.

---

### D5 — Third dataset

**Phase A (verbatim).** Decision: *"Third dataset"*. My recommendation: *"YAGO3-10 if your GPU budget allows (cost measured in the dev tier); otherwise a cheaper accepted benchmark, justified"*

**Phase B default — CHANGED.**
- **CoDEx-M** becomes the default third dataset.
- **YAGO3-10** becomes an optional fourth "scale" dataset. It is run only if the measured cost allows, and always reported with its leakage caveat. CoDEx-L is the clean large-scale alternative.

**Why the change.** Two facts found in Phase B:
1. Akrami et al. (2020) show YAGO3-10's two largest relations (isAffiliatedTo, playsFor) are near-duplicates, and **2,561 of its 5,000 test triples have duplicates in training**. This inflates MRR and weakens what triple-level DP means, because changing one triple leaves its duplicate.
2. Cost (reduced core, `data/cost_estimate.csv`):
   - per dataset, YAGO3-10 costs 57–332 GPU-h vs 14–122 for CoDEx-M, i.e. 2.7–4.2×;
   - for the whole three-dataset plan, 90–602 vs 47–393 GPU-h, i.e. 1.5–2×.

**Rationale for CoDEx-M** (details in `04_dataset_benchmark.md`):
- an established benchmark (Safavi & Koutra, EMNLP 2020), MIT-licensed repository, derived from Wikidata;
- inverse relations and relations with > 50 % overlapping entity pairs were removed by construction;
- 51 relations, so the Dirichlet partition is expected to be feasible (not simulated; checked in Phase D);
- cost relative to FB15k-237 per run: about 0.7× for non-private runs and 0.87–0.95× for DP runs (design Q);
- the authors report a TransE MRR of 0.303 (their protocol), useful as a sanity reference only.

**Implications.**
- *Benchmark:* FB15k-237 + WN18RR + CoDEx-M cover three different DP regimes. The per-step noise-to-clip ratio at ε = 4, q = 0.05 is 2.6, 13.8 and 4.2.
- *Claims:* a reviewer may ask "why not YAGO3-10?". The answer is the documented leakage plus cost, and the optional extension.
- *Compute:* adding YAGO3-10 as a fourth dataset raises the core cost by roughly 80–120 % (`data/cost_estimate.csv`).

**Alternatives.**

| Option | For | Against |
|---|---|---|
| **CoDEx-M (recommended)** | Clean construction; MIT; cheap; 51 relations | Less familiar to some reviewers than YAGO3-10 |
| YAGO3-10 | The most widely used large benchmark; roadmap's suggestion | Documented test leakage; duplicated facts; about 2–5× FB15k-237 cost per run; δ would have to be 1e-7 |
| CoDEx-L | Clean and large (77,951 entities, 551,193 training triples) | About 2× FB15k-237 cost per non-private run |
| NELL-995 | Used by FedE and DP-Flames | Not in PyKEEN; licence unchecked; known split problems |
| FB15k / WN18 | Historical | Rejected: inverse-relation test leakage |

---

### D6 — Keep H3 / membership inference?

**Phase A (verbatim).** Decision: *"Keep H3 / MIA?"*. My recommendation: *"only as an empirical audit attributed to DP"*

**Phase B default — refined.** Keep H3 only as a pre-registered empirical audit, and only with six fixes:
1. **Audit pool from the client's own data.** Before training, each client sets aside an audit pool from its own training triples, and each candidate is included in training with probability ½. Members and non-members therefore come from the same distribution (MJ-15). This replaces using official test triples as non-members.
2. **Threat model:** the attacker is an honest-but-curious server, or a user of the final global model, with score access. The target is whether a triple belongs to a client's training data.
3. **Primary test (pre-registered):** the relation-calibrated score attack (A2) on the final global model, pooled over all clients' audit pools. The other two attacks are secondary.
4. **Metrics:** AUC, TPR at FPR = 1 % and 0.1 %, compared with the DP bound TPR ≤ e^ε·FPR + δ. An empirical lower bound on ε comes from the **one-run audit** method (Steinke, Nasr & Jagielski 2023), which is valid with a single training run.
5. **Testability rule:** if the non-private model shows no measurable advantage, H3 is declared "not testable", not "confirmed".
6. **Attribution and seeds:** results are attributed to DP only (FedAvg vs FedAvg + DP). Block M1 uses **5 seeds in both profiles**, because it carries a hypothesis test.

If you would rather save the compute, **drop H3**. The (ε, δ) guarantee is then the paper's privacy claim, which is the cleaner option scientifically.

**Implications.**
- *Compute:* audit runs change the training set, so they cannot reuse other runs. Block M1 is 60 runs, ≈ 3–33 GPU-h.
- *Claims:* the old "30.56 % MI reduction" is withdrawn in every case.

**Alternatives.**
- Drop H3: cheapest and cleanest.
- LiRA-style audit with shadow models: much stronger, very expensive.
- Re-implement DP-Flames' client-side attacks: specific to federated KGE, but there is no public code (none found), so fidelity is a risk.

---

### D7 — IPFS

**Phase A (verbatim).** Decision: *"IPFS"*. My recommendation: *"honest "SHA-256 content-addressed integrity layer (not IPFS)" unless you want a local IPFS node experiment"*

**Phase B default — refined.**
- Option (a): an honest SHA-256 content-addressed integrity layer, but **placed in the data path**. The server aggregates only tensors deserialised from bytes that passed verification (fixes CR-13).
- Identifiers are assumed to arrive over an authenticated channel.
- Two experiments: overhead with integrity on vs off (I1), and in-transit corruption injection with integrity on vs off (I2).
- **The paper's title cannot say "IPFS-Based"** under option (a). The wording changes in the manuscript phase.

**Implications.**
- *Threat model:* integrity detects modification of stored or transmitted bytes, given authentic identifiers. It does **not** detect poisoning (a malicious client hashes its poisoned update correctly), does not provide trust, availability or authenticity of the identifier channel, and is not IPFS.
- *Claims:* "IPFS-compatible" is not used, because SHA-256 hex identifiers are not CIDs.

**Alternatives.**
- (b) A local IPFS node (Kubo) storing every object with real CIDs, and measured local add/get times. This honestly keeps "IPFS" in the title, but it is still a single machine with no network measurements, and adds an external binary and runtime.
- (c) The public IPFS network or a pinning service. Needs credentials and depends on the network, so it is not reproducible. Not recommended.

---

### D8 — Seeds

**Phase A (verbatim).** Decision: *"Seeds"*. My recommendation: *"5 for everything, 10 for the headline comparisons if compute allows"*

**Phase B default — refined.**

| Seed set | Seeds | Used for |
|---|---|---|
| Tuning (S_TUNE) | 1001 | Selection only; never reported as evidence (MJ-18) |
| Confirmatory (S5) | 42, 123, 256, 512, 1024 (roadmap seeds) | **Every block that carries a pre-registered hypothesis test** (H1, H2, H2b, H3, HS): N1, R1p, DP1/DP2 at ε* = 4, R2, R2a, R3, R3a, M1 |
| Headline extension (S10x) | 2048, 4096, 8192, 16384, 32768 | Full profile only: brings the hypothesis blocks to 10 seeds (N1, N2, R1p, R2, R2a, R3, R3a; DP1h and DP2h for the ε* = 4 cells) |
| Sensitivity (S3) | 42, 123, 256 | Descriptive blocks only, labelled "descriptive": a subset of S5, so still paired, and **never used for a hypothesis test** |

Core blocks that use 3 seeds (I1, I2; and DP3, R1, R4, R5, R5a in the reduced profile) are **descriptive**.

**Rationale.**
- With 5 seeds, the smallest two-sided p any exact paired test can reach is 0.0625, and the smallest one-sided p is 1/32 ≈ 0.031. That exceeds α = 0.025, so with 5 seeds only the paired t-test can reject.
- With 10 seeds, the smallest one-sided exact p is 1/1024.
- Using the same seeds across conditions makes every comparison paired.
- A separate tuning seed prevents the "winner's curse" (selecting and reporting on the same runs).

**Implications.**
- *Compute:* full profile is 1,485 core runs; reduced profile (hypothesis blocks at 5 seeds) is 837.
- *Claims:* effect sizes with confidence intervals are the primary evidence; p-values are secondary.

---

### D9 — Hypotheses H1–H3

**Phase A (verbatim).** Decision: *"Hypotheses H1–H3"*. My recommendation: *"keep, with the precise definitions above, accepting they may fail"*

**Phase B default — refined.** The decision rules are fixed before Stage 4 (`03_methodology_specification.md` §13).

**Testing scheme (all hypotheses).** One-sided paired t-tests on seeds at **α = 0.025**, with Holm correction **within each family**. The families are:
- H1: 3 datasets;
- H2: 3 datasets × 7 attacks = 21, where untestable members count with p = 1;
- H2b, H3 and HS: 3 datasets each.

"Holds on all datasets" requires every member to pass. Unadjusted 95 % confidence intervals are reported alongside.

- **H1 — utility retention.**
  - The complete method at ε* = 4 keeps ≥ 90 % of the centralised non-private MRR, per dataset.
  - Tested on the per-seed log-ratio. H0: mean log ratio ≤ log 0.9.
- **H2 — robustness.**
  - **E ≥ 0.35** against each attack, where E = 1 − mean(degradation of the complete method) / mean(degradation of FedAvg under the same DP settings). E is a ratio of means.
  - Tested as the linear contrast c = 0.65·Δ_FedAvg − Δ_complete, with H0: mean c ≤ 0.
  - Only attacks that are effective against FedAvg are testable.
- **H2b — no harm.** Clean MRR of the complete method ≥ 95 % of FedAvg under the same DP settings.
- **H3 — membership leakage** (only if D6 keeps it). At ε* = 4 the attack advantage falls by ≥ 25 % relative to the non-private model, subject to the testability rule.
- **HS — new.** The selected noise schedule beats fixed σ at the same ε*. It is "not testable" if tuning selects the fixed schedule.

**Rationale.**
- The thresholds 90 %, 35 % and 25 % are kept from the original paper ("H1: KGE accuracy ≥ 90 %, H2: poisoning defense ≥ 35 %, H3: inference resistance ≥ 25 %") for continuity. Changing them now would look post hoc.

**Implications.**
- *Claims:* H1 is judged on the **private** complete method, not on a non-private model.
- *Expectation:* a failed H1 at ε* = 4 is a plausible and reportable outcome.
- *Withdrawn:* the old statement that "all hypotheses are confirmed (p < 0.001)" is withdrawn regardless.

**Alternatives.**
- Report effect sizes only, with no thresholds: purely descriptive, weaker story.
- Change the thresholds: would look post hoc without a separate justification.

---

### D10 — If DP utility is unacceptable at ε ≤ 8

**Phase A (verbatim).** Decision: *"If DP utility is unacceptable at ε ≤ 8"*. My recommendation: *"report it honestly; optionally add one justified design alternative (OP-3)"*

**Phase B default — refined: the trigger is declared in advance.**
- **Trigger:** after Stage 3 tuning, the best FedAvg + DP *validation* MRR at ε* = 4 on FB15k-237 is below **25 %** of the non-private FedAvg validation MRR. You can change 25 % now, but not after seeing results.
- **If triggered:** you decide, with that evidence, whether to add **one** alternative:
  - (a) relation-only sharing (FedR-style), or
  - (b) sparsity-preserving DP for embedding tables (DP-FEST style).
- Neither is run by default. Results at ε ≤ 8 are reported as measured either way.

**Rationale.** Without a declared trigger, a researcher can keep trying mechanisms until one looks good. Declaring it in advance and judging it on validation data only prevents that.

**Implications.**
- *Claims:* an alternative changes the method and its protocol. For example, relation-only sharing keeps entity embeddings local, which changes how evaluation works. It would be presented as a separate variant.
- *Compute:* one more block of about 15–45 runs.

---

## Part 2 — New decisions found in Phase B

### D11 — DP sampling design (affects the accounting statement)

- **Recommended:** offer **design Q** next to the revision's design A, and let tuning step **T2d** decide by validation MRR at ε* = 4. If tied, choose Q.
  - **Design Q:** one common sampling rate q for all clients: client k's expected batch is q·N̂_k, with T = round(1/q) steps per round and one shared σ.
  - **Design A:** a fixed batch B = 512 with a σ calibrated per client.
  - P2.3 is only an early look.
- **Why offer Q at all:**
  - one shared σ and one sampling rate make the accounting statement simpler;
  - design A cannot enlarge the batch for small clients. The revision even raises an error if N_k < B, and small clients' sampling rate climbs towards 0.5, which wastes privacy amplification.
  - Both designs give every client ε ≤ ε*, so equal ε is **not** a distinguishing argument.
- **What is *not* claimed:**
  - Both designs leave a similar, roughly 5×, per-epoch signal-to-noise gap between the smallest and the mean client.
  - Which design gives more uniform update *norms*, the thing that matters for the trust rule (G8), depends on the optimiser. With plain SGD, design A equalises the per-round noise norm. With Adam's per-coordinate rescaling, equal step counts (design Q) may matter more.
  - This is therefore **measured** (benign FPR by client-size third in P2.3 and T2d), not assumed. The D15 trigger applies under either design.

### D12 — What "adaptive DP" means (affects claims and the paper title)

- **Recommended: (a).**
  - Deterministic noise schedules (σ decaying linearly, exponentially or by cosine) are fixed before training, calibrated to the same ε*, and executed for all R rounds.
  - Describe them as "scheduled noise decay".
  - Claim a benefit only if HS holds.
- **Option (b)** (optional block O1):
  - σ decays when the server's validation MRR stalls, as in DP-Flames' policy.
  - The signal is computed from the published global model (itself post-processing of DP outputs) on server data, so it costs no client privacy.
  - The cumulative cost is controlled by an RDP filter (Feldman & Zrnic 2021), applied order by order against the target RDP curve of the calibrated fixed schedule. It stops when any order would exceed its budget. Details in Phase C.
- **Option (c):** remove "Adaptive" from the title.
- **Why it matters:** DP-Flames already published validation-driven adaptive privacy-budget allocation for federated KGE. Claiming "adaptive DP" as new is not defensible without this positioning (MJ-20).

### D13 — Tuning and confirmation protocol

- **Recommended:**
  - Select only on the tuning seed, using validation metrics.
  - Give non-private training the same grid for the *shared* optimiser settings (learning rate and batch size; T1). The DP-specific parameters (C, q, R, sampling design, schedule; 21 DP tuning cells per dataset, versus 6 for non-private FedAvg) have no non-private counterpart. This remaining asymmetry is **disclosed**.
  - Pre-register the selection rules and freeze their hashes before Stage 4.
  - Hyperparameters selected at ε* = 4 are **reused** at ε = 1, 2 and 8, and this is disclosed.
  - DP runs execute all R rounds; choosing the best validated checkpoint is post-processing (fixes G6). Non-private runs may stop early after 4 evaluations without improvement.
  - Disclose that hyperparameter tuning consumed client privacy, which is not included in ε (G10).
- **Alternative:** the revision's protocol (select and report on the same five seeds). It is cheaper, but biased in the method's favour.

### D14 — Trust threshold τ selection rule

- **Recommended:**
  - τ* = the smallest τ in {1.5, 2, 2.5, 3, 3.5, 4, 5} (MAD units) whose mean benign false-positive rate is ≤ 5 %.
  - Measured in clean DP FedAvg runs on the tuning seed, using anomaly scores logged every round.
  - Chosen per dataset, **after** the D15 variant is fixed. If the variant changes, τ* is selected again.
  - No attack outcome is used for selection. Full τ sensitivity is reported (X2, X2a).
- **Alternatives:**
  - Keep the revision's τ = 3, fixed a priori.
  - Maximise validation MRR under a tuning attack. Not recommended: it tunes the defence to the attack.

### D15 — Which trust rule is "the proposed method"

- **Recommended:** the revision's rule exactly as specified in 03 §8.3 (λ = 0.5, norm bound on), frozen before any result.
- **One pre-declared modification, variant V1:**
  - **What V1 changes:** the magnitude anomaly compares each client with the median norm of the clients in the **same declared-size third** in the current round. It uses only the published updates and the public sizes, so it stays post-processing.
  - **When it applies:** in Stage 2–3 clean runs, honest clients in the smallest-size third have benign FPR above 10 %, or more than twice that of the largest-size third.
  - **When it is decided:** before τ* is selected and before Stage 4. It is reported as a design change.
  - No other variant exists.
- λ is fixed a priori; its sensitivity is checked in X3.

### D16 — Attacker model under DP

- **Recommended:**
  - Malicious clients take part in DP training like honest ones. Each attack is applied to the attacker's own noisy update ("inherit") or with noise matched to it ("matched").
  - Noise-free attackers, the revision's behaviour, are a secondary check (X5) because they are easy to detect (G7).
  - Attacker fraction f = 0.2 (2 of 10 clients) is the main setting; f = 0.1 and 0.3 are sensitivity checks.
  - Attackers are placed at random, with a seed.
  - Attack strengths are the revision's a-priori values (s = 3; ALIE's z from its formula; the adaptive γ from its search).
  - Client sizes are declared before training. Sybil identities claim the median size.
  - **KG-targeted attack:** its target queries come from the attacker's *own* training triples, not from the test set (MN-21).
- **Phase C items:** the inherited and matched noise modes, the targeted attacker's DP training and the adaptive attack against FedAvg are not in the revision code yet. They are changes C5 in `03` §15.
- **Alternative:** noise-free attackers as the main setting. Not recommended: it overstates robustness.

### D17 — External DP baseline (master prompt §13, item 9)

- **Recommended:**
  - No external DP-KGE reproduction in the core matrix.
  - DP-Flames has no public code that I could find (its paper gives no code link), so a faithful re-implementation is a fidelity risk.
  - FKGE (Peng et al., CIKM 2021) studies a different setting: separate KGs aligned peer-to-peer.
  - The DP baseline is standard DP-SGD with FedAvg and no trust (blocks DP1 and DP2).
  - The DP-Flames-*inspired* adaptive policy (O1) is optional and labelled "not a reproduction".
- **Alternative:** re-implement DP-Flames from its paper (high effort, uncertain fidelity).

### D18 — Compute profile and run order

- **Recommended:**
  - Run the **reduced profile** first, in the priority order of `07_compute_feasibility.md` §6. The first priority includes every arm that H1, H2b and HS need.
  - Extend hypothesis blocks to 10 seeds only if the measured budget allows.
  - Keep final model weights only for the main-table, schedule and MIA runs: ≈ 1.5 GB (reduced) or 2.2 GB (full) with CoDEx-M (`data/storage_estimate.csv`).
  - Run each paired comparison on one GPU type where possible.
- **Gate:** the Stage-2 pilot (≈ 1–4 GPU-hours) replaces the cost assumptions with measured seconds per round before anything larger is started.

---

## Approval sheet

Reply with something like "approve all", or "approve all except D5 → YAGO3-10, D6 → drop H3".

| ID | Recommended default | Changed vs Phase A? | Your choice |
|---|---|---|---|
| D1 | Extend the revision package; legacy frozen (conditional on File 2) | unchanged | |
| D2 | Triple-level DP per client under zero-out adjacency (ε unchanged); no client-level DP | **changed** | |
| D3 | ε* = 4, δ = 1e-6; ε ∈ {1, 2, 4, 8} + non-private; RDP primary (reverses OP-1), PLD and PRV reported | refined | |
| D4 | 10 clients; Dirichlet over relations, α ∈ {0.1, 0.5, 1.0}; IID; legacy replicas; size rule + fallback | refined | |
| D5 | CoDEx-M as third dataset; YAGO3-10 optional extension | **changed** | |
| D6 | H3 only as a fixed audit (randomised audit pool, one-run bound, 5 seeds, 60 runs), or drop H3 | refined | |
| D7 | SHA-256 integrity in the data path; no IPFS claim; title wording changes | refined | |
| D8 | Tuning seed 1001; 5 seeds for every hypothesis block; 10 in the full profile; 3-seed blocks descriptive | refined | |
| D9 | H1, H2, H2b, H3, HS with fixed one-sided tests, Holm families, E as a ratio of means | refined | |
| D10 | Declared trigger (25 % on FB15k-237 validation) before any alternative | refined | |
| D11 | Offer design Q next to design A; T2d decides; norm effects measured | new | |
| D12 | "Scheduled noise decay" (a); O1 optional; or remove "Adaptive" | new | |
| D13 | Separate tuning seed; shared-setting grid for both; DP-specific asymmetry and ε-reuse disclosed; DP runs use all R rounds | new | |
| D14 | τ* by benign FPR ≤ 5 % on clean runs, after D15 | new | |
| D15 | Revision trust rule frozen; one declared variant (V1) with its trigger | new | |
| D16 | Attackers inherit or match DP noise; f = 0.2 main; noise-free as a check; targets from the attacker's own data | new | |
| D17 | No external DP-KGE reproduction; DP-FedAvg baseline; O1 optional | new | |
| D18 | Reduced profile first; pilot gate; storage policy | new | |
