"""End-to-end P1 -> P4 on synthetic data: schemas, independent epsilon recomputation, selections, reports,
determinism, resume after interruption, stale-result detection, missing-upstream failure."""
import json
import shutil

import numpy as np
import pandas as pd
import pytest

from conftest import CONFIG_DIR, SCHEMA_DIR
from fedkge import accountant as A
from fedkge.analysis import collect
from fedkge.io import IntegrityError, Paths, RunDir, read_json
from fedkge.schemas import validate_file, validate_rounds_csv


def _runs(paths, phase):
    return pd.read_csv(paths.index(phase))


def test_all_outputs_match_schemas(offline):
    validate_file(offline.p1("synthetic") / "dataset_card.json", SCHEMA_DIR, "dataset_card")
    validate_file(offline.p1("synthetic") / "manifest.json", SCHEMA_DIR, "p1_manifest")
    validate_file(offline.p1("synthetic") / "validation_report.json", SCHEMA_DIR, "validation_report")
    for m in offline.p2("synthetic").rglob("*_manifest.json"):
        validate_file(m, SCHEMA_DIR, "partition_manifest")
        validate_file(m.with_name(m.name.replace("_manifest", "_stats")), SCHEMA_DIR, "partition_stats")
    for ph in ("p3", "p4"):
        for rid in set(_runs(offline, ph)["run_id"]):
            d = offline.run(rid)
            validate_file(d / "config.json", SCHEMA_DIR, "run_config")
            validate_file(d / "final.json", SCHEMA_DIR, "final")
            dp = read_json(d / "config.json")["dp"]["enabled"]
            validate_rounds_csv(d / "rounds.csv", SCHEMA_DIR, dp)
            if dp:
                validate_file(d / "accountant.json", SCHEMA_DIR, "accountant")
    validate_file(offline.selection("dp_selection"), SCHEMA_DIR, "dp_selection")


def test_epsilon_recomputed_independently(offline):
    """Every reported epsilon must equal a fresh composition from the logged q / steps / sigma trace."""
    n = 0
    for rid in set(_runs(offline, "p4")["run_id"]):
        acc = read_json(offline.run(rid) / "accountant.json")
        orders = acc["orders_used"]
        for c in acc["per_client"]:
            sig = acc["sigma_schedule_per_client"][c["client"]][:acc["rounds_executed"]]
            e = A.eps_from_rdp(A.composed_rdp(c["q"], [c["steps_per_round"]] * len(sig), sig, orders), acc["delta"], orders)
            assert abs(e - c["eps_rdp"]) < 1e-9
            n += 1
        assert abs(acc["eps_worst_client"] - max(c["eps_rdp"] for c in acc["per_client"])) < 1e-12
        assert len(acc["eps_trace_per_round_per_client"]) == acc["rounds_executed"]
        if acc["mode"] == "calibrated":
            assert acc["budget_ok"] and acc["eps_worst_client"] <= acc["target_epsilon"] + 1e-9
            assert acc["schedule_verified"]
    assert n > 0


def test_selections_use_validation_only_and_full_grid(offline):
    sel = read_json(offline.selection("dp_selection"))
    cands = sel["_clip_rule"]["candidates"]
    assert {c["clip"] for c in cands} == {0.25, 0.5, 1.0, 2.0, 4.0}
    assert sum(c["chosen"] for c in cands) == 1
    assert "val_mrr_mean" in cands[0] and not any("test" in k for k in cands[0])
    assert "schedule_shape" in sel["synthetic"]


def test_reports_are_built_and_watermarked(offline):
    from fedkge.reports import write_p3_reports, write_p4_reports
    f3, f4 = write_p3_reports(offline), write_p4_reports(offline)
    assert "p4_dp_ladder" in f4 and "p3_reference" in f3
    assert all("NOT_FOR_MANUSCRIPT" in p for p in list(f3.values()) + list(f4.values()))
    lad = pd.read_csv(f4["p4_dp_ladder"])
    assert len(lad) == 6 and lad["test_mrr.n"].min() >= 1


def test_deterministic_rerun(offline, tmp_path):
    """Same config + same seed -> identical results (CPU) in a fresh results directory."""
    from fedkge.federated import run_experiment
    rid = _runs(offline, "p4")[lambda d: d.block == "4B_clip"]["run_id"].iloc[0]
    cfg = read_json(offline.run(rid) / "config.json")
    p2 = Paths(tmp_path, "smoke")
    shutil.copytree(offline.base / "artifacts", p2.base / "artifacts")
    shutil.copytree(offline.cache(), p2.cache())
    f = run_experiment(cfg, p2, "cpu")
    ref = read_json(offline.run(rid) / "final.json")
    assert f["test"]["mrr"] == ref["test"]["mrr"] and f["privacy"]["eps"] == ref["privacy"]["eps"]


def test_resume_after_interruption(offline, tmp_path, monkeypatch):
    from fedkge import federated as F
    rid = _runs(offline, "p3")[lambda d: d.block == "P3_iid"]["run_id"].iloc[0]
    cfg = read_json(offline.run(rid) / "config.json")
    cfg["train"].update({"rounds_max": 4, "ckpt_every": 2, "eval_every": 1, "patience": 10})
    p2 = Paths(tmp_path, "smoke")
    shutil.copytree(offline.base / "artifacts", p2.base / "artifacts")
    ref = F.run_experiment(json.loads(json.dumps(cfg)), p2, "cpu", force=True)
    shutil.rmtree(p2.base / "runs")
    calls = {"n": 0}
    real = F.evaluate

    def flaky(*a, **k):
        calls["n"] += 1
        if calls["n"] == 3:
            raise RuntimeError("simulated Colab disconnect")
        return real(*a, **k)
    monkeypatch.setattr(F, "evaluate", flaky)
    with pytest.raises(RuntimeError):
        F.run_experiment(cfg, p2, "cpu")
    assert RunDir(p2.run(F.run_id(cfg))).status()["status"] == "FAILED"
    assert (p2.run(F.run_id(cfg)) / "checkpoint.pt").exists()
    monkeypatch.setattr(F, "evaluate", real)
    out = F.run_experiment(cfg, p2, "cpu")
    assert out["test"]["mrr"] == ref["test"]["mrr"]


def test_stale_code_is_detected(offline, monkeypatch):
    runs, probs = collect(offline, ["p3", "p4"])
    assert len(probs) == 0 and len(runs) > 0
    import fedkge.analysis as AN
    import fedkge.io as IO
    monkeypatch.setattr(AN, "code_hash", lambda: "f" * 64)
    monkeypatch.setattr(IO, "code_hash", lambda: "f" * 64)
    runs, probs = collect(offline, ["p3", "p4"])
    assert len(runs) == 0 and set(probs["problem"]) == {"STALE_CODE"}
    with pytest.raises(IntegrityError):
        collect(offline, ["p3"], require_all=True)


def test_missing_upstream_fails_without_fallback(offline, tmp_path):
    from fedkge.federated import run_experiment
    rid = _runs(offline, "p3")["run_id"].iloc[0]
    cfg = read_json(offline.run(rid) / "config.json")
    with pytest.raises(IntegrityError):
        run_experiment(cfg, Paths(tmp_path, "smoke"), "cpu")      # no P1/P2 artifacts here
    st = RunDir(Paths(tmp_path, "smoke").run(rid)).status()
    assert st["status"] == "FAILED" and not (Paths(tmp_path, "smoke").run(rid) / "final.json").exists()


def test_legacy_stop_rule_and_naive_sum(offline, tmp_path):
    """The legacy stop rule stops on the NAIVE sum; the formal RDP value is reported next to it and is smaller."""
    from fedkge.federated import run_experiment
    rid = _runs(offline, "p4")[lambda d: d.block == "L1_legacy"]["run_id"].iloc[0]
    cfg = read_json(offline.run(rid) / "config.json")
    cfg["dp"]["legacy_budget"] = 6.0; cfg["train"]["rounds_max"] = 8
    p2 = Paths(tmp_path, "smoke"); shutil.copytree(offline.base / "artifacts", p2.base / "artifacts")
    f = run_experiment(cfg, p2, "cpu")
    assert f["stop_reason"] == "legacy_naive_budget_exceeded"
    assert f["privacy"]["legacy_naive_sum"] > 6.0
    assert f["privacy"]["eps"] < f["privacy"]["legacy_naive_sum"]
