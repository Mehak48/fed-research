# Final implementation report (2026-11-05)

**Scope:** what was changed to turn the Phase C package into the complete executable methodology (`FedKGE_COMPLETE_EXECUTABLE_METHODOLOGY.zip`), why, and how each change was checked. The owner's directives are in `instructions/5_final_implementation_directive.txt` and `instructions/6_final_directive_complete_executable_methodology.txt` (the second one supersedes the first in name, notebook structure and optimisation scope; §5 below). Her decisions are in `revision/13_documentation/STAGE3_APPROVAL_REGISTER_2026-11-04.md`.

**No research run was started.** No tuning or confirmatory run exists. Every execution mentioned here is a software check on synthetic data, on 3,000-triple subsets of the real data (smoke tier), or on labelled fixture numbers.

---

## 1. Starting point and reconciliation

**Inputs:**

| Archive | What it turned out to be |
|---|---|
| `fedkge_stage3_B2-B5_checkpoint_2026-11-04.zip` (SHA-256 `39a1ba34…`) | the Phase C final package of 2026-11-04 plus one git commit, `6e2ea67` "Checkpoint Phase C handoff and freeze approved B2-B5 decisions" (approval register added; code otherwise as delivered) |
| `fedkge_code_phaseC.zip` (`4fb27cf8…`), `fedkge_phaseC_handoff_2026-11-02.zip` | the code the owner ran on Colab (predates PC-6) and the 2026-11-02 handoff |
| `colab_pilot_results_20261104T165553Z_pilot_done.zip` (`235f21de…`) | the owner's GPU session record |

**Comparison results:**

- The checkpoint contains every later verified fix: PC-6 (forced reruns archive the completed folder; collision-safe archive names; 2 tests), PC-7 (`scripts/run_legacy_blocks.py`; corrected `confirm.yaml` header) and the 2026-11-04 README.
- Against the code zip, the only differences are exactly those fixes.
- Nothing was overwritten. The checkpoint became the baseline, and its git history is continued in `revision/`.
- **Not in the checkpoint:** `revision/results/` (git-ignored, so the Phase C result records, such as the CPU pilot and the Colab session copy, were not carried).
  - The owner's GPU session zip is restored under `provenance/phaseC_gpu_pilot_session_20261104/`.
  - The measured numbers remain quoted in `audit/phaseC/pilot_plan.md`.

**Environment rebuilt:**

- Python 3.13.18 and the exact `requirements-phaseC.txt` versions.
- Baseline test suite on the untouched checkpoint code: **133 passed, 0 failed, 0 skipped**, as recorded in Phase C.

**Datasets re-downloaded:**

- Done with the owner's recorded licence confirmation of 2026-11-02, for code-level validation only.
- Every file is **byte-identical** to the owner's Colab session (SHA-256 of all three archives and nine split files compared). These values are now pinned in `scripts/prepare_data.py`.

---

## 2. Owner decisions → implementation → verification

| Decision | Implementation | Verified by |
|---|---|---|
| **B2** budget: 99 / 756 / 30, Stage 5 deferred, priority order | `10_configs/manifest/FROZEN_MANIFEST.*` built from the configs by `fedkge/manifest.py` (114 tuning cells = 99 runs; 756 cells = 756 runs, 726 if s\* = fixed; 30 legacy). Every Stage-4 cell has a priority 1–7 (`confirm.yaml` `priority` / `priority_when`; legacy = 3). `run_plan.py` refuses Stage 5 and the full profile, checks every expanded entry against the manifest, and runs in priority → dataset → seed order | `test_frozen_manifest_counts_equal_the_approved_budget`, `test_expanded_entries_must_equal_manifest_cells`, `test_manifest_detects_a_changed_matrix`, `test_run_plan_refuses_stage5_and_full_profile`; the smoke run reproduced the same arithmetic (99 + 15 reused; 192 cells = 186 runs with s\* = fixed) |
| **B3** τ fallback | `selection.select_tau`: direction check (`check_tau_direction`: grid strictly increasing, benign FPR non-increasing overall and per size third). Smallest feasible τ; otherwise the largest grid τ with `rule_met = false`, status `RULE_NOT_MET_LARGEST_GRID_TAU`, the observed FPR, the excess and a label; the grid is never extended. Non-finite scores, attack rows and the final tier are refused. Candidate tables are kept across sessions. `selection_rules.yaml` states score, flag, choice and fallback. The label flows into FROZEN.json, Table 8, Table 9, the summary and the draft | 9 B3 tests (feasible, boundary FPR = 5 %, infeasible, direction, refusals, no-fallback rule, determinism, multi-session, flow into Stage 4) + schema |
| **B4** remove V1 | `trust.py` (no groups, no `magnitude_reference`; the frozen rule is unchanged bit for bit), `federated.py` (no `A_v1`), `config.py` (the key is rejected), `base.yaml`, `confirm.yaml`, `selection_rules.yaml` (no `v1_trigger`), `run_plan.py`, `pilot.py`, the schema (`A_v1` forbidden). Size-third FPR remains a diagnostic (selection tables, `final.json`, table `fpr_by_size_third`, figure F12) | `test_b4_variant_v1_and_its_switch_are_removed`, `test_frozen_rule_unchanged_by_b4` (against a direct implementation of 03 §8.3), `test_b4_no_v1_anywhere_in_configs`, `test_b4_config_with_v1_key_is_rejected`, `test_b4_trust_rounds_schema_forbids_v1_column`, `test_b4_size_third_fpr_remains_a_diagnostic` |
| **B5** D10 25 % trigger | `gates.d10_trigger` (`gates.yaml`, `action: flag_only`), written after tuning stage 6 into `tune/gates/d10_trigger.json`, FROZEN.json and every report; nothing else changes | `test_d10_trigger_is_a_flag_only` |
| **B5** 95 % non-inferiority | `hypotheses.yaml` H2b + `fedkge/hypotheses.py`: paired one-sided log-ratio t-test against log 0.95, Holm over 3 members, p = 1 for missing members, "supported" only if Holm p ≤ 0.025, the one-sided lower bound reported, a point estimate never counted | `test_h2b_non_inferiority_needs_the_bound_not_the_point_estimate`, `test_family_size_never_shrinks_and_not_testable_enters_with_p1` |
| **B5** MIA settings preserved | unchanged (`base.yaml` `mia`, `fedkge/mia.py`); the H3 gate and red line are implemented in the analysis | `test_hypotheses_file_matches_the_preregistration`, `test_h2_effectiveness_gate_and_h3_gates` |
| **B5** privacy scope | `DP_MECHANISM.md` §"Scope", FINAL_METHODOLOGY §6, the results draft §5 and the privacy summary all state "per-model, not end-to-end" | `test_fixture_pipeline_end_to_end_is_labelled` checks that the draft says it |
| **B5** folder layout, git checkpoint | layout kept (`revision/` numbered folders + `scripts/`); superseded top-level files moved to `history/`, not deleted; git commit of the final state (`provenance/GIT_CHECKPOINT.md`) | — |
| Safeguard 5: accuracy sanity gate | `gates.sanity_gate` + `gates.yaml`; tuning block T1C is **stage 0**; `run_plan.py` stops Stage 3 (exit 4) and writes `SANITY_GATE_REPORT.md` with recovery steps; enforced on the tune tier only; results merged across sessions; `freeze_selections.py` refuses datasets that did not pass | `test_sanity_gate_*` (3 tests); the smoke run recorded "FAILED, not enforced" on 3-round subsets, as designed |

---

## 3. Inconsistencies found and resolved

| ID | Finding | Resolution |
|---|---|---|
| **RC-1** | Stage-4 non-private references (N1, N2, N3, R5, R5a, I1, M1) were capped at `rounds_max: 60`, a Phase B cost-model assumption, while their tuning (T1C, T1F) and the approved protocol use R_max = 100 with early stopping. A shorter cap could under-train the references and bias H1 towards the proposed method | Stage 4 uses 100 (the tuned protocol). Run count unchanged; GPU upper bound +9.1 h at most |
| RC-2 | Checkpoints were written with a plain `torch.save`: a disconnect during the write could leave a truncated `checkpoint.pt`, which made the run fail and stopped the stage | `io.atomic_torch_save` (temporary file + rename) for checkpoints and final weights. An unreadable checkpoint is moved aside (`checkpoint.unreadable-*.pt`) and the run restarts from round 1 (same computation); a checkpoint of another run still fails loudly |
| RC-3 | Selecting one dataset per session overwrote the candidate tables of datasets selected earlier (the audit trail would be lost) | candidate tables are merged per dataset; a rule text that changed between sessions is refused |
| RC-4 | A retried FAILED run overwrote its `error.txt` | the earlier traceback is kept as `error_attempt<k>.txt`; `status.json` counts attempts |
| RC-5 | `run_plan.py` had no session budget, so a free-Colab session limit always cut a run mid-way | `--max-hours` / `--max-runs`: no new run starts after the budget; the rest is PENDING (exit 3), never COMPLETE |
| RC-6 | The run identity does not include the device, and nothing prevented mixing GPU types or torch builds inside one comparison (blockers B13, B16) | environment lock per (tier, dataset) in `gates.check_environment_lock`; the analysis also marks a member INVALID if its runs span environments |
| RC-7 | Downloads were checksummed but not compared with known values | pinned SHA-256 values in `prepare_data.py`; a mismatch writes nothing |
| RC-8 | The smoke-only τ placeholder (`--smoke-tau-fallback`) duplicated what B3 now defines for every tier | removed |
| RC-9 | Table and figure builders for the revised matrices did not exist (blocker B9) | `fedkge/paper.py`, `figures.py`, `draft.py`, `reporting.py`, `context.py`, with scripts `analyze_results.py`, `make_figures.py`, `build_report.py` |

---

## 4. Files

**New, core analysis (not result-determining; hashed separately):**

- `gates.py`, `manifest.py`, `hypotheses.py`, `paper.py`, `figures.py`, `draft.py`, `reporting.py`, `context.py`, `fixtures.py`.

**Changed, result-determining (the code hash changed, so every earlier smoke or pilot run is stale by design):**

- `trust.py` (B4), `federated.py` (B4, atomic checkpoints, unreadable checkpoint, attempts), `config.py` (B4 key rejected), `io.py` (atomic save, analysis module list).
- `selection.py` (B3, merge) and `runner.py` (priorities, deadline, symbolic expansion) are analysis modules.

**Configs:**

- `base.yaml` (V1 key removed), `selection_rules.yaml` (B3, B4), `matrices/tune.yaml` (T1C = stage 0), `matrices/confirm.yaml` (priorities, RC-1, V1 placeholder removed).
- New: `gates.yaml`, `hypotheses.yaml`, `manifest/FROZEN_MANIFEST.{json,csv,sha256}`.

**Schemas:**

- `trust_rounds_csv` (`A_v1` forbidden), `tuning_selection` (the τ outcome is required).

**Scripts:**

- Rewritten: `run_plan.py`, `run_legacy_blocks.py`, `freeze_selections.py`.
- Changed: `prepare_data.py`.
- New: `build_manifest.py`, `status.py`, `analyze_results.py`, `make_figures.py`, `build_report.py`, `export_artifacts.py`, `colab/make_notebook.py`.

**Tests:**

- New: `test_final_b3_b4_gates_manifest.py` (28 tests), `test_final_reporting.py` (8 tests), `test_final_execution_equivalence.py` (13 tests, §5).
- Updated: `test_phaseC_trust_attacks.py` (V1 test replaced by 2 B4 tests), `test_phaseC_pipeline.py` (checkpoint behaviour; V1), `test_phaseC_regression_matrix.py`, `test_no_hardcoded_results.py` (now also scans `scripts/` and the notebooks).

**Documentation:**

- New: `13_documentation/FINAL_METHODOLOGY.md`, `../EXECUTION_GUIDE.md`, `../README.md`, this report, `../VALIDATION_REPORT.md`.
- Updated: `DP_MECHANISM.md` (B5 scope); historical pages marked as such.

**Notebook:**

- `../RUN_COMPLETE_FEDKGE_RESEARCH.ipynb` (outside the git repository, because it carries the expected commit).

---

## 5. Second directive of 2026-11-05 ("complete executable methodology")

The directive asked for no new design. It asked for:
- the redundant steps removed from the mandatory GPU path, with the accuracy sanity gate kept;
- a notebook in nine steps;
- execution-equivalent optimisations with evidence;
- an honest deadline assessment;
- one ZIP named `FedKGE_COMPLETE_EXECUTABLE_METHODOLOGY.zip`.

| ID | Change | Why | Evidence |
|---|---|---|---|
| RC-10 | `freeze_selections.py` freezes dataset by dataset, append-only | Before, freezing was refused while any dataset was still tuning. A changed value for a frozen dataset is still refused | `test_freeze_is_gated_append_only_and_per_dataset` |
| RC-11 | **Integrity fast path** (`integrity.py`): `serialize` joins the payload straight from the array buffer; `parse` reads the payload as a view instead of slicing a copy. One payload copy fewer at the sender and one fewer at every receiver | Integrity is 12–52 % of a federated T4 round (pilot); every hash and every verification is still computed | `test_integrity_fast_path_is_byte_identical` (bytes and SHA-256 identifiers equal to the previous implementation for 7 shapes); a WN18RR-sized round gives the same manifest chain ID and 9 % less integrity time on this CPU (`provenance/validation_2026-11-05/optimisation_equivalence/`); the smoke schedule rerun gives bit-identical federated outputs (`VALIDATION_REPORT.md`) |
| RC-12 | **Run order:** M1 (H3) moved from priority 7 to 3; old priorities 3–6 (legacy, R1q, baselines, descriptive blocks) moved down by one | Directive §7, "essential hypotheses first": all five hypothesis families become decidable after priority 3 (≈ 58 GPU-h instead of ≈ 118) | All 900 manifest cells are identical in every column except `priority` (`provenance/validation_2026-11-05/rc12_priority_reorder/RC12_identity_check.json`); only `confirm.yaml` changed among the configs; manifest test updated |
| RC-13 | **Notebook:** Steps 1–9 as listed in the directive. The CPU test suite left the mandatory path (opt-in appendix cell, `RUN_CPU_CHECKS = False`). The freeze runs automatically at the end of Step 4. Step 6 reports and completes the replications and runs L0 | Directive §1 and §4 | `test_notebook_cells_are_valid_python_and_follow_the_nine_steps`, `test_mandatory_path_runs_no_cpu_test_training_and_no_smoke_or_pilot_tier`, `test_sanity_gate_is_the_only_preliminary_training_and_precedes_tuning`; end-to-end notebook execution (`VALIDATION_REPORT.md`) |
| RC-14 | **Operator guide corrected.** The earlier guide allowed splitting datasets "per account" and did not forbid parallel sessions | Colab's FAQ lists "using multiple accounts to work around access or resource usage restrictions" as disallowed. Two sessions writing the same results folder can race on the shared selection and gate files | `EXECUTION_GUIDE.md` §2, `DEADLINE_PLAN.md` §5 |
| RC-15 | **Reproducible cost model** per priority and dataset (`provenance/deadline_cost_model/compute_costs.py`) | The earlier totals mixed a measured basis with a flat RC-1 bound | Total upper bound 118.3 GPU-h (was quoted as ≈ 119) |

**Considered and not done:**

| Option | Why not |
|---|---|
| sharing one hash among the receivers of a broadcast, or hashing in threads | weakens the mechanism or changes the reported integrity overhead |
| caching artifacts across runs | measured < 1 s per run |
| dropping the final-round checkpoint | it protects the post-training evaluation and MIA |
| fewer rounds, seeds or negatives | changes the science |
| tooling to merge results from several platforms | not needed for the approved one-folder workflow; it would add risk this week |

The training loops were already free of avoidable host–device synchronisation.

**Changed files in this step:**
- `01_fedkge_core/fedkge/integrity.py` (core: the core code hash changed, so the manifest was rebuilt);
- `fedkge/manifest.py` (legacy priority 4; priority descriptions);
- `10_configs/matrices/confirm.yaml` (priorities, header);
- `scripts/freeze_selections.py`, `scripts/run_legacy_blocks.py`, `scripts/run_plan.py` (help text);
- `colab/make_notebook.py`;
- tests: `test_final_b3_b4_gates_manifest.py` (priorities, freeze) and `test_final_execution_equivalence.py` (new);
- `13_documentation/FINAL_METHODOLOGY.md` §12, `revision/README.md`;
- the top-level README, EXECUTION_GUIDE, DEADLINE_PLAN (new) and VALIDATION_REPORT.

## 6. Third directive of 2026-11-07 ("independent, parallel-executable GPU phases")

**What was added:** an optional execution layer, `revision/parallel/`. It splits the frozen schedule into jobs that run concurrently in separate results roots. The jobs exchange only verified bundles and packs, and a master store validates and merges them. On 2026-11-05 (§5) this tooling was rejected as unnecessary risk for the one-folder workflow; it is now built because the owner asked for it. The risk is contained:
- it is optional;
- it calls only the unchanged core and entry-point functions;
- every imported run is re-checked: code, data, partition, selection, environment and run-id equality;
- an end-to-end smoke equivalence check gave bit-identical runs.

**What did not change:**
- the core code hash (`13b56d18…`);
- every config and the frozen manifest (`f86054ff…`);
- the 900 cells and 885 runs;
- the single-notebook route.

**Execution-order differences (no configuration or result changes):**
- the legacy replications may start before Stage-4 priorities 1–3;
- priorities interleave across workers, but each worker queue keeps 1 → 7;
- the gate-G-B barrier before tuning stage 1 is kept on purpose.

**Methodological defects found:** none.

**Documents:** `PARALLEL_ARCHITECTURE.md`, `PARALLEL_EXECUTION_GUIDE.md`, `PARALLEL_METHODOLOGY_PRESERVATION.md`. Evidence: `provenance/validation_2026-11-07_parallel/`.
