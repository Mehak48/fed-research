#!/usr/bin/env python3
"""Phase B PLANNING simulation: feasibility of the Dirichlet-over-relations partition (audit gap G15).

Simulates ONLY the partition rule of the revision package (fedkge/partition.py, scheme 'dirichlet_relation'):
for every relation r with n_r training triples, p_r ~ Dir(alpha * 1_K); the shuffled triples of r are cut at
floor(cumsum(p_r)[:-1] * n_r); a draw is accepted iff every client holds >= max(min_abs, min_frac * N / K) triples,
otherwise it is redrawn. Only per-relation COUNTS are needed (no triples, no entities, no training, no download).

Inputs
  FB15k-237: per-relation training counts from the legacy Phase 1 output rollup_by_relation.csv  [Legacy-measured]
  WN18RR   : per-relation training counts recalled from the literature (sum = 86,835 = official training size;
             proportions agree with the rounded relation shares in Allen et al. 2019, Table 3)       [UNVERIFIED]
             The binding check runs on the loaded data in Phase D.
Output: CSV with acceptance probability, expected attempts and client-heterogeneity statistics of accepted draws.
Labels: [Calculated - Phase B planning]; not an experimental result.
"""
from __future__ import annotations

import argparse
import csv
import sys

import numpy as np

WN18RR_RECALLED = {  # [UNVERIFIED] training-triple counts per relation (to be re-measured in Phase D)
    "_hypernym": 34796, "_derivationally_related_form": 29715, "_member_meronym": 7402, "_has_part": 4816,
    "_synset_domain_topic_of": 3116, "_instance_hypernym": 2921, "_also_see": 1299, "_verb_group": 1138,
    "_member_of_domain_region": 923, "_member_of_domain_usage": 629, "_similar_to": 80,
}


def gini(x: np.ndarray) -> float:
    x = np.sort(np.asarray(x, float))
    n = len(x)
    return float((2 * np.arange(1, n + 1) - n - 1).dot(x) / (n * x.sum()))


def draw(counts: np.ndarray, K: int, alpha: float, rng: np.random.Generator) -> np.ndarray:
    """Return (R, K) matrix of per-relation, per-client triple counts for one Dirichlet draw (revision's cut rule)."""
    M = np.zeros((len(counts), K), dtype=np.int64)
    for i, n in enumerate(counts):
        p = rng.dirichlet(np.full(K, alpha))
        cuts = (np.cumsum(p)[:-1] * n).astype(np.int64)
        M[i] = np.diff(np.concatenate([[0], cuts, [n]]))
    return M


def js_vs_global(M: np.ndarray) -> float:
    glob = M.sum(1) / M.sum()
    out = []
    for k in range(M.shape[1]):
        c = M[:, k] / max(M[:, k].sum(), 1)
        m = 0.5 * (c + glob)
        kl = lambda a, b: float(np.sum(a[a > 0] * np.log2(a[a > 0] / b[a > 0])))
        out.append(0.5 * kl(c, m) + 0.5 * kl(glob, m))
    return float(np.mean(out))


def simulate(name: str, counts: np.ndarray, K: int, alpha: float, draws: int, min_frac: float, min_abs: int,
             seed: int) -> dict:
    rng = np.random.default_rng(seed)
    N = int(counts.sum())
    m = int(max(min_abs, min_frac * N / K))
    acc, stats = 0, []
    for _ in range(draws):
        M = draw(counts, K, alpha, rng)
        sizes = M.sum(0)
        if sizes.min() >= m:
            acc += 1
            if len(stats) < 2000:
                share_top = M.max(1) / np.maximum(M.sum(1), 1)          # largest client's share of each relation
                stats.append({"gini": gini(sizes), "max_share": sizes.max() / N, "max_min": sizes.max() / sizes.min(),
                              "min_size": sizes.min(), "rels_per_client_mean": float((M > 0).sum(0).mean()),
                              "rels_per_client_min": int((M > 0).sum(0).min()),
                              "frac_rel_triples_in_dominant_client": float((M.max(1)).sum() / N),
                              "frac_relations_90pct_one_client": float((share_top >= 0.9).mean()),
                              "mean_js": js_vs_global(M)})
    p = acc / draws
    row = {"dataset": name, "n_relations": len(counts), "n_train": N, "K": K, "alpha": alpha,
           "min_client_size": m, "draws": draws, "accept_prob": p,
           "expected_attempts": (1 / p) if p > 0 else float("inf")}
    if stats:
        for k in stats[0]:
            v = np.array([s[k] for s in stats], float)
            row[f"{k}_median"] = float(np.median(v))
    return row


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--fb-rollup", required=True, help="legacy complete/rollup_by_relation.csv")
    ap.add_argument("--out-csv", required=True)
    ap.add_argument("--draws", type=int, default=4000)
    a = ap.parse_args(argv)
    fb = []
    with open(a.fb_rollup) as f:
        for r in csv.DictReader(f):
            fb.append(int(r["total_count"]))
    fb = np.array(fb)
    wn = np.array(list(WN18RR_RECALLED.values()))
    rows = []
    for name, counts in (("fb15k237 [legacy-measured counts]", fb), ("wn18rr [recalled counts, unverified]", wn)):
        for alpha in (0.1, 0.5, 1.0):
            rows.append(simulate(name, counts, 10, alpha, a.draws, 0.2, 1024, seed=20261028))
    keys = list(dict.fromkeys(k for r in rows for k in r))
    with open(a.out_csv, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader(); w.writerows(rows)
    print(f"FB15k-237 relations={len(fb)} sum={fb.sum()}; WN18RR relations={len(wn)} sum={wn.sum()}")
    for r in rows:
        print({k: (round(v, 3) if isinstance(v, float) else v) for k, v in r.items()
               if k in ("dataset", "alpha", "min_client_size", "accept_prob", "expected_attempts", "gini_median",
                        "max_share_median", "max_min_median", "rels_per_client_mean_median",
                        "frac_relations_90pct_one_client_median", "mean_js_median")})
    return 0


if __name__ == "__main__":
    sys.exit(main())
