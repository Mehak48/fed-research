# Compute and resource accounting (measured run time; integrity time also shown separately)

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| plan | hardware | dataset | runs | hours | integrity_hours |
|---|---|---|---|---|---|
| legacy | CPU | fb15k237 | 6 | 0.002178 | 0.0001791 |
| main (Stage 4) | CPU | codex_m | 64 | 0.02283 | 0.002055 |
| main (Stage 4) | CPU | fb15k237 | 64 | 0.02464 | 0.002207 |
| main (Stage 4) | CPU | wn18rr | 64 | 0.02817 | 0.002879 |
| legacy | CPU | ALL | 6 | 0.002178 | 0.0001791 |
| main (Stage 4) | CPU | ALL | 192 | 0.07564 | 0.007141 |
