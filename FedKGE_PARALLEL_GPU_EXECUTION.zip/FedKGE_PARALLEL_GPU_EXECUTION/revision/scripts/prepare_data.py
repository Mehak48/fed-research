#!/usr/bin/env python3
"""Fetch a benchmark dataset behind an explicit licence confirmation (Phase B G12 / Phase C section 10).

Nothing is downloaded unless --i-confirm-licence is given. The script first prints the source, the licence
terms found when the source was verified, and the citation. Archives are treated as untrusted: only the three
regular files train.txt / valid.txt / test.txt are extracted (no paths, no links), and the SHA-256 of every
fetched and extracted file is written to <data-dir>/<dataset>/source_manifest.json, which the loader re-checks.
Dataset files are never copied into deliverables (no redistribution).

Final package (2026-11-05): integrity check against PINNED SHA-256 values. The fetched archive / files must equal the
bytes the owner downloaded in her Colab session of 2026-11-04 (recorded in that session's dataset cards) and that were
re-downloaded identically on 2026-11-05. A different byte means the pinned upstream copy changed: the script stops
(nothing is written) instead of silently using different data. --allow-unpinned exists only for diagnosis and marks
the manifest as UNPINNED, which the research tiers must not use.

  python scripts/prepare_data.py --dataset codex_m --data-dir ../data_cache                 # prints terms only
  python scripts/prepare_data.py --dataset codex_m --data-dir ../data_cache --i-confirm-licence --operator-note "..."
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import io
import json
import sys
import tarfile
import urllib.request
from pathlib import Path

CONVE = "f3c0eb286025410fa5b4c04696c918264163d0ca"     # github.com/TimDettmers/ConvE HEAD on 2026-10-28
CODEX = "3132e426c2a6b643b70bad679905a3a6270be440"     # github.com/tsafavi/codex HEAD on 2026-10-28

SOURCES = {
    "fb15k237": {
        "kind": "tar.gz",
        "url": f"https://raw.githubusercontent.com/TimDettmers/ConvE/{CONVE}/FB15k-237.tar.gz",
        "official": "https://www.microsoft.com/en-us/download/details.aspx?id=52312 (FB15K-237.2.zip; blocked here)",
        "licence": ("The Microsoft release page states no dataset-specific licence. The KB triples are a subset of "
                    "FB15k (Bordes et al. 2013), derived from Freebase; Google's Freebase data dumps are distributed "
                    "under Creative Commons Attribution (CC BY 2.5) and 'free of charge for any purpose', subject to "
                    "the Freebase Terms of Service. The ClueWeb12 textual mentions in the Microsoft release are NOT "
                    "used. Use: research, with attribution; no redistribution in deliverables."),
        "citation": "Toutanova & Chen 2015; Bordes et al. 2013; Freebase (Google)",
        "expected": {"train": 272115, "valid": 17535, "test": 20466},
        "pinned_sha256": {"FB15k-237.tar.gz": "311df7930f842a02979eaa7a802484a6afe62303c07f915f1e6edbc30cbe05e8",
                          "train.txt": "6e4c2782169af21e9743f3b1d200886f5d595bf6bc504ec1351720949c5cdfae",
                          "valid.txt": "cf6309010852f6a8d47a45df830a426415d1ee6f7a3970a8376ff1fb81db4a5c",
                          "test.txt": "5711cf41623ceb4eacc50eb6108a3ca6565c7492e3caaf82a3e355cc660d1574"},
    },
    "wn18rr": {
        "kind": "tar.gz",
        "url": f"https://raw.githubusercontent.com/TimDettmers/ConvE/{CONVE}/WN18RR.tar.gz",
        "official": "same archive PyKEEN downloads (ConvE repository)",
        "licence": ("Derived from WordNet 3.0: the WordNet licence grants permission to use, copy, modify and "
                    "distribute for any purpose without fee, provided the copyright notice and disclaimer are kept. "
                    "ConvE repository code is MIT-licensed."),
        "citation": "Dettmers et al. 2018 (AAAI); Miller 1995 (WordNet)",
        "expected": {"train": 86835, "valid": 3034, "test": 3134},
        "pinned_sha256": {"WN18RR.tar.gz": "1eb9152f804c140d163462c0d49f65e5a0b30ab5fbb375c5e3353c11a6249060",
                          "train.txt": "038612e783c215ee5f3ca9fbfca27b8d0739be1028fe4ee7c174aecf0b83d5df",
                          "valid.txt": "453ce7202afa58094a04d2b1560ee2b02660f1c260b32ce6651c8ccedd1028ab",
                          "test.txt": "0383bceaaa1096cf3c03ec021ed0048068e2355dbfc0239b292cefdac821cec5"},
    },
    "codex_m": {
        "kind": "raw",
        "urls": {k: f"https://raw.githubusercontent.com/tsafavi/codex/{CODEX}/data/triples/codex-m/{k}.txt"
                 for k in ("train", "valid", "test")},
        "official": "https://github.com/tsafavi/codex",
        "licence": ("Repository: 'This project is licensed under the terms of the MIT license.' Triples extracted "
                    "from Wikidata (CC0). Wikipedia text extracts and the hard-negative files are not used."),
        "citation": "Safavi & Koutra 2020 (EMNLP)",
        "expected": {"train": 185584, "valid": 10310, "test": 10311},
        "pinned_sha256": {"train.txt": "d99c3437ab51690391a26d96976adf6e5494dba7ef6902e77000551bfa566556",
                          "valid.txt": "11c323096367354940846b9ed940c5dabddc1d20a70474222babe7e7fd28b28d",
                          "test.txt": "0575ce05e4ce915e395bb4f708e8df9547989dd4c8c71407cbfd78c19daffcf7"},
    },
}


def check_pins(src: dict, fetched: dict, files: dict) -> list:
    """Mismatches between the fetched bytes and the pinned SHA-256 values (empty list = identical bytes)."""
    pins, bad = src.get("pinned_sha256", {}), []
    for url, h in fetched.items():
        name = url.rsplit("/", 1)[-1]
        if name in pins and name.endswith(".tar.gz") and pins[name] != h:
            bad.append(f"{name}: {h} != pinned {pins[name]}")
    for name, b in files.items():
        if name in pins and pins[name] != sha256(b):
            bad.append(f"{name}: {sha256(b)} != pinned {pins[name]}")
    return bad


def sha256(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def fetch(url: str) -> bytes:
    with urllib.request.urlopen(url, timeout=120) as r:
        return r.read()


def safe_extract_three(blob: bytes) -> dict:
    out = {}
    with tarfile.open(fileobj=io.BytesIO(blob), mode="r:gz") as tf:
        for m in tf.getmembers():
            name = m.name.split("/")[-1]
            if name in ("train.txt", "valid.txt", "test.txt") and m.isfile():
                if name in out:
                    raise RuntimeError(f"archive contains {name} twice")
                out[name] = tf.extractfile(m).read()
    if set(out) != {"train.txt", "valid.txt", "test.txt"}:
        raise RuntimeError(f"archive does not contain the three split files: {sorted(out)}")
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True, choices=sorted(SOURCES))
    ap.add_argument("--data-dir", required=True)
    ap.add_argument("--i-confirm-licence", action="store_true")
    ap.add_argument("--operator-note", default="")
    ap.add_argument("--allow-unpinned", action="store_true", help="diagnosis only: keep data whose bytes differ from the "
                    "pinned SHA-256 values (marked UNPINNED; never for research runs)")
    a = ap.parse_args(argv)
    src = SOURCES[a.dataset]
    print(f"Dataset   : {a.dataset}\nSource    : {src.get('url') or src['urls']}\nOfficial  : {src['official']}\n"
          f"Licence   : {src['licence']}\nCitation  : {src['citation']}")
    if not a.i_confirm_licence:
        print("\nNOT downloaded: re-run with --i-confirm-licence after reading the terms above.")
        return 2
    if not a.operator_note.strip():
        print("\nNOT downloaded: --operator-note must say who confirmed the licence terms, and when.")
        return 2
    d = Path(a.data_dir) / a.dataset
    if (d / "source_manifest.json").exists():
        print(f"{d} already prepared; verify with the loader (checksums) - nothing re-downloaded.")
        return 0
    d.mkdir(parents=True, exist_ok=True)
    fetched = {}
    if src["kind"] == "tar.gz":
        blob = fetch(src["url"])
        fetched[src["url"]] = sha256(blob)
        files = safe_extract_three(blob)
    else:
        files = {}
        for k, u in src["urls"].items():
            b = fetch(u)
            fetched[u] = sha256(b)
            files[f"{k}.txt"] = b
    bad = check_pins(src, fetched, files)
    if bad and not a.allow_unpinned:
        d.rmdir() if not any(d.iterdir()) else None
        print("\nSTOP: the downloaded bytes differ from the pinned SHA-256 values (upstream copy changed?):\n  "
              + "\n  ".join(bad) + "\nNothing was written. See EXECUTION_GUIDE.md, 'Dataset checksum mismatch'.")
        return 3
    counts = {}
    for name, b in files.items():
        (d / name).write_bytes(b)
        counts[name[:-4]] = sum(1 for ln in b.decode("utf-8").splitlines() if ln.strip())
    man = {"dataset": a.dataset, "retrieved_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
           "fetched_sha256": fetched, "files_sha256": {n: sha256(b) for n, b in files.items()},
           "line_counts": counts, "expected_counts_official": src["expected"],
           "counts_match_official": counts == src["expected"], "licence": src["licence"],
           "citation": src["citation"], "official_source": src["official"],
           "licence_confirmed_flag": True, "operator_note": a.operator_note,
           "pinned_sha256_match": not bad, "UNPINNED": bool(bad)}
    (d / "source_manifest.json").write_text(json.dumps(man, indent=2))
    print(json.dumps({k: man[k] for k in ("line_counts", "expected_counts_official", "counts_match_official")}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
