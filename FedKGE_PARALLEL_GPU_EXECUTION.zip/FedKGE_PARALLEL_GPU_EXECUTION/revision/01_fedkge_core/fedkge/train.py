"""Non-private local training (one federated round on one client, or centralised training)."""
from __future__ import annotations

from typing import Dict, Tuple

import torch

from .model import Params, margin_loss_per_example
from .sampling import sample_negatives


def local_train(params: Params, triples: torch.Tensor, n_ent: int, tcfg: Dict, normalize: bool,
                margin: float, gen: torch.Generator, extra_triples: torch.Tensor | None = None) -> Tuple[Params, Dict]:
    """Adam with fresh state; `local_epochs` passes over the client's triples.
    extra_triples: attacker-injected triples (targeted data poisoning), concatenated to the local data."""
    data = triples if extra_triples is None else torch.cat([triples, extra_triples], 0)
    ent = params["ent"].detach().clone().requires_grad_(True)
    rel = params["rel"].detach().clone().requires_grad_(True)
    opt = torch.optim.Adam([ent, rel], lr=float(tcfg["lr"]))
    B, N = int(tcfg["batch_size"]), len(data)
    drop_last = bool(tcfg.get("drop_last", False))
    grad_clip = tcfg.get("grad_clip")
    losses, steps = [], 0
    for _ in range(int(tcfg["local_epochs"])):
        perm = torch.randperm(N, generator=gen, device=data.device)
        for b in range(0, N, B):
            idx = perm[b:b + B]
            if drop_last and len(idx) < B:
                break
            h, r, t = data[idx, 0], data[idx, 1], data[idx, 2]
            nh, nt = sample_negatives(h, t, n_ent, int(tcfg["neg_samples"]), tcfg["neg_mode"], gen)
            loss = margin_loss_per_example(ent[h], rel[r], ent[t], ent[nh], ent[nt], margin, normalize).mean()
            opt.zero_grad(set_to_none=True)
            loss.backward()
            if grad_clip:
                torch.nn.utils.clip_grad_norm_([ent, rel], float(grad_clip))
            opt.step()
            losses.append(loss.detach())
            steps += 1
    mean_loss = float(torch.stack(losses).mean()) if losses else float("nan")
    return {"ent": ent.detach(), "rel": rel.detach()}, {"loss": mean_loss, "steps": steps, "n_examples": N}
