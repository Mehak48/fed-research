#!/usr/bin/env python3
"""Publication figures from recorded runs (PNG 300 dpi + PDF, each with its data table and a figure manifest).

  python scripts/make_figures.py --tier final [--results R]          -> <R>/final/figures/
  python scripts/make_figures.py --tier smoke                        -> watermarked software check
  python scripts/make_figures.py --fixture --out DIR                  -> FIXTURE software check (random numbers)
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from _common import Manifest
from analyze_results import make_context


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results"); ap.add_argument("--tier", default="final", choices=["final", "smoke"])
    ap.add_argument("--fixture", action="store_true"); ap.add_argument("--out")
    a = ap.parse_args(argv)
    if a.fixture and not a.out:
        ap.error("--fixture needs --out (fixture outputs never go into a results root)")
    from fedkge.hypotheses import evaluate_hypotheses
    from fedkge.reporting import run_figures
    ctx = make_context(a)
    out = Path(a.out) if a.out else ctx.paths.base / "figures"
    hyp = evaluate_hypotheses(ctx.runs, ctx.hyp, ctx.selection, ctx.tier, ctx.env_of)
    mp = run_figures(ctx, hyp, out)
    print(mp.with_suffix(".md").read_text())
    if not a.fixture:
        man = Manifest(ctx.root, f"figures_{a.tier}"); man.output(mp); man.close("COMPLETE")
    return 0


if __name__ == "__main__":
    sys.exit(main())
