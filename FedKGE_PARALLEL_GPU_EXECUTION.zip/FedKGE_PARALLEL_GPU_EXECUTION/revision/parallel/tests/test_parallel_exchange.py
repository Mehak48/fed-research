"""File-exchange safety: atomic bundles and packs, tamper detection, append-only selection installs, and the
cross-worker environment lock of the master store."""
import json
import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fedkge_parallel.bundles import (_merge_gate, _merge_selection, install_pack, open_zip, verified,  # noqa: E402
                                     write_zip_atomically)
from fedkge_parallel.common import IntegrityError, Layout, sha256_bytes  # noqa: E402


def _zip(path, members, head="BUNDLE.json", meta=None):
    meta = dict(meta or {"kind": "result_bundle"})
    meta["files_sha256"] = {n: sha256_bytes(b) for n, b in members.items()}
    m = dict(members)
    m[head] = json.dumps(meta).encode()
    return write_zip_atomically(path, m)


def test_sidecar_and_member_hashes(tmp_path):
    p = tmp_path / "b.zip"
    _zip(p, {"runs/r/final.json": b"{}"})
    ok, sha, _ = verified(p)
    assert ok and sha
    z, meta = open_zip(p)
    assert meta["kind"] == "result_bundle"
    (p.with_name(p.name + ".sha256")).write_text("0" * 64 + "  b.zip\n")
    assert not verified(p)[0]
    q = tmp_path / "c.zip"
    assert not verified(q)[0]                    # no sidecar yet = not usable yet


def test_tampered_member_is_refused(tmp_path):
    p = tmp_path / "b.zip"
    meta = {"kind": "result_bundle", "files_sha256": {"runs/r/final.json": sha256_bytes(b"{}")}}
    with zipfile.ZipFile(p, "w") as z:
        z.writestr("runs/r/final.json", b'{"x": 1}')
        z.writestr("BUNDLE.json", json.dumps(meta))
    with pytest.raises(IntegrityError):
        open_zip(p)


def test_unsafe_member_names_are_refused(tmp_path):
    p = tmp_path / "b.zip"
    with zipfile.ZipFile(p, "w") as z:
        z.writestr("../evil.py", b"x")
        z.writestr("BUNDLE.json", json.dumps({"files_sha256": {}}))
    with pytest.raises(IntegrityError):
        open_zip(p)


def test_selection_merge_is_append_only():
    old = {"fb15k237": {"T2a": {"dp": {"q": 0.05}}}, "_T2a_rule": {"x": 1}}
    new = {"fb15k237": {"T2a": {"dp": {"q": 0.05}}, "T2b": {"dp": {"clip": 1.0}}}, "wn18rr": {"T2a": {"dp": {"q": 0.1}}}}
    m = _merge_selection(old, new, "t")
    assert m["fb15k237"]["T2b"] == {"dp": {"clip": 1.0}} and "wn18rr" in m and "_T2a_rule" in m
    with pytest.raises(IntegrityError):
        _merge_selection(old, {"fb15k237": {"T2a": {"dp": {"q": 0.1}}}}, "t")
    g_old = {"rule_sha256": "a", "datasets": {"fb15k237": {"status": "PASSED"}}}
    assert set(_merge_gate(g_old, {"rule_sha256": "a", "datasets": {"wn18rr": {"status": "PASSED"}}}, "t")["datasets"]) \
        == {"fb15k237", "wn18rr"}
    with pytest.raises(IntegrityError):
        _merge_gate(g_old, {"rule_sha256": "a", "datasets": {"fb15k237": {"status": "FAILED"}}}, "t")
    with pytest.raises(IntegrityError):
        _merge_gate(g_old, {"rule_sha256": "b", "datasets": {}}, "t")


def test_frozen_pack_install(tmp_path):
    sel1 = json.dumps({"fb15k237": {"tau": {"aggregation": {"tau": 3.0}}}}).encode()
    fz1 = json.dumps({"datasets": ["fb15k237"]}).encode()
    p1 = tmp_path / "packs" / "p1.zip"
    _zip(p1, {"final/selection/tuning.json": sel1, "final/selection/FROZEN.json": fz1}, "PACK.json",
         {"kind": "release_pack", "tier": "final", "frozen_sha256": sha256_bytes(sel1), "jobs": []})
    root = tmp_path / "worker"
    install_pack(p1, root, log=lambda *a: None)
    assert (root / "final/selection/tuning.json").read_bytes() == sel1
    sel2 = json.dumps({"fb15k237": {"tau": {"aggregation": {"tau": 3.0}}}, "wn18rr": {"tau": {}}}).encode()
    p2 = tmp_path / "packs" / "p2.zip"
    _zip(p2, {"final/selection/tuning.json": sel2, "final/selection/FROZEN.json":
              json.dumps({"datasets": ["fb15k237", "wn18rr"]}).encode()}, "PACK.json",
         {"kind": "release_pack", "tier": "final", "frozen_sha256": sha256_bytes(sel2), "jobs": []})
    install_pack(p2, root, log=lambda *a: None)
    assert (root / "final/selection/tuning.json").read_bytes() == sel2
    bad = json.dumps({"fb15k237": {"tau": {"aggregation": {"tau": 4.0}}}}).encode()
    p3 = tmp_path / "packs" / "p3.zip"
    _zip(p3, {"final/selection/tuning.json": bad, "final/selection/FROZEN.json": fz1}, "PACK.json",
         {"kind": "release_pack", "tier": "final", "frozen_sha256": sha256_bytes(bad), "jobs": []})
    with pytest.raises(IntegrityError):
        install_pack(p3, root, log=lambda *a: None)
    assert (root / "final/selection/tuning.json").read_bytes() == sel2          # nothing changed


def test_master_environment_lock_across_workers(tmp_path):
    from fedkge_parallel.store import Master
    m = Master(Layout(tmp_path), "research")
    a = {"device_type": "cuda", "gpu_name": "Tesla T4", "torch": "2.9.0+cu126", "cuda": "12.6", "python_minor": "3.12"}
    m.env_check("final", "fb15k237", a, "bundle-1")
    m.env_check("final", "fb15k237", dict(a), "bundle-2")                       # same class: fine
    m.env_check("final", "wn18rr", {**a, "gpu_name": "NVIDIA L4"}, "bundle-3")  # another group: its own class
    with pytest.raises(IntegrityError):
        m.env_check("final", "fb15k237", {**a, "gpu_name": "NVIDIA L4"}, "bundle-4")
    with pytest.raises(IntegrityError):
        m.env_check("final", "fb15k237", {**a, "torch": "2.10.0+cu126"}, "bundle-5")
    with pytest.raises(IntegrityError):
        m.env_check("tune", "codex_m", None, "bundle-6")                        # research tiers need a signature
    s = Master(Layout(tmp_path / "s"), "smoke")
    s.env_check("smoke", "fb15k237", a, "x")
    s.env_check("smoke", "fb15k237", {**a, "gpu_name": "other"}, "y")           # check tier: recorded, not enforced
