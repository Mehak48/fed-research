The GPU pilot kit exactly as the owner ran it on 2026-11-04 (code zip SHA-256 in SHA256SUMS.txt).
It predates fix PC-6; the Stage 3 kit must be built from the current code in revision/.
