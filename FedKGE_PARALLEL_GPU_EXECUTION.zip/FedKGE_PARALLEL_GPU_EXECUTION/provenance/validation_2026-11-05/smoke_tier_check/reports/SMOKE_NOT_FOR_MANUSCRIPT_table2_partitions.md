# Table 2 — client partition statistics

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| dataset | partition | seeds | n_clients | size_gini_mean | size_max_share_mean | mean_relation_js | mean_pairwise_entity_jaccard | attempts_max | min_size_min |
|---|---|---|---|---|---|---|---|---|---|
| CoDEx-M | centralized_n1 | 42 | 1 | 0 | 1 | 0 |  | 1 | 0 |
| CoDEx-M | dirichlet_a0.1_n10 | 42 | 10 | 0.3849 | 0.3317 | 0.4809 | 0.02581 | 1 | 64 |
| CoDEx-M | dirichlet_a0.5_n10 | 42 | 10 | 0.2263 | 0.1863 | 0.2421 | 0.04571 | 1 | 64 |
| CoDEx-M | dirichlet_a1.0_n10 | 42 | 10 | 0.2263 | 0.21 | 0.1321 | 0.05806 | 1 | 64 |
| CoDEx-M | iid_n10 | 42 | 10 | 0 | 0.1 | 0.02207 | 0.07244 | 1 | 0 |
| FB15k-237 | centralized_n1 | 42 | 1 | 0 | 1 | 0 |  | 1 | 0 |
| FB15k-237 | dirichlet_a0.1_n10 | 42 | 10 | 0.1939 | 0.1557 | 0.5402 | 0.039 | 1 | 64 |
| FB15k-237 | dirichlet_a0.5_n10 | 42 | 10 | 0.1555 | 0.155 | 0.2893 | 0.0514 | 1 | 64 |
| FB15k-237 | dirichlet_a1.0_n10 | 42 | 10 | 0.09347 | 0.1463 | 0.1911 | 0.05942 | 1 | 64 |
| FB15k-237 | iid_n10 | 42 | 10 | 0 | 0.1 | 0.1189 | 0.0612 | 1 | 0 |
| FB15k-237 | relation_disjoint_legacy_n5 | 42 | 5 | 0.1596 | 0.3133 | 0.6153 | 0.03217 | 1 | 0 |
| WN18RR | centralized_n1 | 42 | 1 | 0 | 1 | 0 |  | 1 | 0 |
| WN18RR | dirichlet_a0.1_n10 | 42 | 10 | 0.3662 | 0.294 | 0.4165 | 0.01005 | 5 | 64 |
| WN18RR | dirichlet_a0.5_n10 | 42 | 10 | 0.2756 | 0.191 | 0.1726 | 0.0153 | 1 | 64 |
| WN18RR | dirichlet_a1.0_n10 | 42 | 10 | 0.2194 | 0.1473 | 0.08258 | 0.01816 | 1 | 64 |
| WN18RR | iid_n10 | 42 | 10 | 0 | 0.1 | 0.006133 | 0.02198 | 1 | 0 |
