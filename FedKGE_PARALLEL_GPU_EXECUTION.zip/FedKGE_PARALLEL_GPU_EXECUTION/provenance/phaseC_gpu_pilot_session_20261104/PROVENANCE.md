# The owner's Colab GPU session of 2026-11-04 (Phase C pilot) — record only, NOT results

* File: `colab_pilot_results_20261104T165553Z_pilot_done.zip`, SHA-256
  `235f21de87754d9b82311eac995f77c8ab13794b2c4a7c15f14b4653cf855814`, exactly as the owner returned it (never edited).
* Produced by the Phase C pilot kit (`../../history/phaseC_handoff_2026-11-04/colab_kit/`, code zip `4fb27cf8...`)
  on a Tesla T4, torch 2.11.0+cu130, Python 3.13.16: tests 130 passed / 1 skipped, 9 GPU smoke runs, 2 x 18 pilot
  configurations of 2 rounds each, 0 failures.
* Use: GPU timing and memory measurements behind the budget (`../../audit/phaseC/pilot_plan.md` sections 4-5), the
  dataset hashes pinned in `scripts/prepare_data.py`, and the GPU code path check. Pilot runs stop after 2 rounds
  (flagged `partial_run`); their MRR values are meaningless and are never results.
* The code that produced it predates fix PC-6 and all final-package changes; its run folders are stale for the
  final code by construction.
