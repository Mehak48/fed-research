"""Evaluation (filtered head+tail, realistic ties) against brute force; negative sampling correctness."""
import numpy as np
import torch

from fedkge.evaluate import FilterIndex, evaluate, evaluate_legacy
from fedkge.sampling import sample_negatives


def _brute(params, trip, all_true, normalize):
    E = params["ent"].numpy(); Rl = params["rel"].numpy()
    n = lambda x: x / np.linalg.norm(x, axis=-1, keepdims=True) if normalize else x
    En = n(E)
    known_t, known_h = {}, {}
    for h, r, t in all_true:
        known_t.setdefault((h, r), set()).add(t); known_h.setdefault((r, t), set()).add(h)
    ranks = []
    for h, r, t in trip:
        s = -np.linalg.norm(En[h] + Rl[r] - En, axis=1)
        mask = np.ones(len(E), bool); mask[list(known_t[(h, r)] - {t})] = False
        g = np.sum(s[mask] > s[t]); eq = np.sum(s[mask] == s[t]) - 1
        ranks.append(1 + g + eq / 2)
        s = -np.linalg.norm(En + Rl[r] - En[t], axis=1)
        mask = np.ones(len(E), bool); mask[list(known_h[(r, t)] - {h})] = False
        g = np.sum(s[mask] > s[h]); eq = np.sum(s[mask] == s[h]) - 1
        ranks.append(1 + g + eq / 2)
    return np.mean(1 / np.array(ranks))


def _kg(seed=0, E=40, R=4, N=300):
    rng = np.random.default_rng(seed)
    trip = np.unique(np.stack([rng.integers(0, E, N), rng.integers(0, R, N), rng.integers(0, E, N)], 1), axis=0)
    return trip, E, R


def test_filtered_head_tail_realistic_matches_bruteforce():
    trip, E, R = _kg()
    g = torch.Generator().manual_seed(0)
    p = {"ent": torch.randn(E, 8, generator=g, dtype=torch.float64), "rel": torch.randn(R, 8, generator=g, dtype=torch.float64)}
    test = trip[:60]
    for norm in (True, False):
        res = evaluate(p, test, FilterIndex(trip), norm, "cpu", batch_size=16)
        assert abs(res["mrr"] - _brute(p, test, trip, norm)) < 1e-9
        assert res["n_queries"] == 2 * len(test) and res["tie_policy"] == "realistic"


def test_ties_are_not_optimistic():
    trip, E, R = _kg(1)
    p = {"ent": torch.ones(E, 4), "rel": torch.zeros(R, 4)}         # every entity scores identically
    res = evaluate(p, trip[:20], FilterIndex(trip), False, "cpu")
    assert res["mrr_optimistic"] == 1.0
    assert res["mrr"] < 0.2 and res["mrr_pessimistic"] < res["mrr"]


def test_filter_removes_other_true_answers():
    E, R = 5, 1
    trip = np.array([[0, 0, 1], [0, 0, 2]])
    p = {"ent": torch.tensor([[0., 0], [1, 0], [0.9, 0], [5, 5], [6, 6]]), "rel": torch.tensor([[0.9, 0.]])}
    # tail query (0,0,?) for t=1: entity 2 scores better but is a true answer -> filtered -> rank 1
    res = evaluate(p, trip[:1], FilterIndex(trip), False, "cpu")
    assert res["tail"]["mrr"] == 1.0


def test_legacy_protocol_is_labelled_and_tail_only():
    trip, E, R = _kg(2)
    p = {"ent": torch.randn(E, 4), "rel": torch.randn(R, 4)}
    r = evaluate_legacy(p, trip, trip, True, "cpu", n=30, seed=0)
    assert "legacy" in r["protocol"] and "tail-only" in r["protocol"]


def test_correct_negatives_never_copy_positive_and_corrupt_one_side():
    g = torch.Generator().manual_seed(0)
    h = torch.randint(0, 50, (2000,), generator=g); t = torch.randint(0, 50, (2000,), generator=g)
    nh, nt = sample_negatives(h, t, 50, 16, "correct", g)
    same_h, same_t = nh == h[:, None], nt == t[:, None]
    assert torch.all(same_h ^ same_t)                     # exactly one side changed
    assert not torch.any(same_h & same_t)


def test_legacy_p4_bug_is_reproduced():
    g = torch.Generator().manual_seed(0)
    h = torch.randint(0, 1000, (20000,), generator=g); t = torch.randint(0, 1000, (20000,), generator=g)
    nh, nt = sample_negatives(h, t, 1000, 1, "p4_legacy", g)
    ident = float(((nh[:, 0] == h) & (nt[:, 0] == t)).float().mean())
    assert 0.22 < ident < 0.28                            # ~25% of 'negatives' equal the positive (old bug)
