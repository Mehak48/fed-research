"""Dataset validation, partition determinism/hashing, config guards."""
import numpy as np
import pytest

from fedkge.config import ConfigError, config_hash, deep_merge, load_yaml, resolve_placeholders, validate
from fedkge.data import build_artifact, load_artifact, make_synthetic, validate_splits
from fedkge.io import IntegrityError
from fedkge.partition import assign, build_partition, canonical_spec, load_partition, spec_key
from conftest import CONFIG_DIR


def test_validation_detects_leakage_and_bad_ids():
    tr, va, te, ent, rel = make_synthetic(seed=1)
    rep = validate_splits(tr, va, np.vstack([te, tr[:3]]), len(ent), len(rel))
    assert not rep["ok"] and rep["train_test_overlap"] == 3
    bad = te.copy(); bad[0, 0] = len(ent) + 5
    assert not validate_splits(tr, va, bad, len(ent), len(rel))["ok"]


def test_artifact_hash_reproducible(tmp_path):
    cfg = load_yaml(CONFIG_DIR / "datasets" / "synthetic.yaml")
    a = build_artifact(cfg, tmp_path / "a"); b = build_artifact(cfg, tmp_path / "b")
    assert a["content_hash"] == b["content_hash"]
    d = load_artifact(tmp_path / "a", a["content_hash"])
    assert len(d.vsel) + len(d.vroot) == len(d.valid)
    assert not (set(map(tuple, d.vsel.tolist())) & set(map(tuple, d.vroot.tolist())))
    (tmp_path / "a" / "labels.json").write_text("{}")         # tampering is detected
    with pytest.raises(IntegrityError):
        load_artifact(tmp_path / "a")


SPECS = [{"scheme": "iid", "n_clients": 10},
         {"scheme": "dirichlet_relation", "alpha": 0.1, "n_clients": 10, "min_client_frac": 0.05, "min_client_abs": 20, "max_attempts": 20000},
         {"scheme": "dirichlet_relation", "alpha": 1.0, "n_clients": 10, "min_client_frac": 0.05, "min_client_abs": 20, "max_attempts": 20000},
         {"scheme": "relation_disjoint_legacy", "n_clients": 5}]


@pytest.mark.parametrize("spec", SPECS)
def test_partition_deterministic_and_seed_dependent(spec):
    tr = make_synthetic(seed=3)[0]
    a, b, c = assign(tr, spec, 42)["client"], assign(tr, spec, 42)["client"], assign(tr, spec, 123)["client"]
    assert np.array_equal(a, b)
    if spec["scheme"] != "relation_disjoint_legacy":
        assert not np.array_equal(a, c)
    assert set(np.unique(a)) == set(range(spec["n_clients"]))


def test_legacy_partition_is_relation_disjoint():
    tr = make_synthetic(seed=3)[0]
    cl = assign(tr, SPECS[3], 0)["client"]
    for r in np.unique(tr[:, 1]):
        assert len(np.unique(cl[tr[:, 1] == r])) == 1


def test_partition_artifact_hash_and_upstream_check(tmp_path):
    tr = make_synthetic(seed=3)[0]
    m1 = build_partition(tr, 8, SPECS[1], 42, tmp_path, "a" * 64)
    m2 = build_partition(tr, 8, SPECS[1], 42, tmp_path / "x", "a" * 64)
    assert m1["content_hash"] == m2["content_hash"]
    assert load_partition(tmp_path, SPECS[1], 42, "a" * 64)["client"].shape == (len(tr),)
    with pytest.raises(IntegrityError):
        load_partition(tmp_path, SPECS[1], 42, "b" * 64)          # built from different Phase 1 data
    with pytest.raises(IntegrityError):
        load_partition(tmp_path, SPECS[1], 123, "a" * 64)         # missing -> FAIL, never re-derived silently


def _cfg(**over):
    base = load_yaml(CONFIG_DIR / "base.yaml")
    cfg = deep_merge(base, {"tier": "smoke", "phase": "p4", "seed": 42, "dataset": {"name": "synthetic"}}, over)
    return cfg


def test_config_guards():
    validate(_cfg())
    with pytest.raises(ConfigError):
        validate(_cfg(train={"warm_start": "phase3.pt"}))
    with pytest.raises(ConfigError):
        validate(_cfg(dp={"enabled": True}, train={"local_epochs": 3}))
    with pytest.raises(ConfigError):
        validate(_cfg(dp={"enabled": True, "schedule": {"shape": "fixed", "rho": 0.5}}))
    with pytest.raises(ConfigError):
        validate(_cfg(train={"neg_mode": "p4_legacy"}))           # legacy negatives need exactly 1
    with pytest.raises(ConfigError):
        validate(_cfg(dp={"enabled": True, "mode": "fixed_sigma", "sigma": 1.0, "stop_rule": "rdp_budget"}))


def test_hash_ignores_labels_only():
    a = _cfg(); b = _cfg(block="X", name="Y")
    assert config_hash(a) == config_hash(b)
    assert config_hash(a) != config_hash(_cfg(seed=123))


def test_missing_selection_fails():
    with pytest.raises(ConfigError):
        resolve_placeholders({"dp": {"clip": "${sel:dp_selection.fb15k237.clip}"}}, {})
