"""Final package: the statistical analysis, tables, figures and results draft, checked on hand-made tables and on the
clearly labelled FIXTURE (random numbers). These tests check the code paths and the honesty rules (no invented
values, PENDING for missing results, Holm with fixed family size, non-inferiority logic, watermarks), never results."""
import json

import numpy as np
import pandas as pd
import pytest

from conftest import CONFIG_DIR, PKG
from fedkge.config import load_yaml

HYP = load_yaml(CONFIG_DIR / "hypotheses.yaml")
SEEDS = [42, 123, 256, 512, 1024]


def _runs(spec):
    """spec: list of (block, dataset, where-dict, values per seed (list of 5), metric)."""
    rows = []
    for blk, ds, where, vals, metric in spec:
        for s, v in zip(SEEDS, vals):
            rows.append({"block": blk, "dataset": ds, "seed": s, "run_id": f"{blk}_{ds}_{s}_{json.dumps(where)}",
                         metric: v, "runtime.device": "cuda", **where})
    return pd.DataFrame(rows)


def test_hypotheses_file_matches_the_preregistration():
    F = HYP["families"]
    assert HYP["alpha_one_sided"] == 0.025 and HYP["correction"] == "holm_within_family" and HYP["seed_set"] == SEEDS
    assert F["H1"]["threshold"] == 0.9 and F["H2b"]["threshold"] == 0.95 and F["H2"]["keep"] == 0.65
    assert F["H3"]["factor"] == 0.75 and len(F["H2"]["attacks"]) == 7
    assert F["H2b"]["denominator"] == {"block": "DP2", "where": {"cfg.dp.target_epsilon": 4.0}}


def test_h2b_non_inferiority_needs_the_bound_not_the_point_estimate():
    from fedkge.hypotheses import evaluate_hypotheses
    base = [0.20, 0.21, 0.19, 0.20, 0.22]
    noisy = [b * f for b, f in zip(base, [1.10, 0.86, 1.05, 0.88, 1.03])]       # geo-mean ~0.98, wide interval
    tight = [b * f for b, f in zip(base, [1.01, 1.00, 1.02, 0.99, 1.01])]       # geo-mean ~1.01, tight interval
    r = _runs([("DP2", "fb15k237", {"cfg.dp.target_epsilon": 4.0}, base, "test.mrr"),
               ("R1p", "fb15k237", {}, noisy, "test.mrr"),
               ("DP2", "wn18rr", {"cfg.dp.target_epsilon": 4.0}, base, "test.mrr"),
               ("R1p", "wn18rr", {}, tight, "test.mrr")])
    res = evaluate_hypotheses(r, HYP, {}, "final")
    m = {x["dataset"]: x for x in res["families"]["H2b"]["members"]}
    assert m["fb15k237"]["estimate"]["ratio_geo_mean"] > 0.95 and m["fb15k237"]["verdict"] == "NOT_SUPPORTED"
    assert m["fb15k237"]["estimate"]["ratio_lower_one_sided_97_5"] < 0.95
    assert m["wn18rr"]["verdict"] == "SUPPORTED" and m["wn18rr"]["estimate"]["ratio_lower_one_sided_97_5"] > 0.95
    assert m["codex_m"]["status"] == "MISSING_RUNS" and m["codex_m"]["p_holm"] == 1.0
    assert res["families"]["H2b"]["holm_status"].startswith("PROVISIONAL")
    # Holm over the full pre-registered family of 3: the missing member still counts
    p = m["wn18rr"]["p_one_sided"]
    assert p < m["fb15k237"]["p_one_sided"] and m["wn18rr"]["p_holm"] == pytest.approx(min(1.0, 3 * p))


def test_family_size_never_shrinks_and_not_testable_enters_with_p1():
    from fedkge.hypotheses import evaluate_hypotheses
    res = evaluate_hypotheses(pd.DataFrame(columns=["block", "dataset", "seed", "run_id"]), HYP, {}, "final")
    sizes = {k: v["n_members"] for k, v in res["families"].items()}
    assert sizes == {"H1": 3, "H2b": 3, "H2": 21, "H3": 3, "HS": 3}
    assert all(m["p_holm"] == 1.0 and m["verdict"] == "PENDING" for f in res["families"].values() for m in f["members"])
    hs = evaluate_hypotheses(pd.DataFrame(columns=["block", "dataset", "seed", "run_id"]), HYP,
                             {"fb15k237": {"T3": {"dp": {"schedule": {"shape": "fixed", "rho": 1.0}}}}}, "final")
    m = hs["families"]["HS"]["members"][0]
    assert m["status"] == "NOT_TESTABLE" and "fixed" in m["reason"] and m["p_holm"] == 1.0


def test_h2_effectiveness_gate_and_h3_gates():
    from fedkge.hypotheses import evaluate_hypotheses
    clean = [0.20, 0.21, 0.19, 0.20, 0.22]
    spec = [("DP2", "fb15k237", {"cfg.dp.target_epsilon": 4.0}, clean, "test.mrr"),
            ("R1p", "fb15k237", {}, clean, "test.mrr"),
            ("R2", "fb15k237", {"cfg.attack.type": "alie"}, [c + 0.001 * (i % 2) for i, c in enumerate(clean)], "test.mrr"),
            ("R3", "fb15k237", {"cfg.attack.type": "alie"}, clean, "test.mrr")]
    res = evaluate_hypotheses(_runs(spec), HYP, {}, "final")
    m = next(x for x in res["families"]["H2"]["members"] if x["member"] == "fb15k237:alie")
    assert m["status"] == "NOT_TESTABLE" and "not effective" in m["reason"]       # FedAvg is not hurt
    m1 = [("M1", "wn18rr", {"cfg.dp.enabled": False}, [0.50, 0.501, 0.499, 0.50, 0.50], "mia.auc"),
          ("M1", "wn18rr", {"cfg.dp.enabled": True, "cfg.dp.target_epsilon": 4.0}, [0.5] * 5, "mia.auc")]
    h3 = {x["dataset"]: x for x in evaluate_hypotheses(_runs(m1), HYP, {}, "final")["families"]["H3"]["members"]}
    assert h3["wn18rr"]["status"] == "NOT_TESTABLE" and "no measurable leakage" in h3["wn18rr"]["reason"]
    r = _runs([("M1", "wn18rr", {"cfg.dp.enabled": False}, [0.60, 0.61, 0.62, 0.60, 0.61], "mia.auc"),
               ("M1", "wn18rr", {"cfg.dp.enabled": True, "cfg.dp.target_epsilon": 4.0}, [0.51] * 5, "mia.auc")])
    r["mia.lower_bound_exceeds_accountant"] = [False] * 5 + [True] + [False] * 4
    h3 = {x["dataset"]: x for x in evaluate_hypotheses(r, HYP, {}, "final")["families"]["H3"]["members"]}
    assert h3["wn18rr"]["status"] == "BLOCKED_RED_LINE"


def test_mixed_environments_invalidate_a_member_and_non_final_is_not_evidence():
    from fedkge.hypotheses import evaluate_hypotheses
    a, b = [0.20, 0.21, 0.19, 0.20, 0.22], [0.10, 0.11, 0.09, 0.10, 0.12]
    r = _runs([("R1p", "codex_m", {}, a, "test.mrr"), ("N1", "codex_m", {}, b, "test.mrr")])
    env = lambda rid: {"gpu": "Tesla T4" if "R1p" in rid else "NVIDIA L4", "torch": "2.11"}
    m = evaluate_hypotheses(r, HYP, {}, "final", env)["families"]["H1"]["members"][2]
    assert m["status"] == "INVALID_MIXED_ENVIRONMENT" and m["p_holm"] == 1.0
    m = evaluate_hypotheses(r, HYP, {}, "smoke")["families"]["H1"]["members"][2]
    assert m["verdict"] == "SUPPORTED" and m["decision"].startswith("NOT EVIDENCE (smoke tier)") and not m["evidence"]


def test_empty_results_give_pending_everywhere_and_no_figures(tmp_path):
    from fedkge.fixtures import FixtureContext
    from fedkge.reporting import run_analysis, run_figures, run_report
    ctx = FixtureContext(CONFIG_DIR, PKG.parent)
    ctx.runs = ctx.runs.iloc[0:0]
    hyp = run_analysis(ctx, tmp_path / "a")
    fm = json.loads(run_figures(ctx, hyp, tmp_path / "f").read_text())
    assert {f["status"] for f in fm["figures"]} == {"NOT_GENERATED"}
    run_report(ctx, hyp, tmp_path / "r", None)
    t3 = pd.read_csv(tmp_path / "r" / "FIXTURE_SYNTHETIC_NOT_RESULTS_table3_main.csv")
    assert set(t3["test.mrr"]) == {"PENDING"}
    draft = (tmp_path / "r" / "FIXTURE_SYNTHETIC_NOT_RESULTS_RESULTS_DRAFT.md").read_text()
    assert draft.count("⟦PENDING") >= 20 and "FIXTURE" in draft
    assert not list((tmp_path / "f").glob("*.png"))


def test_fixture_pipeline_end_to_end_is_labelled(tmp_path):
    from fedkge.fixtures import FixtureContext
    from fedkge.reporting import run_analysis, run_figures, run_report
    ctx = FixtureContext(CONFIG_DIR, PKG.parent)
    hyp = run_analysis(ctx, tmp_path / "analysis")
    fm_path = run_figures(ctx, hyp, tmp_path / "figures")
    idx = run_report(ctx, hyp, tmp_path / "reports", fm_path)
    files = [p for p in tmp_path.rglob("*") if p.is_file()]
    assert files and all(p.name.startswith("FIXTURE_SYNTHETIC_NOT_RESULTS_") for p in files)
    fm = json.loads(fm_path.read_text())
    gen = {f["id"]: f for f in fm["figures"]}
    for fid in ("F1_utility_vs_privacy", "F2_dataset_comparison", "F3_robustness_attacks", "F3b_targeted_attack",
                "F4_aggregation_comparison", "F5_convergence", "F6_membership_inference", "F7_integrity_overhead",
                "F8_ablations", "F9_3d_privacy_utility_bars", "F12_benign_fpr_by_size_third"):
        assert gen[fid]["status"] == "GENERATED", fid
        for f in gen[fid]["files"]:
            assert (tmp_path / "figures" / f).stat().st_size > 1000
        assert gen[fid]["watermark"].startswith("FIXTURE")
    for fid in ("F10_3d_surface_eps_alpha", "F11_3d_surface_tau_f"):
        assert gen[fid]["status"] == "NOT_GENERATED" and "B2" in gen[fid]["reason"]
    draft = (tmp_path / "reports" / idx["draft"]).read_text()
    assert "FIXTURE: SYNTHETIC NUMBERS" in draft and "PENDING: H3 CoDEx-M" in draft
    assert "no end-to-end DP guarantee" in draft
    md = (tmp_path / "reports" / "FIXTURE_SYNTHETIC_NOT_RESULTS_table3_main.md").read_text()
    assert "FIXTURE" in md.splitlines()[2]
    t9 = pd.read_csv(tmp_path / "reports" / "FIXTURE_SYNTHETIC_NOT_RESULTS_table9_attacks.csv")
    assert {"H2 status", "E_a (ratio of means)"} <= set(t9.columns)


def test_fixture_numbers_never_reach_a_results_root(tmp_path):
    import subprocess
    import sys
    r = subprocess.run([sys.executable, str(PKG / "scripts" / "build_report.py"), "--fixture"], capture_output=True,
                       text=True)
    assert r.returncode == 2 and "never go into a results root" in r.stderr
