#!/usr/bin/env python3
"""Phase C privacy-accounting validation (section 5.2 of the Phase C brief). Nothing here trains a model.

For every operating point of the approved plan the noise multiplier is CALIBRATED with the run-time code
(fedkge.accountant.calibrate_sigma0) and the resulting epsilon is then computed five ways:
  1. run-time path        : fedkge.accountant (dp_accounting private RDP function + compute_epsilon)
  2. public API, zero-out : dp_accounting RdpAccountant(neighboring_relation=REPLACE_SPECIAL)  [same library]
  3. PLD                  : dp_accounting PLDAccountant                                          [same library]
  4. PRV                  : prv-accountant (Gopi et al. 2021)                                     [other library]
  5. own quadrature       : numerical integration of the subsampled-Gaussian Renyi divergence + own conversion,
                            no dp_accounting at all                                               [own code]
Known analytical cases (Gaussian mechanism, q = 1) and the legacy per-round log (Phase A) are re-checked here,
independently of the Phase A scripts. Outputs: <results>/privacy_accounting/.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time

import numpy as np
import pandas as pd
from scipy.special import logsumexp

from _common import Manifest, results_root
from fedkge import accountant as A

QUAD_ORDERS = [a for a in A.MAIN_ORDERS if a <= 256]


def own_rdp_epsilon(q: float, steps_per_round, sigmas, delta: float, n: int = 100_001) -> float:
    """Library-independent: per-order RDP of one subsampled-Gaussian step by log-space trapezoid quadrature,
    A_a = E_{z~N(0,s^2)}[(1-q + q exp((2z-1)/(2 s^2)))^a], rho_step = log(A_a)/(a-1) (Mironov, Talwar & Zhang 2019),
    composed over all steps, converted with eps = rho + log((a-1)/a) - (log delta + log a)/(a-1) (Balle et al. 2020)."""
    groups = {}
    for k, s in zip(steps_per_round, sigmas):
        if k:
            groups[float(s)] = groups.get(float(s), 0) + int(k)
    best = float("inf")
    for a in QUAD_ORDERS:
        rho = 0.0
        for s, k in groups.items():
            z = np.linspace(-40 * s, a + 40 * s + 5, n)
            dz = z[1] - z[0]
            log_mu0 = -z ** 2 / (2 * s ** 2) - math.log(s * math.sqrt(2 * math.pi))
            log_inner = np.logaddexp(math.log1p(-q) if q < 1 else -np.inf, math.log(q) + (2 * z - 1) / (2 * s ** 2))
            lw = np.full(n, math.log(dz)); lw[0] = lw[-1] = math.log(dz / 2)
            rho += k * float(logsumexp(log_mu0 + a * log_inner + lw)) / (a - 1)
        best = min(best, rho + math.log((a - 1) / a) - (math.log(delta) + math.log(a)) / (a - 1))
    return best


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results")
    ap.add_argument("--quick", action="store_true", help="fewer operating points (for CI)")
    a = ap.parse_args(argv)
    root = results_root(a.results)
    out = root / "privacy_accounting"
    man = Manifest(root, "privacy_accounting")
    t0 = time.time()
    rows, failures = [], []
    eps_grid = [1.0, 4.0] if a.quick else [1.0, 2.0, 4.0, 8.0]
    designs = [("Q", q, None, R) for q in ((0.05,) if a.quick else (0.02, 0.05, 0.1)) for R in ((100,) if a.quick else (50, 100))]
    # design A: representative public sizes (mean client and the smallest allowed client, Phase B partition plan)
    for ds, n_mean in (("fb15k237", 27212), ("wn18rr", 8684), ("codex_m", 18558)):
        for label, n in (("mean", n_mean), ("min_allowed", max(1024, int(0.2 * n_mean)))):
            designs.append((f"A:{ds}:{label}", None, n, 100))
    for delta in (1e-6, 1e-5):
        for eps_t in eps_grid:
            for name, q, n, R in designs:
                if name == "Q":
                    sr = A.dp_steps_common_rate(10_000, q)
                else:
                    sr = A.dp_steps_and_rate(int(n), 512, False)
                cal = A.calibrate_sigma0(sr["q"], sr["steps"], R, "fixed", 1.0, eps_t, delta, 5)
                ks, sig = [sr["steps"]] * R, cal["sigmas"]
                e_rt = A.eps_from_rdp(A.composed_rdp(sr["q"], ks, sig), delta)
                e_pub = A.rdp_epsilon_public_api(sr["q"], ks, sig, delta)
                e_pld = A.pld_epsilon(sr["q"], ks, sig, delta)
                prv = A.prv_epsilon(sr["q"], ks, sig, delta)
                e_own = own_rdp_epsilon(sr["q"], ks, sig, delta)
                rec = {"design": name, "q": sr["q"], "steps_per_round": sr["steps"], "rounds": R, "delta": delta,
                       "eps_target": eps_t, "sigma0": cal["sigma0"], "eps_runtime_rdp": e_rt,
                       "eps_public_api_zero_out": e_pub, "eps_pld": e_pld, "eps_prv_lower": prv["lower"],
                       "eps_prv_upper": prv["upper"], "eps_own_quadrature": e_own}
                checks = {"meets_target": e_rt <= eps_t + 1e-9,
                          "public_api_equal": abs(e_rt - e_pub) < 1e-9,
                          # dp_accounting bounds fractional orders from above (exact at integer orders), so the
                          # run-time epsilon may exceed the exact quadrature slightly - never the other way round
                          "own_quadrature_not_above_runtime": e_own <= e_rt + 1e-6,
                          "own_quadrature_within_0_5pct": (e_rt - e_own) <= 5e-3 * e_rt,
                          "pld_le_rdp": e_pld <= e_rt + 1e-9,
                          "prv_upper_le_rdp": prv["upper"] <= e_rt + 1e-6,
                          "prv_brackets_pld": prv["lower"] - 2e-3 <= e_pld <= prv["upper"] + 2e-3}
                rec.update(checks)
                rows.append(rec)
                if not all(checks.values()):
                    failures.append({k: v for k, v in rec.items()})
    df = pd.DataFrame(rows)
    stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())             # never overwrite an earlier validation
    csv_out, json_out = out / f"accounting_validation_{stamp}.csv", out / f"accounting_validation_summary_{stamp}.json"
    df.to_csv(csv_out, index=False)
    # ---- analytical cases and the legacy log
    analytic = []
    for s in (0.5, 1.0, 2.0, 5.0):
        v = A.rdp_vector(1.0, s)
        exact = np.array(A.MAIN_ORDERS) / (2 * s * s)
        analytic.append({"sigma": s, "max_abs_err": float(np.max(np.abs(v - exact)))})
    legacy = []
    for k, (n_k, logged) in enumerate(((83830, 0.860877), (56322, 0.942189), (41261, 1.033917), (50033, 0.975682),
                                       (40669, 1.040574))):
        sr = A.dp_steps_and_rate(n_k, 256, True)
        e = A.legacy_round_epsilon(sr["q"], sr["steps"], 1.0, 1e-5)
        legacy.append({"client": k, "n": n_k, "steps": sr["steps"], "q": sr["q"], "logged_eps_round": logged,
                       "recomputed": e, "abs_diff": abs(e - logged)})
    w = A.dp_steps_and_rate(40669, 256, True)
    worst16 = A.eps_from_rdp(A.composed_rdp(w["q"], [w["steps"]] * 16, [1.0] * 16, A.OPACUS_DEFAULT_ORDERS), 1e-5,
                             A.OPACUS_DEFAULT_ORDERS)
    group = [{"g": g, "eps": g * 4.0, "delta": g * math.exp((g - 1) * 4.0) * 1e-6} for g in (1, 2, 3, 4)]
    summary = {"n_operating_points": len(df), "n_failed_checks": len(failures), "failures": failures,
               "max_abs_runtime_vs_public_api": float((df["eps_runtime_rdp"] - df["eps_public_api_zero_out"]).abs().max()),
               "max_abs_runtime_vs_own_quadrature": float((df["eps_runtime_rdp"] - df["eps_own_quadrature"]).abs().max()),
               "max_rel_runtime_minus_own_quadrature": float(((df["eps_runtime_rdp"] - df["eps_own_quadrature"]) / df["eps_runtime_rdp"]).max()),
               "min_runtime_minus_own_quadrature": float((df["eps_runtime_rdp"] - df["eps_own_quadrature"]).min()),
               "pld_over_rdp_range": [float((df["eps_pld"] / df["eps_runtime_rdp"]).min()),
                                      float((df["eps_pld"] / df["eps_runtime_rdp"]).max())],
               "gaussian_closed_form_max_err": max(x["max_abs_err"] for x in analytic),
               "legacy_per_round_max_abs_diff": max(x["abs_diff"] for x in legacy),
               "legacy_worst_client_rdp_16_rounds_delta_1e-5": worst16,
               "group_privacy_eps4_delta1e-6": group, "seconds": time.time() - t0,
               "adjacency": A.ADJACENCY}
    json_out.write_text(json.dumps({**summary, "analytic": analytic, "legacy": legacy}, indent=2))
    for p in (csv_out, json_out):
        man.output(p)
    ok = not failures and summary["gaussian_closed_form_max_err"] < 1e-9 and summary["legacy_per_round_max_abs_diff"] < 1e-6
    man.close("COMPLETE" if ok else "CHECKS_FAILED", n_points=len(df), n_failed=len(failures))
    print(json.dumps({k: summary[k] for k in ("n_operating_points", "n_failed_checks", "max_abs_runtime_vs_public_api",
                                              "max_abs_runtime_vs_own_quadrature", "max_rel_runtime_minus_own_quadrature",
                                              "min_runtime_minus_own_quadrature", "pld_over_rdp_range",
                                              "gaussian_closed_form_max_err", "legacy_per_round_max_abs_diff",
                                              "legacy_worst_client_rdp_16_rounds_delta_1e-5", "seconds")}, indent=1))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
