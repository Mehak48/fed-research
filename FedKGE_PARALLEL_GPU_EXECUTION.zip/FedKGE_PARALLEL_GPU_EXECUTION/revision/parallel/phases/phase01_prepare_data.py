#!/usr/bin/env python3
"""PHASE 01 - datasets for THIS environment: licence gate, download, pinned SHA-256 check (scripts/prepare_data.py).
CPU, minutes, only what is missing. Run it on every worker and on the master. Dataset files are never exchanged
between environments and never enter a bundle, a pack or an export.

  python parallel/phases/phase01_prepare_data.py --data-dir <base>/data_cache --datasets fb15k237 wn18rr codex_m \
         [--i-confirm-licence --operator-note "who, when, for what"]

Without --i-confirm-licence it prints each dataset's source, licence terms and citation and downloads nothing.
Output: <data-dir>/<dataset>/{train,valid,test}.txt + source_manifest.json (pinned_sha256_match = true).
Next: phase 02 (artifacts) on this environment.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

from _cli import finish, parser

from fedkge_parallel.common import DATASETS, EXIT_CONTRACT, EXIT_OK, REPO


def main(argv=None) -> int:
    ap = parser(__doc__)
    ap.add_argument("--data-dir", required=True)
    ap.add_argument("--datasets", nargs="+", default=list(DATASETS), choices=list(DATASETS))
    ap.add_argument("--i-confirm-licence", action="store_true")
    ap.add_argument("--operator-note", default="")
    a = ap.parse_args(argv)
    data = Path(a.data_dir)
    missing = []
    for ds in a.datasets:
        sm = data / ds / "source_manifest.json"
        if sm.exists():
            m = json.loads(sm.read_text())
            if m.get("pinned_sha256_match") and not m.get("UNPINNED"):
                print(f"{ds}: present, pinned checksums OK (reused)")
                continue
            print(f"STOP: {ds}: the data in {data / ds} are not the pinned bytes"); return finish(EXIT_CONTRACT)
        cmd = [sys.executable, "scripts/prepare_data.py", "--dataset", ds, "--data-dir", str(data)]
        if a.i_confirm_licence:
            if not a.operator_note.strip():
                print("STOP: --operator-note is required with --i-confirm-licence"); return finish(EXIT_CONTRACT)
            cmd += ["--i-confirm-licence", "--operator-note", a.operator_note]
        p = subprocess.run(cmd, cwd=REPO)
        if p.returncode != 0 or not sm.exists():
            missing.append(ds)
    if missing:
        print(f"not prepared: {missing} (read the licence terms above, then rerun with --i-confirm-licence and a note)")
        return finish(EXIT_CONTRACT)
    return finish(EXIT_OK)


if __name__ == "__main__":
    sys.exit(main())
