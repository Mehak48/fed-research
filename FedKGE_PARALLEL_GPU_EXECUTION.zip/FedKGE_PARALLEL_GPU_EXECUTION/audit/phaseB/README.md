# Phase B — Methodology design (planning only)

**Date:** 2026-10-28 · **Status:** complete as a *planning and design* stage, and **waiting for your approval**.
- No source code was modified, no dataset was downloaded, no model was trained, and no existing result was overwritten. The self-check verifies this (`scripts/phaseB_check_docs.py`).
- The Phase A deliverables in `audit/` are unchanged and read-only.
- An independent review pass checked the maths, the numbers and the cross-references against the revision's source code. Its corrections are applied, including three defects it found (CR-14, MN-21, MN-22).

## The eight items you asked for

| # | Item | Document | Machine-readable |
|---|---|---|---|
| 1 | Consolidated list of all methodological defects (83: 14 critical, 32 major, 26 minor, 11 optional) | `01_defect_register.md` | `data/defect_register.csv` |
| 2 | D1–D10 quoted exactly from Phase A, with recommended defaults, rationale, implications and alternatives; new decisions D11–D18; approval sheet | `02_design_decisions.md` | – |
| 3 | Proposed mathematical methodology, manuscript-ready Algorithm 1, hypotheses with decision rules; threat model | `03_methodology_specification.md`, `03a_threat_model.md` | – |
| 4 | Three-dataset benchmark recommendation (FB15k-237 + WN18RR + CoDEx-M; YAGO3-10 optional) | `04_dataset_benchmark.md` | `data/dataset_candidates.csv` |
| 5 | Privacy–utility evaluation plan, including the accounting validation | `05_privacy_utility_plan.md` | `data/phaseB_sigma_plan.csv`, `data/phaseB_sigma_plan.json` |
| 6 | Baseline, ablation and threshold-sweep matrix | `06_experiment_matrix.md` | `data/experiment_matrix.csv`, `data/threshold_inventory.csv`, `drafts/experiment_matrix_draft.yaml` |
| 7 | Computational feasibility estimate and staged plan | `07_compute_feasibility.md` | `data/run_counts.csv`, `data/cost_estimate.csv`, `data/per_run_time_estimate.csv`, `data/storage_estimate.csv`, `data/priority_cost.csv` |
| 8 | Unresolved questions and missing source documents (including the File 2 identity check) | `08_open_questions.md` | – |

## Labels

| Label | Meaning |
|---|---|
| [Legacy-measured] | produced by a real run of the original notebooks (only the two legacy runs and their logs) |
| [Calculated – Phase B planning] | computed here from formulas, published dataset sizes or legacy counts. It is **not** an experimental result |
| [UNVERIFIED] | an input that could not be checked here. Only the WN18RR per-relation counts in the partition simulation carry this label |
| Reported in literature | a value from a published paper, under that paper's protocol. Used only for sanity checks, never as a target, and never placed in our result tables |
| [Phase C] | a design element the revision code does not implement yet |

**There are no new experimental results in Phase B.** All revised experiments remain **unexecuted** until run records exist.

## Naming conventions (to avoid confusion)

| Prefix | Meaning |
|---|---|
| **D1…D18** | *decisions* (`02`) |
| P2.x, T, L, N, DP, R, I, M, X, O | experiment *blocks* (`06`). The DP blocks are named **DP1, DP1h, DP2, DP2h, DP3** so they never clash with decision IDs |
| CR-, MJ-, MN-, OP-, G | *defects* (`01`) |
| RK- | *risks* (`01`) |
| H1, H2, H2b, H3, HS | *hypotheses* (`03` §13) |
| C1…C17 | Phase C *changes* (`03` §15) |
| S_TUNE, S1, S3, S5, S10x, S10 | *seed sets* (`06` §3) |

## Most important outcomes

1. **Two recommendations change from Phase A; one is refined with a title consequence.**
   - D2: triple-level DP under **zero-out adjacency**, and no client-level DP (numerically infeasible with 10 clients).
   - D5: CoDEx-M replaces YAGO3-10 as the default third dataset, because of YAGO3-10's documented test leakage and its cost.
   - D7 (refined): the integrity layer must sit *in the data path*, and "IPFS-Based" leaves the title unless you choose a real local IPFS node.
2. **Three new defects would have made revised results invalid if the revision package had been run as delivered.**
   - CR-14: its privacy statement (add/remove adjacency) is false while exact client sizes are published. Zero-out adjacency fixes the statement; every ε value stays the same.
   - CR-13: integrity verification never touches the aggregated data.
   - MJ-15: the membership-inference audit compares training triples with structurally different test triples.
3. **Privacy accounting validated four ways**, two of them independent of the library the revision uses:
   - the revision's `calibrate_sigma0` vs my own calibration (same library, different code path): σ within 0.2 %;
   - my own numerical integration of the subsampled-Gaussian RDP (no `dp_accounting`): ε within 1.4·10⁻⁴;
   - the PRV accountant (a different library and method): its interval contains the PLD value at all four operating points;
   - PLD ≈ 0.93 × RDP at the calibrated σ, as expected.
4. **Compute.** The recommended core plan (reduced profile, CoDEx-M) is 837 runs and **≈ 46.5–392.6 GPU-hours** on an assumed T4-class GPU. A 1–4 GPU-hour pilot narrows that range before anything large starts. Nothing assumes your hardware.

## Reproducing every Phase B calculation (no GPU, no dataset download)

Requirements: Python ≥ 3.10, numpy, scipy, pyyaml, `dp-accounting` (0.6.0 used), `prv-accountant` (0.2.0 used). Run from `audit/phaseB/scripts/`:

```bash
python3 -I phaseB_sigma_plan.py --out-csv ../data/phaseB_sigma_plan.csv --out-json ../data/phaseB_sigma_plan.json \
        --crosscheck-revision /path/to/a/COPY/of/fedkge/accountant.py          # cross-check is optional
python3 -I phaseB_partition_feasibility.py --fb-rollup "/path/to/legacy/complete/rollup_by_relation.csv" \
        --out-csv ../data/phaseB_partition_feasibility.csv
python3 -I phaseB_experiment_matrix.py --out-dir ../data --draft-yaml ../drafts/experiment_matrix_draft.yaml
python3 -I phaseB_defect_register.py --out-csv ../data/defect_register.csv --out-md-table ../drafts/defect_tables.md.part
python3 -I phaseB_render_matrix_tables.py --matrix ../data/experiment_matrix.csv --out-matrix-md ../drafts/matrix_table.md.part \
        --out-threshold-csv ../data/threshold_inventory.csv --out-threshold-md ../drafts/threshold_table.md.part
python3 -I phaseB_check_docs.py --phaseb .. --phasea-zip /path/to/fedkge_phaseA_audit.zip \
        --uploads /mnt/user-data/uploads --attachments /path/to/attachments
```

`drafts/` holds the generated table fragments that are assembled into `01` and `06`, plus the YAML draft of the matrix for Phase C.

## What happens next

Nothing, until you reply to `08_open_questions.md` §3 and the approval sheet in `02`. Phase C (code repair and tests) starts only after that, and no experiment beyond smoke tests runs before gate G-A (`07` §8).
