#!/usr/bin/env python3
"""PHASE 05 (master, CPU, seconds per step) - Stage-3 selections, gate G-B, tau, D10, freeze (G-C), releases.

  python parallel/phases/phase05_select_freeze_release.py --base B          (do every step whose inputs are ready)

For every dataset, as soon as its tuning runs are imported (phase 08):
  chain mode: replay the pre-registered selection stage by stage on the master (scripts/run_plan.py tune_select:
              T1_central + gate G-B, T1_nonprivate + T2a, T2b, T2c, T2d, T3, tau with fallback B3, D10); the result
              must equal the worker's own selection exactly; then freeze (scripts/freeze_selections.py --datasets
              <ds>) and publish the release pack of the dataset's Stage-4 jobs.
  stage mode: select the finished stage and release the next stage's jobs (stage 0 releases stage 1 ONLY if gate
              G-B passed); after stage 5: stage 6 (tau, D10), freeze, release Stage 4.
A dataset never waits for another dataset. Outputs: <master>/tune/selection, tune/gates, final/selection/FROZEN.json,
<master>/parallel/steps/SEL-*.json, release packs in <base>/exchange/packs/. Next: workers run the released jobs.
"""
from __future__ import annotations

import json
import sys

from _cli import finish, layout, parser

from fedkge_parallel.common import EXIT_GATE, EXIT_OK
from fedkge_parallel.master_flow import advance
from fedkge_parallel.store import Master


def main(argv=None) -> int:
    ap = parser(__doc__)
    ap.add_argument("--datasets", nargs="*")
    a = ap.parse_args(argv)
    L = layout(a)
    m = Master(L, a.mode)
    acts = advance(m, a.datasets or ("fb15k237", "wn18rr", "codex_m"))
    for x in acts:
        print(f"{x['step']}: {x['status']}" + (f" - {x.get('why', '')[:300]}" if x["status"] != "DONE" else
                                               f" -> {x.get('pack')}"))
    if not acts:
        print("nothing to do: every selection step is done or not yet reachable")
    return finish(EXIT_GATE if any(x["status"] == "GATE_FAILED" for x in acts) else EXIT_OK)


if __name__ == "__main__":
    sys.exit(main())
