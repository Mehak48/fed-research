"""Client-side DP-SGD for TransE with exact per-example clipping on sparse embedding rows.

Mechanism for ONE local step (matches Opacus semantics; validated against Opacus in the test suite):
  1. Poisson sampling: every local triple is included independently with probability q.
  2. For each sampled triple x (with its k negatives, which are data-independent), compute the gradient g_x of
     its own loss w.r.t. ALL parameters. g_x is non-zero only on the rows of h, t, the negative entities and r.
     Rows of the same entity occurring several times inside one example are summed BEFORE the norm is taken.
  3. Clip: g_x <- g_x * min(1, C / (||g_x||_2 + 1e-6)). A per-example gradient with ANY non-finite entry is
     replaced by 0 before clipping (Phase C, defect MN-22): otherwise a NaN norm would turn the clipping factor
     into NaN and the bound ||clip(g_x)|| <= C (the sensitivity the accountant assumes) would not hold.
  4. Sum clipped gradients, add N(0, sigma^2 C^2) independently to EVERY coordinate of every parameter
     (dense noise: untouched rows also receive noise), divide by the expected batch size q*N_k, where N_k is the
     client's PUBLIC record count (data-independent; null records of the zero-out relation count in N_k).
  5. Adam step (post-processing).
The noise multiplier sigma may change between rounds (deterministic schedule fixed before training).
A client with no records (a Sybil identity running the protocol on empty data) releases pure noise steps.
"""
from __future__ import annotations

from typing import Dict, Tuple

import torch

from .model import Params, margin_loss_per_example
from .sampling import sample_negatives


def per_example_clipped_sum(ent: torch.Tensor, rel: torch.Tensor, h, r, t, nh, nt, clip: float, margin: float,
                            normalize: bool) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """Returns (G_ent, G_rel, per_example_norms, per_example_loss) where G_* are sums of clipped per-example
    gradients (no noise)."""
    b, k = nh.shape
    d = ent.shape[1]
    n_ent = ent.shape[0]
    ph = ent[h].detach().requires_grad_(True)
    pr = rel[r].detach().requires_grad_(True)
    pt = ent[t].detach().requires_grad_(True)
    ne_h = ent[nh].detach().requires_grad_(True)
    ne_t = ent[nt].detach().requires_grad_(True)
    loss_ex = margin_loss_per_example(ph, pr, pt, ne_h, ne_t, margin, normalize)
    g_ph, g_pr, g_pt, g_nh, g_nt = torch.autograd.grad(loss_ex.sum(), [ph, pr, pt, ne_h, ne_t])
    # each leaf row belongs to exactly one example, so its gradient IS that example's gradient contribution
    ids = torch.cat([h[:, None], t[:, None], nh, nt], 1)                       # (b, 2+2k)
    grads = torch.cat([g_ph[:, None], g_pt[:, None], g_nh, g_nt], 1)           # (b, 2+2k, d)
    ex = torch.arange(b, device=ent.device)[:, None].expand_as(ids)
    key = (ex * n_ent + ids).reshape(-1)
    uniq, inv = torch.unique(key, return_inverse=True)
    acc = torch.zeros(len(uniq), d, device=ent.device, dtype=ent.dtype).index_add_(0, inv, grads.reshape(-1, d))
    ex_u, ent_u = uniq // n_ent, uniq % n_ent
    # non-finite guard (MN-22): an example whose gradient has any inf/NaN entry contributes exactly zero
    nonfin_rows = (~torch.isfinite(acc).all(1)).to(ent.dtype)
    bad = torch.zeros(b, device=ent.device, dtype=ent.dtype).index_add_(0, ex_u, nonfin_rows) > 0
    bad |= ~torch.isfinite(g_pr).all(1)
    acc = torch.nan_to_num(acc, nan=0.0, posinf=0.0, neginf=0.0)
    g_pr = torch.nan_to_num(g_pr, nan=0.0, posinf=0.0, neginf=0.0)
    sq = torch.zeros(b, device=ent.device, dtype=ent.dtype).index_add_(0, ex_u, (acc ** 2).sum(1))
    sq = sq + (g_pr ** 2).sum(1)
    norms = sq.sqrt()
    scale = torch.clamp(clip / (norms + 1e-6), max=1.0)
    scale = torch.where(bad | ~torch.isfinite(norms), torch.zeros_like(scale), scale)
    G_ent = torch.zeros_like(ent).index_add_(0, ent_u, acc * scale[ex_u, None])
    G_rel = torch.zeros_like(rel).index_add_(0, r, g_pr * scale[:, None])
    norms = torch.where(bad, torch.full_like(norms, float("nan")), norms)
    return G_ent, G_rel, norms.detach(), loss_ex.detach()


def add_gaussian_noise(G: torch.Tensor, sigma: float, clip: float, gen: torch.Generator) -> torch.Tensor:
    """Dense Gaussian noise N(0, (sigma*C)^2) on EVERY coordinate (including rows no sampled example touched)."""
    return G + torch.randn(G.shape, generator=gen, device=G.device, dtype=G.dtype) * (sigma * clip)


def dp_local_train(params: Params, triples: torch.Tensor, n_ent: int, tcfg: Dict, normalize: bool, margin: float,
                   sigma: float, clip: float, steps: int, q: float, expected_batch: float,
                   gen: torch.Generator, physical_batch: int = 4096) -> Tuple[Params, Dict]:
    ent = params["ent"].detach().clone().requires_grad_(True)
    rel = params["rel"].detach().clone().requires_grad_(True)
    opt = torch.optim.Adam([ent, rel], lr=float(tcfg["lr"]))
    N = len(triples)
    k = int(tcfg["neg_samples"])
    all_norms, losses, sampled = [], [], []
    for _ in range(int(steps)):
        mask = torch.rand(N, generator=gen, device=triples.device) < q
        idx = mask.nonzero(as_tuple=False).squeeze(1)
        G_ent = torch.zeros_like(ent)
        G_rel = torch.zeros_like(rel)
        for c in range(0, len(idx), physical_batch):
            sub = idx[c:c + physical_batch]
            h, r, t = triples[sub, 0], triples[sub, 1], triples[sub, 2]
            nh, nt = sample_negatives(h, t, n_ent, k, tcfg["neg_mode"], gen)
            ge, gr, nrm, lex = per_example_clipped_sum(ent.detach(), rel.detach(), h, r, t, nh, nt, clip, margin,
                                                       normalize)
            G_ent += ge; G_rel += gr
            all_norms.append(nrm); losses.append(lex)
        if sigma > 0:                      # sigma = 0 only in the DP3 cost-decomposition ablation (no guarantee)
            G_ent = add_gaussian_noise(G_ent, sigma, clip, gen)
            G_rel = add_gaussian_noise(G_rel, sigma, clip, gen)
        ent.grad = G_ent / expected_batch
        rel.grad = G_rel / expected_batch
        opt.step()
        opt.zero_grad(set_to_none=True)
        sampled.append(len(idx))
    norms = torch.cat(all_norms) if all_norms else torch.zeros(0, device=triples.device)
    finite = torch.isfinite(norms)
    fn = norms[finite]
    stats = {"steps": int(steps), "sigma": float(sigma), "clip": float(clip), "q": float(q),
             "expected_batch": float(expected_batch),
             "mean_sampled_batch": float(sum(sampled) / max(len(sampled), 1)),
             "loss": float(torch.cat(losses).mean()) if losses else float("nan"),
             "clip_fraction": float((fn > clip).float().mean()) if len(fn) else float("nan"),
             "grad_norm_q50": float(fn.quantile(0.5)) if len(fn) else float("nan"),
             "grad_norm_q90": float(fn.quantile(0.9)) if len(fn) else float("nan"),
             "n_nonfinite_examples_zeroed": int((~finite).sum()),
             "n_examples": N}
    return {"ent": ent.detach(), "rel": rel.detach()}, stats
