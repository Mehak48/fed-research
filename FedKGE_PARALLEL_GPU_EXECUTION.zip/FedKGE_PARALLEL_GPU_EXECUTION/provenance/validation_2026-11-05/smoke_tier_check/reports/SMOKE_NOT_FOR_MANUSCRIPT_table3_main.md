# Table 3 — main results by dataset

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| system | dataset | block | test.mrr | test.hits@1 | test.hits@3 | test.hits@10 | privacy.eps |
|---|---|---|---|---|---|---|---|
| Centralised TransE (non-private) | FB15k-237 | N1 | 0.112 (n=1) | 0.082 (n=1) | 0.122 (n=1) | 0.170 (n=1) | PENDING |
| FedAvg (non-private) | FB15k-237 | N2 | 0.005 (n=1) | 0.002 (n=1) | 0.003 (n=1) | 0.007 (n=1) | PENDING |
| DP-FedAvg, eps* = 4 (selected schedule) | FB15k-237 | DP2 | 0.005 (n=1) | 0.002 (n=1) | 0.003 (n=1) | 0.007 (n=1) | 0.97 (n=1) |
| Complete method, eps* = 4 | FB15k-237 | R1p | 0.005 (n=1) | 0.002 (n=1) | 0.003 (n=1) | 0.007 (n=1) | 0.97 (n=1) |
| Centralised TransE (non-private) | WN18RR | N1 | 0.015 (n=1) | 0.009 (n=1) | 0.016 (n=1) | 0.025 (n=1) | PENDING |
| FedAvg (non-private) | WN18RR | N2 | 0.001 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0.003 (n=1) | PENDING |
| DP-FedAvg, eps* = 4 (selected schedule) | WN18RR | DP2 | 0.001 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0.003 (n=1) | 0.97 (n=1) |
| Complete method, eps* = 4 | WN18RR | R1p | 0.001 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0.003 (n=1) | 0.97 (n=1) |
| Centralised TransE (non-private) | CoDEx-M | N1 | 0.102 (n=1) | 0.063 (n=1) | 0.110 (n=1) | 0.180 (n=1) | PENDING |
| FedAvg (non-private) | CoDEx-M | N2 | 0.004 (n=1) | 0.000 (n=1) | 0.002 (n=1) | 0.012 (n=1) | PENDING |
| DP-FedAvg, eps* = 4 (selected schedule) | CoDEx-M | DP2 | 0.002 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0.003 (n=1) | 0.97 (n=1) |
| Complete method, eps* = 4 | CoDEx-M | R1p | 0.002 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0.003 (n=1) | 0.97 (n=1) |
