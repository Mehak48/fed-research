#!/usr/bin/env python3
"""PHASE 09 (master, CPU) - the automated artifact validation tool.

  python parallel/phases/phase09_validate.py --base B [--schemas]

Checks the master store against EVERY approved cell: status of each cell (COMPLETE / NOT_STARTED / WAITING_FOR_
SELECTIONS / INCOMPLETE / FAILED / STALE_*), the core's validity checks (code, tier, data, partition and selection
hashes), one environment per (tier, dataset), the required output files of every COMPLETE run, quarantined duplicate
executions, unfrozen datasets with Stage-4 runs, bundles waiting for import. Missing cells are mapped to the job and
the planned worker that must run them. --schemas also runs scripts/validate_outputs.py (JSON-schema validation).
Outputs: <master>/parallel/VALIDATION_REPORT.md/.json, VALIDATION_CELLS.csv, RERUN_LIST.csv.
Exit: 0 complete and compatible, 2 compatible but incomplete, 1 incompatibility found.
"""
from __future__ import annotations

import subprocess
import sys

from _cli import layout, parser

from fedkge_parallel.common import REPO, tiers_for
from fedkge_parallel.validate import validate_store


def main(argv=None) -> int:
    ap = parser(__doc__)
    ap.add_argument("--schemas", action="store_true")
    a = ap.parse_args(argv)
    L = layout(a)
    rep = validate_store(L, a.mode)
    print((L.master / "parallel" / "VALIDATION_REPORT.md").read_text())
    code = rep["exit_code"]
    if a.schemas:
        for tier in sorted(set(tiers_for(a.mode).values())):
            p = subprocess.run([sys.executable, "scripts/validate_outputs.py", "--results", str(L.master), "--tier", tier],
                               cwd=REPO)
            if p.returncode != 0:
                code = 1
    print(f"EXIT {code}: {rep['verdict']}")
    return code


if __name__ == "__main__":
    sys.exit(main())
