> **Historical page (original package).** It describes the Phases 1-4 notebooks. The current, frozen methodology is `13_documentation/FINAL_METHODOLOGY.md`; the execution procedure is `../EXECUTION_GUIDE.md` and the notebook `../RUN_COMPLETE_FEDKGE_RESEARCH.ipynb`. Kept unchanged below for the record.

# Colab runbook — Phases 1–4

## One-time setup
1. Unzip `fedkge_revision_P1-P4.zip` into Google Drive so that this path exists:
   `/content/drive/MyDrive/fedkge_revision/01_fedkge_core/fedkge/`
2. Results go to `/content/drive/MyDrive/fedkge_results/` (created automatically). **Keep results on Drive**: a
   Colab VM is wiped when it disconnects; Drive is not.
3. `Runtime → Change runtime type → GPU` for Phases 3–4 (T4 is enough; L4/A100 are faster). Phases 1–2 run on CPU.
4. Optional but recommended once: run the test-suite in a Colab cell:
   ```
   !cd /content/drive/MyDrive/fedkge_revision && pip -q install -r requirements-colab.txt && python -m pytest -q 12_validation_tests
   ```
   Expected: all tests pass (~3–5 min on CPU).

## Every notebook
* Edit **only** the SETTINGS cell: `TIER = "smoke"` → later `"dev"` → later `"final"`. Optional `DATASETS=["wn18rr"]`
  to split work across sessions, `MAX_RUNS_THIS_SESSION = 20` to stop cleanly before a time limit.
* `Runtime → Run all`. The last cell prints `RUN STATUS: COMPLETE | INCOMPLETE | FAILED` + the file list.
* **INCOMPLETE** = the session limit was hit: just `Run all` again. Completed runs are skipped; an interrupted run
  resumes from its checkpoint (every 5 rounds).
* **FAILED** = a real error; the summary prints the traceback and each failed run has `runs/<run_id>/error.txt`.
  Nothing is ever filled in for a failed or missing input.

## Order (per tier)
`phase1_data` → `phase2_noniid` → `phase3_federated` → `phase4_dp`. See `MASTER_EXECUTION_ORDER.md` for the files to
check after each notebook.

## Parallel sessions
Two Colab sessions may run the same notebook with different `DATASETS` (e.g. one does `["yago310"]`). Do not run two
sessions on the same dataset at the same time. Selections need all datasets' stage results only for their own
dataset, so this is safe.

## If you change code or configs
Any change to a result-determining module changes the code hash: all affected runs become STALE and are rerun
automatically (old outputs moved to `<tier>/stale/`). Changing `selection_rules.yaml` after selection invalidates
the selection. This is intended.

## Troubleshooting
| Symptom | Cause / fix |
|---|---|
| `package not found at …` | fix `PKG_ROOT` in SETTINGS |
| `required file missing: …/artifacts/p1/…` | run Phase 1 for this tier first |
| `partition artifact missing` | run Phase 2 for this tier first |
| `Phase 3 is not complete` (P4) | finish Phase 3 for this tier/dataset |
| `stage 1 incomplete … before selecting` | rerun P4; selection waits for the full grid × all seeds |
| `could not satisfy min client size` | documented partition constraint failed; report it, do not lower silently |
| CUDA OOM on YAGO3-10 | lower `dp.physical_batch` in base.yaml (does not change the mechanism or ε) |
| PyKEEN download error | rerun; the datasets are fetched from their public mirrors by PyKEEN |
