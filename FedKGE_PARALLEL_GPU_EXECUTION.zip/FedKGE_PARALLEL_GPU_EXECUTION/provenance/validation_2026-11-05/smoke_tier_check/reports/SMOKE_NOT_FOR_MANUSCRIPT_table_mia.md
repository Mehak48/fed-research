# Membership-inference audit (block M1, attack A2 primary)

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| dataset | configuration | A2 AUC | TPR at FPR 1 % | TPR at FPR 0.1 % | empirical eps lower bound (max) | accountant eps (max) | red line (lower bound > accountant) | n |
|---|---|---|---|---|---|---|---|---|
| FB15k-237 | FedAvg non-private | 0.539 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0 |  | False | 1 |
| FB15k-237 | FedAvg + DP eps* = 1 | 0.538 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0 | 0.2301 | False | 1 |
| FB15k-237 | FedAvg + DP eps* = 4 | 0.538 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0 | 0.965 | False | 1 |
| FB15k-237 | FedAvg + DP eps* = 8 | 0.538 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0 | 2.056 | False | 1 |
| WN18RR | FedAvg non-private | 0.553 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0 |  | False | 1 |
| WN18RR | FedAvg + DP eps* = 1 | 0.551 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0 | 0.2301 | False | 1 |
| WN18RR | FedAvg + DP eps* = 4 | 0.551 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0 | 0.965 | False | 1 |
| WN18RR | FedAvg + DP eps* = 8 | 0.551 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0 | 2.056 | False | 1 |
| CoDEx-M | FedAvg non-private | 0.555 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0 |  | False | 1 |
| CoDEx-M | FedAvg + DP eps* = 1 | 0.535 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0 | 0.2301 | False | 1 |
| CoDEx-M | FedAvg + DP eps* = 4 | 0.534 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0 | 0.965 | False | 1 |
| CoDEx-M | FedAvg + DP eps* = 8 | 0.534 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0 | 2.056 | False | 1 |
