# fedkge core package
Install in Colab: handled by each notebook (`sys.path`) — or `pip install -e 01_fedkge_core` locally.
Module map and data flow: `13_documentation/ARCHITECTURE.md`. CLI (optional, same as notebooks):
`python -m fedkge.runner --config-dir 10_configs --results <RESULTS_ROOT> --tier final --phase p4 --stage 1 [--list|--estimate]`
