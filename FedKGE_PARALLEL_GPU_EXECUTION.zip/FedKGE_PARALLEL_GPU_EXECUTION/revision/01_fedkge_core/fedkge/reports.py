"""Phase 3 / Phase 4 result tables (consumed unchanged by Phase 5b / Phase 8 later). Every function reads collected runs (see analysis.collect) and returns a
DataFrame that keeps EVERY seed value next to mean / SD / 95% CI. Paired statistics are computed by seed.
Nothing here trains, estimates or imputes: a missing configuration raises.
"""
from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from .analysis import seed_table
from .stats import holm, paired, pareto_front, summarize

TEST, VAL = "test.mrr", "val.mrr"


def agg_label(r) -> str:
    m = r["cfg.aggregation.method"]
    if m == "trimmed_mean":
        return f"trimmed_mean(beta={r['cfg.aggregation.beta']})"
    if m == "fltrust":
        return f"fltrust(root={int(r['cfg.aggregation.root_size'])})"
    if m == "proposed":
        extra = "" if r.get("cfg.aggregation.norm_bound", True) else ",no_norm_bound"
        return f"proposed(tau={r['cfg.aggregation.tau']},lam={r['cfg.aggregation.lam']}{extra})"
    return m


def attack_label(r) -> str:
    t = r["cfg.attack.type"]
    if t == "none":
        return "none"
    if t == "sybil":
        return f"sybil(k={int(r['cfg.attack.sybil_k'])},s={r['cfg.attack.strength']})"
    parts = [f"f={r['cfg.attack.fraction']}"]
    if t in ("signflip", "gaussian", "targeted", "ipm"):
        parts.append(f"s={r['cfg.attack.strength']}")
    if t == "adaptive":
        parts.append(r["cfg.attack.knowledge"])
    if r.get("cfg.attack.placement", "random") != "random":
        parts.append(str(r["cfg.attack.placement"]))
    return f"{t}({','.join(parts)})"


def dp_label(r) -> str:
    if not r["cfg.dp.enabled"]:
        return "non-DP"
    if r["cfg.dp.mode"] == "fixed_sigma":
        return f"fixed_sigma={r['cfg.dp.sigma']}"
    return f"eps*={r['cfg.dp.target_epsilon']},{r['cfg.dp.schedule.shape']}(rho={r['cfg.dp.schedule.rho']}),C={r['cfg.dp.clip']}"


def add_labels(runs: pd.DataFrame) -> pd.DataFrame:
    runs = runs.copy()
    runs["agg"] = runs.apply(agg_label, axis=1)
    runs["atk"] = runs.apply(attack_label, axis=1)
    runs["dpl"] = runs.apply(dp_label, axis=1)
    return runs


def _metrics_table(df: pd.DataFrame, by: List[str], metrics: List[str]) -> pd.DataFrame:
    out = None
    for m in metrics:
        if m not in df.columns:
            continue
        t = seed_table(df.dropna(subset=[m]), by, m) if df[m].notna().any() else None
        if t is None:
            continue
        out = t if out is None else out.merge(t.drop(columns=["n_seeds"]), on=by, how="outer")
    if out is None:
        raise ValueError(f"no metrics among {metrics}")
    return out


def _require(df: pd.DataFrame, what: str) -> pd.DataFrame:
    if df.empty:
        raise ValueError(f"required results missing: {what}")
    return df


# ---------------------------------------------------------------------------------------------------- Phase 3
def table_p3(runs: pd.DataFrame) -> pd.DataFrame:
    df = _require(runs[runs["phase"] == "p3"], "Phase 3 runs")
    df = df.assign(setting=df["block"] + ":" + df["name"])
    cols = [TEST, "test.hits@1", "test.hits@3", "test.hits@10", VAL, "test.mrr_optimistic", "rounds_executed",
            "selected_round", "runtime.total_s"]
    if "test_legacy_protocol.mrr" in df.columns:
        cols.append("test_legacy_protocol.mrr")
    return _metrics_table(df, ["dataset", "setting"], cols)


def fl_gap(runs: pd.DataFrame) -> pd.DataFrame:
    """Paired (by seed) centralised - federated MRR gap per dataset and partition."""
    rows = []
    for ds in sorted(runs["dataset"].unique()):
        c = runs[(runs["block"] == "P3_central") & (runs["dataset"] == ds)]
        for blk in ("P3_iid", "P3_dir"):
            for name, g in runs[(runs["block"] == blk) & (runs["dataset"] == ds)].groupby("name"):
                pr = paired(c[TEST].tolist(), g[TEST].tolist(), c["seed"].tolist(), g["seed"].tolist())
                rows.append({"dataset": ds, "federated": f"{blk}:{name}", **{k: pr[k] for k in (
                    "mean_diff", "ci95_low", "ci95_high", "d_z", "p_exact_signflip", "p_paired_t", "n_pairs")},
                    "relative_gap_pct": 100 * pr["mean_diff"] / summarize(c[TEST])["mean"]})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------------------------------- Phase 4
def table_ladder(runs: pd.DataFrame, dp_sel: Dict) -> pd.DataFrame:
    rows, steps = [], []
    for ds in sorted(runs[runs["phase"] == "p4"]["dataset"].unique()):
        sel = dp_sel[ds]
        P = runs[runs["dataset"] == ds]
        l0 = P[(P["block"] == "P3_dir") & (P["cfg.partition.alpha"] == 0.1)]
        l1, l2, l3 = (P[P["block"] == b] for b in ("L1_legacy", "L2_trainer_fixed", "L3_accounting_fixed"))
        l4a = P[(P["block"] == "4B_clip") & (P["cfg.dp.clip"] == sel["clip"])]
        if sel["schedule_shape"] == "fixed":
            l4b = l4a
        else:
            l4b = P[(P["block"] == "4C_schedule") & (P["cfg.dp.schedule.shape"] == sel["schedule_shape"]) &
                    (P["cfg.dp.schedule.rho"] == sel["schedule_rho"])]
        ladder = [("L0 non-DP (P3 main)", l0), ("L1 legacy mechanism", l1), ("L2 + trainer fixed", l2),
                  ("L3 + formal RDP stopping", l3), ("L4a calibrated fixed, C_sel, eps*=4", l4a),
                  ("L4b calibrated selected schedule, eps*=4", l4b)]
        for lab, g in ladder:
            _require(g, f"ladder step {lab} for {ds}")
            rec = {"dataset": ds, "step": lab, **{f"test_mrr.{k}": v for k, v in summarize(g[TEST]).items() if k != "values"}}
            rec["test_mrr.per_seed"] = dict(zip(g["seed"], g[TEST]))
            if "privacy.eps" in g and g["privacy.eps"].notna().any():
                rec["eps_rdp_worst_client.mean"] = float(g["privacy.eps"].mean())
                rec["eps_rdp_worst_client.max"] = float(g["privacy.eps"].max())
                rec["delta"] = float(g["privacy.delta"].iloc[0])
                if "privacy.legacy_naive_sum" in g and g["privacy.legacy_naive_sum"].notna().any():
                    rec["legacy_naive_eps_sum.mean"] = float(g["privacy.legacy_naive_sum"].mean())
            rec["rounds_executed.mean"] = float(g["rounds_executed"].mean())
            rows.append(rec)
        for (la, a), (lb, b) in zip(ladder[1:-1], ladder[2:]):
            pr = paired(b[TEST].tolist(), a[TEST].tolist(), b["seed"].tolist(), a["seed"].tolist())
            steps.append({"dataset": ds, "from": la, "to": lb, **{k: pr[k] for k in ("mean_diff", "ci95_low", "ci95_high", "d_z", "p_exact_signflip")}})
        pr = paired(l0[TEST].tolist(), l4b[TEST].tolist(), l0["seed"].tolist(), l4b["seed"].tolist())
        steps.append({"dataset": ds, "from": "L4b", "to": "L0 (genuine DP cost at eps*=4)", **{k: pr[k] for k in ("mean_diff", "ci95_low", "ci95_high", "d_z", "p_exact_signflip")}})
    return pd.DataFrame(rows), pd.DataFrame(steps)


def table_clip(runs):
    return _metrics_table(_require(runs[runs["block"] == "4B_clip"], "4B"), ["dataset", "cfg.dp.clip"],
                          [VAL, TEST, "privacy.eps", "privacy.sigma0_worst", "rounds_executed"])


def table_schedule(runs, dp_sel):
    parts = []
    for ds, sel in ((d, s) for d, s in dp_sel.items() if not d.startswith("_")):
        parts.append(runs[(runs["block"] == "4B_clip") & (runs["dataset"] == ds) & (runs["cfg.dp.clip"] == sel["clip"])])
        parts.append(runs[(runs["block"] == "4C_schedule") & (runs["dataset"] == ds)])
    df = _require(pd.concat(parts), "schedule runs")
    return _metrics_table(df, ["dataset", "cfg.dp.schedule.shape", "cfg.dp.schedule.rho"],
                          [VAL, TEST, "privacy.eps", "privacy.eps_pld", "privacy.sigma0_worst", "rounds_executed"])


def table_privacy_utility(runs, dp_sel):
    parts = []
    for ds, sel in ((d, s) for d, s in dp_sel.items() if not d.startswith("_")):
        R = runs[runs["dataset"] == ds]
        parts.append(R[R["block"] == "4D_regimes"])
        parts.append(R[(R["block"] == "4B_clip") & (R["cfg.dp.clip"] == sel["clip"])])
        if sel["schedule_shape"] != "fixed":
            parts.append(R[(R["block"] == "4C_schedule") & (R["cfg.dp.schedule.shape"] == sel["schedule_shape"]) &
                           (R["cfg.dp.schedule.rho"] == sel["schedule_rho"])])
    df = _require(pd.concat(parts), "privacy-utility runs")
    df = df.assign(schedule=np.where(df["cfg.dp.schedule.shape"] == "fixed", "fixed", "selected"))
    t = _metrics_table(df, ["dataset", "cfg.dp.target_epsilon", "schedule"], [TEST, VAL, "privacy.eps", "privacy.eps_pld"])
    t["pareto"] = False
    for ds, g in t.groupby("dataset"):
        t.loc[g.index, "pareto"] = pareto_front(g["privacy.eps.mean"], g[f"{TEST}.mean"])
    return t



def table_legacy(runs: pd.DataFrame) -> pd.DataFrame:
    """Old-notebook replicas: legacy protocol (random 300/150 test triples, tail-only, optimistic) next to the
    corrected protocol on the SAME trained model, plus the naive vs RDP epsilon for the DP replica."""
    df = runs[runs["block"].isin(["R3_legacy", "R3_fixed", "R4_legacy"])]
    if df.empty:
        return pd.DataFrame()
    cols = [TEST, "test.mrr_optimistic", "test.tail.mrr", "test_legacy_protocol.mrr", "privacy.eps",
            "privacy.legacy_naive_sum", "rounds_executed"]
    return _metrics_table(df, ["dataset", "block"], [c for c in cols if c in df.columns])


# ---------------------------------------------------------------------------------------------------- writers
def _prefix(tier: str) -> str:
    return "" if tier == "final" else f"{tier.upper()}_NOT_FOR_MANUSCRIPT_"


def write_p3_reports(paths) -> Dict[str, str]:
    """Phase 3 report tables -> RESULTS_ROOT/<tier>/reports/p3/. Refuses stale/failed/missing runs."""
    from .analysis import collect
    from .io import write_csv
    runs, probs = collect(paths, ["p3"], require_all=True)
    runs = add_labels(runs)
    out = paths.base / "reports" / "p3"
    pre = _prefix(paths.tier)
    files = {}
    for name, df in (("p3_reference", table_p3(runs)), ("p3_fl_gap_paired", fl_gap(runs)),
                     ("p3_legacy_replica", table_legacy(runs)), ("p3_all_runs", runs)):
        if len(df):
            p = out / f"{pre}{name}.csv"; write_csv(p, df); files[name] = str(p)
    return files


def write_p4_reports(paths) -> Dict[str, str]:
    """Phase 4 report tables (ladder, clip grid, schedule grid, privacy-utility) -> <tier>/reports/p4/."""
    from .analysis import collect
    from .io import read_json, write_csv
    runs, probs = collect(paths, ["p3", "p4"], require_all=True)
    runs = add_labels(runs)
    dp_sel = read_json(paths.selection("dp_selection"))
    out = paths.base / "reports" / "p4"
    pre = _prefix(paths.tier)
    lad, steps = table_ladder(runs, dp_sel)
    files = {}
    for name, df in (("p4_dp_ladder", lad), ("p4_dp_ladder_paired_steps", steps), ("p4_clip_grid", table_clip(runs)),
                     ("p4_schedule_grid", table_schedule(runs, dp_sel)),
                     ("p4_privacy_utility", table_privacy_utility(runs, dp_sel)),
                     ("p4_legacy_replica", table_legacy(runs[runs["phase"] == "p4"])),
                     ("p4_all_runs", runs[runs["phase"] == "p4"])):
        if len(df):
            p = out / f"{pre}{name}.csv"; write_csv(p, df); files[name] = str(p)
    return files
