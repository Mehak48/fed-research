#!/usr/bin/env python3
"""PHASE 00 - check this environment and register it as a worker (or as the master). No training.

  python parallel/phases/phase00_register_worker.py --base B --worker colab-t4-a [--speed 1.0] [--device cuda]
  python parallel/phases/phase00_register_worker.py --base B --worker master --role master --device cpu

Checks: Python 3.10-3.13, the frozen manifest and configs (scripts/build_manifest.py --check logic), the core code
hash, a GPU when --role worker. Writes <base>/exchange/registry/worker_<name>.json with the environment-lock signature
(GPU name, torch, CUDA, Python minor), the GPU memory and the relative speed you declare (1.0 = Tesla T4; it is used
ONLY to estimate the schedule - replace it by measured values later with phase 03 --measured).
Output: the registry file. Next: phase 01 (datasets) on this environment; phase 03 on the master once every worker is
registered.
"""
from __future__ import annotations

import json
import platform
import sys

from _cli import finish, layout, parser

from fedkge_parallel.common import (EXIT_CONTRACT, EXIT_MANIFEST, EXIT_OK, IntegrityError, atomic_write_json,
                                    code_hash, environment_signature, frozen_manifest, safe_name, signature_key,
                                    utc_now)


def main(argv=None) -> int:
    ap = parser(__doc__, worker=True, gpu=True)
    ap.add_argument("--role", choices=["worker", "master"], default="worker")
    ap.add_argument("--speed", type=float, default=1.0, help="relative speed vs a Tesla T4 (estimate)")
    a = ap.parse_args(argv)
    L = layout(a)
    if not (3, 10) <= sys.version_info[:2] <= (3, 13):
        print(f"STOP: Python {platform.python_version()} is outside the tested range 3.10-3.13"); return finish(EXIT_CONTRACT)
    try:
        man = frozen_manifest()
    except IntegrityError as e:
        print(f"STOP: {e}"); return finish(EXIT_MANIFEST)
    import torch
    gpu = torch.cuda.is_available()
    if a.role == "worker" and a.device.startswith("cuda") and not gpu:
        print("STOP: no GPU in this runtime (a worker never falls back to the CPU silently)"); return finish(EXIT_CONTRACT)
    sig = environment_signature(a.device)
    rec = {"name": safe_name(a.worker), "role": a.role, "device": a.device, "signature": sig,
           "env_class": signature_key(sig), "speed": float(a.speed),
           "gpu_name": torch.cuda.get_device_name(0) if gpu else None,
           "gpu_memory_gb": round(torch.cuda.get_device_properties(0).total_memory / 1e9, 1) if gpu else None,
           "python": platform.python_version(), "platform": platform.platform(), "code_hash": code_hash(),
           "frozen_manifest_content_sha256": man["content_sha256"], "registered_utc": utc_now()}
    p = L.registry / f"worker_{rec['name']}.json"
    atomic_write_json(p, rec)
    print(json.dumps(rec, indent=1))
    print(f"registered: {p}")
    return finish(EXIT_OK)


if __name__ == "__main__":
    sys.exit(main())
