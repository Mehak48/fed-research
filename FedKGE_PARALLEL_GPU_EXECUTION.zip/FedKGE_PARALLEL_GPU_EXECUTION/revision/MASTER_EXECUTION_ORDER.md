> **Historical page (original package).** It describes the Phases 1-4 notebook order. The current, frozen methodology is `13_documentation/FINAL_METHODOLOGY.md`; the execution procedure is `../EXECUTION_GUIDE.md` and the notebook `../RUN_COMPLETE_FEDKGE_RESEARCH.ipynb`. Kept unchanged below for the record.

# MASTER EXECUTION ORDER — Phases 1–4

Do every row for **smoke**, then repeat all rows for **dev**, then for **final** (set `TIER` in each notebook's
SETTINGS cell). Results root: `/content/drive/MyDrive/fedkge_results` (below: `R/<tier>/…`).

| # | Run | It produces | Check this file before moving on | Next | Preserve |
|---|---|---|---|---|---|
| 0 | (once) `python -m pytest -q 12_validation_tests` | test report | all tests pass | 1 | — |
| 1 | `02_phase1_data/phase1_data.ipynb` | `R/<tier>/artifacts/p1/<ds>/*` | `…/p1/<ds>/validation_report.json` → `"ok": true`, all overlaps 0; `reports/p1/*dataset_summary.csv`; last cell `RUN STATUS: COMPLETE` | 2 | whole `artifacts/p1/` |
| 2 | `03_phase2_noniid/phase2_noniid.ipynb` | `R/<tier>/artifacts/p2/<ds>/<spec>/seed*` | `reports/p2/*partition_stats.csv` (sizes, Gini, largest share); `COMPLETE` | 3 | whole `artifacts/p2/` |
| 3 | `04_phase3_federated/phase3_federated.ipynb` (repeat until `COMPLETE`) | `R/<tier>/runs/p3_*`, `index/p3_runs_index.csv`, `reports/p3/*` | `reports/p3/*p3_reference.csv` (per-seed MRR, mean/SD/CI); `…p3_legacy_replica.csv` (old number reproduced vs corrected); `COMPLETE` | 4 | `runs/p3_*`, `index/p3_*`, `reports/p3/` |
| 4 | `05_phase4_dp/phase4_dp.ipynb` (repeat until `COMPLETE`) | `R/<tier>/runs/p4_*`, `selection/dp_selection.json`, `index/p4_runs_index.csv`, `reports/p4/*` | `selection/dp_selection.json` (C_sel, schedule per dataset + full candidate tables); `reports/p4/*p4_dp_ladder.csv` + `*_paired_steps.csv`; `*p4_privacy_utility.csv`; notebook prints "accountant checks passed"; `COMPLETE` | send results → P5–P8 delivery | `runs/p4_*`, `selection/`, `index/`, `reports/p4/`, `_cache/` |

## When is a phase valid?
* **P2** is valid only while P1's `content_hash` is unchanged (checked on every load).
* **P3/P4 runs** are valid only while: code hash unchanged, P1 and P2 hashes unchanged, used selection values
  unchanged, tier = the tier being analysed. Otherwise they show up as `STALE_*` and are rerun automatically.
* **P4 stage 2** starts only after stage 1 is complete for all seeds and C_sel is selected; **stage 3** only after
  the schedule is selected. **P4** itself requires **P3 complete** (ladder L0).
* **Final-tier evidence** = only `R/final/…`. Nothing under `R/smoke` or `R/dev` may be cited (files are prefixed
  `*_NOT_FOR_MANUSCRIPT_`).

## What to send me for P5–P8
`R/final/index/`, `R/final/selection/`, `R/final/reports/`, and the `final.json` + `accountant.json` of a few runs
(or the whole `R/final/runs/` folder zipped), plus the manuscript and teacher review.
