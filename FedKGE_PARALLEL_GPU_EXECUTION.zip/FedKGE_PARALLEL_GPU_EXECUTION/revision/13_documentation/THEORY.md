# Theory notes relevant to Phases 1–4 (privacy)

Only standard, citable results are used; no new theorem is claimed.

**Prop. 1 (per-client guarantee).** With Poisson sampling rate q_i, noise multipliers σ_t and K_i steps per round,
client i's transmitted updates over T rounds satisfy RDP ε_i(α) = Σ_t K_i · ε_SGM(α; q_i, σ_t) at every order α
(composition of RDP, Mironov 2017; subsampled Gaussian RDP, Mironov, Talwar & Zhang 2019), hence (ε_i, δ)-DP with
ε_i = min_α [ε_i(α) + conversion(α, δ)] (conversion as implemented in `dp_accounting`, Balle et al. 2020 style).

**Prop. 2 (post-processing).** Server aggregation, early-stopping selection on server-held validation data, and
all evaluation are functions of the released updates and public/server data; they do not increase ε_i
(post-processing, Dwork & Roth 2014). Adaptive but *data-independent* schedules fixed before training are
covered by Prop. 1; a schedule adapted to client data during training would not be, and is not used.

**Prop. 3 (fair schedule comparison).** Because σ₀ is calibrated so that ε_i(R_max) ≤ ε* for every schedule,
utility differences between schedules at the same ε* are privacy-matched; any reported gain is a genuine
privacy-utility improvement, not extra privacy spending.

**What we do NOT claim.** No utility/convergence theorem for DP-TransE; no claim that trust aggregation gives
privacy; no client-level DP; RDP-to-(ε, δ) conversions are upper bounds (PLD shows the gap).

**Statistics (n = 5 seeds).** Seeds pair partitions, initialisation and sampling across configurations, so
comparisons are paired by seed: mean difference with 95% t-CI, d_z, paired t-test, exact sign-flip test. The
smallest attainable exact two-sided p with n = 5 is 0.0625; effect sizes with CIs are primary.
