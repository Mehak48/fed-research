"""Link-prediction evaluation.

Protocol (replaces the old random-300-triple, tail-only, optimistic, test-selected evaluation):
  * every query triple is ranked twice: tail prediction (h, r, ?) and head prediction (?, r, t);
  * FILTERED setting: all other entities forming a known-true triple (train U valid U test) are removed;
  * REALISTIC tie handling: rank = 1 + #(score > s_true) + #(score == s_true, others)/2
    (the expected rank under uniformly random tie-breaking); optimistic and pessimistic ranks are stored too;
  * metrics: MRR, Hits@1/3/10 (realistic), per direction, per relation, with a bootstrap CI over queries.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Dict, Optional

import numpy as np
import torch

from .model import Params, ent_repr


class FilterIndex:
    """Known-true answers for filtered ranking."""

    def __init__(self, all_true: np.ndarray):
        self.tails = defaultdict(list)
        self.heads = defaultdict(list)
        for h, r, t in all_true.tolist():
            self.tails[(h, r)].append(t)
            self.heads[(r, t)].append(h)


def _scores_all_tails(params: Params, h, r, normalize: bool) -> torch.Tensor:
    E = ent_repr(params["ent"], normalize)
    q = ent_repr(params["ent"][h], normalize) + params["rel"][r]
    return -torch.cdist(q, E)


def _scores_all_heads(params: Params, r, t, normalize: bool) -> torch.Tensor:
    E = ent_repr(params["ent"], normalize)
    q = ent_repr(params["ent"][t], normalize) - params["rel"][r]      # ||e + r - t|| = ||e - (t - r)||
    return -torch.cdist(q, E)


def _ranks(scores: torch.Tensor, true_idx: torch.Tensor, filt_lists) -> Dict[str, torch.Tensor]:
    b = scores.shape[0]
    s_true = scores[torch.arange(b, device=scores.device), true_idx].clone()
    rows, cols = [], []
    for i, lst in enumerate(filt_lists):
        if lst:
            rows.extend([i] * len(lst)); cols.extend(lst)
    if rows:
        scores[torch.tensor(rows, device=scores.device), torch.tensor(cols, device=scores.device)] = -float("inf")
    scores[torch.arange(b, device=scores.device), true_idx] = s_true
    greater = (scores > s_true[:, None]).sum(1).double()
    equal = (scores == s_true[:, None]).sum(1).double() - 1.0
    return {"optimistic": 1 + greater, "pessimistic": 1 + greater + equal, "realistic": 1 + greater + equal / 2}


def _metrics(r: np.ndarray) -> Dict[str, float]:
    return {"mrr": float(np.mean(1.0 / r)), "hits@1": float(np.mean(r <= 1)), "hits@3": float(np.mean(r <= 3)),
            "hits@10": float(np.mean(r <= 10)), "mean_rank": float(np.mean(r))}


@torch.no_grad()
def evaluate(params: Params, triples: np.ndarray, filt: FilterIndex, normalize: bool, device,
             batch_size: int = 256, bootstrap: int = 0, seed: int = 0, per_relation: bool = False) -> Dict:
    if len(triples) == 0:
        raise ValueError("evaluation set is empty")
    T = torch.as_tensor(triples, device=device, dtype=torch.long)
    out = {k: {"tail": [], "head": []} for k in ("realistic", "optimistic", "pessimistic")}
    for b in range(0, len(T), batch_size):
        x = T[b:b + batch_size]
        h, r, t = x[:, 0], x[:, 1], x[:, 2]
        hl, rl, tl = h.tolist(), r.tolist(), t.tolist()
        st = _scores_all_tails(params, h, r, normalize)
        rt = _ranks(st, t, [[e for e in filt.tails[(a, c)] if e != d] for a, c, d in zip(hl, rl, tl)])
        sh = _scores_all_heads(params, r, t, normalize)
        rh = _ranks(sh, h, [[e for e in filt.heads[(c, d)] if e != a] for a, c, d in zip(hl, rl, tl)])
        for k in out:
            out[k]["tail"].append(rt[k].cpu().numpy()); out[k]["head"].append(rh[k].cpu().numpy())
    res: Dict = {"n_queries": int(2 * len(triples)), "tie_policy": "realistic"}
    ranks = {k: {d: np.concatenate(v[d]) for d in v} for k, v in out.items()}
    both = np.concatenate([ranks["realistic"]["tail"], ranks["realistic"]["head"]])
    res.update(_metrics(both))
    res["tail"] = _metrics(ranks["realistic"]["tail"]); res["head"] = _metrics(ranks["realistic"]["head"])
    res["mrr_optimistic"] = _metrics(np.concatenate([ranks["optimistic"]["tail"], ranks["optimistic"]["head"]]))["mrr"]
    res["mrr_pessimistic"] = _metrics(np.concatenate([ranks["pessimistic"]["tail"], ranks["pessimistic"]["head"]]))["mrr"]
    if bootstrap:
        rng = np.random.default_rng(seed)
        rr = 1.0 / both
        bs = [rr[rng.integers(0, len(rr), len(rr))].mean() for _ in range(bootstrap)]
        res["mrr_bootstrap_ci95"] = [float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))]
    if per_relation:
        rel = np.concatenate([triples[:, 1], triples[:, 1]])
        res["per_relation_mrr"] = {int(k): float(np.mean(1.0 / both[rel == k])) for k in np.unique(rel)}
    return res


@torch.no_grad()
def evaluate_legacy(params: Params, test: np.ndarray, all_true: np.ndarray, normalize: bool, device,
                    n: int, seed: int) -> Dict:
    """Reproduction of the OLD protocol (random n test triples, tail-only, optimistic ties).
    Reported only in the legacy-replica rows, labelled 'legacy_protocol'. Never used for selection."""
    rng = np.random.default_rng(seed)
    sub = test[rng.choice(len(test), size=min(n, len(test)), replace=False)]
    known = defaultdict(set)
    for h, r, t in all_true.tolist():
        known[(h, r)].add(t)
    ranks = []
    for h, r, t in sub.tolist():
        s = _scores_all_tails(params, torch.tensor([h], device=device), torch.tensor([r], device=device),
                              normalize)[0].cpu().numpy()
        for t2 in known[(h, r)]:
            if t2 != t:
                s[t2] = -1e9
        ranks.append(int(np.sum(s > s[t])) + 1)
    r = np.array(ranks, dtype=float)
    return {**_metrics(r), "protocol": f"legacy: {len(sub)} random test triples, tail-only, optimistic ties"}


@torch.no_grad()
def targeted_success(params: Params, targets: np.ndarray, normalize: bool, device, k: int = 10) -> Dict:
    """targets: (M,3) array (h, r, t_star) with t_star an attacker-chosen FALSE tail.
    Success = t_star ranked within top-k among all entities for query (h, r, ?) (raw ranking: t_star is not a
    true answer, and the attacker cares about what users would see)."""
    if len(targets) == 0:
        return {"target_hits@10": float("nan"), "target_mrr": float("nan"), "n_targets": 0}
    T = torch.as_tensor(targets, device=device, dtype=torch.long)
    s = _scores_all_tails(params, T[:, 0], T[:, 1], normalize)
    s_star = s[torch.arange(len(T), device=device), T[:, 2]]
    rank = 1 + (s > s_star[:, None]).sum(1).double() + ((s == s_star[:, None]).sum(1).double() - 1) / 2
    rk = rank.cpu().numpy()
    return {f"target_hits@{k}": float(np.mean(rk <= k)), "target_mrr": float(np.mean(1.0 / rk)),
            "n_targets": int(len(rk))}
