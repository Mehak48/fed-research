# Phase C — test report

**Date:** 2026-11-02, updated 2026-11-04 · **Environments:** see `environment_report.md` (local: CPU only, Python 3.13.18, torch 2.14.1; the owner's Colab: Tesla T4, Python 3.13.16, torch 2.11.0+cu130). The 2026-11-02 version is kept in `_versions/2026-11-02/`.

**Rule followed:** a test counts as passed only if it executed and passed. Skipped and not-run items are listed separately.

## 1. Test-suite runs (complete history, nothing removed)

| Run | Where | Code state | Passed | Failed | Errors | Skipped | Report |
|---|---|---|---|---|---|---|---|
| `baseline_unmodified` (2026-10-28) | local | Unmodified revision zip | 53 | 0 | 0 | 0 | `results/phaseC/test_reports/pytest_baseline_unmodified.log` |
| `phaseC_full` (2026-10-28) | local | Phase C, mid-repair | 115 | **6** | 0 | 0 | `…/summary_phaseC_full.json` (causes in §4) |
| `phaseC_handoff` (2026-11-02) | local | Phase C, before real data | 123 | 0 | 0 | 0 | `…/summary_phaseC_handoff.json` |
| `phaseC_final` (2026-11-02, 19:01) | local | Code of the Colab kit (core hash `94105bac…`) | 131 | 0 | 0 | 0 | `…/summary_phaseC_final.json` (225 s) |
| `colab_env` (2026-11-04) | **owner's Colab** | Same code (kit zip `4fb27cf8…`) | 130 | 0 | 0 | 1 | `results/phaseC/colab/session_20261104T163226Z/results_colab/test_reports/summary_colab_env.json` (436 s) |
| `phaseC_final_pc6` (2026-11-04) | local | **Final Phase C code** (core hash `f4de1447…`, after fix PC-6) | **133** | 0 | 0 | 0 | `…/summary_phaseC_final_pc6.json` (220 s) |

**The baseline run resolves Phase A's gap.** Phase A could not run the 26 PyTorch tests (no PyTorch). They now run and pass, including the Opacus comparison.

**About the Colab run:**

- **The skip is expected.** The skipped test is `test_historical_artifacts_unchanged`, with the reason "Phase A inventory or the original uploads are not present in this environment". It needs the owner's original uploads, which exist only here. It passes locally in every run.
- **The tests pin `device=cpu`.** So the Colab run checks Colab's software stack, not the GPU. The GPU path was exercised by the GPU smoke and the pilot (§5).
- **The warnings are the same benign ones as locally.**

## 2. Results by file (final run, `phaseC_final_pc6`)

| Test file | Passed | Failed | Error | Skipped | Data used |
|---|---|---|---|---|---|
| `test_accountant.py` | 12 | 0 | 0 | 0 | none (analytic / legacy parameters) |
| `test_data_partition_config.py` | 11 | 0 | 0 | 0 | synthetic |
| `test_dp_clipping.py` | 11 | 0 | 0 | 0 | synthetic tensors |
| `test_evaluate_sampling.py` | 6 | 0 | 0 | 0 | synthetic |
| `test_no_hardcoded_results.py` | 4 | 0 | 0 | 0 | source code |
| `test_phaseC_data_stats.py` | 10 | 0 | 0 | 0 | synthetic / toy files |
| `test_phaseC_integrity.py` | 10 | 0 | 0 | 0 | synthetic |
| `test_phaseC_pipeline.py` | 23 | 0 | 0 | 0 | synthetic KG |
| `test_phaseC_privacy.py` | 15 | 0 | 0 | 0 | synthetic / analytic |
| `test_phaseC_regression_matrix.py` | 6 | 0 | 0 | 0 | historical uploads (hashes), configs |
| `test_phaseC_schemas.py` | 7 | 0 | 0 | 0 | synthetic KG |
| `test_phaseC_trust_attacks.py` | 9 | 0 | 0 | 0 | synthetic tensors |
| `test_pipeline_offline.py` | 9 | 0 | 0 | 0 | synthetic KG |
| **Total** | **133** | **0** | **0** | **0** | |

**Totals:** 53 legacy tests and 80 Phase C tests. There were 13 warnings, none affecting the results:

- an Opacus backward-hook notice;
- numpy "degrees of freedom ≤ 0" from single-seed report fixtures;
- a pandas fragmentation notice.

**All test inputs are synthetic or analytic.** Passing tests show that the implementation does what it specifies. They are **not** evidence that the defence, the privacy-utility trade-off or any hypothesis holds on the benchmarks.

## 3. Coverage of the required test groups (Phase C instructions §12)

**A. Unit:**

| Area | Tests |
|---|---|
| KGE scoring and loss | `test_evaluate_sampling.py`, `test_dp_clipping.py` |
| Clipping | `test_each_example_norm_bounded`, `test_matches_opacus`, `test_matches_bruteforce_per_example_autograd`, `test_zero_out_sensitivity_of_implemented_sum`, `test_non_finite_example_is_zeroed_and_others_unchanged` |
| Noise | `test_noise_is_dense_and_scaled`, `test_pure_noise_client_and_no_noise_ablation` |
| Accounting | `test_accountant.py`, `test_phaseC_privacy.py`, plus the 96-point validation (§5) |
| Partitioning | `test_dirichlet_partition_valid_deterministic`, `test_partition_*`, `test_smoke_subset_keeps_n_train_and_caps_only_eval` |
| Trust scores and weighted aggregation | `test_phaseC_trust_attacks.py` |
| Integrity | `test_1_unchanged_artifact_passes`, `test_2_modified_artifact_fails`, `test_3_incorrect_hash_fails`, `test_serialisation_roundtrip_and_ids`, `test_persisted_store_tamper_test_and_manifest_chain` |
| Filtered evaluation | `test_filtered_head_tail_realistic_matches_bruteforce`, `test_ties_are_not_optimistic` |
| Config validation | `test_invalid_configs_fail_loudly`, `test_config_guards` |

**B. Integration** (complete small federated rounds with real model updates, DP, trust, integrity and evaluation):

- `test_full_round_dp_q_proposed_integrity_attack`;
- `test_attacks_under_dp_complete[4]`;
- `test_fedavg_runs_log_anomaly_scores_and_design_a`;
- `test_4_rejected_artifact_is_not_aggregated`;
- `test_5_verified_bytes_are_the_bytes_consumed`;
- `test_5b_aggregator_receives_exactly_the_deserialised_verified_bytes`;
- `test_mia_audit_pool_and_one_run_bound`;
- `test_every_run_output_matches_its_schema[3]`;
- `test_pipeline_offline.py`, which also runs the legacy `p3` / `p4` matrices on the synthetic KG.

**C. Regression:**

| Test | What it checks |
|---|---|
| `test_historical_artifacts_unchanged` | Re-hashes the original uploads against the Phase A inventory |
| `test_results_root_is_not_a_historical_location` | Outputs never land in historical locations |
| `test_forced_rerun_keeps_the_earlier_complete_run`, `test_archive_names_never_collide` (2026-11-04, PC-6) | A rerun never writes over an earlier run folder; the earlier folder is kept byte for byte |
| `test_no_hardcoded_results.py` | Linter against old result literals and silent fallbacks |
| `test_confirmatory_matrix_matches_phaseB_plan[full, reduced]` | Run count of every block = the Phase B plan |

**D. Reproducibility:**

- **Tests:**
  - `test_reproducible_same_seed` (same seed → identical outputs);
  - `test_deterministic_rerun`;
  - `test_dp_trainer_deterministic`;
  - `test_partition_deterministic_and_seed_dependent`;
  - `test_size_matched_synthetic_generator`.
- **Numerical tolerance:** exact equality on CPU.
- **Across environments:** Colab rebuilt every artifact. Every P1 content hash and P2 partition hash equals the local build.
- **GPU:**
  - Same seed twice on the same T4: the logged loss, ε and MRR are identical to 4 decimals in 18 / 18 pilot configurations.
  - **Bitwise GPU determinism is not tested,** and CUDA's deterministic mode is not switched on.
  - CPU and GPU results differ, because their random streams differ.

**E. Failure paths:**

| Failure | Tests |
|---|---|
| Invalid configurations | `test_invalid_configs_fail_loudly` (8 cases) |
| Missing dataset | `test_missing_dataset_files_fail`, `test_missing_upstream_fails_without_fallback` |
| Malformed checkpoint | `test_malformed_checkpoint_fails_and_is_not_trusted` |
| Invalid hash and replayed header | `test_3_incorrect_hash_fails`, `test_header_replay_and_wrong_round_fail` |
| Interrupted run | `test_resume_after_interruption` |
| Failed client updates | `test_corruption_with_and_without_verification` |
| Accountant edge cases | `test_accountant_edge_cases_raise`, `test_small_client_fails_loudly` |
| Stale code | `test_stale_code_is_detected` |

**F. PyTorch:** every test that trains or evaluates uses PyTorch. All of them execute locally and on Colab, on CPU in both places.

## 4. Failures found and how they were resolved

| Run | Failed tests | Cause | Resolution |
|---|---|---|---|
| `phaseC_full` | `test_invalid_configs_fail_loudly[stop_after_rounds]` | The test case also used synthetic data on the tune tier, which another rule rejects first | Test corrected (non-synthetic dataset name) |
| `phaseC_full` | `test_confirmatory_matrix_matches_phaseB_plan[full, reduced]` | **Real defect PC-3:** `keep_final_weights` inside the run hash split one shared experiment into two runs (X2: 9 extra) | Output-only key, merged over shared runs. Kept weights now 225 / 150, as planned |
| `phaseC_full` | 3 tests in `test_pipeline_offline.py` (`STALE_CODE`) | Core code was edited while the suite ran; stale-code detection worked as intended | No code change; rerun 9 / 9 passed. Rule adopted: no code edits during runs |

**No test failed on 2026-11-04.** Defect PC-6 was found by inspecting the Colab record, not by a failing test. Its two new tests pass. The `RUN FAILED: UnpicklingError` line in the final log is the expected output of `test_malformed_checkpoint_fails_and_is_not_trusted`.

## 5. Smoke tests and other executions (not pytest)

| Step | Where / data | Result | Record |
|---|---|---|---|
| Privacy-accounting validation | local; analytic (96 operating points) | 0 failed checks, run twice (system Python and project venv) | `privacy_accounting/accounting_validation_*.csv` |
| Small runs, 11 profiles × 3 datasets | local CPU; **real** benchmark subsets (3,000 training triples, 3 rounds) | **33 of 33 complete** | `smoke/small_runs_<dataset>.csv`, `logs/smoke_small_runs_*.log` |
| Schema validation of the real smoke tier, after the 33 small runs | local; real | 60 items, 0 failures | `test_reports/schema_validation_smoke_20261102T130952Z.json` |
| Every block in smoke, part 1: tuning chain | local CPU; **real** subsets | **Complete.** All 6 stages ran: 114 entries (99 runs, 15 reused winners). Every selection was made by the pre-registered rules; the smoke-only τ placeholder was **not** needed | `smoke/plan_tune_status_20261102T134418Z.csv`, `smoke/selection/tuning.json` |
| Every block in smoke, part 2: confirmatory matrix (reduced profile, one seed per block) | local CPU; **real** subsets | **Complete.** All 28 blocks: 329 entries (322 runs, 7 shared), 0 failures. DP2 and R1q have no runs of their own: with the fixed schedule that the smoke chain selected, they equal DP1 and R1p | `smoke/plan_confirm_status_20261102T135654Z.csv` |
| Every block in smoke, part 3: legacy replicas L1–L4 (2026-11-04; gap PC-7) | local CPU; **real** FB15k-237 subset | **6 of 6 complete** (`R3_legacy`, `R3_fixed`, `R4_legacy`, `L1_legacy`, `L2_trainer_fixed`, `L3_accounting_fixed`); 1 partition built (5-client relation-disjoint) | `smoke/legacy_blocks_status_*.csv`, `manifests/*_legacy_blocks_smoke.json` |
| Schema validation after the full smoke run | local; real | First pass: 3 failures. The non-private M1 audits have no accountant ε, but the MIA schema required the red-line flag anyway (schema defect PC-5, fixed). Second pass: **496 items, 454 run directories, 0 failures** | `test_reports/schema_validation_smoke_20261102T135703Z.json` (failures kept) and the later report |
| Schema validation of the whole smoke tier (2026-11-04) | local; real | **506 items, 460 run directories, 0 failures** (the 6 legacy runs included) | `test_reports/schema_validation_smoke_20261104T171721Z.json` |
| Real-data small runs after the PC-6 fix | local CPU; WN18RR subset; `np_fed`, `dp_q`, `complete` | 3 of 3 complete. The earlier folders, from older code, were moved to `smoke/stale/` | `smoke/small_runs_wn18rr.csv` |
| Colab kit dry run (`revision/colab/phaseC_pilot_colab.ipynb`, run on this CPU; only Colab's Drive mount, pip install and the CUDA device were replaced) | local; real (WN18RR) | Complete in 6.5 min | scratchpad dry-run log (summarised here) |
| **GPU smoke** (2026-11-04) | **owner's Colab T4**; real subsets; `np_fed`, `dp_q`, `complete` × 3 datasets | **9 of 9 complete**; ε after 3 rounds equal to the CPU value (3.997) | `colab/session_20261104T163226Z/results_colab/smoke/` |
| **GPU pilot** (2026-11-04) | **owner's Colab T4**; full data, 2 rounds | **2 × 18 configurations complete, 0 failures** | `colab/session_20261104T163226Z/results_colab/pilot/`; `pilot_plan.md` §4 |
| L0 legacy checkpoint | local; real (full FB15k-237) | Executed: test MRR 0.197 (corrected), 0.240–0.280 (legacy protocol) | `pilot/L0_legacy_checkpoint_eval.json` |
| Measured pilot | local CPU; real (full data) | 18 configurations + 1 re-measurement complete; see `pilot_plan.md` | `pilot/pilot_measurements_*.csv` |

**Smoke runs are software checks:** 3 rounds on 3,000 triples barely move the model. Their MRR values (0.001–0.009) are meaningless and are not reported anywhere as results.

## 6. Not run (and why)

| Item | Why | Where it will run |
|---|---|---|
| Bitwise GPU determinism | Not a Phase C requirement; partial evidence only (§3 D) | Disclosed (`remaining_blockers.md` B17) |
| pytest on the GPU device | The tests pin `device=cpu`; the GPU path is covered by the GPU smoke and the pilot | — |
| `test_historical_artifacts_unchanged` outside this environment | It needs the original uploads at `/mnt/user-data/uploads` | Elsewhere it **skips**, and is reported as skipped (as on Colab) |
| Full-length runs (any stage ≥ 3) | Not authorised before the owner's review (Phase C §13, §16) | After approval: Stage 3 on Colab |
