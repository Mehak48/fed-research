"""Negative sampling.

correct   : k negatives per positive; each negative corrupts EITHER the head OR the tail (fair coin) with an
            entity drawn uniformly from the entities different from the one it replaces (never a copy of the
            positive, never both sides).
p3_legacy : exact old Phase 3 behaviour (1 negative, head or tail corrupted) - replica only.
p4_legacy : exact old Phase 4 behaviour (1 negative; two INDEPENDENT coin flips -> 25% of negatives equal
            the positive, 25% corrupt both sides) - replica / DP-ladder L1 only.
Negative sampling is data-independent randomness, so it does not affect the DP analysis.
"""
from __future__ import annotations

import torch


def sample_negatives(h: torch.Tensor, t: torch.Tensor, n_ent: int, k: int, mode: str,
                     generator: torch.Generator):
    B = h.shape[0]
    dev = h.device
    if mode == "correct":
        hk = h.unsqueeze(1).expand(B, k).clone()
        tk = t.unsqueeze(1).expand(B, k).clone()
        corrupt_head = torch.rand(B, k, generator=generator, device=dev) < 0.5
        # draw from {0..n_ent-1} \ {original}: sample in [0, n_ent-2], shift values >= original by one
        rnd = torch.randint(0, n_ent - 1, (B, k), generator=generator, device=dev)
        new_h = rnd + (rnd >= hk).long()
        new_t = rnd + (rnd >= tk).long()
        nh = torch.where(corrupt_head, new_h, hk)
        nt = torch.where(corrupt_head, tk, new_t)
        return nh, nt
    if k != 1:
        raise ValueError("legacy modes use exactly one negative")
    if mode == "p3_legacy":
        coin = torch.rand(B, generator=generator, device=dev) > 0.5
        rnd = torch.randint(0, n_ent, (B,), generator=generator, device=dev)
        return torch.where(coin, rnd, h).unsqueeze(1), torch.where(coin, t, rnd).unsqueeze(1)
    if mode == "p4_legacy":
        c1 = torch.rand(B, generator=generator, device=dev) > 0.5
        r1 = torch.randint(0, n_ent, (B,), generator=generator, device=dev)
        c2 = torch.rand(B, generator=generator, device=dev) > 0.5
        r2 = torch.randint(0, n_ent, (B,), generator=generator, device=dev)
        return torch.where(c1, r1, h).unsqueeze(1), torch.where(c2, t, r2).unsqueeze(1)
    raise ValueError(f"unknown negative mode {mode}")
