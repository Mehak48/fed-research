# Privacy and robustness summary

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

## Privacy

- Guarantee: worst-client RDP (ε, δ = 1e-6) per trained model; triple-level, zero-out adjacency; PLD / PRV are cross-checks.
- **Not end-to-end:** the privacy cost of the 99 Stage-3 tuning runs, of hyperparameter selection and of releasing several models trained on the same client data is NOT included in any reported ε.

- DP cells recorded: 145; largest worst-client ε: 7.330; budget_ok in every cell: False.

## Membership inference (H3)

- Holm status: PROVISIONAL (incomplete family)
- FB15k-237: MISSING_RUNS — NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed
- WN18RR: MISSING_RUNS — NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed
- CoDEx-M: MISSING_RUNS — NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed

## Robustness (H2, H2b)

- H2b: PROVISIONAL (incomplete family); decisions {"PENDING": 3}
- H2: PROVISIONAL (incomplete family); decisions {"PENDING": 21}

## Trust-rule diagnostics

- FB15k-237: τ* = 2.0 — tau rule met
- WN18RR: τ* = 3.0 — tau rule met
- CoDEx-M: τ* = 5.0 — tau rule met
- Benign FPR per client-size third: see the table 'fpr_by_size_third' (diagnostic only, decision B4).

## Flags

- D10 utility review: D10 not triggered: r = 0.937 >= 0.25 on fb15k237
