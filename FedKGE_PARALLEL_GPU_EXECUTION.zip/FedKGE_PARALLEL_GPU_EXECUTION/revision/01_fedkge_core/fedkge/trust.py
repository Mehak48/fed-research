"""Proposed update-based trust-weighted aggregation (the frozen rule of Phase B 03 section 8.3, decision D15).

Inputs per round t: the updates actually transmitted, U_i = theta_i^local - theta^t (DP-noised when DP is on),
and public client sizes n_i. NOTHING else (no client-reported losses: those were an un-noised release outside
the privacy accountant in the old design). Because only DP outputs are used, this is post-processing and adds
NO privacy loss - but it also PROVIDES no privacy: it is a robustness mechanism, not a privacy mechanism.

  1. Reference update        U_ref = coordinate-wise median_i U_i                       (no server data)
  2. Directional anomaly     a_i = 1 - cos(U_i, U_ref)                                  in [0, 2]
  3. Magnitude anomaly       m_i = | log( ||U_i|| / median_j ||U_j|| ) |                (median over ALL updates)
  4. MAD standardisation     z(x_i) = (x_i - median_j x_j) / (1.4826 * MAD_j(x) + 1e-12)
                             A_i = max( z(a_i), z(m_i) )
  5. Flag                    flag_i = [A_i > tau]                                        (tau in MAD units)
  6. History                 h_i <- h_i + flag_i ;  trust t_i = exp(-lam * h_i) * (1 - flag_i)
  7. Norm bound (optional)   accepted U_i rescaled to norm <= median_j ||U_j||
  8. Weights                 w_i = n_i t_i / sum_j n_j t_j
  9. Fallback                if every client is rejected: coordinate-wise median (logged as fallback)

Owner decision B4 (2026-11-04): the variant V1 (magnitude reference = the median norm of the client's declared-size
third, switched on by the D15 trigger) and its switching mechanism are REMOVED. Only the frozen rule above exists.
The declared-size thirds remain a DIAGNOSTIC: benign false-positive rates are reported per size third
(selection.benign_fpr_table, final.json anomaly_scores), they never change the rule.
"""
from __future__ import annotations

from typing import Dict, Optional

import numpy as np
import torch

MAD_SCALE = 1.4826


def coordinate_median(U: torch.Tensor) -> torch.Tensor:
    """Exact median along clients (average of the two middle values for even n)."""
    n = U.shape[0]
    s, _ = torch.sort(U, dim=0)
    return s[n // 2] if n % 2 else 0.5 * (s[n // 2 - 1] + s[n // 2])


def _median1d(x: torch.Tensor) -> torch.Tensor:
    return x.median() if len(x) % 2 else 0.5 * torch.sort(x)[0][len(x) // 2 - 1: len(x) // 2 + 1].sum()


def robust_z(x: torch.Tensor) -> torch.Tensor:
    med = _median1d(x)
    mad = _median1d((x - med).abs())
    return (x - med) / (MAD_SCALE * mad + 1e-12)


def size_thirds(declared_sizes: np.ndarray) -> np.ndarray:
    """Group label 0/1/2 (small/middle/large) of every identity by its PUBLIC declared size (rank-based thirds,
    ties broken by index). DIAGNOSTIC ONLY (benign false-positive rate per size third); never used by the rule."""
    order = np.argsort(np.asarray(declared_sizes, float), kind="stable")
    lab = np.empty(len(order), dtype=np.int64)
    for g, chunk in enumerate(np.array_split(order, 3)):
        lab[chunk] = g
    return lab


def anomaly_scores(U: torch.Tensor, ref: Optional[torch.Tensor] = None) -> Dict[str, torch.Tensor]:
    """Anomaly scores of the rows of U under the frozen rule: direction relative to the coordinate-wise median
    update, magnitude relative to the median norm of ALL rows."""
    ref = coordinate_median(U) if ref is None else ref
    norms = torch.linalg.vector_norm(U, dim=1)
    cos = (U @ ref) / (norms * torch.linalg.vector_norm(ref) + 1e-12)
    a = 1.0 - cos
    med_norm = _median1d(norms)
    m = torch.log((norms + 1e-12) / (med_norm + 1e-12)).abs()
    za, zm = robust_z(a), robust_z(m)
    return {"ref": ref, "norms": norms, "median_norm": med_norm, "cos": cos, "a": a, "m": m, "z_a": za, "z_m": zm,
            "A": torch.maximum(za, zm)}


class TrustState:
    """History h_i is indexed by IDENTITY (0..n-1). Each round the caller passes the updates that passed integrity
    verification and the identities they belong to (`idx`); identities absent this round keep their history."""

    def __init__(self, n_clients: int, tau: float, lam: float, norm_bound: bool):
        self.tau, self.lam, self.norm_bound = float(tau), float(lam), bool(norm_bound)
        self.history = np.zeros(n_clients)

    def aggregate(self, U: torch.Tensor, sizes: np.ndarray, idx: Optional[np.ndarray] = None) -> Dict:
        idx = np.arange(U.shape[0]) if idx is None else np.asarray(idx, dtype=np.int64)
        sc = anomaly_scores(U)
        A = sc["A"].cpu().numpy()
        flags = A > self.tau
        self.history[idx] += flags
        trust = np.exp(-self.lam * self.history[idx]) * (~flags)
        w_raw = sizes * trust
        fallback = bool(w_raw.sum() <= 0)
        if fallback:
            agg = sc["ref"]
            weights = np.zeros_like(w_raw)
        else:
            weights = w_raw / w_raw.sum()
            Uc = U
            if self.norm_bound:
                factor = torch.clamp(sc["median_norm"] / (sc["norms"] + 1e-12), max=1.0)
                Uc = U * factor[:, None]
            agg = (torch.as_tensor(weights, device=U.device, dtype=U.dtype)[:, None] * Uc).sum(0)
        return {"update": agg, "weights": weights, "flags": flags, "history": self.history[idx].copy(),
                "trust": trust, "fallback": fallback, "A": A, "a": sc["a"].cpu().numpy(), "m": sc["m"].cpu().numpy(),
                "z_a": sc["z_a"].cpu().numpy(), "z_m": sc["z_m"].cpu().numpy(), "cos": sc["cos"].cpu().numpy(),
                "norms": sc["norms"].cpu().numpy()}

    def state_dict(self): return {"history": self.history.tolist()}
    def load_state_dict(self, d): self.history = np.array(d["history"], dtype=float)
