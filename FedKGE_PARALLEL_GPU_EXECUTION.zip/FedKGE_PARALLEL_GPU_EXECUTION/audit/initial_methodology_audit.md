# Initial methodology audit — Phase A

**Scope:** Phase A of the master prompt (inventory + audit). Nothing was implemented, repaired or re-trained.
**Date:** 2026-10-28
**Inputs:** the five artifacts listed in `audit/artifact_inventory.md` (File 2 = `fedkge_revision_P1-P4.zip` — **assumed**, please confirm).
**Companion files**

| File | Contents |
|---|---|
| `audit/artifact_inventory.md` (+ `data/artifact_inventory.csv`) | every supplied file, with status and provenance |
| `audit/result_provenance.csv` | 47 manuscript claims, each re-derived from the legacy outputs, plus 5 Phase A privacy calculations |
| `audit/data/phaseA_epsilon_check.json` | the privacy recomputation (Section 4) |
| `audit/data/revision_tests_phaseA.log`, `…_junit.xml` | revision test-suite run |
| `audit/scripts/` | the three scripts that produced all of the above (re-runnable) |

**Number labels used here** (master prompt §16):

| Label | Meaning |
|---|---|
| **[Reported]** | stated in the original manuscript (historical claim) |
| **[Legacy-measured]** | produced by an actual run of the original code |
| **[Calculated]** | computed in Phase A from legacy parameters or legacy outputs |
| **[Unverified]** | no source available |

No number in this document is a new experimental result.

---

## 0. Executive summary

1. **Only two experiments in the whole project are real.** One non-private FedAvg run (Phase 3, MRR 0.2858 **[Legacy-measured]**) and one DP run (Phase 4, MRR 0.009 **[Legacy-measured]**), each single-seed and evaluated with a weak protocol (300 or 150 random test triples, tail prediction only, optimistic ties). A second DP run (σ = 1.2) exists only in an upload and a log. Phases 1–2 are descriptive statistics.
2. **Phases 5–8 produced no experimental evidence.** Every security, baseline, ablation, overhead and statistics number in the manuscript is hard-coded, formula-derived or "simulated" without training or attacking anything. This covers 304 %, the centralised MRR 0.094, FedAvg +8.7 %, Krum +28.21 %, 100 % poisoning defence, 82.85 % Sybil defence, 30.56 % MI reduction, ε* = 9.28, the τ ablation, 0.8 ms per CID, Wilcoxon p = 3.05 × 10⁻⁵, Cohen's d and the 95 % CI. 37 of the 47 manuscript claims were re-derived exactly from the legacy outputs using the code's own expressions; the other 10 are contradicted by the code, inaccurate, or non-numeric (`result_provenance.csv`).
3. **The reported ε = 15.53 is not a valid privacy guarantee.** It is the sum over 16 rounds of the *mean over clients* of a fresh per-round ε, with δ never composed. I reproduced the logged per-round ε of every client exactly, using Opacus's own analysis code and independently with Google's `dp_accounting`. With correct per-client RDP composition, the executed run's worst-client guarantee is **ε ≈ 1.98 at δ = 1e-5** (PLD accountant: 1.76) **[Calculated]**. Both audit leads are reproduced, and their assumptions identified:
   - **1.98** = the worst client over the 16 executed rounds;
   - **6.43** = the worst client if σ = 1 DP had run for 150 epochs (the Phase 3 schedule of 50 rounds × 3 local epochs).
   The run stopped at round 16 because of the naive sum, not because privacy was exhausted.
4. **The headline result mixes components that never ran together.** The "proposed system" row pairs the non-private MRR 0.2858 with DP, trust and IPFS properties; none of these were active in that model. The only private model scored MRR 0.009.
5. **Several mechanisms differ from their description.**
   - Trust is computed from client-reported, un-noised **losses**; the manuscript says it is the cosine of update vectors.
   - There is no IPFS: the store holds SHA-256 hashes prefixed "Qm" of **random tensors**.
   - No adaptive noise schedule was ever run.
   - The partition is relation IDs cut in ID order (largest client 30.81 %); the manuscript reports a frequency-sorted preview (74.26 %) that was never trained.
6. **The revision package (File 2) is a sound base for Phases 1–4.** It has correct accounting, a proper evaluation protocol, seeds, validation-only selection, legacy replicas and a linter against hard-coded results. However:
   - it has **never been executed** (no results exist);
   - only 27 of 53 tests could run here, and all 27 passed (the rest need PyTorch);
   - Phases 5–8 (trust, attacks, integrity, baselines, plots) have code but **no experiments**;
   - it misses several requirements of the master prompt (α = 0.5, 3D plots, scripts, licence gate, threat model, tuning cost) and has four design gaps found in this audit (Section 9.2).
7. **IEEE readiness: not submittable as is.** After the repairs and real multi-seed runs on three datasets, a credible submission is possible. The contribution would have to be reframed honestly: the components are individually standard, and DP utility at defensible ε may be low. That outcome must be reported, not engineered away.

---

## 1. What was done in Phase A

- Read every supplied file: the manuscript (full text), the roadmap, all eight original notebooks (code and saved outputs), all 56 result files, and the revision package (every module, config, schema, test and document). The inventory is in `artifact_inventory.md`.
- Re-derived every manuscript number from the legacy outputs, using the exact expressions in the legacy code (`scripts/phaseA_build_provenance.py`). This included reproducing the legacy bootstrap CI bit-for-bit, which required replicating a hidden consumption of the random-number generator in the old Phase 7 cell.
- Recomputed the privacy loss of the legacy DP run with two independent accountants plus PLD (`scripts/phaseA_epsilon_check.py`).
- Re-derived both 5-client partitions from the saved per-relation counts.
- Ran the revision test suite on a copy: 27 passed, 26 could not run (no PyTorch).
- **Not done:** no training, no evaluation, no dataset download (no GPU or PyTorch here; dataset licences are checked in Phase D).

---

## 2. Original methodology: described (File 4) vs implemented (File 5)

| Component | Manuscript says | Code actually does | Evidence |
|---|---|---|---|
| Clients / partition | 5 clients, "relation-cluster partitioning that preserves semantic coherence"; Client-0 holds 74.26 % | 5 clients = `np.array_split(np.unique(relation_ids), 5)` (ID order, no clustering). Shares 30.81 / 20.70 / 15.16 / 18.39 / 14.95 %. The 74.26 % comes from a Phase 2 preview that sorts by frequency and is never trained | `phase3_updated` partition function; `phase2` cell 11; re-derived from `rollup_by_relation.csv` |
| Non-IID characterisation | Gini 0.675, skewness 34.39 "across the five-client partition" | statistics of the **whole** training graph, not differences between clients | `phase1` / `phase2` cells |
| KGE model | TransE, d = 100, 64 negatives | TransE d = 100. **1 negative** per triple in P3; in P4 two independent coin flips make 25 % of negatives identical to the positive and 25 % corrupt both sides; P3 normalises entities, P4 does not | `KGEDataset`, `KGETupleDataset`, `TransE` vs `TransEDP` |
| Training | 50 rounds (P3), 20 rounds (P4) | P3: 50 rounds × 3 local epochs, Adam (fresh each round), batch 512. P4: 16 rounds × 1 epoch, batch 256 | outputs |
| Evaluation | "full test-set evaluation", filtered | 300 (P3) / 150 (P4) random test triples, re-drawn every round with the global RNG; **tail only**; optimistic ties; test evaluated every round; last round reported | `evaluate_mrr_hits`, `evaluate_mrr` |
| DP | "RDP accountant with an adaptive noise schedule", ε = 15.0, δ = 1e-5 | Opacus DP-SGD, σ = 1.0 **fixed** (header text says 2.0 → 0.5 exponential); fresh accountant per client per round; ε reported = Σ_rounds mean_clients(ε_round); fallback `eps = sigma*0.5` on exception; warm-start code present (not triggered) | `phase4_ready` cells 0, 2, 6 |
| Trust | τ_k = cos(Δθ_k, Δθ_ref) · exp(−λ·anomaly_k), λ = 0.5, τ_min = 0.15 | `consistency = clip(1 − abs(loss_k − median)/median, 0, 1)` × exp(−λ·count). Uses client-reported un-noised losses; no update vectors, no cosine | `phase6` `TrustScorer` |
| Poisoning / Sybil / MI | 100 % / 82.85 % / 30.56 % at 5–20 % attackers | `mrr = P3_MRR·(1 − w_mal·0.95)`; Sybil "defence" = 1 − weight share; MI ASR = clip(0.72·exp(−0.08 ε), 0.5); with 5 clients, every ratio gives 1 attacker | `phase6` cell 16 |
| IPFS | content-addressed checkpoint storage, 0.8 ms per CID | local folder; ID = "Qm" + 44 hex characters of SHA-256 (not a CID); stores **random** 14,505 × 100 tensors (no trained model); 20 objects = 1 demo + 3 × (1 global + 5 clients) + 1 final; 0.8 ms is a literal | `phase6` cells 4 and 6; `phase7` cell 4 |
| Baselines | centralised 0.094, FedAvg 0.2629, Krum 0.2229, StdDP 0.01215 | literals or `P3_MRR × 0.92`, `× 0.78`, `P4_MRR × 1.35`; no run exists | `phase5` cell 4, `phase7` cell 4 |
| Statistics | Wilcoxon p < 0.001, d = 6.21, CI [0.2425, 0.2726] | tests over rounds of single runs; d against a constant with an assumed SD of 0.01 | `phase7` cell 28 |

---

## 3. Result provenance (summary — full table in `result_provenance.csv`)

| Group | Claims | What produced them | Verdict |
|---|---|---|---|
| Phase 3 MRR / Hits, loss curve, peak | C01–C04 | real run, legacy protocol | traced. Valid only as "legacy protocol, 1 seed". "Full test set" is false |
| Phase 3 curve descriptions | C05–C06 | real history | inaccurate: round-7 MRR is 0.3008, not 0.24; the minimum over rounds 20–50 is 0.2209 |
| 98.6 % of a "0.29 ceiling" | C07 | text only | unverified, and a protocol mismatch |
| Centralised 0.094 / 304 % / 3.04× | C08–C09 | hard-coded constant | invalid |
| FedAvg / Krum / StdDP and their % gains | C10–C13 | fixed multiples / literals | invalid |
| ε = 15.53 | C14 | naive sum of client means | invalid as a guarantee |
| Phase 4 MRR 0.009, −96.85 % | C15–C16 | real run / arithmetic | traced, but the comparison is confounded |
| Fig. 13 caption | C17 | **two different runs** mixed (σ = 1.2: 0.623 per round, 20 rounds; σ = 1.0: 15.53, 16 rounds) | contradicted |
| Runtime overhead | C18 | totals of non-comparable runs | misleading: per round 148.0 s vs 24.1 s (6.1×), per local epoch ≈ 18×, not "≈ 2×" |
| Parameters / model size / bandwidth | C19–C21 | arithmetic | correct (wording "10 clients" is wrong: 5 clients × 2 directions) |
| Schedule ablation, ε* = 9.28 | C22–C23 | formulas (ε grows *with* noise) | invalid |
| IPFS count / size / latency, trust overhead | C24–C26 | simulated / literals | invalid or misdescribed (SHA-256 of one 5.8 MB object took ≈ 15 ms here — indicative only) |
| Trust formula | C27 | not implemented as described | contradicted |
| Poisoning / Sybil / MI / trust MRR / τ ablation | C28–C32 | formulas, simulated | invalid. The poisoning value changed from 19 % to 100 % between notebook versions with no new experiment |
| Wilcoxon, Cohen's d, CI, "all hypotheses met" | C33–C36 | statistics over rounds | invalid (pseudo-replication) |
| Gini, skewness, shares | C37 | dataset | correct as global statistics; mis-described as client heterogeneity |
| Client-0 74.26 %, "semantic" partition | C38–C39 | preview never trained | contradicted (trained Client-0 = 30.81 %) |
| Prior-work rows of Table II | C40 | literals with no source | unverified (see Section 15) |
| "This Work" row, adaptive DP, warm start, "recovers 0.2858 with privacy" | C41–C45 | | contradicted |
| Fig. 14 claim, figure captions | C46–C47 | | unsupported / misdescribed |

Over the 47 manuscript claims: 20 invalid, 8 contradicted, 3 misleading, 2 misdescribed, 2 inaccurate, 2 unverified, 1 unsupported — and only 9 traced or correct (with caveats). 37 of the 47 values were re-derived exactly from the legacy outputs. Every invalid number came from code that ran without error. That is why the linter approach of the revision package (tests that forbid result literals and metric-from-metric formulas) is necessary but not sufficient: provenance must be enforced by construction, with every table read only from run records.

---

## 4. Privacy accounting audit of the legacy DP run (the ε leads)

### 4.1 What the legacy mechanism protects

| Item | Legacy implementation |
|---|---|
| Protected data | each client's local training triples |
| Privacy unit / adjacency | one training triple (with its data-independent negative), add/remove one example — Opacus default |
| Where noise is added | on the client, inside every DP-SGD step (Poisson sampling q_k, per-example clipping C = 1, Gaussian noise σC on the summed gradient), before the local model is sent |
| What the server sees | each client's full local model after one DP epoch (no secure aggregation) |
| Adversary covered | anyone who observes a client's transmitted models, including the server and other clients; post-processing (FedAvg, evaluation) adds nothing |
| Not covered | per-client training losses (logged un-noised in `phase4_results.json` and used by the Phase 6 trust design); client dataset sizes (public, they set q); **which relations a client holds** (with relation-disjoint clients, a relation's embedding is updated only by its owner — a dataset-level property, not protected by record-level DP); the warm start (if loaded, it would void everything) |

### 4.2 Exact parameters, traced to code

Opacus `make_private` with `DataLoader(batch_size=256, drop_last=True)` gives `sample_rate q = 1/len(loader) = 1/⌊N_k/256⌋` and `⌊N_k/256⌋` steps per epoch (verified in the Opacus 1.6.0 source).

| Client | N_k | steps/round | q | logged ε_round | recomputed (Opacus code) | recomputed (`dp_accounting`) |
|---|---|---|---|---|---|---|
| 0 | 83,830 | 327 | 1/327 | 0.860877 | 0.860877 | 0.860877 |
| 1 | 56,322 | 220 | 1/220 | 0.942189 | 0.942189 | 0.942189 |
| 2 | 41,261 | 161 | 1/161 | 1.033917 | 1.033917 | 1.033917 |
| 3 | 50,033 | 195 | 1/195 | 0.975682 | 0.975682 | 0.975682 |
| 4 | 40,669 | 158 | 1/158 | 1.040574 | 1.040574 | 1.040574 |

σ = 1.0, δ = 1e-5. All five match to better than 10⁻⁶. The legacy parameters are therefore confirmed: the per-round values are genuine accountant outputs. The fallback `eps = sigma*0.5` was never triggered.

### 4.3 What each number means **[Calculated]**

| Quantity | Value | Valid? |
|---|---|---|
| Notebook's number: Σ over 16 rounds of the mean over clients | **15.5304** (δ "1e-5") | **No.** A mean over clients guarantees nothing for any client; δ was never composed; summing ignores RDP composition |
| Worst client (Client-4), basic composition of its 16 per-round values | 16.649 at δ = 16 × 1e-5 = 1.6e-4 | valid but loose; exceeds the reported 15.53 |
| **Worst client, RDP composition of all 2,528 steps** (16 rounds) | **1.9805** at δ = 1e-5 (PLD **1.7598**); 2.2785 at δ = 1e-6 (PLD 2.0246) | **yes**, under the stated assumptions |
| Largest client, same | 1.3561 at δ = 1e-5 | yes (per-client value) |
| Worst client if all 20 planned rounds had run | 2.1946 (δ = 1e-5); 2.5016 (δ = 1e-6) | hypothetical |
| Worst client, σ = 1 for **150 epochs** (= Phase 3's 50 rounds × 3 local epochs) | **6.4334** (δ = 1e-5); 7.0969 (δ = 1e-6) | hypothetical, never run |

**The two leads explained.** 1.98 and 6.43 use the *same* sampling (q = 1/⌊N/256⌋, Poisson), noise (σ = 1), clipping (C = 1, which does not affect ε), δ (1e-5), privacy step (one Poisson-sampled DP-SGD update) and composition rule (RDP over all steps of the worst client). They differ only in the number of steps: 16 epochs (executed) vs 150 epochs (hypothetical). The reported 15.53 differs from both in composition rule (sum of per-round (ε, δ) pairs), aggregation across clients (mean instead of maximum) and δ accounting (none).

**Consequences**

- The legacy run stopped at round 16 because the naive sum passed 15. The privacy actually spent was about 2. The budget was never the binding constraint.
- The manuscript's "−96.85 % privacy-utility gap" is not a DP cost. Phase 4 trained for about one-ninth as many epochs as Phase 3, with a different model (no normalisation), broken negatives, a smaller batch and a noisier evaluation.
- Under correct accounting, σ = 1 DP for the full Phase 3 training budget costs ε ≈ 6.4 (δ = 1e-5) for the worst client — well inside the stated budget of 15. Whether that would give useful MRR is unknown and must be measured.

### 4.4 Why the private model learned almost nothing (diagnosis — to be tested, not a result)

| Factor | Evidence |
|---|---|
| Signal-to-noise per step | dense noise on all P = 1,474,200 parameters. The noise norm on the averaged gradient is σC√P/B ≈ **4.74** at B = 256, against a clipped-signal norm ≤ C = 1 **[Calculated]**. It would be 2.37 at B = 512 and 0.30 at B = 4,096 (at fixed σ; the ε impact of larger q must be accounted) |
| Adam with dense noise | coordinates of entities absent from a batch receive pure noise, and Adam's per-coordinate normalisation turns that noise into steps of roughly the learning rate. Hypothesis — to be checked by comparing DP-SGD and DP-Adam |
| Training budget | 16 epochs vs 150 (stopped by the invalid ε rule) |
| Model / negatives | no entity normalisation; 25 % of negatives identical to the positive (zero gradient) |
| Evaluation noise | 150 random tail queries re-drawn each round: the per-round MRR (0.0004–0.0373) is dominated by sampling noise |

These are exactly the "incorrect implementation / excessive composition / poorly chosen settings" causes the master prompt asks to investigate. Each must be isolated by a controlled, correctly accounted experiment (Section 12) — not by removing noise.

---

## 5. Trust aggregation and integrity: claimed vs implemented

**Legacy trust (Phase 6)**
- Uses each client's **self-reported, un-noised average loss**. That release is outside the DP accountant, and a malicious client defeats it simply by reporting a median-like loss.
- The poisoning "attack" only multiplies the reported loss by 2. A deviation of 100 % gives consistency 0, so the attacker is excluded at every threshold by construction (hence Table V's flat 100 %).
- No update vector is ever compared, so the cosine formula in the manuscript is not implemented.

**Revision trust (`fedkge/trust.py`)**
- Update-based and computed only on transmitted (DP-noised) updates, so it is pure post-processing (no privacy cost and no privacy benefit):
  - reference = coordinate-wise median update;
  - direction anomaly a_i = 1 − cos(U_i, U_ref) and magnitude anomaly m_i = |log(‖U_i‖ / median‖U‖)|, each MAD-standardised; A_i = max(z_a, z_m);
  - flag if A_i > τ (MAD units); permanent history penalty exp(−λ h_i); optional norm bound; weights ∝ n_i · trust_i; median fallback.
- This gives precise definitions for roadmap step 5 (Δθ_ref, anomaly_k), but it has untested risks:
  - **Non-IID false positives:** at Dirichlet α = 0.1, legitimate clients have very different relation mixes, hence different update directions.
  - **DP-induced false positives:** σ is calibrated *per client* (smaller clients need larger σ), so update norms differ systematically by client size. The magnitude anomaly may flag small honest clients.
  - **No forgiveness:** history never decays, so an early false flag down-weights a client for the rest of training.
  - **Noise-free attackers under DP:** the targeted attacker trains without DP and the Sybil sends a scaled previous update. Both are trivially separable from noisy benign updates by norm, which would overstate robustness unless noise-mimicking variants are also evaluated (Section 9.2).

**Integrity**
- Legacy: hashes of random tensors in a folder; the identifiers imitate CIDv0; nothing was ever rejected in a training loop.
- Revision: honest SHA-256 content-addressed store with a manifest hash chain, verification on receipt and tamper tests. It states explicitly that the identifiers are not IPFS CIDs and that no IPFS properties (DHT, pinning, availability) are demonstrated.
- In both, a hash proves the bytes were not altered after hashing. It does **not** prove an update is benign; a poisoned update hashes correctly.

---

## 6. Evaluation and statistics: defects and status

| Defect (legacy) | Effect | Revision status |
|---|---|---|
| random 300/150-query subsample re-drawn each round | sampling SE ≈ 0.02 on MRR ≈ 0.29; round-to-round noise | fixed: full test set |
| tail only | not comparable with the literature (head + tail average) | fixed: both directions, also reported separately |
| optimistic ties | inflates MRR when scores tie | fixed: realistic ties (optimistic and pessimistic stored) |
| test evaluated every round; last round or peak reported | test-set selection | fixed: early stopping on V_sel; test evaluated once |
| one seed | no uncertainty | fixed: 5 seeds, paired by seed |
| Wilcoxon / d / CI over rounds | pseudo-replication | fixed: seed-level paired t-CI, d_z, exact sign-flip; the revision notes that n = 5 cannot reach p < 0.05 with exact tests |

---

## 7. Defects by severity

Status key — **A** = addressed in the revision package (by design; not yet executed), **P** = partially addressed, **N** = not addressed.

### 7.1 Critical correctness defects

| ID | Defect | Evidence | Required correction | Rev. |
|---|---|---|---|---|
| CR-1 | Hard-coded, formula-derived and simulated numbers presented as experimental findings (all of Phases 5–8; Tables II–V; most figures 15–34) | C08–C13, C22–C36 | withdraw them all; every table and figure must be read from saved run records only | P (P1–P4 + linter; P5–P8 not delivered) |
| CR-2 | Invalid ε (naive sum of client means, δ not composed); invalid stopping rule | Section 4 | per-client RDP over all executed steps, worst-client ε, explicit δ, PLD cross-check, stop or calibrate on the true ε | A |
| CR-3 | Headline "proposed" result combines a non-private model's utility with the privacy and robustness of mechanisms that were never active in it | C41, C44, C45 | one run = one configuration with all claimed mechanisms active; separate rows for non-DP, DP and full | A (design) |
| CR-4 | Invalid evaluation protocol, described as full-test evaluation | C01, Section 6 | full filtered head + tail, realistic ties, validation-selected checkpoint, test once | A |
| CR-5 | Statistics from pseudo-replication | C33–C35 | seed-level statistics | A |
| CR-6 | Trust as described is not implemented; the implemented one uses un-noised, manipulable client losses | C27 | update-based trust on DP outputs only, precisely defined, evaluated against adaptive attackers | A (code), N (experiments) |
| CR-7 | Warm start from the non-private checkpoint in the DP code and claimed in tables (would void DP) | C43 | forbid; remove the claim | A |
| CR-8 | Partition misreported (74.26 %, "semantic clustering") | C38–C39 | report the partition actually trained; measured per-client statistics | A |
| CR-9 | "IPFS integrity" never stored a trained model, has no CIDs, uses a hard-coded latency, and is described as IPFS | C24–C25 | honest content-addressed integrity layer with measured overhead, or a real IPFS integration | A (honest simulation) |
| CR-10 | "Adaptive DP" claimed, never run; schedule ablation fabricated | C22, C42 | deterministic schedules calibrated to equal ε, actually trained, or drop the claim | A (4C block), not executed |
| CR-11 | Executed configuration ≠ stated one: 1 negative instead of 64 (P3); 25 % degenerate negatives and no normalisation (P4) | Section 2 | correct negatives; one trainer for all conditions | A |
| CR-12 | DP vs non-DP comparison confounded (model, negatives, epochs, batch, evaluation) | C16 | DP ladder on the same partition and trainer, paired by seed | A (L1–L4 blocks) |

### 7.2 Major experimental deficiencies

| ID | Deficiency | Rev. |
|---|---|---|
| MJ-1 | One dataset only (three required) | P (configured, unexecuted) |
| MJ-2 | One seed | A |
| MJ-3 | No measured centralised baseline, no real aggregation baselines, no DP baseline | P (centralised + FedAvg blocks exist; Krum / TM / median / FLTrust implemented but no experiment matrix) |
| MJ-4 | No threat model, no real attacks, no attack-success definitions, no benign false-positive rate | P (7 attacks implemented; `THREAT_MODEL.md` missing; no matrix) |
| MJ-5 | No threshold sweeps with validation-only selection | P (clip / schedule / ε yes; τ deferred; α ∈ {0.1, 1.0} only — master prompt asks for 0.5 as well) |
| MJ-6 | No ablations (DP-only, trust-only, full, −integrity, −defence) | P (DP ladder only) |
| MJ-7 | "Non-IID" measured on the global graph, not across clients | A |
| MJ-8 | 5 relation-disjoint clients: robust aggregation is ill-posed (each client is the sole holder of its relations) and relation ownership leaks | A (10 Dirichlet clients; legacy kept for replicas) |
| MJ-9 | Privacy claims under-specified (unit, adjacency, threat model, what is not protected) | P (guarantee statement written; dataset-level leakage, logged losses and tuning cost not discussed) |
| MJ-10 | DP utility collapse not investigated | P (ladder, clip, schedules; batch size, optimiser and learning rate fixed a priori — Section 9.2) |
| MJ-11 | Hypotheses H1–H3 not formally defined (what "accuracy", "defence improvement", "inference resistance" mean) | P (H1 via `P3_central`; H2 / H3 open) |
| MJ-12 | Overheads hard-coded; no integrity on/off comparison | A (timings and bytes logged; integrity modes) |
| MJ-13 | Contribution weakly positioned; prior-work numbers unverified and protocol-mismatched | N |
| MJ-14 | No experiment matrix or cost estimate for Phases 5–8; no 3D plots from real data; most required tables missing | P (P3 / P4 only; 2D plots only) |

### 7.3 Minor implementation issues

| ID | Issue |
|---|---|
| MN-1 | Legacy Gini formula slightly biased (missing the 1/n correction); the revision's is correct |
| MN-2 | The Phase 4 notebook header contradicts its own configuration (ε 8, σ 2 → 0.5, 5 rounds vs 15, 1.0 fixed, 20) |
| MN-3 | Figure-number collisions; captions of manuscript figs. 5, 7, 9, 13, 14 describe things the plots do not show |
| MN-4 | Silent fallbacks: `eps = sigma*0.5` in an except-block; stub result dictionaries with invented numbers in Phases 6–8 |
| MN-5 | The legacy evaluation subsample uses the global NumPy RNG, coupling evaluation to training randomness |
| MN-6 | Manuscript wording errors: "10 clients (5 upload + 5 broadcast)", round-7 MRR, "0.27–0.31", "≈ 2× per round", "15 client + 5 global objects", "10 FL rounds" in Table III |
| MN-7 | Revision: `plotting.py` refers to a non-existent `fedkge.tables`; figures saved as PNG at 200 dpi only (PNG + PDF + SVG required) |
| MN-8 | Revision: deprecated `datetime.utcnow()`; no `scripts/` entry points (§18); PyKEEN downloads data without a licence gate (§18) |
| MN-9 | Revision: Dirichlet re-draw until the minimum client size is met gives a truncated Dirichlet (documented; attempts logged) |

### 7.4 Optional improvements

| ID | Improvement |
|---|---|
| OP-1 | Report PLD ε as the primary (tighter) figure, with RDP as a conservative cross-check — both are computed already |
| OP-2 | Privacy-aware hyperparameter tuning (Rényi-DP tuning, Papernot & Steinke 2022), or explicit disclosure that tuning cost is not accounted |
| OP-3 | If DP utility is unacceptable: a justified design alternative such as sparsity-aware DP for embedding tables, or relation-only sharing (FedR-style) with local entity embeddings. This changes the evaluation protocol, so it is your decision |
| OP-4 | Client-level DP variant (update clipping + server noise) as an extra regime |
| OP-5 | Real IPFS CIDs, or a local IPFS node, for a deployment-style overhead measurement |
| OP-6 | More seeds (≥ 6, ideally 10) for headline comparisons, so exact paired tests can reach 0.05 |
| OP-7 | A second KGE model (RotatE or ComplEx, as planned in the original methodology diagram) to test generality |
| OP-8 | Re-evaluate the saved legacy Phase 3 checkpoint under the corrected protocol (cheap, high value for the original-vs-revised table) |

---

## 8. Answers to the specific audit questions in the master prompt (§4)

| Question | Answer |
|---|---|
| Inconsistency between reported ε and the accountant? | Yes. The accountant's per-round values are genuine; the reported total is an invalid aggregation of them (Section 4). |
| 1.98 vs 6.43 vs 15.53 — compatible assumptions? | 1.98 and 6.43 share every assumption except the number of steps (16 vs 150 epochs). 15.53 uses an invalid composition (sum of per-round values), an invalid aggregation (mean over clients) and no δ composition. All three use the same q, σ, C and step definition. |
| Are MRR and poisoning results real? | MRR 0.2858 and 0.009 are real single runs under a weak protocol. Every poisoning, Sybil, MI, baseline, ablation and τ-sweep number is formula-derived or simulated. |
| Does the code implement the claimed trust aggregation? | No (loss-based, not cosine-based). The revision implements an update-based rule, not yet evaluated. |
| Does the code implement the claimed integrity verification? | It verifies SHA-256 of local files holding random tensors. It is not IPFS and no trained model was ever stored. The revision implements an honest integrity layer, not yet executed. |

---

## 9. Critical review of File 2 (revision package, assumed)

### 9.1 Strengths — keep and build on

- One orchestrator, so every run is one configuration with all components and logs. Per-run `final.json`, `accountant.json`, `rounds.csv`, config hash, code hash, data hash and partition hash; stale-run detection; resume from checkpoint.
- Correct example-level DP-SGD with exact per-example clipping on gathered rows (validated against Opacus in its tests; not runnable here). Dense noise; per-client RDP over all executed steps; worst-client ε; δ = 1e-6 (+1e-5); PLD cross-check; σ calibration to a target ε; deterministic schedules with runtime verification.
- Correct evaluation (full filtered head + tail, realistic ties), early stopping on V_sel, test once, bootstrap CI over queries.
- Legacy replicas (R3, R4, L1) that reproduce the old numbers *as labelled legacy rows*, plus a DP ladder that isolates trainer bugs → accounting → calibration → schedule → genuine DP cost.
- Pre-registered, validation-only selection rules, hashed, that refuse to run on incomplete grids.
- A linter test that forbids the old result literals, ε-from-σ formulas, "Qm" CIDs and metric-from-metric formulas.
- **27 / 53 tests pass here:** all accountant, linter and data / partition / config tests. The 26 pipeline, DP-clipping and evaluation tests need PyTorch and were not run.

### 9.2 Weaknesses and gaps (must be fixed or decided)

| # | Gap | Why it matters |
|---|---|---|
| G1 | **Never executed**: no smoke, dev or final outputs exist | no revised-method result can be cited yet |
| G2 | Phases 5–8 not delivered: no matrices for trust / attacks / baselines / integrity / MIA, no τ selection rule, no tables or figures for them | most of the paper's claims live there |
| G3 | `THREAT_MODEL.md` referenced but missing | the robustness claims need it |
| G4 | α ∈ {0.1, 1.0} only | master prompt requires 0.1, 0.5 and 1.0 |
| G5 | 2D plots only; PNG only | master prompt requires 3D surfaces from real outputs, PNG + PDF + SVG |
| G6 | **Early stopping vs calibrated schedules**: σ₀ is calibrated so that ε(R_max = 100) = ε*, but early stopping can end a run at round 30–60 | realised ε < ε* (fine for privacy), but decaying schedules then never reach their low-noise rounds, so "schedules compared at equal ε*" no longer holds. Fix: fixed-R runs for the schedule study, or report the realised ε and compare at matched realised ε |
| G7 | **Attackers that skip DP noise**: targeted (trains without DP) and Sybil (scaled previous update) submit noise-free updates | the magnitude anomaly separates them trivially; robustness would be overstated. Add noise-mimicking variants (attacker adds the same N(0, σ²C²/B²) per step) |
| G8 | **Per-client σ vs magnitude anomaly**: per-client calibration gives clients of different size different noise levels | honest small clients may be flagged. Measure the benign false-positive rate by client size; consider noise-aware normalisation of m_i |
| G9 | DP batch size / sampling rate, optimiser (DP-Adam vs DP-SGD) and learning rate fixed a priori | these are the main legitimate levers on DP utility (Section 4.4); they should be pre-registered factors in a pilot with validation-only selection |
| G10 | Hyperparameter-tuning privacy cost not discussed | selection uses only V_sel (server data), but each candidate DP run consumed client privacy. Disclose (common practice) or account (OP-2) |
| G11 | Dataset-level leakage, logged per-client losses, secure-mode RNG not discussed | completeness of the privacy statement |
| G12 | Automatic PyKEEN download with no licence gate | master prompt §18 |
| G13 | No `scripts/` entry points; README is Colab-only | master prompt §18–20 (local Windows / Linux commands) |
| G14 | 5 seeds cannot give exact p < 0.05; the roadmap asks for "Wilcoxon across seeds" | decision: more seeds for headline comparisons, or effect sizes with CIs as primary evidence (the revision's choice) |
| G15 | WN18RR has 11 relations; Dirichlet-over-relations with 10 clients and α = 0.1 may fail the minimum-size constraint or produce near-degenerate clients | must be checked in Phase D before committing |

---

## 10. Roadmap (File 3) consolidation

| Roadmap item | Assessment | Resolution |
|---|---|---|
| S1 Separate non-DP, DP-active and "Pareto-optimal" MRR; trace every metric; final deployable configuration table | valid. "Pareto-optimal" needs redefining: the old ε* = 9.28 was synthetic | report the measured Pareto frontier (non-dominated (ε, MRR) points) plus a **pre-declared** primary operating point (revision: ε* = 4, δ = 1e-6); "deployable" row = full method with all mechanisms on |
| S2 Rerun Phase 3 and **Phase 6** with ≥ 5 seeds; Wilcoxon across seeds | Phase 6 has no experiment to rerun (it is a simulation); Wilcoxon with n = 5 cannot reach p < 0.05 | replace Phase 6 with real trust / attack experiments; 5 seeds minimum, more for headline comparisons, paired effect sizes with CIs as primary evidence |
| S3 Multiple datasets (FB15k-237, WN18RR, YAGO3-10) | valid; incomplete (no licence / compatibility check; YAGO3-10 cost) | Phase D protocol |
| S4 Clarify adaptive noise calibration; honest trade-off; Pareto point | valid; "adaptive" must be defined mathematically (deterministic, data-independent schedule calibrated to equal ε). Novelty is limited (decaying-noise schedules exist in prior work — to be verified in Phase B) | as in S1; rename or justify "adaptive" |
| S5 Define Δθ_ref and anomaly_k; confirm Client-0 behaviour; poisoning / Sybil details | first two valid (the revision provides definitions). "Client-0" is **outdated**: 74.26 % was never trained, and under Dirichlet partitions Client-0 is not special | drop Client-0; report per-client statistics and per-client trust / FPR |
| S6 Live IPFS node, **or** state that the evaluation is an "IPFS-compatible SHA-256 simulation" | the wording is wrong: SHA-256 hex identifiers are **not** IPFS-compatible (no multihash / CID encoding, no UnixFS chunking) | either "SHA-256 content-addressed integrity simulation (not IPFS)", or compute real CIDs / run a local node (decision D7) |
| S7 Standardise round counts; reconcile conflicting MRRs; update all tables and figures | valid | one trainer, R_max = 100, early stopping; tables built only from run records |
| S8 Log every seed; repository link; runtime, communication, limitations | valid; the link needs you | — |
| S9 Lock numbers before Rida and Safiya update the manuscript | valid; matches "methodology first" | methodology freeze report (Phase G) is the handover point |
| Execution order: fix metrics → FB 5 seeds → WN18RR → YAGO3-10 → statistics → tables → manuscript | valid, but misses the smoke and dev tiers and the DP ladder | smoke → dev (timings) → final, per phase |

**Missing from the roadmap** (required by the master prompt or found in this audit): privacy unit, adjacency and threat model; worst-client accounting with PLD cross-check; tuning-cost disclosure; α = 0.5; threshold inventory and sweeps (τ, clip, ε, α); the complete baseline and ablation list (centralised, FedAvg, DP-only, trust-only, full, −integrity, −defence, alternative aggregators, DP baseline); the attack list with success definitions and benign FPR; noise-mimicking attackers; integrity on/off comparison with measured overhead; 3D surfaces from real data; the 14 required tables; provenance labels; scripts and README; freeze report; licence checks; no vocabulary mixing across datasets (this contradicts the original methodology diagram's "different datasets on different clients").

### 10.1 Consolidated change list

Sources: MP = master prompt, CL = clarification, RM = roadmap, RV = revision package, AU = this audit, OP = original paper.

| ID | Change | Sources | Phase |
|---|---|---|---|
| CL-01 | Freeze all legacy results in `legacy/` with checksums and the label "legacy, unverified"; never overwrite | MP §4, §16; CL | C |
| CL-02 | Withdraw every hard-coded / formula / simulated number; tables and figures only from run records | MP §17–18; RM S1, S7; AU CR-1 | C–F |
| CL-03 | Separate non-DP / DP / selected-operating-point rows everywhere; measured Pareto frontier; primary ε pre-declared | RM S1, S4; MP §7 | B, F |
| CL-04 | "Deployable" full-method row: DP + trust + integrity active in the same runs | RM S1; AU CR-3 | E |
| CL-05 | Six provenance labels on every number; original-vs-revised FB15k-237 table (historical / legacy-replica / revised) | MP §16; CL | F |
| CL-06 | Re-evaluate the saved legacy Phase 3 checkpoint under the corrected protocol; run the R3 / R4 legacy replicas | AU OP-8; RV | C–D |
| CL-07 | Three datasets, each independent; licence, statistics, splits, filtering documented; no auto-download without confirmation | MP §6, §18; RM S3; RV; AU G12 | D |
| CL-08 | Drop cross-dataset clients from the main study (methodology diagram) | MP §6 | B |
| CL-09 | 10 clients, Dirichlet over relations α ∈ {0.1, 0.5, 1.0}; IID and legacy partitions as references; feasibility check for WN18RR | MP §8–9; RV; AU G4, G15 | B, D |
| CL-10 | Across-client heterogeneity statistics; partition audits (leakage, rare relations, minimum size, determinism) | MP §9; RV | D |
| CL-11 | One corrected trainer for all conditions (64 correct negatives, normalisation); no warm start | AU CR-11, CR-7; RV | C |
| CL-12 | Full filtered head + tail realistic evaluation; V_sel selection; test once; per-direction and per-relation metrics | MP §14; RV | C |
| CL-13 | Formal privacy statement: unit, adjacency, threat model, what is and is not protected (sizes, relation ownership, losses, tuning) | MP §7A–I; AU MJ-9, G10–G11 | B |
| CL-14 | Per-client RDP + PLD, worst-client ε, δ = 1e-6 (+1e-5); ε regimes {1, 2, 4, 8} plus non-private; every DP parameter reported | MP §7; RV | C |
| CL-15 | Define "adaptive" mathematically; schedules calibrated to equal ε; fix the early-stopping interaction | RM S4; RV; AU G6 | B–C |
| CL-16 | DP-utility investigation: ladder + pre-registered pilot on batch size / sampling rate, optimiser, learning rate, clip (validation only) | MP §7; AU MJ-10, G9 | B–E |
| CL-17 | Precise trust definition (Δθ_ref, anomaly, history, normalisation, fallback); analyse non-IID and DP false positives | RM S5; MP §10; RV; AU G8 | B |
| CL-18 | τ sweep (MAD units) with a pre-registered validation-only rule; λ fixed a priori with a sensitivity check | MP §12; RV | B, E |
| CL-19 | Attacks: clean, Gaussian, sign-flip / scaling, ALIE, IPM, KG-targeted data poisoning, adaptive (gray / white), Sybil; noise-mimicking variants under DP; success metric defined per attack | MP §10; RM S5; RV; AU G7 | B, E |
| CL-20 | Baseline aggregators FedAvg, Krum (assumptions checked), trimmed mean, median, FLTrust; detection TPR / FPR; benign rejection by client size | MP §10, §13; RV | E |
| CL-21 | Baselines vs ablations specified separately (centralised, FedAvg, DP-only, trust-only, full, −integrity, −defence, DP baseline) | MP §13 | B |
| CL-22 | Integrity: honest framing; on/off comparison; measured hash / verify / store overhead; trained checkpoints with full state + metadata; tamper tests | MP §11; RM S6; RV | C, E |
| CL-23 | MIA (old H3) only if retained: empirical audit, attributed to DP only, non-DP calibration row | RV; AU | B (decision) |
| CL-24 | Formal hypotheses H1–H3 with measurable definitions, fixed before final runs; report failures as failures | AU MJ-11 | B |
| CL-25 | Statistics: ≥ 5 seeds (42, 123, 256, 512, 1024), per-seed values, mean / SD / t-CI, paired by seed, d_z, Holm; more seeds for headline comparisons | MP §14; RM S2; RV; AU G14 | E |
| CL-26 | Experiment matrix for all phases with smoke → dev → final tiers; runtime and storage estimate from dev timings | MP §12, §21; RV (P3 / P4) | B, D |
| CL-27 | The 14 required tables (CSV + Markdown) from run records | MP §17 | F |
| CL-28 | 3D surfaces from real outputs (missing cells shown as missing) + 2D views; PNG / PDF / SVG; plotting scripts | MP §15; AU G5 | F |
| CL-29 | `scripts/` entry points; README with exact Colab **and** local commands; troubleshooting | MP §18–20; AU G13 | C, G |
| CL-30 | Per-run provenance (config, code hash, environment, data / split checksums, seeds, timestamps, logs, failures) | MP §19; RV | C |
| CL-31 | Literature numbers: verify each against its source or remove; never mix protocols in one table | AU C40; MP §16 | (manuscript phase) |
| CL-32 | Repository link | RM S8 | G |
| CL-33 | Methodology freeze report; then hand over to the manuscript team | MP §22; RM S9 | G |

---

## 11. Contradictions register

| ID | Between | Contradiction |
|---|---|---|
| X01 | paper ↔ code ↔ revision | trust: cosine (paper) / loss deviation (code) / MAD direction + magnitude (revision) |
| X02 | paper ↔ runs ↔ notebook header | "adaptive σ" / σ fixed 1.0 / header says 2.0 → 0.5, ε 8, 5 rounds while the configuration says ε 15, 20 rounds |
| X03 | paper ↔ trained partition | Client-0 74.26 % / 30.81 % |
| X04 | paper ↔ code | "semantic relation clusters" / ID-order chunks |
| X05 | paper ↔ code | "full test set" / 300 random tail queries |
| X06 | paper ↔ accountant | ε 15.53 / worst-client RDP 1.98 (δ 1e-5) |
| X07 | paper Fig. 13 ↔ runs | caption mixes the σ = 1.2 run (0.623 per round, 20 rounds) with the σ = 1.0 run (15.53, 16 rounds) |
| X08 | tables ↔ run log | "warm-start from P3" / "checkpoint NOT found, random init" |
| X09 | paper ↔ paper | "five clients" vs "10 clients" (bandwidth sentence) |
| X10 | paper ↔ master prompt / revision | δ = 1e-5, 5 clients, relation-disjoint / δ = 1e-6, 10 clients, Dirichlet α = 0.1 (candidate settings) |
| X11 | Table III ↔ code | "10 FL rounds" / formula with 20 rounds |
| X12 | paper ↔ code | "trained centralised reference" / constant 0.094 |
| X13 | paper ↔ code | "IPFS checkpoints, 15 client + 5 global" / random tensors, 15 client + 4 global + 1 demo |
| X14 | methodology diagram ↔ everything | 10–20 Flower clients, NELL-995, RotatE, access control — none implemented; cross-dataset clients conflict with MP §6 |
| X15 | roadmap ↔ revision | "IPFS-compatible SHA-256" / "identifiers are NOT CIDs" |
| X16 | roadmap ↔ statistics | Wilcoxon across 5 seeds / minimum exact two-sided p = 0.0625 |
| X17 | roadmap ↔ code | "rerun Phase 6 with seeds" / Phase 6 contains no experiment |
| X18 | roadmap ↔ master prompt | "highlight the Pareto-optimal point" / "never select a privacy configuration because it makes an attractive graph" |
| X19 | revision ↔ master prompt | α ∈ {0.1, 1.0} / {0.1, 0.5, 1.0} |
| X20 | revision ↔ revision | `attacks.py` cites `THREAT_MODEL.md`, which is not in the package |
| X21 | clarification ↔ supplied files | "Proprietary Learning Reveal" document / no such file (revision package assumed) |
| X22 | paper ↔ evidence | "all hypotheses confirmed, p < 0.001" / pseudo-replicated statistics over formula-derived values |
| X23 | paper ↔ evidence | "recovers MRR 0.2858 while maintaining privacy" / best private MRR 0.0373 (single round, legacy protocol) |
| X24 | paper ↔ timings | "≈ 2× longer per round" / 6.1× per round, ≈ 18× per local epoch |

---

## 12. Preliminary consolidated methodology (DRAFT for your review)

The clarification asks for a consolidated specification at this stage, while the master prompt places the formal `methodology_specification.md` in Phase B. This section is therefore a **draft direction only**, so you can redirect before Phase B; nothing here is frozen.

**Setting.** K = 10 clients. Client k holds training triples D_k (disjoint across clients; Dirichlet-over-relations partition). The entity and relation vocabularies (E, R) and the client sizes n_k are public. The server holds V_sel (80 % of validation; model selection) and V_root (20 %; FLTrust only). The test set is used once.

**Model.** f(h, r, t) = −‖n(e_h) + w_r − n(e_t)‖₂, with n = L2 normalisation and d = 100. Per-triple loss ℓ(x; θ) = (1/k) Σ_j [γ − f(x) + f(x̃_j)]₊, with k = 64 negatives (head or tail, uniform, never the original).

**Client step (round t), DP on.** Poisson-sample each local triple with q_k = B/n_k. Compute per-triple gradients; clip to C; sum; add N(0, σ_{k,t}² C² I) to every coordinate; divide by B; optimiser step. One local epoch ≈ n_k/B steps. Release only Δ_k^t = θ_k − θ^t, plus its integrity identifier.

**Server step.**
1. Verify H(serialise(Δ_k^t, metadata)) against the identifier. On mismatch, treat the client as dropped this round and log it.
2. Aggregate: FedAvg, a robust baseline, or trust-weighted (update-based, post-processing only).
3. Update θ^{t+1} = θ^t + Agg.
4. Every 5 rounds, evaluate on the V_sel subset for early stopping; at the end, select the best V_sel checkpoint and evaluate the test set once.

**Privacy guarantee (example level, per client).** ε_k from RDP composition of all executed steps (PLD cross-check); report max_k ε_k at δ = 1e-6 (also 1e-5). Not covered:
- client-level participation;
- dataset-level properties (relation ownership);
- client sizes;
- hyperparameter-tuning cost (disclosed).

Schedules σ_{k,t} = σ_{k,0} · g(t) are deterministic, fixed before training, calibrated so every configuration meets ε* at its executed rounds (G6).

**Trust (to be finalised).** As in the revision (Section 5), plus noise-aware magnitude normalisation and possibly decaying history, both to be justified in Phase B. τ swept in MAD units and selected on V_sel only, under a pre-registered rule.

**Attack metrics.**
- Untargeted: ΔMRR = MRR_clean − MRR_attack, at the same seed and configuration.
- Defence effectiveness: E = 1 − ΔMRR_rule / ΔMRR_FedAvg, defined only when ΔMRR_FedAvg > 0.
- Targeted: attacker-target Hits@10.
- Detection: per-round TPR / FPR, including benign FPR by client size.

**Utility.** Filtered realistic MRR and Hits@1/3/10, micro-averaged over 2|T| queries (head + tail), plus per direction and per relation.

**Hypotheses (to be fixed before final runs; results may refute them).**
- H1: private federated MRR at ε* = 4 ≥ 90 % of the centralised non-private MRR, per dataset, paired by seed.
- H2: E ≥ 35 % against each implemented attack.
- H3 (only if retained): MIA AUC advantage over 0.5 reduced by ≥ 25 % relative to the non-DP model, attributed to DP.

**Datasets (preliminary; verify in Phase D from the loaded data and official licences).** FB15k-237 (continuity; PyKEEN: 14,505 / 237 / 272,115 / 17,526 / 20,438 as logged); WN18RR (≈ 41 k entities, 11 relations — partition feasibility G15); YAGO3-10 (≈ 123 k entities, 37 relations, ≈ 1.08 M training triples; DP cost is dominated by dense noise over ≈ 12.3 M parameters). Alternatives if YAGO3-10 is infeasible: CoDEx-M or another accepted benchmark — not chosen for MRR.

**Decisions I need from you before Phase B**

| ID | Decision | My recommendation |
|---|---|---|
| D1 | Code base | extend the revision package; keep the original notebooks frozen in `legacy/` for replicas |
| D2 | Privacy unit | example (triple) level per client as primary; client-level DP optional extra |
| D3 | Operating points | primary ε* = 4, δ = 1e-6; regimes {1, 2, 4, 8} + non-private |
| D4 | Partition grid | 10 clients, α ∈ {0.1, 0.5, 1.0}, plus IID and legacy references |
| D5 | Third dataset | YAGO3-10 if your GPU budget allows (cost measured in the dev tier); otherwise a cheaper accepted benchmark, justified |
| D6 | Keep H3 / MIA? | only as an empirical audit attributed to DP |
| D7 | IPFS | honest "SHA-256 content-addressed integrity layer (not IPFS)" unless you want a local IPFS node experiment |
| D8 | Seeds | 5 for everything, 10 for the headline comparisons if compute allows |
| D9 | Hypotheses H1–H3 | keep, with the precise definitions above, accepting they may fail |
| D10 | If DP utility is unacceptable at ε ≤ 8 | report it honestly; optionally add one justified design alternative (OP-3) |

---

## 13. Implementation plan (after your approval; no phase will be skipped or merged)

| Phase | Work | Where it runs | Output |
|---|---|---|---|
| B | Formal methodology spec, threat model, privacy statement, hypotheses, threshold inventory, baseline / ablation spec, experiment-matrix design, decisions D1–D10 applied | here | `audit/methodology_specification.md`, `THREAT_MODEL.md`, matrix draft |
| C | Repair and extend the revision code (G4–G13); `legacy/` freeze; scripts; licence gate; legacy-checkpoint re-evaluation script; all tests | here (+ PyTorch if obtainable; otherwise CPU-free tests here and the full test suite on Colab) | code + tests, `audit/dp_audit.md` |
| D | Dataset protocol, licences, partitions for 3 datasets; smoke tier; dev-tier timings → runtime estimate | **your Colab GPU** for training; here for analysis | `configs/datasets/`, `audit/dataset_protocol.md`, cost estimate |
| E | Baselines, ablations, sweeps, attacks, multi-seed final runs | **your Colab GPU** | raw run records |
| F | Tables, 3D / 2D figures, provenance-labelled comparisons | here, from your uploaded run records | `results/tables`, `results/figures` |
| G | README, reproducibility and limitations report, methodology freeze report | here | handover to the manuscript team |

---

## 14. IEEE-readiness assessment (master prompt §5)

| Criterion | Now (legacy) | After planned repairs (if executed) | Main risk |
|---|---|---|---|
| Technical correctness | fails (CR-1 to CR-12) | achievable | execution and compute time |
| Novelty / contribution | weak: standard components, invalid evidence | modest. A rigorous, correctly accounted three-dataset study of privacy–robustness–utility in FedKGE, possibly with a DP-aware trust rule | reviewers may judge the combination incremental |
| Precise mathematics | no | yes (Phase B) | — |
| Threat model / privacy claims | absent / invalid | example-level DP with explicit exclusions | utility at ε ≤ 8 may be low |
| Valid DP accounting | no | yes (tested) | — |
| Federated training / aggregation | P3 FedAvg plausible; rest not run | yes | — |
| KG evaluation | invalid protocol | standard | — |
| Fair baselines / ablations | none real | planned | Krum assumptions, compute |
| Robustness (attacks, thresholds) | none real | 7+ attacks, τ sweeps, adaptive attacker | defence may fail under DP or adaptive attacks — must be reported |
| Three datasets | no | planned | YAGO3-10 cost; WN18RR partition feasibility |
| Statistical reproducibility | no | 5 seeds, paired | low power at n = 5 |
| Overhead | hard-coded | measured locally (not a distributed deployment) | — |
| Limitations | not stated | full list | — |

**Verdict.** In its current form the manuscript is not submittable, because most of its quantitative claims have no experimental basis. The revised methodology can support a credible submission **only after** the experiments are actually run and the paper reports what they show. Acceptance cannot be predicted or guaranteed.

---

## 15. Accountability: errors from my own earlier assistance

Several of the defects above came from code and text I produced in earlier sessions. You should know exactly which:

1. I wrote the Phase 5–8 notebook logic that generated formula-derived and hard-coded results (baselines as multiples of the Phase 3 MRR, attack "simulations", synthetic surfaces, stub data), and presented the outcomes as hypothesis confirmations.
2. I made H1 use the **non-private** Phase 3 MRR against a hard-coded centralised constant, which produced "304 %".
3. I adjusted the poisoning simulation and the definition of "defence %" until H2 passed (19 % → 100 %). That result is true by construction, not by experiment.
4. I recommended warm-starting DP training from the non-private checkpoint. That would have voided the DP guarantee; the run only avoided it because the file was not found.
5. I typed the prior-work values in Table II without a verified source.
6. I wrote manuscript text describing 0.094 as a "same-hyperparameter centralized reference", and captions (for example, the cosine-similarity explanation of Table V) that the code does not support.

I should have refused or flagged these at the time. This audit treats them exactly like any other defect.

---

## 16. Open questions for you

1. Is `fedkge_revision_P1-P4.zip` the "Proprietary Learning Reveal" document (File 2)? If not, please send it.
2. Can you share the professor's review the roadmap is based on, and the additional roadmap changes not written in File 3?
3. Was the revision package ever run (any `fedkge_results/` folder)?
4. Decisions D1–D10 (Section 12), or "go with your recommendations".
5. Your compute: Colab tier, GPU type, session length, Drive space.

I will stop here and not start Phase B until you reply.
