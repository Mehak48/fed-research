"""Figures for Phase 2/5b/8. Every figure is drawn from a table produced from run records by fedkge.reports
(never from literals). Figures from non-final tiers carry a visible watermark so they cannot be mistaken for
manuscript figures. Each figure is written as PNG (300 dpi), PDF and SVG (Phase C, defect MN-7)."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _finish(fig, path: Path, tier: str):
    if tier != "final":
        fig.text(0.5, 0.5, f"{tier.upper()} TIER - NOT FOR MANUSCRIPT", ha="center", va="center", fontsize=22,
                 color="red", alpha=0.25, rotation=25, transform=fig.transFigure)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    for ext in (".png", ".pdf", ".svg"):
        fig.savefig(path.with_suffix(ext), dpi=300)
    plt.close(fig)
    return path.with_suffix(".png")


def errbar(ax, x, t, metric, label=None, **kw):
    ax.errorbar(x, t[f"{metric}.mean"], yerr=[t[f"{metric}.mean"] - t[f"{metric}.ci95_low"],
                                              t[f"{metric}.ci95_high"] - t[f"{metric}.mean"]],
                marker="o", capsize=3, label=label, **kw)


def fig_privacy_utility(t: pd.DataFrame, path: Path, tier: str):
    dss = sorted(t["dataset"].unique())
    fig, axes = plt.subplots(1, len(dss), figsize=(4.5 * len(dss), 3.6), squeeze=False)
    for ax, ds in zip(axes[0], dss):
        for sch, g in t[t["dataset"] == ds].groupby("schedule"):
            g = g.sort_values("privacy.eps.mean")
            errbar(ax, g["privacy.eps.mean"], g, "test.mrr", label=sch)
        ax.set_xscale("log"); ax.set_xlabel("worst-client RDP epsilon"); ax.set_ylabel("test MRR (filtered)")
        ax.set_title(ds); ax.legend()
    return _finish(fig, path, tier)


def fig_sweep(t: pd.DataFrame, xcol: str, metrics, path: Path, tier: str, logx=False, hue: Optional[str] = None):
    dss = sorted(t["dataset"].unique())
    fig, axes = plt.subplots(len(metrics), len(dss), figsize=(4.5 * len(dss), 3.2 * len(metrics)), squeeze=False)
    for j, ds in enumerate(dss):
        g0 = t[t["dataset"] == ds]
        for i, m in enumerate(metrics):
            ax = axes[i][j]
            if f"{m}.mean" not in g0:
                ax.axis("off"); continue
            groups = g0.groupby(hue) if hue else [("", g0)]
            for lab, g in groups:
                g = g.sort_values(xcol).dropna(subset=[f"{m}.mean"])
                if len(g):
                    errbar(ax, g[xcol], g, m, label=str(lab) if hue else None)
            if logx: ax.set_xscale("log")
            ax.set_xlabel(xcol.split(".")[-1]); ax.set_ylabel(m); ax.set_title(ds)
            if hue: ax.legend(fontsize=6)
    return _finish(fig, path, tier)


def fig_heatmap(wc: pd.DataFrame, path: Path, tier: str):
    dss = sorted(wc["dataset"].unique())
    fig, axes = plt.subplots(1, len(dss), figsize=(6 * len(dss), 4.5), squeeze=False)
    for ax, ds in zip(axes[0], dss):
        g = wc[wc["dataset"] == ds].set_index("agg").drop(columns=["dataset"])
        im = ax.imshow(g.values.astype(float), aspect="auto", cmap="viridis")
        ax.set_xticks(range(g.shape[1])); ax.set_xticklabels(g.columns, rotation=60, ha="right", fontsize=6)
        ax.set_yticks(range(g.shape[0])); ax.set_yticklabels(g.index, fontsize=6)
        for (i, j), v in np.ndenumerate(g.values.astype(float)):
            ax.text(j, i, f"{v:.3f}", ha="center", va="center", fontsize=5, color="w")
        ax.set_title(f"{ds}: test MRR (mean over seeds)"); fig.colorbar(im, ax=ax)
    return _finish(fig, path, tier)


def fig_partition(stats_rows: pd.DataFrame, path: Path, tier: str):
    fig, ax = plt.subplots(figsize=(7, 3.5))
    for (ds, key), g in stats_rows.groupby(["dataset", "partition"]):
        ax.plot(sorted(g["share"], reverse=True), marker=".", label=f"{ds}:{key}")
    ax.set_xlabel("client rank"); ax.set_ylabel("share of training triples"); ax.legend(fontsize=6)
    return _finish(fig, path, tier)
