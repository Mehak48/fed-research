# Phase C — test report

**Date:** 2026-11-02 · **Environment:** see `environment_report.md` (CPU only; Python 3.13.18; torch 2.14.1).
**Rule followed:** a test counts as passed only if it executed and passed. Skipped and not-run items are listed separately.

## 1. Test-suite runs (complete history, nothing removed)

| Run | Code state | Passed | Failed | Errors | Skipped | Report |
|---|---|---|---|---|---|---|
| `baseline_unmodified` (2026-10-28) | Unmodified revision zip | 53 | 0 | 0 | 0 | `results/phaseC/test_reports/pytest_baseline_unmodified.log` |
| `phaseC_full` (2026-10-28) | Phase C, mid-repair | 115 | **6** | 0 | 0 | `…/summary_phaseC_full.json` (causes in §4) |
| `phaseC_handoff` (2026-11-02) | Phase C, before real data | 123 | 0 | 0 | 0 | `…/summary_phaseC_handoff.json` |
| `phaseC_final` (2026-11-02, 19:01) | **Final Phase C code** | **131** | 0 | 0 | 0 | `…/summary_phaseC_final.json` (225 s) |

**The baseline run resolves Phase A's gap.** Phase A could not run the 26 PyTorch tests (no PyTorch). They now run and pass, including the Opacus comparison.

## 2. Results by file (final run)

| Test file | Passed | Failed | Error | Skipped | Data used |
|---|---|---|---|---|---|
| `test_accountant.py` | 12 | 0 | 0 | 0 | none (analytic / legacy parameters) |
| `test_data_partition_config.py` | 11 | 0 | 0 | 0 | synthetic |
| `test_dp_clipping.py` | 11 | 0 | 0 | 0 | synthetic tensors |
| `test_evaluate_sampling.py` | 6 | 0 | 0 | 0 | synthetic |
| `test_no_hardcoded_results.py` | 4 | 0 | 0 | 0 | source code |
| `test_phaseC_data_stats.py` | 10 | 0 | 0 | 0 | synthetic / toy files |
| `test_phaseC_integrity.py` | 10 | 0 | 0 | 0 | synthetic |
| `test_phaseC_pipeline.py` | 21 | 0 | 0 | 0 | synthetic KG |
| `test_phaseC_privacy.py` | 15 | 0 | 0 | 0 | synthetic / analytic |
| `test_phaseC_regression_matrix.py` | 6 | 0 | 0 | 0 | historical uploads (hashes), configs |
| `test_phaseC_schemas.py` | 7 | 0 | 0 | 0 | synthetic KG |
| `test_phaseC_trust_attacks.py` | 9 | 0 | 0 | 0 | synthetic tensors |
| `test_pipeline_offline.py` | 9 | 0 | 0 | 0 | synthetic KG |
| **Total** | **131** | **0** | **0** | **0** | |

**Totals:** 53 legacy tests and 78 Phase C tests. There were 13 warnings, none affecting the results: an Opacus backward-hook notice, numpy "degrees of freedom ≤ 0" from single-seed report fixtures, and a pandas fragmentation notice.

**All test inputs are synthetic or analytic.** Passing tests show that the implementation does what it specifies. They are **not** evidence that the defence, the privacy-utility trade-off or any hypothesis holds on the benchmarks.

## 3. Coverage of the required test groups (Phase C instructions §12)

**A. Unit:**

| Area | Tests |
|---|---|
| KGE scoring and loss | `test_evaluate_sampling.py`, `test_dp_clipping.py` |
| Clipping | `test_each_example_norm_bounded`, `test_matches_opacus`, `test_matches_bruteforce_per_example_autograd`, `test_zero_out_sensitivity_of_implemented_sum`, `test_non_finite_example_is_zeroed_and_others_unchanged` |
| Noise | `test_noise_is_dense_and_scaled`, `test_pure_noise_client_and_no_noise_ablation` |
| Accounting | `test_accountant.py`, `test_phaseC_privacy.py`, plus the 96-point validation (§6) |
| Partitioning | `test_dirichlet_partition_valid_deterministic`, `test_partition_*`, `test_smoke_subset_keeps_n_train_and_caps_only_eval` |
| Trust scores and weighted aggregation | `test_phaseC_trust_attacks.py` |
| Integrity | `test_1_unchanged_artifact_passes`, `test_2_modified_artifact_fails`, `test_3_incorrect_hash_fails`, `test_serialisation_roundtrip_and_ids`, `test_persisted_store_tamper_test_and_manifest_chain` |
| Filtered evaluation | `test_filtered_head_tail_realistic_matches_bruteforce`, `test_ties_are_not_optimistic` |
| Config validation | `test_invalid_configs_fail_loudly`, `test_config_guards` |

**B. Integration** (complete small federated rounds with real model updates, DP, trust, integrity, evaluation):

- `test_full_round_dp_q_proposed_integrity_attack`;
- `test_attacks_under_dp_complete[4]`;
- `test_fedavg_runs_log_anomaly_scores_and_design_a`;
- `test_4_rejected_artifact_is_not_aggregated`;
- `test_5_verified_bytes_are_the_bytes_consumed`;
- `test_5b_aggregator_receives_exactly_the_deserialised_verified_bytes`;
- `test_mia_audit_pool_and_one_run_bound`;
- `test_every_run_output_matches_its_schema[3]`;
- `test_pipeline_offline.py`.

**C. Regression:**

| Test | What it checks |
|---|---|
| `test_historical_artifacts_unchanged` | Re-hashes the original uploads against the Phase A inventory |
| `test_results_root_is_not_a_historical_location` | Outputs never land in historical locations |
| `test_no_hardcoded_results.py` | Linter against old result literals and silent fallbacks |
| `test_confirmatory_matrix_matches_phaseB_plan[full, reduced]` | Run count of every block = the Phase B plan |

**D. Reproducibility:**

- `test_reproducible_same_seed` (same seed → identical outputs);
- `test_deterministic_rerun`;
- `test_dp_trainer_deterministic`;
- `test_partition_deterministic_and_seed_dependent`;
- `test_size_matched_synthetic_generator`.

Numerical tolerance: exact equality on CPU. GPU determinism is **not tested** (no GPU).

**E. Failure paths:**

| Failure | Tests |
|---|---|
| Invalid configurations | `test_invalid_configs_fail_loudly` (8 cases) |
| Missing dataset | `test_missing_dataset_files_fail`, `test_missing_upstream_fails_without_fallback` |
| Malformed checkpoint | `test_malformed_checkpoint_fails_and_is_not_trusted` |
| Invalid hash and replayed header | `test_3_incorrect_hash_fails`, `test_header_replay_and_wrong_round_fail` |
| Interrupted run | `test_resume_after_interruption` |
| Failed client updates | `test_corruption_with_and_without_verification` |
| Accountant edge cases | `test_accountant_edge_cases_raise`, `test_small_client_fails_loudly` |
| Stale code | `test_stale_code_is_detected` |

**F. PyTorch:** every test that trains or evaluates uses PyTorch. All of them execute here (CPU).

## 4. Failures found and how they were resolved

| Run | Failed tests | Cause | Resolution |
|---|---|---|---|
| `phaseC_full` | `test_invalid_configs_fail_loudly[stop_after_rounds]` | The test case also used synthetic data on the tune tier, which another rule rejects first | Test corrected (non-synthetic dataset name) |
| `phaseC_full` | `test_confirmatory_matrix_matches_phaseB_plan[full, reduced]` | **Real defect PC-3:** `keep_final_weights` inside the run hash split one shared experiment into two runs (X2: 9 extra) | Output-only key, merged over shared runs. Kept weights now 225 / 150, as planned |
| `phaseC_full` | 3 tests in `test_pipeline_offline.py` (`STALE_CODE`) | Core code was edited while the suite ran; stale-code detection worked as intended | No code change; rerun 9 / 9 passed. Rule adopted: no code edits during runs |

## 5. Smoke tests and other executions (not pytest)

| Step | Data | Result | Record |
|---|---|---|---|
| Privacy-accounting validation | Analytic (96 operating points) | 0 failed checks, run twice (system Python and project venv) | `privacy_accounting/accounting_validation_*.csv` |
| Small runs, 11 profiles × 3 datasets | **Real** benchmark subsets (3,000 training triples, 3 rounds) | **33 of 33 complete** | `smoke/small_runs_<dataset>.csv`, `logs/smoke_small_runs_*.log` |
| Schema validation of the real smoke tier, after the 33 small runs | Real | 60 items, 0 failures | `test_reports/schema_validation_smoke_20261102T130952Z.json` |
| Every block in smoke, part 1: tuning chain | **Real** subsets | **Complete.** All 6 stages ran: 114 entries (99 runs, 15 reused winners). Every selection was made by the pre-registered rules; the smoke-only τ placeholder was **not** needed | `smoke/plan_tune_status_20261102T134418Z.csv`, `smoke/selection/tuning.json` |
| Every block in smoke, part 2: confirmatory matrix (reduced profile, one seed per block) | **Real** subsets | **Complete.** All 26 blocks: 329 entries (322 runs, 7 shared), 0 failures. Gate G-A "every block completes in smoke" is met | `smoke/plan_confirm_status_20261102T135654Z.csv` |
| Schema validation after the full smoke run | Real | First pass: 3 failures. The non-private M1 audits have no accountant ε, but the MIA schema required the red-line flag anyway (schema defect PC-5, fixed). Second pass: **496 items, 454 run directories, 0 failures** | `test_reports/schema_validation_smoke_20261102T135703Z.json` (failures kept) and the later report |
| Colab kit dry run (`revision/colab/phaseC_pilot_colab.ipynb`, run on this CPU; only Colab's drive mount, pip install and the CUDA device were replaced) | Real (WN18RR) | Complete in 6.5 min: fingerprint check, extraction, licence-gated download, artifacts, 3 smoke runs, 6-configuration pilot, results zip (0.1 MB; no dataset files, labels or weights). The final kit differs from the tested one only in documentation text | scratchpad dry-run log (summarised here) |
| L0 legacy checkpoint | Real (full FB15k-237) | Executed: test MRR 0.197 (corrected), 0.240–0.280 (legacy protocol) | `pilot/L0_legacy_checkpoint_eval.json` |
| Measured pilot | Real (full data), **CPU** | See `pilot_plan.md` | `pilot/pilot_measurements_*.csv` |

**Smoke runs are software checks:** 3 rounds on 3,000 triples barely move the model. Their MRR values (0.001–0.005) are meaningless and are not reported anywhere as results.

## 6. Not run (and why)

| Item | Why | Where it will run |
|---|---|---|
| Any test or run on a GPU | No GPU in this environment | Free Colab kit (`revision/colab/`) |
| GPU determinism | Same | Colab, if needed |
| `test_historical_artifacts_unchanged` outside this environment | It needs the original uploads at `/mnt/user-data/uploads` | Elsewhere it **skips**, and must be reported as skipped |
| Full-length runs (any stage ≥ 3) | Not authorised before the pilot review (Phase C §13) | After approval |
