"""Shared helpers for the Phase C entry points: package import path, results layout, execution manifests."""
from __future__ import annotations

import datetime as dt
import json
import os
import platform
import subprocess
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "01_fedkge_core"))
CONFIG_DIR = REPO / "10_configs"
SCHEMA_DIR = REPO / "11_experiment_schemas"
DEFAULT_RESULTS = REPO / "results" / "phaseC"
SUBDIRS = ("logs", "configs", "smoke", "privacy_accounting", "pilot", "checkpoints", "test_reports", "manifests")


def results_root(arg: str | None) -> Path:
    root = Path(arg) if arg else Path(os.environ.get("FEDKGE_RESULTS", DEFAULT_RESULTS))
    for s in SUBDIRS:
        (root / s).mkdir(parents=True, exist_ok=True)
    return root


def git_commit() -> str | None:
    try:
        out = subprocess.run(["git", "rev-parse", "HEAD"], cwd=REPO, capture_output=True, text=True, timeout=5)
        dirty = subprocess.run(["git", "status", "--porcelain"], cwd=REPO, capture_output=True, text=True, timeout=5)
        return out.stdout.strip() + ("-dirty" if dirty.stdout.strip() else "") if out.returncode == 0 else None
    except Exception:
        return None


class Manifest:
    """Execution manifest: command, code version, start/end, outputs, warnings. Written even if the step fails."""

    def __init__(self, root: Path, name: str):
        self.path = root / "manifests" / f"{dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')}_{name}.json"
        self.rec = {"step": name, "command": " ".join([sys.executable] + sys.argv), "git_commit": git_commit(),
                    "python": sys.version.split()[0], "platform": platform.platform(),
                    "start_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "outputs": [], "warnings": []}

    def output(self, p) -> None:
        self.rec["outputs"].append(str(p))

    def warn(self, msg: str) -> None:
        self.rec["warnings"].append(msg)
        print("WARNING:", msg)

    def close(self, status: str, **extra) -> Path:
        self.rec.update({"status": status, "end_utc": dt.datetime.now(dt.timezone.utc).isoformat(), **extra})
        self.path.write_text(json.dumps(self.rec, indent=2, default=str))
        return self.path
