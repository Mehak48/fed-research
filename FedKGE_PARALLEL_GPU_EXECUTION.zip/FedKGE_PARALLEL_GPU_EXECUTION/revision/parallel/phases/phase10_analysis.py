#!/usr/bin/env python3
"""PHASE 10 (master, CPU, minutes) - statistical analysis of the master store (scripts/analyze_results.py, unchanged).

  python parallel/phases/phase10_analysis.py --base B

Paired-seed one-sided t-tests, Holm over the fixed families, CIs, effect sizes, non-inferiority (H2b), from COMPLETE
current runs only. Missing members enter with p = 1 and the family is PROVISIONAL; nothing is imputed. Runs first
the validation (phase 09) and prints its verdict, so partial results are always labelled as partial. Families become
decidable as their blocks complete: H1, H2b and HS after priority 1 of all three datasets, H2 after priority 2, H3
after priority 3 (DEADLINE_PLAN.md). Outputs: <master>/final/analysis/ (research) or <master>/<tier>/analysis/.
"""
from __future__ import annotations

import subprocess
import sys

from _cli import layout, parser

from fedkge_parallel.common import REPO
from fedkge_parallel.validate import validate_store


def main(argv=None) -> int:
    ap = parser(__doc__)
    a = ap.parse_args(argv)
    L = layout(a)
    rep = validate_store(L, a.mode)
    print(f"validation: {rep['verdict']} (cells by status: {rep['cells_by_status']})")
    tier = "final" if a.mode == "research" else "smoke"
    if a.mode == "dev":
        print("the analysis scripts support the final tier (and the smoke software check) only"); return 0
    p = subprocess.run([sys.executable, "scripts/analyze_results.py", "--results", str(L.master), "--tier", tier], cwd=REPO)
    return p.returncode


if __name__ == "__main__":
    sys.exit(main())
