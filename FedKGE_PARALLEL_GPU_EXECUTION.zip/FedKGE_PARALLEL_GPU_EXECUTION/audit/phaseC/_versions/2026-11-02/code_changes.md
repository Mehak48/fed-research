# Phase C — record of code changes

**Date:** 2026-11-02 · **Repository:** `revision/` · **Baseline:** git tag `baseline-revision-P1-P4` = `fedkge_revision_P1-P4.zip` as delivered, unmodified (sha256 `57d23c4e…54f8`).

**Where the changes live:**

- All Phase C changes are in the working tree of branch `phaseC`.
- **Nothing is committed.** Changes are committed only when the owner asks.
- Exact diff: `git diff baseline-revision-P1-P4`. New files: `git status --short`.

**Untouched:**

- The original code (`files/`) and the historical outputs (`complete/`).
- `audit/` from Phases A and B (read-only).

`test_historical_artifacts_unchanged` re-hashes the original uploads against the Phase A inventory on every test run.

**Size of the change:**

- 33 tracked files modified: +2,063 / −411 lines (`git diff --shortstat`, 2026-11-02, final).
- 36 new files: 11 scripts, 7 test files, 9 configs, 5 schemas, the Colab notebook, `THREAT_MODEL.md`, `requirements-phaseC.txt`, `.gitignore`.

The reason for each change is given with its defect or decision ID (`audit/phaseB/data/defect_register.csv`, `02_design_decisions.md`).

## 1. Core package `01_fedkge_core/fedkge/`

| File | +/− | Change | Why |
|---|---|---|---|
| `accountant.py` | +74/−2 | Zero-out relation (`REPLACE_SPECIAL`) and `rdp_epsilon_public_api`; PRV cross-check `prv_epsilon`; design Q helper `dp_steps_common_rate`; adjacency text | CR-14, CR-2, D2, D11 |
| `dp.py` | +24/−7 | Non-finite per-example gradients zeroed before clipping; noise only if σ > 0 (DP3); empty clients; expected batch and zeroed-example count in the stats | MN-22, G7, DP3 |
| `federated.py` | +388/−138 | Rewritten round loop: verified broadcast; local training from the verified copy; only verified updates aggregated; ε over executed steps; DP runs use all R rounds, then select the best checkpoint; anomaly scores in every run; attack, integrity and MIA records; `stop_after_rounds` for timing; non-finite guard; `weights_only=True`; peak GPU memory | CR-13, G6, C3, C4, C11, C16, MN-16 |
| `integrity.py` | +255/−64 | Rewrite: canonical serialisation + header, SHA-256 id (not an IPFS CID), send / store / corrupt / fetch / verify / deserialise; modes; manifest chain; tamper test | CR-9, CR-13, D7 |
| `trust.py` | +56/−12 | History indexed by identity; variant V1 (size-third magnitude reference) behind a flag; size thirds | D15, G8 |
| `aggregators.py` | +40/−16 | Robust-baseline parameters at f_design; identities of verified updates; parameters recorded | MN-18 |
| `attacks.py` | +110/−23 | Noise modes inherit / matched / none; `match_norm`; Sybil with DP noise; targets from the attackers' own data; adaptive search with own noise | G7, D16, MN-21 |
| `data.py` | +150/−11 | Local-file loader with PyKEEN-identical ids and unseen-triple counts; checksum binding; CoDEx-M; size-matched synthetic generator (timing only); **fix PC-1**: the smoke subset capped the training split at `n_eval` | D5, MN-20, G12, PC-1 |
| `mia.py` | +133/−31 | Randomised audit pool, A1 / A2 / A3, ROC metrics with resolvability flags, one-run ε lower bound | MJ-15, D6 |
| `selection.py` | +129/−0 | Tuning chain `select_rule`, `select_tau`, `v1_trigger`; final tier refuses to select | D13–D15, MJ-5, MJ-18 |
| `stats.py` | +75/−3 | One-sided t, log-ratio test, H2 contrast with testability gate, Holm families | D9, CR-5, G14 |
| `config.py` | +56/−8 | New tiers, datasets, options and validations; output-only `keep_final_weights` outside the run hash | D11–D18, C2 |
| `runner.py` | +66/−9 | Profiles, seed sets, `exclude`, `_cell`, `keep_weights_when`, shared-run weight merge, `max_seeds_per_block`, rerun for missing weights (old run archived) | D18, C11 |
| `io.py` | +32/−6 | Timezone-aware UTC; JSON-safe numpy; environment record; archive with reason | MN-8 |
| `schemas.py` | +33/−0 | `validate_csv_columns`, `validate_run_dir` | gate G-A |
| `plotting.py` | +9/−4 | PNG 300 dpi + PDF + SVG; docstring fixed | MN-7, G5 |
| `__init__.py`, `pyproject.toml` | small | Version 1.1.0-phaseC; prv-accountant dependency | — |

**Unchanged and verified:** `model.py`, `train.py`, `sampling.py`, `evaluate.py`, `partition.py`, `analysis.py`, `reports.py`.

## 2. Configuration `10_configs/`

| File | Change | Why |
|---|---|---|
| `base.yaml` | Design Q settings; `select_best`; `keep_final_weights`; f_design; magnitude reference; anomaly logging; attack noise mode and target source; corruption; MIA settings | D11–D16 |
| `datasets/fb15k237.yaml`, `wn18rr.yaml`, `yago310.yaml` | Source `local_files`, licence and citation | G12 |
| `datasets/codex_m.yaml` (new) | CoDEx-M | D5 |
| `datasets/synthetic_*_sized.yaml` (new, 3) | Size-matched stand-ins for timing only, with `size_proxy_for` | pilot without data |
| `matrices/tune.yaml` (new) | Stage 3 tuning chain T1–T3, TAU | D13 |
| `matrices/confirm.yaml` (new) | Stages 4–5: every Phase B block; DP1/DP2 keep weights at ε\* = 4 | Phase B 06, D18 |
| `matrices/p3.yaml`, `p4.yaml` | Legacy replicas: `select_best: false` | legacy fidelity |
| `selection_rules.yaml` | Pre-registered rules T1–T3, V1 trigger, τ (rules for the legacy blocks unchanged) | D13–D15 |
| `tiers/smoke.yaml` | CoDEx-M; one seed per block; rounds cut with `stop_after_rounds` (keeps T2c / T1 cells distinct) | G-A |
| `tiers/final.yaml` | S5, three datasets | D8 |
| `tiers/pilot.yaml`, `tiers/tune.yaml`, `tiers/smoke_synthetic.yaml` (new) | Pilot (seed 1001), tuning (seed 1001), synthetic smoke | D13, D18 |

## 3. Schemas `11_experiment_schemas/`

| File | Change |
|---|---|
| `dataset_card.schema.json` | Accepts `codex_m` and `synthetic_*` |
| `integrity`, `attack`, `mia`, `trust_rounds_csv`, `tuning_selection` (new) | Schemas for the Phase C outputs. The integrity schema forbids "consumed a corrupted object" and an IPFS-CID claim |
| `README.md` | New rows |

## 4. Tests `12_validation_tests/`

| File | Content |
|---|---|
| `conftest.py` (+92) | Synthetic config helper and fixtures for Phase C |
| `test_phaseC_privacy.py` (new) | 15 cases: zero-out equality, closed form, PLD/PRV bracketing, edge cases, sensitivity, non-finite guard, empty client, ablation |
| `test_phaseC_integrity.py` (new) | 10: the owner's 5 required tests plus header replay, store tamper, serialisation |
| `test_phaseC_trust_attacks.py` (new) | 9: identity history, V1, robust parameters, noise modes, targets, adaptive search |
| `test_phaseC_pipeline.py` (new) | 21: full rounds with every mechanism, attacks under DP, corruption, DP3, timing flag, MIA, reproducibility, invalid configs, malformed checkpoint, missing data |
| `test_phaseC_data_stats.py` (new) | 10: loader, generator, subset (PC-1), partitions, statistics, one-run bound |
| `test_phaseC_regression_matrix.py` (new) | 6: historical artifacts unchanged, results root, tuning chain reuse, matrix counts = Phase B plan, run identity |
| `test_phaseC_schemas.py` (new) | 7: every run output valid (4 configurations, including a non-private MIA audit); integrity schema rejects bad claims; MIA red-line flag rule; dataset names |

**Test-only fixes during Phase C** (the code under test was not changed to make them pass):

- the validation-order case in `test_invalid_configs_fail_loudly`;
- the wrong outlier row in `test_history_only_updates_present_identities`;
- the toy-KG rows in the loader test.

## 5. Scripts `scripts/` (all new)

| File | Purpose |
|---|---|
| `_common.py` | Results root (`--results` or `FEDKGE_RESULTS`) and its subfolders; execution manifests; git commit |
| `run_tests.py` | Pytest with junit; summary counts |
| `check_privacy_accounting.py` | 96-point, five-method accounting validation (timestamped outputs) |
| `prepare_data.py` | Licence-gated, pinned, checksummed dataset fetch |
| `build_artifacts.py` | Phase 1 and 2 artifacts, partition audit, acceptance rates; `--tier-file` |
| `small_run.py` | Validated small-run script (11 profiles); `--tier-file` |
| `run_plan.py` | Tuning chain with selections, and the confirmatory matrix; builds needed partitions; smoke-only recorded τ placeholder |
| `freeze_selections.py` | Freeze and hash the tuning selections for the final tier |
| `pilot.py` | Measured pilot: one subprocess per configuration; extrapolation over the expanded matrices |
| `legacy_l0_eval.py` | L0: legacy checkpoint under the corrected and the legacy protocol |
| `validate_outputs.py` | Schema validation of a whole results tier |

## 6. Documentation, environment, Colab

| File | Change |
|---|---|
| `13_documentation/DP_MECHANISM.md` | Rewritten: zero-out, designs, guards, executed steps, cross-checks, conservativeness note, ablation, tests |
| `13_documentation/THREAT_MODEL.md` (new) | From Phase B `03a` |
| `requirements-phaseC.txt` (new) | Exact versions used here |
| `requirements-colab.txt` | Colab / Kaggle list (keeps the platform's torch) |
| `README.md` | Rewritten: Phase C layout, setup, commands in the required order, result paths, enforced rules |
| `colab/phaseC_pilot_colab.ipynb` (new) | Free-Colab GPU pilot kit |
| `.gitignore` (new) | `results/`, caches |

`README.md` was rewritten for Phase C, with exact commands and result paths.

**Not yet updated:** `MASTER_EXECUTION_ORDER.md`, `13_documentation/COLAB_RUNBOOK.md` and `EXECUTION_PLAN.md`. They still describe the original notebook workflow; the README says so.

## 7. Defects found during Phase C (not in the Phase B register)

| ID | Where | Effect | Fix | Test |
|---|---|---|---|---|
| PC-1 | `data._subset` (original revision code, never executed before) | The smoke subset kept 300 instead of 3,000 training triples, so every Dirichlet partition failed on the real data | Only the evaluation splits are capped | `test_smoke_subset_keeps_n_train_and_caps_only_eval` |
| PC-2 | `selection` rule D15 (design) | Variant V1's size-third reference uses groups of 3–4 clients; its robust scale is unstable (in a synthetic probe, benign A_v1 reached 9.1) | **Not fixed (a design question for the owner)** | `remaining_blockers.md` B4 |
| PC-3 | `config` run identity | `keep_final_weights` inside the run hash split one experiment shared by two blocks into two runs (X2 gave 9 extra runs) | Output-only key, OR-merged across sharing blocks | `test_output_only_option_does_not_change_run_identity`, matrix-count test |
| PC-4 | `check_privacy_accounting.py` (my own first version) | Flagged the conservative direction as a failure | Direction-aware checks | the validation itself (0 failures) |
| PC-5 | `mia.schema.json` (my own first version) | Required the red-line flag `lower_bound_exceeds_accountant` also for non-private audits, which have no accountant ε. Found by validating the real smoke tier (3 failures, report kept) | The flag is required only when `eps_accountant` is a number | `test_mia_schema_requires_the_red_line_flag_only_with_an_accountant`, `test_every_run_output_matches_its_schema[nonprivate_mia]` |
