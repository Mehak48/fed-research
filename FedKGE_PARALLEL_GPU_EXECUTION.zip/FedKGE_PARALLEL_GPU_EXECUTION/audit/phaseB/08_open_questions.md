# 08 — Unresolved questions and missing source documents (Phase B, item 8)

## 1. Is `fedkge_revision_P1-P4.zip` File 2 ("Proprietary Learning Reveal")? — **not established**

As you asked, I checked the zip against your description of File 2 ("the revised methodology development, particularly the transition from Phase 1 to Phase 2 … the newer methodological direction and the changes already made").

| Check | Your description | What the zip contains | Result |
|---|---|---|---|
| Name | "Proprietary Learning Reveal" | none of its 78 files contains "Proprietary", "Reveal" or "Learning Reveal" in its name or text (searched all of them) | **does not match** |
| Kind of artifact | a document | a code package: 24 Python modules, 4 notebooks, 18 Markdown files (7 methodology documents in `13_documentation/`), 12 YAML configs, 11 JSON schemas, 53 tests | **partly matches** (it includes methodology documents) |
| Focus | the Phase 1 → Phase 2 transition | revised Phase 1 (data validation, splits) and Phase 2 (Dirichlet non-IID partition), **plus** Phases 3–4. Folders for Phases 5–8 are empty | **matches, but covers more** |
| "Newer direction, changes already made" | changes already made to the research | design and code changes, with an old-to-new mapping (`OLD_CLAIMS_MAPPING_P1_P4.md`). **No executed outputs:** all 4 notebooks have no outputs and there is no results folder. All 96 zip entries are dated 2026-09-22 | **matches for design; no executed results** |
| Inputs it expects | – | asks for "the manuscript and teacher review" before Phases 5–8 (`MASTER_EXECUTION_ORDER.md`) | its author also did not have the professor's review |

**Conclusion.**
- The zip is consistent with a revised methodology covering Phase 1 → Phase 2 (and Phases 3–4).
- Its name and form do not match your description, so **I cannot establish that it is the same artifact**. The discrepancy stays open as X21.
- Per your instruction it is used as the *provisional* File 2.
- **If a separate "Proprietary Learning Reveal" document exists, please send it.** Decision D1, and parts of `03`, would then be re-checked against it before Phase C.

## 2. Missing source documents

| # | Missing input | Why it matters | How Phase B handled its absence |
|---|---|---|---|
| M1 | **The professor's review.** The roadmap says its tasks are "based on the professor's review" | it is the original statement of the requested changes | **no recommendation is attributed to the professor** beyond the roadmap's own text; the methodology rests on the audit and the master prompt |
| M2 | **Your additional roadmap changes**, mentioned in the clarification but not written in File 3 | they may add or change requirements | not invented; the consolidated change list (Phase A, CL-01…CL-33) is marked as possibly incomplete |
| M3 | The "Proprietary Learning Reveal" document, if it is not the zip | see §1 | the zip is treated as provisional |
| M4 | Any outputs from running the revision package (a `fedkge_results/` folder) | evidence of execution | **every revised experiment is labelled unexecuted**; no revised number exists |
| M5 | A revised manuscript, if one exists (the master prompt mentions "previous manuscript and revised manuscript") | continuity of claims | only the original paper ("final version 1.1 (2)") was supplied and used |
| M6 | Repository link (roadmap step 8) | reproducibility statement | needed in Phase G |

## 2b. Inputs used here but not verified (each is re-measured or confirmed before it matters)

| Input | Where it is used | How it gets verified |
|---|---|---|
| WN18RR per-relation training counts (recalled, labelled UNVERIFIED) | partition simulation: 3.75 % acceptance at α = 0.1 | Phase D measures the real counts and reruns the partition check (G15) |
| CoDEx-M partition feasibility (not simulated; no per-relation counts were available) | D5 | Phase D partition audit |
| FB15k-237 licence (the official page states none) and YAGO3 licence page (not checked) | licence gate | your confirmation (§3, question 3) |
| Cost-model parameters (step overhead, per-example and per-parameter costs) | `07` | Stage-2 pilot measures them (gate G-B) |
| Published dataset statistics | `04`, σ and cost planning | Phase D re-counts everything on the loaded data |
| References marked *[standard]* in `03` (not re-fetched in this session) | methodology text | checked against their sources in the manuscript phase (CL-31) |

## 3. Questions for you

1. **Decisions D1–D18.** Use the approval sheet at the end of `02_design_decisions.md`.
   - Two decisions **change** my Phase A recommendations:
     - D2: triple-level DP under **zero-out adjacency** (needed because client sizes are published; ε values are unchanged) and no client-level DP;
     - D5: CoDEx-M instead of YAGO3-10 as the third dataset.
   - D7 is refined, and it has a title consequence: "IPFS-Based" must go from the title unless you choose a real local IPFS node.
   - D9 adds one threshold that is **not** from the original paper: H2b's "no harm" bound (clean MRR ≥ 95 % of FedAvg under the same DP settings). Approve, change or drop it now.
2. **Compute** (after reading `07`). You do not need to commit now. When ready, tell me:
   - which of Kaggle, Colab, a university GPU or a paid GPU you can actually use;
   - the GPU type, if known;
   - roughly how many GPU-hours per week;
   - where results can be stored (for example, free Google Drive space).
   The plan assumes **you run the GPU stages** and upload the run records, and I build the tables and figures from them (as in the Phase A plan). Is that right?
3. **Licences.**
   - FB15k-237's official Microsoft page states no licence. Do you confirm that research use is acceptable?
   - If YAGO3-10 is chosen, do you confirm its CC BY attribution terms?
4. **H3 (D6).** Keep it as a fixed, dedicated audit (60 extra runs, ≈ 3–33 GPU-h; randomised audit pool of 10 % of each client's triples with inclusion probability ½; one-run lower bound with pre-declared guess counts), or drop it and rely on the formal (ε, δ) guarantee?
5. **The D10 trigger value** (25 % of non-private validation MRR at ε* = 4 on FB15k-237). Keep it or change it **now**? It cannot change after results exist.
6. **Restructuring.** Phase C would reorganise the revision package into the master-prompt layout (`src/`, `scripts/`, `configs/`, `tests/`) while keeping its logic and tests. Is that acceptable? It is part of D1.

## 4. Items that stay manuscript-dependent (not part of the methodology phase)

- **Client-0 (74.26 %).** Replaced by measured per-client statistics. The manuscript must remove the old claim.
- **Round-count reconciliation and wording errors** (MN-6).
- **Prior-work numbers.** Each is checked against its source or removed (CL-31). Numbers from per-client test-set protocols (FedE, DP-Flames) are never placed in our tables.
- **Title changes** that follow from D7 ("IPFS-Based") and D12 ("Adaptive").

## 5. What happens after your reply (not started)

Phase C:
- repair and extend the code as listed in `03_methodology_specification.md` §15 (C1–C17);
- run the full test suite, including the PyTorch tests, which needs a GPU or CPU PyTorch environment;
- write `audit/dp_audit.md`.

**No experiment beyond smoke tests runs before gate G-A** (`07` §8). Phases D–G follow in order, without merging phases.
