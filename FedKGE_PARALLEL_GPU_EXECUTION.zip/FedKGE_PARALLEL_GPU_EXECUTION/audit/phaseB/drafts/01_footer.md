
## Contradictions (Phase A, §11) mapped to the defects that resolve them

| Contradiction | Resolved by |
|---|---|
| X01 trust: cosine (paper) / loss deviation (code) / MAD rule (revision) | CR-6, D15 |
| X02 adaptive σ claimed / fixed σ run / header mismatch | CR-10, MN-2, D12 |
| X03, X04 Client-0 74.26 % and "semantic clusters" vs ID-order chunks | CR-8 |
| X05 "full test set" vs 300 random tail queries | CR-4 |
| X06 ε 15.53 vs worst-client RDP 1.98 | CR-2 |
| X07 Fig. 13 caption mixes two runs | MN-3 |
| X08 warm start claimed vs not loaded | CR-7 |
| X09, X11, X24 wording, round counts, runtime ratio | MN-6 |
| X10 δ, clients, partition (paper vs revision) | D3, D4 |
| X12 trained centralised reference vs constant 0.094 | CR-1, MJ-3 |
| X13, X15 IPFS objects; "IPFS-compatible" wording | CR-9, D7 |
| X14 methodology diagram (Flower, NELL-995, RotatE, cross-dataset clients) | D5, OP-7; cross-dataset clients excluded (master prompt §6) |
| X16 Wilcoxon with 5 seeds | G14, D8 |
| X17 "rerun Phase 6 with seeds" — Phase 6 had no experiment | G2 |
| X18 "highlight the Pareto-optimal point" vs "never choose a configuration because it looks good" | D3 (ε* = 4 declared in advance; the full frontier is reported) |
| X19 α grid | G4 |
| X20 missing THREAT_MODEL.md | G3 (draft in `03a_threat_model.md`) |
| X21 "Proprietary Learning Reveal" vs the supplied zip | `08_open_questions.md` §1 (unresolved) |
| X22 "all hypotheses confirmed" | CR-5, MJ-11 |
| X23 "recovers 0.2858 while private" | CR-3 |
