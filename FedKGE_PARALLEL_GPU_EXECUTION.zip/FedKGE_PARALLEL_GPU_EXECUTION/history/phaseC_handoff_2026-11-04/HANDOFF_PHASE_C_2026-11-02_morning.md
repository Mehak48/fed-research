# FedKGE project — handoff brief for the next AI

**Snapshot date:** 2026-11-02 · **Project owner:** Mehak Ramzan · **Prepared by:** Claude (the AI that did Phases A, B and part of C)

**Where the project stands:** Phases A (audit) and B (design) are **complete**. Phase C (repair the code, test it, prepare experiments) is **partly done**:

- the code repair and the test suite are mostly finished;
- the real-data runs, the measured pilot, the schema update and the seven Phase C reports are **not done**.

Phase C is **not complete**. The rest of this brief explains what exists, what is verified, what is not, and the exact steps that remain.

---

## 0. Read this first (rules that override everything else)

The owner wants a **scientifically defensible IEEE paper, not one that only looks convincing**. She wants brutal honesty, wants scope creep flagged, and wants the work done in small, verified steps.

Non-negotiable rules. These are the owner's own instructions, copied in `instructions/`:

1. **Never fabricate results.** Never fill gaps with estimates. Never claim that something ran when it did not. Never make tables or figures from invented values.
2. **Never overwrite or delete:**
   - the original source code;
   - historical results (`files/`, `complete/`, and everything in `audit/`, which is read-only);
   - failed or inconvenient runs. Keep them as results.
3. **Do not download benchmark datasets until the owner confirms their licences** (see §7, Step 3).
   - In this session, a download attempt was **blocked** because the AI tried to confirm the licence on her behalf.
   - Only she can confirm. Do not work around this.
4. **Do not launch the full experiment matrix** (837 core runs, reduced profile) until the owner has reviewed the pilot and the compute budget.
5. **Make no claims of:**
   - client-level DP;
   - IPFS (none exists);
   - "SHA-256 integrity" as a poisoning defence.

   Do not hard-code ε. ε is always computed from the executed configuration.
6. **Use synthetic data only for software tests.** Synthetic success is never evidence about the benchmarks.
7. **Use validation data only for every selection** (hyperparameters, τ, schedules). Read the test split only for final reporting.
8. **Keep the approved design.** If a setting turns out to be invalid or infeasible:
   - stop;
   - explain the problem;
   - propose the smallest justified correction;
   - wait for approval.

   Do not silently substitute another algorithm or drop a dataset.
9. **Do not invent the professor's review.** It was never supplied; only the owner's roadmap file was.
10. **Git:** do not commit or push unless the owner asks. All Phase C changes are uncommitted in the working tree (see §1).

---

## 1. What is in this package

```
fedkge_phaseC_handoff/
├── HANDOFF_PHASE_C.md          ← this file
├── instructions/               ← the owner's own messages (the specification)
│   ├── 1_master_prompt_phaseA.txt
│   ├── 2_clarification_files_and_history.txt
│   ├── 3_phaseB_instructions.txt
│   └── 4_phaseC_instructions.txt     ← the active task (Phase C)
├── audit/                      ← Phase A (read-only) + Phase B design documents
│   ├── artifact_inventory.md, initial_methodology_audit.md, result_provenance.csv, data/, scripts/
│   └── phaseB/ 01…08 *.md, data/ (defect register, experiment matrix, cost/storage estimates), scripts/
├── revision/                   ← THE CODE (git repo; branch phaseC; tag baseline-revision-P1-P4)
│   ├── 01_fedkge_core/fedkge/  ← Python package (all core changes are here)
│   ├── 10_configs/             ← base.yaml, datasets/, tiers/, matrices/ (tune.yaml, confirm.yaml), selection_rules.yaml
│   ├── 12_validation_tests/    ← pytest suite (legacy + 6 new test_phaseC_*.py files)
│   ├── 13_documentation/       ← DP_MECHANISM.md (rewritten), THREAT_MODEL.md (new), older docs (not yet updated)
│   ├── scripts/                ← NEW Phase C entry points (see §5.3)
│   ├── results/phaseC/         ← official Phase C outputs so far (test reports, accounting validation, manifests)
│   ├── requirements-phaseC.txt ← pinned versions used here
│   └── 02_…09_ notebooks, README.md, MASTER_EXECUTION_ORDER.md  ← from the original revision zip, NOT yet updated
├── phaseC_changes.patch        ← `git diff baseline-revision-P1-P4` (the 29 modified tracked files)
├── phaseC_git_status.txt       ← `git status --short` (lists the 28 new, untracked files)
├── phaseC_dev_probes/          ← EXPLORATORY software probes on synthetic data (not results; see §5.8)
└── reference/legacy_code_extracted/  ← code cells of the original P3 and P4 notebooks as text (for §5.6)
```

**Git state of `revision/`:**

- Tag `baseline-revision-P1-P4` = the owner's `fedkge_revision_P1-P4.zip`, unmodified (sha256 `57d23c4e…54f8`).
- Branch `phaseC` = that tag plus uncommitted changes:
  - 29 tracked files modified (+1,875 / −393 lines);
  - 28 new files: 10 scripts, 6 test files, 9 configs, `THREAT_MODEL.md`, `requirements-phaseC.txt`, `.gitignore`.
- To see the changes: `cd revision && git status && git diff baseline-revision-P1-P4`.
- To recreate the untouched baseline for comparison: `git worktree add ../revision_baseline baseline-revision-P1-P4`.

**Not included** (the owner has these; ask her for them when needed):

- the original upload files (paper, roadmap, original notebooks `files/`, historical outputs `complete/`);
- the legacy checkpoint `complete/global_transe_final.pt`, which Step 7 needs;
- the Python virtual environment (5.3 GB; rebuild it with Step 0).

---

## 2. The project in brief

- **Original paper:** "Privacy-Preserving Federated Knowledge Graph Embedding with Adaptive Differential Privacy, IPFS-Based Model Integrity and Trust-Weighted Aggregation on Non-IID Distributed Data". TransE on FB15k-237 with 5 clients, Colab notebooks for Phases 1–8.
- **Phase A verdict:** not submittable. Only two experiments were real:
  - a non-private FedAvg run: MRR 0.2858;
  - a DP run: MRR 0.009.

  Both used 1 seed and a weak evaluation: 300 or 150 random test triples, tail prediction only, optimistic ties. Every Phase 5–8 number was hard-coded or simulated.
- **Revised study (Phase B design, approved direction):**

| Area | Approved design |
|---|---|
| Datasets | FB15k-237, WN18RR, CoDEx-M; each needs a licence and version check |
| Clients and partitions | 10 clients; Dirichlet-over-relations partitions with α ∈ {0.1, 0.5, 1.0}; IID; centralised reference |
| Privacy unit | Triple-level DP per client under **zero-out adjacency**; no client-level DP |
| Privacy targets | ε ∈ {1, 2, 4, 8}, primary ε\* = 4; δ = 1e-6 (also 1e-5); RDP accountant, with PLD and PRV cross-checks |
| Baselines | Non-private references; DP-FedAvg (main privacy baseline); robust baselines (trimmed mean, median, Krum, FLTrust) |
| Proposed method | Trust-weighted aggregation from update anomaly scores (frozen rule, plus one variant V1 with a pre-declared trigger) |
| Attacks | Gaussian, sign-flip, ALIE, IPM, KG-targeted, Sybil, adaptive. Main fraction f = 0.2, sensitivity f = 0.1 / 0.3. Under DP, attackers inherit or match the DP noise |
| Integrity | SHA-256 verification **in the data path** (only verified bytes are aggregated). Not a poisoning defence; no IPFS |
| Membership inference (H3) | A fixed audit: randomised audit pool and a one-run lower bound |
| Seeds | 5 for confirmatory comparisons, 10 for headline comparisons; tuning on a separate seed (1001) |
| Selection | Validation-only, with pre-registered rules |
| Order | Staged: tests → smoke → pilot → tuning → confirmatory |

---

## 3. Phase A — complete (do not redo)

**Files** (all in `audit/`):

- `initial_methodology_audit.md`: start with §0 (executive summary).
- `artifact_inventory.md`.
- `result_provenance.csv`: 47 manuscript claims traced to code and outputs.
- `data/`, `scripts/`.

**Key findings** (Phase A; the ε numbers were re-verified independently in Phase C):

- **The reported ε = 15.53 is invalid.**
  - It is the sum over 16 rounds of the per-round mean ε over clients, and δ was never composed.
  - Correct per-client RDP composition gives a worst-client **ε ≈ 1.98 at δ = 1e-5** (PLD: 1.76).
  - The run stopped at round 16 because of the invalid sum.
- **The headline row** pairs the non-private MRR 0.2858 with DP, trust and IPFS that were never active in that model.
- **Trust** came from client-reported, un-noised **losses**, not the update cosine the paper describes.
- **"IPFS"** was SHA-256 hashes, prefixed "Qm", of **random tensors**.
- **No adaptive DP** was ever run.
- **The partition was misreported.** The paper's largest-client share (74.26 %) came from a preview that was never trained; the trained partition's largest client held 30.81 %.
- **Phases 5–8 numbers** (304 %, Krum +28.21 %, 100 % poisoning defence, 30.56 % MI reduction, p-values, …) were hard-coded or simulated.
- **The revision zip** (`fedkge_revision_P1-P4.zip`, assumed to be "Proprietary Learning Reveal") is a sound base for Phases 1–4. The match is **not established**; it is treated as provisional.

---

## 4. Phase B — complete; direction approved by the owner in the Phase C instructions

**Files** (all in `audit/phaseB/`):

| File | Contents |
|---|---|
| `01_defect_register.md` + `data/defect_register.csv` | 83 defects: CR-1…14, MJ-1…21, MN-1…22, OP-1…11, G1…G15 |
| `02_design_decisions.md` | D1–D18, with an approval sheet at the end |
| `03_methodology_specification.md` + `03a_threat_model.md` | The maths, privacy model and threat model |
| `04_dataset_benchmark.md` | Dataset choice |
| `05_privacy_utility_plan.md` | Hypotheses H1, H2, H2b, H3, HS; tests; Holm families |
| `06_experiment_matrix.md` + `data/experiment_matrix.csv` | Every block with its run counts |
| `07_compute_feasibility.md` | GPU-hours, storage and stage gates G-A…G-D. **Unverified estimates** |
| `08_open_questions.md` | Open questions for the owner |

**D1–D18 recommended defaults** (the approved direction):

| ID | Default |
|---|---|
| D1 | Extend the revision package; keep legacy code frozen |
| D2 | Triple-level DP per client, **zero-out adjacency**; no client-level DP |
| D3 | ε\* = 4, δ = 1e-6; ε ∈ {1, 2, 4, 8} + non-private; RDP primary; PLD/PRV reported |
| D4 | 10 clients; Dirichlet over relations, α ∈ {0.1, 0.5, 1.0}; IID; legacy replicas |
| D5 | CoDEx-M as third dataset (YAGO3-10 optional) |
| D6 | H3 as a fixed MIA audit: randomised pool, one-run bound, 5 seeds, 60 runs |
| D7 | SHA-256 integrity in the data path; no IPFS claim; "IPFS-Based" removed from the title |
| D8 | Tuning seed 1001; 5 seeds per hypothesis block; 10 in the full profile |
| D9 | H1, H2, H2b, H3, HS with one-sided tests and Holm families |
| D10 | Declared trigger: if DP utility at ε\* = 4 on FB15k-237 is below 25 % of non-private validation MRR, decide an alternative (decided before results) |
| D11 | Sampling design Q (common q, one σ) next to design A (fixed batch 512, per-client σ); tuning step T2d decides; ties go to Q |
| D12 | "Adaptive DP" = pre-declared scheduled noise decay (option a). O1 (validation-triggered) is optional |
| D13 | Separate tuning seed; same shared-setting grid for private and non-private; DP runs use all R rounds |
| D14 | τ\* = smallest τ on the grid {1.5, 2, 2.5, 3, 3.5, 4, 5} with benign FPR ≤ 5 % in the clean DP-FedAvg tuning run |
| D15 | The revision trust rule is frozen. One variant, V1 (size-third magnitude reference), applies only if a pre-declared trigger fires |
| D16 | Attackers inherit or match the DP noise; f = 0.2 main; noise-free attacks are a secondary check; targets come from the attackers' own data |
| D17 | No external DP-KGE reproduction; DP-FedAvg is the baseline |
| D18 | Reduced profile first; a pilot gate; a storage policy |

**Phase B plan size** (from `data/run_counts.csv`; GPU-hours are **unverified Phase B estimates**):

| Plan | Runs | GPU-hours (LOW–HIGH) |
|---|---|---|
| Reduced profile with CoDEx-M: core | **837** | 46.5–392.6 |
| H3 audit (M1) | 60 | 2.8–32.5 |
| Extended blocks (optional) | 432 | 20.7–234.9 |
| Full profile: core | 1,485 | 78.4–721.4 |

Planned storage is ≤ 2.33 GB (reduced) or ≤ 3.46 GB (full).

**Still unanswered by the owner** (from `08_open_questions.md` §3):

| Topic | Status |
|---|---|
| Compute environment | Which GPU, how many hours per week, where results are stored |
| Licences | FB15k-237 (the Microsoft page states no licence) and CoDEx-M/WN18RR; see Step 3 |
| D10 trigger value | 25 % |
| H2b "no harm" bound | Clean MRR ≥ 95 % of FedAvg under the same DP settings; a new threshold, not from the original paper |
| H3 | Keep or drop. Implemented as block M1, as approved |
| Restructuring to `src/`, `scripts/`, `configs/`, `tests/` | **Not done.** The original layout was kept and `scripts/` added; ask whether that is acceptable |

---

## 5. Phase C — what has been done

### 5.1 Environment (measured)

**Machine** (this cloud container):

- 2 CPU cores, 7.8 GB RAM, **no GPU**;
- Linux; Python 3.13.18.

**Installed versions** (`revision/requirements-phaseC.txt`):

| Package | Version |
|---|---|
| torch | 2.14.1 (CUDA 13 build, used on CPU) |
| numpy | 2.5.3 |
| scipy | 1.18.1 |
| pandas | 3.0.5 |
| PyYAML | 6.0.3 |
| jsonschema | 4.26.0 |
| matplotlib | 3.11.2 |
| dp-accounting | 0.6.0 |
| prv-accountant | 0.2.0 |
| opacus | 1.6.0 |
| pytest | 9.1.1 |

**Network:**

- PyPI works.
- download.pytorch.org is blocked, so torch came from PyPI. That took 29 minutes.
- The GitHub API returns 403; `git ls-remote` and raw.githubusercontent.com work.

**Phase A's gap is resolved:** the 26 PyTorch tests that Phase A could not run (no PyTorch) now run and pass, including the Opacus comparison.

### 5.2 Code changes and status, by component

**Status legend** (none of these mean "works on real data"):

- **IMPL** = implemented.
- **UNIT** = unit-tested.
- **INTEG** = integration-tested in full federated rounds on the synthetic KG.
- **PROBE** = exercised in exploratory synthetic probes (§5.8).
- **Nothing has run on real benchmark data yet.**

**Configuration and run identity** · Status: IMPL, UNIT

- **Files:** `config.py`, `base.yaml`, `tiers/*.yaml`
- **Defect:** no tiers or options for the new design.
- **Phase C change:**
  - Tiers smoke / dev / pilot / tune / final.
  - Datasets now include `codex_m` and `synthetic_*` (the synthetic ones are rejected in the tune and final tiers).
  - New validations: design Q needs 0 < q < 1; clip = None only with no_noise; `stop_after_rounds` only in smoke/dev/pilot; the attack noise mode and target source; f_design ∈ (0, 0.5); `corrupt_p` not allowed with mode off; MIA pool settings; warm start rejected.
  - `train.keep_final_weights` is now *output-only*: it is excluded from the run hash, so identical runs shared across blocks stay one run.
- **Tests:** `test_invalid_configs_fail_loudly` (8 cases), `test_output_only_option_does_not_change_run_identity`, `test_data_partition_config.py`

**Dataset loaders** · Status: IMPL, UNIT on toy files only. **No real file has been loaded.**

- **Files:** `data.py`, `scripts/prepare_data.py`, `datasets/*.yaml`
- **Defects:** MN-8 / G12 (automatic PyKEEN download with no licence gate); MN-20 (vocabulary mismatch); no CoDEx-M.
- **Phase C change:**
  - A local-file loader that maps labels to ids exactly as PyKEEN does (sorted labels). Evaluation triples with entities unseen in training are dropped and counted.
  - File checksums are bound to `source_manifest.json`.
  - A **licence gate** with pinned sources: ConvE repo commit `f3c0eb28…` for FB15k-237/WN18RR, CoDEx repo commit `3132e426…`.
  - The dataset card records licence, citation and relations with fewer than 10 training triples.
  - A size-matched synthetic generator, for timing only.
- **Tests:** `test_pykeen_identical_mapping_and_unseen_drop`, `test_loader_binds_checksums_and_rejects_malformed`, `test_size_matched_synthetic_generator`

**Partitioning** · Status: IMPL, UNIT. Acceptance rates on **real** relation counts are not measured (risk for WN18RR at α = 0.1, open item G15).

- **Files:** `partition.py` (unchanged), `scripts/build_artifacts.py`
- **Defects:** G4 (α = 0.5 missing); G15 (WN18RR feasibility at α = 0.1 unknown); MN-9 (a truncated Dirichlet).
- **Phase C change:**
  - The α grid is set through the configs.
  - A partition audit script checks coverage, no empty client, the minimum-size rule, determinism and hash binding.
  - It also estimates the acceptance rate from fresh Dirichlet draws on the relation counts. This has **not yet been run on real data**.
  - The accepted partition is always the first draw that meets the rule in the seeded stream; nothing is re-drawn to get a better partition.
  - Audit files are timestamped and never overwritten.
- **Tests:** `test_dirichlet_partition_valid_deterministic[0.1, 0.5, 1.0]`, legacy partition tests

**TransE model and loss** · Status: UNIT (baseline tests pass)

- **Files:** `model.py`, `train.py`, `sampling.py` (all unchanged)
- **Defect:** none new. The revision already uses entity normalisation and correct negatives.
- **Phase C change:** none.
- **Tests:** `test_evaluate_sampling.py`, `test_dp_clipping.py`

**DP mechanism** · Status: IMPL, UNIT, INTEG

- **Files:** `dp.py`
- **Defects:** MN-22 (no non-finite guard); G7 (attackers skip the noise).
- **Phase C change:**
  - Per-example clipping now zeroes any non-finite per-example gradient.
  - Dense noise is added only if σ > 0, which gives the DP3 no-noise ablation.
  - Clients with empty data work (pure-noise client); this is used by Sybil.
  - Stats record the expected batch and the number of zeroed examples.
- **Tests:** `test_phaseC_privacy.py` (11 test functions, 15 cases), `test_dp_clipping.py` (matches Opacus and brute-force autograd)

**Privacy accountant** · Status: IMPL, UNIT, plus a 96-point validation (§5.5)

- **Files:** `accountant.py`, `scripts/check_privacy_accounting.py`
- **Defects:** CR-2 (invalid ε); CR-14 (add/remove adjacency vs public sizes); MJ-16 (design A fails for small clients).
- **Phase C change:**
  - Zero-out adjacency via `dp_accounting` `NeighboringRelation.REPLACE_SPECIAL`. The public API must equal the runtime RDP; a mismatch raises.
  - Design Q helper `dp_steps_common_rate`.
  - A PRV cross-check; PLD is kept.
  - ε is composed over the steps **each client actually executed** (a skipped round counts 0 steps).
  - σ₀ is calibrated by bisection to meet ε\*.
- **Tests:** `test_phaseC_privacy.py`, `test_accountant.py`

**Federated loop** · Status: IMPL, INTEG, PROBE

- **Files:** `federated.py` (largely rewritten: +388 / −138 lines)
- **Defects:** CR-13 (integrity not in the data path); G6 (early stopping vs DP); MN-16 (unsafe checkpoint loading); MN-21 (targets from the test set).
- **Phase C change:**
  1. Clients train from their **verified copy** of the broadcast.
  2. Only verified uploads are aggregated.
  3. DP runs execute all R rounds; the best validated checkpoint is selected afterwards (post-processing).
  4. Anomaly scores (A and A_v1) are logged in **every** run.
  5. Each run writes trust_rounds.csv and integrity.json. It also writes accountant.json (DP runs), attack.json (attack runs) and mia.json (MIA runs).
  6. `stop_after_rounds` supports timing runs, which are flagged `partial_run`.
  7. A non-finite global model stops the run.
  8. Checkpoints load with `weights_only=True`.
  9. Peak GPU memory is recorded.
- **Tests:** `test_phaseC_pipeline.py` (11 test functions, 21 cases)

**Integrity verification** · Status: IMPL, UNIT, INTEG

- **Files:** `integrity.py` (rewritten)
- **Defects:** CR-9 (fake IPFS); CR-13.
- **Phase C change:**
  - Canonical serialisation with a header.
  - SHA-256 object id. This is **not** an IPFS CID.
  - Sequence: send → store → optional in-transit corruption (`corrupt_p`) → fetch → verify the hash and the header (name, round, shape) → deserialise the **verified bytes**.
  - Modes: off / transport_only / hash_only / full_store_last_k.
  - A manifest hash chain; a store tamper test.
- **Tests:** `test_phaseC_integrity.py` (10 tests, including the 5 tests the owner required)

**Trust aggregation (proposed method)** · Status: IMPL, UNIT, PROBE. A V1 weakness was found (§6, item 4).

- **Files:** `trust.py`, `aggregators.py`
- **Defects:** CR-6 (trust from losses); G8 (per-client σ vs the magnitude anomaly); MN-18 (robust-aggregator assumptions depend on f).
- **Phase C change:**
  - History is indexed by client identity, so only identities present in a round are updated.
  - Variant V1 uses the size-third magnitude reference.
  - Robust baselines are set at f_design = 0.2: Krum f = max(true f, 2); trim β = max(0.2, f/n).
  - Benign false-positive rates are logged.
- **Tests:** `test_phaseC_trust_attacks.py` (9 tests)

**Attacks** · Status: IMPL, UNIT, INTEG

- **Files:** `attacks.py`
- **Defects:** G7; MN-19 (one strength for every attack); MN-21.
- **Phase C change:**
  - Noise modes: `auto` resolves to inherit (sign-flip, Gaussian, targeted) or matched (ALIE, IPM, adaptive, Sybil). `none` gives the secondary noise-free check.
  - `match_norm`.
  - Sybil uses the real DP noise from training on empty data.
  - The targeted attacker trains with DP; its targets come from the attackers' own triples.
  - The adaptive attacker's search includes its own noise and is allowed against FedAvg.
- **Tests:** `test_phaseC_trust_attacks.py`, `test_attacks_under_dp_complete[4 attacks]`

**Link-prediction evaluation** · Status: UNIT. Already correct in the revision.

- **Files:** `evaluate.py` (unchanged)
- **Defects:** CR-4 (fixed in the revision).
- **Phase C change:** none. Full filtered head + tail ranking with realistic ties. The legacy protocol is available only as a labelled replica.
- **Tests:** `test_filtered_head_tail_realistic_matches_bruteforce`, `test_ties_are_not_optimistic`

**Selection (tuning chain, τ, V1 trigger)** · Status: IMPL, regression-tested. The chain was probed end-to-end on synthetic data: stages 1–5 worked; stage 6 stopped as designed (§5.8).

- **Files:** `selection.py`, `selection_rules.yaml`, `scripts/run_plan.py`, `scripts/freeze_selections.py`
- **Defects:** MJ-5 (no threshold-selection rule); MJ-18 (selection seeds = reporting seeds); D13–D15.
- **Phase C change:**
  - A generic `select_rule` covers T1, T2a–T2d and T3.
  - `select_tau` implements D14; `v1_trigger` implements D15.
  - The final tier **refuses** to select.
  - Selections are frozen and hashed before Stage 4.
- **Tests:** `test_tuning_chain_reuses_previous_winner`, `test_selections_use_validation_only_and_full_grid`

**Experiment matrices and runner** · Status: IMPL, regression-tested

- **Files:** `runner.py`, `matrices/tune.yaml`, `matrices/confirm.yaml`
- **Defects:** G2 (no matrices for Phases 5–8); MJ-14.
- **Phase C change:**
  - Seed sets S1, S3, S5, S10, S10x and the full and reduced profiles.
  - Block features: `exclude`, `_cell` overlays, and `keep_weights_when`.
  - A shared run keeps its weights if any block needs them.
  - `max_seeds_per_block` (smoke uses one seed per block).
  - A run with missing weights is rerun, and the old run is archived, not deleted.
- **Tests:** `test_confirmatory_matrix_matches_phaseB_plan[full, reduced]`. The new-run count of **every block** equals the Phase B CSV, and kept weights are 225 (full) / 150 (reduced) as planned.

**Statistics** · Status: IMPL, UNIT

- **Files:** `stats.py`
- **Defects:** CR-5; G14 (n = 5 cannot give exact p < 0.05).
- **Phase C change:** a one-sided t-test with a 97.5 % bound; a log-ratio test; the H2 contrast with a testability gate; Holm correction with fixed families.
- **Tests:** `test_one_sided_and_log_ratio`, `test_h2_contrast_gate_and_holm_family_fixed_membership`

**Membership-inference audit (H3)** · Status: IMPL, UNIT, INTEG

- **Files:** `mia.py` (rewritten)
- **Defect:** MJ-15 (compared training triples with official test triples).
- **Phase C change:**
  - Audit pool = 10 % of each client's triples. Each candidate is included with probability ½; excluded ones become null records.
  - Attacks A1, A2 (relation-calibrated; primary) and A3 (white-box).
  - Metrics: AUC; TPR at 1 % and 0.1 % FPR, with a resolvability flag.
  - The one-run ε lower bound (Steinke, Nasr & Jagielski 2023), Bonferroni-corrected over the guess counts.
  - If the bound exceeds the accountant's ε, the run is flagged (a red line).
- **Tests:** `test_one_run_bound_behaviour`, `test_mia_audit_pool_and_one_run_bound`

**Plotting** · Status: IMPL. No publication figures were made.

- **Files:** `plotting.py`
- **Defects:** MN-7 / G5 (PNG only).
- **Phase C change:** PNG at 300 dpi, plus PDF and SVG.
- **Tests:** legacy report test

**I/O, manifests, reproducibility** · Status: IMPL, UNIT

- **Files:** `io.py`, `scripts/_common.py`
- **Defect:** MN-8 (deprecated utcnow).
- **Phase C change:**
  - `utc_now()`.
  - The environment record now includes CPU, threads and prv version.
  - Execution manifests for every script step.
  - Stale runs are archived, never deleted.
- **Tests:** `test_resume_after_interruption`, `test_stale_code_is_detected`, `test_reproducible_same_seed`

**Legacy re-evaluation (L0)** · Status: **NOT RUN.** It needs the FB15k-237 files and `complete/global_transe_final.pt`.

- **Files:** `scripts/legacy_l0_eval.py`
- **Defect:** OP-8.
- **Phase C change:** re-evaluates the legacy checkpoint under the corrected protocol and the legacy protocol.
- **Tests:** none.

### 5.3 New entry-point scripts (`revision/scripts/`)

All scripts write to `results/phaseC/`, or wherever `--results` or `FEDKGE_RESULTS` points. Each step writes a manifest to `manifests/`.

| Script | Purpose |
|---|---|
| `run_tests.py --name X` | Runs pytest; writes junit, a log and `summary_X.json` (passed / failed / error / skipped) |
| `check_privacy_accounting.py` | Validates the accountant five ways over 96 operating points (§5.5) |
| `prepare_data.py` | Licence-gated fetch of pinned sources, with safe tar extraction; writes `source_manifest.json` with checksums. **Needs the owner's confirmation flag** |
| `build_artifacts.py` | Builds Phase 1 data artifacts and Phase 2 partitions, plus the partition audit CSV and acceptance rates. `--tier-file` selects the tier settings |
| `small_run.py` | The validated small-run script: profiles np_central, np_fed, np_fed_iid, dp_a, dp_q, complete, attack_alie, attack_targeted, integrity_corrupt, mia, dp3_no_noise |
| `run_plan.py` | Runs the tuning chain in order (stages 1–6, with selection after each stage) or the confirmatory matrix. Builds missing partitions; stops on any failure. **No unit test.** The tune plan ran once on synthetic data (§5.8); the confirm plan has never run |
| `freeze_selections.py` | Copies tune-tier selections to the final tier and records their hash |
| `pilot.py` | The measured pilot. Each config runs in its own subprocess for true peak memory; it extrapolates cost over the real expanded matrices. **Rewritten at the end of the session.** Its worker mode ran once (the probe in §5.8); the driver and the extrapolation have **never run** |
| `legacy_l0_eval.py` | L0 (see the table above) |

### 5.4 Tests

**Baseline** (unmodified revision zip):

- **53 passed, 0 failed, 0 skipped** in 392 s;
- this includes all 26 PyTorch tests and the Opacus comparison;
- report: `revision/results/phaseC/test_reports/pytest_baseline_unmodified.log`.

**Current code, full suite** (legacy + Phase C tests), run on 2026-11-02 for this handoff:
**123 passed, 0 failed, 0 errors, 0 skipped** (222 s on 2 CPU cores).

- 53 legacy tests: all still pass.
- 70 new Phase C test cases:
  - privacy 15;
  - pipeline 21;
  - integrity 10;
  - data and statistics 9;
  - trust and attacks 9;
  - regression and matrix 6.
- 13 warnings, none affecting the results:
  - an Opacus backward-hook notice;
  - numpy "degrees of freedom ≤ 0", from single-seed report fixtures;
  - a pandas fragmentation notice.
- All test data are synthetic.

- Report: `results/phaseC/test_reports/summary_phaseC_handoff.json` (+ junit / log).

**Earlier full run** (2026-10-28): 115 passed, 6 failed. The causes were found and fixed:

| Failed tests | Cause | Fix |
|---|---|---|
| 1 | A test-design error in the order of validation rules | Test corrected |
| 2 (full and reduced profile) | Block X2 gave 9 extra runs, because `keep_final_weights` split one shared run | Made `keep_final_weights` output-only |
| 3 (legacy offline tests) | `STALE_CODE` | None needed: code had been edited **during** the test run, which correctly triggered stale-code detection. A rerun gave 9/9 passing |

**Lesson for you:** never edit `01_fedkge_core/fedkge/*.py` while tests or runs are executing.

**The owner's six test groups are all covered:**

- **A** unit;
- **B** integration (a full DP-Q round with proposed aggregation, integrity and an attack);
- **C** regression (historical artifacts unchanged; outputs never written to historical locations);
- **D** reproducibility (same seed → identical outputs);
- **E** failure paths (invalid configs, missing dataset, malformed checkpoint, wrong hash, header replay, interrupted run, rejected uploads);
- **F** PyTorch.

### 5.5 Privacy accounting validation

Command: `python scripts/check_privacy_accounting.py`, run 2026-10-28, run 2.

Outputs:

- `results/phaseC/privacy_accounting/accounting_validation.csv`
- `results/phaseC/privacy_accounting/accounting_validation_summary.json`

**Coverage:** 96 operating points:

- ε ∈ {1, 2, 4, 8};
- δ ∈ {1e-6, 1e-5};
- designs A and Q;
- three datasets' published sizes;
- every point is calibrated by the runtime code.

**Result: 0 failed checks.**

| Check | Result |
|---|---|
| Runtime vs `dp_accounting` public zero-out API | max difference 1.15e-14 |
| Own numerical quadrature (no `dp_accounting`) | never above runtime ε; runtime is at most 0.143 % conservative |
| PLD / RDP | 0.914–0.936 |
| PRV upper bound | ≤ RDP |
| Gaussian closed form | error 0 |
| Legacy per-round log reproduced | max difference 4.05e-7 |
| Legacy worst-client RDP over 16 rounds | 1.98054 at δ = 1e-5 |

**Why runtime is slightly conservative:** `dp_accounting` is exact at integer orders and an upper bound at fractional orders. So the reported ε is conservative, never too small.

**Honest note:**

- **Run 1 reported 1 failed check.** The cause was a direction error in *my* check: it flagged the conservative direction as a failure.
- The fix is recorded in its manifest (`manifests/20261028T164547Z_privacy_accounting.json`, status CHECKS_FAILED).
- Run 1's CSV was overwritten by run 2. The script now timestamps its outputs, so this cannot happen again.
- Run 2 used the system Python, which has the same package versions as the venv.

### 5.6 The 0.009 vs 0.2858 gap

These are code-level findings, verified in the legacy code. **The gap is not measured yet.**

**The comparison is confounded.** It is not "DP alone":

| Setting | P3 (non-private, 0.2858) | P4 (DP, 0.009) |
|---|---|---|
| Entity normalisation | yes | no |
| Negatives | 1 per triple | 1 per triple, independent coins: 25 % identical to the positive (zero gradient) |
| Local epochs | 3 | 1 |
| Rounds | 50 | 16, stopped early by the invalid naive-sum rule (> 15) |
| Batch | 512 | 256, Poisson, `drop_last` |
| Clipping / noise | `clip_grad_norm` 1 | C = 1, σ = 1 |
| Evaluation | 300 random test triples | 150 random test triples |

**Also:**

- Both evaluations were tail-only with optimistic ties, on the last-round model.
- The claimed warm start was not actually loaded.
- Dense noise on all 1.47 M parameters with Adam (Phase A §4.4) is a major suspect: noise-norm-to-signal ratio ≈ 4.74 at B = 256.

**How the plan decomposes it:**

- legacy replicas L1–L4;
- the DP3 no-noise ablation (σ = 0, same training settings; **no guarantee**);
- L0 (the legacy checkpoint under correct evaluation).

**None of these has run.**

### 5.7 Dataset and licence status

**Licences checked** (web pages, 2026-10-28):

- Freebase dumps: CC BY 2.5.
- The Microsoft FB15K-237 page **states no terms**; the README inside the archive could not be checked.
- CoDEx repository: MIT; its triples come from Wikidata (CC0).
- WN18RR: under the WordNet licence; the ConvE repository is MIT.

**Benchmark files:** **not downloaded.** This is blocked until the owner confirms the licences.

**Size-matched synthetic stand-ins** (`synthetic_*_sized.yaml`):

- They exist **for timing only**.
- Their counts come from the dataset papers and were **not measured here**.

### 5.8 Exploratory probes (`phaseC_dev_probes/`; synthetic data; NOT results; not in `results/phaseC`)

1. **`small_run.py`, all 11 profiles, on the synthetic KG:** all completed.
   - Integrity with `corrupt_p` = 0.1: 4 corrupted, 4 rejected, 0 consumed.
   - ALIE matched norm = the attacker's honest norm.
   - MIA AUC ≈ 0.51 (as expected for 3 rounds).
2. **`run_plan.py --plan tune` on synthetic data:**
   - Stages 1–5 ran 33 runs and made a selection after each stage.
   - Reuse of the previous winner worked: T2b0, T2c0, T2d0, T30 and TAU were not re-run.
   - **Stage 6 stopped:** no τ on the grid met benign FPR ≤ 5 %, because the V1 trigger fired and V1 scores were unstable (§6, item 4).
   - Detail: under the frozen rule, τ = 3.0 had benign FPR exactly 5 %, which meets the rule. But only 20 benign observations existed (2 rounds × 10 clients). The trigger fired on 1 of 8 smallest-third observations, so it fired on noise.
   - This stop is the *designed* behaviour ("report and decide; never extend the grid"). As a result, the **confirm plan has never been run end-to-end, even in smoke.**
3. **Pilot timing probe** (one round; FB15k-237-sized synthetic stand-in; design Q, q = 0.10, ε\* = 4, CPU):

| Measure | Value |
|---|---|
| Time per round | **79 s** (10 clients × 10 steps) |
| Final full filtered evaluation | 8.6 s |
| Peak memory (RSS) | **2.0 GB** |
| Run directory | 6 MB, including 5.9 MB of final weights |
| Extrapolated time per DP run | ≈ 2.2 CPU-hours |

**Consequence:** the full plan is **infeasible on this CPU**. A GPU is required.

---

## 6. Known issues, risks and decisions needed (be honest about these)

1. **BLOCKER: dataset licences.** The owner must confirm FB15k-237, WN18RR and CoDEx-M research use (Step 3). Until then:
   - no real smoke runs;
   - no per-dataset run;
   - no real partition acceptance rates;
   - no L0;
   - no real pilot.
2. **BLOCKER: compute.** No GPU here. The owner has not yet said what GPU or hours she has. The pilot must be run on her GPU to pass gate G-B.
3. **RISK: the τ rule (D14) may have no feasible τ on real data.**
   - If so, the pipeline stops for a decision, by design. Do not extend the grid after seeing data.
   - Ask the owner in advance what to do if it happens.
4. **RISK: variant V1 is statistically unstable with 10 clients.**
   - Size thirds have only 3–4 clients, so the per-group median and MAD scale is noisy.
   - In the synthetic probe, benign clients got A_v1 scores up to 9.1, so V1's false positives were *worse* than the frozen rule's.
   - The V1 trigger also uses `reference_tau` = 3.0 and `min_fpr_for_ratio` = 0.05. These are Phase C details **pending the owner's approval**.
   - Raise this with the owner **before** Stage 3. Do not change the rule silently.
5. **RISK: WN18RR at α = 0.1** may rarely meet the minimum-size rule (Phase B simulated about 3.75 % acceptance on *recalled* counts). CoDEx-M was never simulated.
   - Measure acceptance with `build_artifacts.py --accept-draws 2000` on the real data.
   - If acceptance is too low, report it and propose a remedy. Never re-draw until it looks good.
6. **Pending approvals that were never answered:**
   - D10 trigger 25 %;
   - H2b 95 % "no harm" bound;
   - MIA pool 10 %, inclusion ½, guesses {100, 300, 1000}, confidence 0.95;
   - the V1 trigger details;
   - the folder restructuring (not done).
7. **Not implemented** (documented as out of Phase C):
   - X6 (local-only training baseline);
   - O1 (validation-triggered σ decay with an RDP filter);
   - IPFS. This is correct: make no IPFS claim.
8. **Schemas:** `11_experiment_schemas/` was **not** extended to the new Phase C outputs: `integrity.json`, `attack.json`, `mia.json`, `trust_rounds.csv`, and the new accountant and final fields. Gate G-A requires valid schemas, so this is still to do.
9. **Documentation:** `revision/README.md`, `MASTER_EXECUTION_ORDER.md`, `COLAB_RUNBOOK.md` and `EXECUTION_PLAN.md` still describe the original package. They must be updated with exact commands.
10. **MIA metric:** TPR at 0.1 % FPR is only meaningful with ≥ 1000 non-members. The code now flags this (`fpr_resolvable_0_1pct`).
11. **The tuning cost of privacy** (selecting on the same data) is disclosed in the design, not accounted. Keep this wording.
12. **Smoke-tier change:** `smoke.yaml` now cuts rounds with `stop_after_rounds` instead of `rounds_max`, and no longer overrides the training batch size. Otherwise, blocks that differ only in R (T2c) or in batch size (T1) would collapse into one run, or clash with a grid key.
    - This was changed at the end of the session.
    - **No test uses `smoke.yaml`**; the tests use the offline tier. Its first real use will be Step 6.
    - The synthetic twin, `smoke_synthetic.yaml`, ran in the tune-chain probe.

---

## 7. What is left — ordered steps with exact commands

Run everything from `revision/` using the project venv. Results go to `revision/results/phaseC/` unless `--results` is given.

**Step 0: Set up the environment** (once)

```bash
python3.13 -m venv .venv && . .venv/bin/activate
pip install -r revision/requirements-phaseC.txt      # torch from PyPI is large (≈ 2–3 GB with CUDA libraries)
cd revision
```

**Step 1: Run the full test suite** (must be 100 % pass, 0 skipped)

```bash
python scripts/run_tests.py --name phaseC_rerun
```

- Do not edit core code while it runs.
- Fix any failure first.
- `test_historical_artifacts_unchanged` needs the owner's original uploads at `/mnt/user-data/uploads` and the Phase A inventory. On another machine it **skips**. Report it as skipped, not passed, or point it at the uploads.

**Step 2: Validate privacy accounting** (expect 0 failed checks)

```bash
python scripts/check_privacy_accounting.py
```

**Step 3: Owner's licence confirmation** (the owner must do this herself, or explicitly tell you to)

```bash
python scripts/prepare_data.py --dataset fb15k237 --data-dir ../data_cache     # prints source, licence and citation only
# only after the owner has confirmed the licence in her own words:
for ds in fb15k237 wn18rr codex_m; do
  python scripts/prepare_data.py --dataset $ds --data-dir ../data_cache --i-confirm-licence \
         --operator-note "<owner's own confirmation and date>"
done
```

- Then check `../data_cache/<dataset>/source_manifest.json`.
- Re-count entities, relations and triples. Compare them with the published statistics and with `synthetic_*_sized.yaml`; record any differences.
- **Do not redistribute the files.**

**Step 4: Build real artifacts and the partition audit**

```bash
python scripts/build_artifacts.py --tier smoke --datasets fb15k237 wn18rr codex_m --data-dir ../data_cache \
       --seeds 42 --alphas 0.1 0.5 1.0 --iid --central --accept-draws 2000
python scripts/build_artifacts.py --tier pilot --datasets fb15k237 wn18rr codex_m --data-dir ../data_cache \
       --seeds 1001 --alphas 0.1 --central --accept-draws 2000
```

- Report the acceptance rate per dataset and α. This resolves G15.
- If a partition cannot meet the minimum-size rule, the build stops with an error.
  - Report the dataset, α and acceptance rate, and propose a remedy to the owner.
  - Do not loosen the rule silently, and do not re-draw until a partition looks favourable.

**Step 5: Real smoke runs** (owner's execution steps 4–6)

```bash
python scripts/small_run.py --dataset fb15k237 --tier smoke --rounds 3 --profiles np_central np_fed      # non-private
python scripts/small_run.py --dataset fb15k237 --tier smoke --rounds 3 --profiles dp_q dp_a complete     # private
# repeat for wn18rr and codex_m (one small run per dataset)
```

**Step 6: Every block in smoke** (gate G-A: "every block completes in smoke")

```bash
python scripts/run_plan.py --plan tune --tier smoke --datasets fb15k237 wn18rr codex_m
python scripts/run_plan.py --plan confirm --tier smoke --profile reduced --datasets fb15k237 wn18rr codex_m
```

- If stage 6 stops on the τ rule, report it to the owner. Do not change the rule.
- For a software-only check on synthetic data, use `--tier smoke --tier-file smoke_synthetic --datasets synthetic`.

**Step 7: L0** (needs `complete/global_transe_final.pt` from the owner)

```bash
python scripts/legacy_l0_eval.py --checkpoint /path/to/complete/global_transe_final.pt --tier pilot
```

- This uses the full FB15k-237 artifact from Step 4.
- It evaluates under the corrected protocol, plus the legacy protocol over 5 random draws.

**Step 8: Measured pilot on the owner's GPU** (gate G-B)

```bash
python scripts/pilot.py --datasets fb15k237 wn18rr codex_m --rounds 2 --device cuda
```

- The pilot gives seconds per round, peak RAM and GPU memory, storage per run, and an upper-bound extrapolation for the tune and confirm plans.
- It **has never been run in full.** It was rewritten at the end of the session; test it on synthetic stand-ins first:

```bash
python scripts/build_artifacts.py --tier pilot --datasets synthetic_fb15k237_sized --data-dir /nonexistent --seeds 1001 --alphas 0.1 --central
python scripts/pilot.py --datasets synthetic_fb15k237_sized --rounds 1 --configs dp_fed_q0.10
```

- Also check the centralised non-private MRR sanity check required by G-B (see `audit/phaseB/05_privacy_utility_plan.md` §2).

**Step 9: Write the remaining Phase C deliverables** (none of the seven `audit/phaseC/*.md` files exists yet; create `audit/phaseC/`)

1. `implementation_traceability.md`
   - Use §5.2 of this brief as the base.
   - Add a "Specification" column with references to Phase B section numbers.
2. `code_changes.md`
   - Generate it from `git diff baseline-revision-P1-P4 --stat` and the patch.
   - Give one reason per file (§5.2).
3. `privacy_implementation_audit.md`
   - Cover all 11 points of Phase C instructions §5.1.
   - `13_documentation/DP_MECHANISM.md` already covers most of them.
   - Add §5.5 and §5.6 of this brief.
4. `test_report.md`
   - Passed, failed, skipped and not-run, each listed separately.
   - State which tests use synthetic data.
5. `environment_report.md`
   - §5.1 of this brief.
   - GPU requirements and exact setup instructions.
6. `pilot_plan.md`
   - Measured numbers only, plus the extrapolation method.
7. `remaining_blockers.md`
   - §6 of this brief, updated.

Also:

- Update `revision/README.md` with exact commands and result paths.
- Extend the schemas (§6, item 8).
- Write a statement of implemented / tested / smoke-tested / unverified for each component.

**Step 10: Stop and present the Phase C report to the owner.** The conditions are in Phase C instructions §16. Do **not** start Stage 3 (tuning) or Stage 4 (confirmatory) without her approval of:

- the pilot results;
- the compute budget;
- the open decisions in §6.

---

## 8. Phase C deliverables checklist (owner's list, instructions §15)

| # | Deliverable | Status |
|---|---|---|
| 1–7 | `audit/phaseC/*.md` (7 documents) | ❌ not written. This brief has most of the content |
| 8 | Corrected source code | ✅ mostly done. Schemas not extended |
| 9 | Dependency and environment files | ✅ `requirements-phaseC.txt`, `requirements-colab.txt` |
| 10 | Executable unit and integration tests | ✅ 6 new test files plus the legacy suite |
| 11 | Validated small-run script | 🟡 `small_run.py` validated on **synthetic data only** |
| 12 | README with exact commands and paths | ❌ |
| 13 | Record of all changes and tests | 🟡 git diff, manifests and this brief. `code_changes.md` missing |
| 14 | Implemented / tested / smoke-tested / unverified statement | 🟡 §5.2 of this brief |
| 15 | Concise completion summary | ❌ (after Steps 1–9) |

---

## 9. Glossary

**Defect IDs** (see `audit/phaseB/data/defect_register.csv`):

- CR = critical;
- MJ = major;
- MN = minor;
- OP = optional;
- G = gaps in the revision package.

**Decisions:** D1–D18 (`audit/phaseB/02_design_decisions.md`).

**Stage gates:** G-A…G-D (`audit/phaseB/07_compute_feasibility.md` §8).

**Blocks** (rows of the experiment matrix):

- N1–N3: non-private references.
- DP1–DP3: DP-FedAvg, the complete method, and the no-noise ablation.
- R1–R5: robust baselines, attacks, and trust without DP.
- I1–I2: integrity.
- M1: MIA.
- X1–X7: extended blocks.
- L0–L4: legacy.
- T1–T3, TAU: tuning.

**Sampling designs:**

- Design A: expected batch 512, per-client σ.
- Design Q: one sampling rate q, T = 1/q steps, one σ.

**Tiers:**

- smoke: tiny subsets, one seed per block;
- pilot: full data, a few rounds, for timing;
- tune: seed 1001, for selections;
- final: confirmatory runs; selections are frozen.
