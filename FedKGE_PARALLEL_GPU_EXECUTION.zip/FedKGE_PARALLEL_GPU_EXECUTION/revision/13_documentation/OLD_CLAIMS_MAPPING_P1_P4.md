# Old claims → replacement evidence (items within Phases 1–4)

| Old item | Problem found in audit | Replacement (file produced) |
|---|---|---|
| MRR 0.2858 (P3) | last round of a re-drawn random 300-triple test sample, tail-only, optimistic ties, test-set selection | P3 blocks, full filtered head+tail realistic MRR on the V_sel-selected checkpoint, 5 seeds → `reports/p3/p3_reference.csv`; the old number is reproduced in `R3_legacy` (`test_legacy_protocol.mrr`) |
| `CENTRALISED_MRR = 0.0940` → "3.04× / 304%" | hard-coded | measured `P3_central` + paired gap → `reports/p3/p3_fl_gap_paired.csv` |
| neg_samples = 64 in config, 1 used | config/code mismatch | 64 correct negatives; legacy replica uses 1 explicitly |
| ε = 15.53 "WITHIN BUDGET" (budget 15) | sum of per-round client means; contradiction | worst-client RDP ε in `accountant.json`; naive sum kept only as `legacy_naive_sum_of_round_means` in L1/L2/R4 |
| "Adaptive σ 2.0→0.5 IMPLEMENTED" | σ fixed at 1.0 | calibrated schedules at equal ε*, runtime assertion `schedule_verified` (4C) |
| `eps = sigma * 0.5` fallback | fabricated | removed; accountant errors raise |
| warm start from non-DP checkpoint | would void DP | `warm_start` rejected by config validation |
| P3 vs P4 confounded (150 vs 16 epochs, normalisation removed, degenerate negatives) | not comparable | DP ladder L1–L4 on the same partition, paired by seed → `reports/p4/p4_dp_ladder*.csv` |
| DP MRR 0.009–0.0122 | P6 values formula-generated; P4 real but confounded | measured privacy-utility curve (`p4_privacy_utility.csv`) |
| single seed | no uncertainty | 5 seeds, per-seed values + mean/SD/95% CI + paired tests |
| "5 relation-disjoint clients" | penalises robust aggregation, too few clients | 10 clients, Dirichlet α ∈ {1.0, 0.1}; legacy split kept for reproduction only |
| Client-0 74.26% | **manuscript-dependent** | new largest-client shares in `reports/p2/partition_stats.csv`; comparison after manuscript is supplied |
| round-count inconsistency | **manuscript-dependent** | `rounds_executed`, `selected_round`, `stop_reason` in every `final.json` |
