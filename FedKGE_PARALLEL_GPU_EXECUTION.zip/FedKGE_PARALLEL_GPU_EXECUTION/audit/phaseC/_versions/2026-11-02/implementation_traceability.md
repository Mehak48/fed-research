# Phase C — implementation traceability matrix

**Date:** 2026-11-02 · **Code:** `revision/` (branch `phaseC`, uncommitted changes on top of tag `baseline-revision-P1-P4`)
**Specification:** `audit/phaseB/03_methodology_specification.md` (§ numbers below), `03a_threat_model.md`, decisions D1–D18 (`02_design_decisions.md`), Phase B change list C1–C17 (`03` §15).

The execution path traced is the one a run actually takes:

```
config (YAML) → fedkge.config.validate → runner.expand / small_run.make_cfg → federated.run_experiment
  → data.load_artifact (P1) → partition.load_partition (P2)
  → per round: broadcast (integrity.send) → each client: integrity.receive → local training
    (train.py non-private | dp.dp_local_train private) → u = θ_local − θ_received → attacks.craft (malicious rows)
    → integrity.send/receive of every update → only verified tensors → trust.anomaly_scores (logged)
    → aggregators.aggregate / TrustState.aggregate → θ_global update → validation on V_es (server data)
  → after the last round: best-validated checkpoint (post-processing) → evaluate (V_sel, test)
  → accountant record, attack / integrity / MIA records, final.json
```

**Status vocabulary:**

| Status | Meaning |
|---|---|
| **Impl** | Implemented |
| **Unit** | Unit-tested |
| **Integ** | Integration-tested in complete federated rounds (synthetic KG) |
| **Smoke-real** | Ran on the real benchmark subsets in the smoke tier (3,000 training triples, at most 3 rounds). Covers the 33 small runs and the every-block check: tuning chain plus all 26 confirmatory blocks, 421 runs, 0 failures |
| **Pilot-CPU** | Ran on the full real datasets for the measured pilot (CPU) |
| **Unverified** | Not yet executed in any of the above ways |

**Smoke and pilot runs are software checks, not evidence.**

| # | Component | Specification | Existing implementation (baseline) | Defect | Repair made in Phase C | Test | Status |
|---|---|---|---|---|---|---|---|
| 1 | Configuration and run identity | `03` §6, D13, D18 | `config.py` validate, config hash, tiers smoke/dev/final | No tiers or options for design Q, noise modes, MIA, corruption, selection; final weights split identical runs | Tiers smoke/dev/pilot/tune/final; options and validations for every new setting; synthetic data refused in tune/final; warm start rejected; `keep_final_weights` output-only (outside the hash, OR-merged over shared runs) | `test_invalid_configs_fail_loudly` (8), `test_output_only_option_does_not_change_run_identity`, `test_data_partition_config.py` | Impl, Unit |
| 2 | Dataset acquisition and licence gate | `04`, D5, G12, MN-8 | PyKEEN automatic download, no gate | Download without licence confirmation | `scripts/prepare_data.py`: prints terms, needs `--i-confirm-licence` + operator note; pinned commits (ConvE `f3c0eb28…`, CoDEx `3132e426…`); safe extraction of the three split files only; SHA-256 of every file in `source_manifest.json` | Loader checksum test | **Executed 2026-11-02** after the owner's confirmation; split counts equal the official counts for all three datasets |
| 3 | Dataset loading, vocabularies, split validation | `03` §2, `04`, MN-20 | `data.py` PyKEEN source; `validate_splits` | No CoDEx-M; vocabulary could differ from official counts | Local-file loader with PyKEEN-identical ids (sorted training labels); evaluation triples with entities unseen in training are dropped and counted; checksums bound to the manifest; dataset card records licence, citation, rare relations | `test_pykeen_identical_mapping_and_unseen_drop`, `test_loader_binds_checksums_and_rejects_malformed` | Impl, Unit, Smoke-real, Pilot-CPU (full data; see `environment_report.md` §4 for measured statistics) |
| 4 | Smoke subset | tiers | `data._subset` | **PC-1 (new, found on the real data):** the subset capped the *training* split at `n_eval` (3,000 → 300 triples), so no partition could meet the size rule | Only validation and test are capped | `test_smoke_subset_keeps_n_train_and_caps_only_eval` | Impl, Unit, Smoke-real |
| 5 | Client partitioning (Dirichlet over relations, IID, centralised) | `03` §3, D4 | `partition.py` (`assign`, `build_partition`, hashes) | α = 0.5 missing (G4); feasibility unknown (G15); truncated Dirichlet (MN-9) | α grid via configs; `scripts/build_artifacts.py` audit (coverage, no empty client, size rule, determinism, hash binding) and acceptance rate on the real relation counts; first accepted draw of the seeded stream, never a re-draw for a better result | `test_dirichlet_partition_valid_deterministic[0.1, 0.5, 1.0]`, legacy partition tests | Impl, Unit, **measured on real data** (acceptance: FB 100 %; WN18RR 3.1 % at α = 0.1; CoDEx-M 67 % at α = 0.1) |
| 6 | KGE model and loss (TransE) | `03` §4–5 | `model.py`: −‖n(e_h)+w_r−n(e_t)‖₂, margin loss, entity normalisation | None found (legacy P4 dropped normalisation; the revision keeps it) | None | `test_evaluate_sampling.py`, `test_dp_clipping.py` | Unit, Integ, Smoke-real, Pilot-CPU |
| 7 | Negative sampling | `03` §5 | `sampling.py` (`correct` mode; legacy modes only for replicas) | Legacy P4: 25 % of negatives equal the positive (reproduced in tests) | None | `test_correct_negatives_never_copy_positive_and_corrupt_one_side`, `test_legacy_p4_bug_is_reproduced` | Unit |
| 8 | Local non-private training | `03` §6 | `train.py` | None | None (early stopping only for non-private runs, C3) | `test_pipeline_offline.py` | Integ, Smoke-real, Pilot-CPU |
| 9 | DP mechanism (sampling, clipping, noise, optimiser) | `03` §7.3, D11 | `dp.py` per-example clipping, dense noise, Adam | No non-finite guard (MN-22); attackers could skip noise (G7); no σ = 0 ablation | Non-finite per-example gradients zeroed before clipping; noise only if σ > 0 (DP3 ablation, no guarantee); pure-noise client (Sybil); design Q (common q, T = round(1/q)) next to design A | `test_phaseC_privacy.py` (15 cases), `test_dp_clipping.py` (Opacus, brute force) | Impl, Unit, Integ, Smoke-real, Pilot-CPU |
| 10 | Privacy accountant and calibration | `03` §7.2, §7.4, D2, D3, CR-2, CR-14 | `accountant.py` RDP, calibration, legacy replica | Add/remove adjacency inconsistent with public client sizes (CR-14); one-library check only | Zero-out adjacency (`REPLACE_SPECIAL`) with a run-time equality check against the public API; PLD and PRV cross-checks; composition over steps actually executed per client; `accountant.json` with the not-covered list | `test_phaseC_privacy.py`, `test_accountant.py`, `scripts/check_privacy_accounting.py` (96 points, 5 methods) | Impl, Unit, validated (0 failed checks, run twice), Smoke-real |
| 11 | Noise schedules ("adaptive DP") | `03` §7.4, D12 | Schedules fixed/linear/exponential/cosine; σ₀ calibrated so ε(R) ≤ ε* | None (CR-10 was the legacy claim) | Wording: "pre-declared scheduled noise decay"; executed σ trace verified per run (`schedule_verified`) | `test_schedules`, `test_calibration_monotone_and_meets_target_for_all_operating_points` | Unit, Smoke-real (T3 schedules in the real-data tuning chain) |
| 12 | Federated protocol and client participation | `03` §6, §14 (Algorithm 1) | `federated.py` | Integrity not in the data path (CR-13); early stopping in DP runs (G6) | All 10 clients every round; clients train from their verified copy of the broadcast; a client that rejects a broadcast skips the round (0 steps, accounted); DP runs execute all R rounds and select the best-validated checkpoint afterwards (post-processing); non-finite global model stops the run | `test_phaseC_pipeline.py` (21 cases) | Impl, Integ, Smoke-real, Pilot-CPU |
| 13 | Integrity verification | `03` §9, `03a` §4, D7, CR-9, CR-13 | `integrity.py` hashed, but an unchecked in-memory copy was aggregated | Wrong object aggregated; "IPFS" naming | Rewrite: canonical serialisation with header → SHA-256 id (not an IPFS CID) → store → optional in-transit corruption → fetch → verify hash + header (name, round, shape) → deserialise the verified bytes → aggregate only those; modes off / transport_only / hash_only / full_store_last_k; manifest hash chain; tamper test | `test_phaseC_integrity.py` (10, incl. the owner's 5 required tests), `test_schemas_reject_wrong_integrity_and_ipfs_claims` | Impl, Unit, Integ, Smoke-real (corruption 0.1: 4 corrupted, 4 rejected, 0 consumed on each dataset) |
| 14 | FedAvg weighting | `03` §8.1, MN-10 | `aggregators.py` weights by the public sizes N̂_k fixed before training (Sybil identities declare the median size) | Sizes are self-declared (MN-10; a disclosed assumption, `03a`) | Unchanged weighting. Phase C: the aggregator receives the identities of the verified updates (`idx`), so a rejected upload drops out of the weights; the same public N̂_k are used by the accountant | `test_history_only_updates_present_identities`, `test_5b_aggregator_receives_exactly_the_deserialised_verified_bytes` | Impl, Unit, Integ |
| 15 | Robust baselines (trimmed mean, median, Krum, FLTrust) | `03` §8.2, MN-18 | `aggregators.py` | Parameters depended on the true f | Parameterised at f_design = 0.2: Krum f = max(true f, 2); trim β = max(0.2, f/n); assumption flags recorded | `test_robust_parameters_at_design_value`, schema test (Krum + sign-flip) | Impl, Unit, Integ, Smoke-real (blocks R1, R4) |
| 16 | Proposed trust-weighted aggregation | `03` §8.3, D14, D15, CR-6 | `trust.py` anomaly score A = max(z_dir, z_mag), flag A > τ, history penalty λ | History updated for absent identities; V1 missing; scores not logged for FedAvg | History indexed by identity; variant V1 (size-third magnitude reference) behind a flag; anomaly scores (A, A_v1) logged in every run; benign FPR in `final.json` | `test_phaseC_trust_attacks.py` (9) | Impl, Unit, Integ, Smoke-real; **weakness found:** V1 unstable with 3–4 clients per third (`remaining_blockers.md` B5) |
| 17 | Attacks | `03` §10, `03a` §3, D16, G7, MN-19, MN-21 | `attacks.py` | Attackers skipped DP noise; targets from the test set | Noise modes inherit / matched / none (`auto` resolves by attack type); `match_norm`; Sybil with real DP noise from empty data; targeted attacker trains with DP, targets from its own triples; adaptive search includes its own noise and is allowed against FedAvg | `test_phaseC_trust_attacks.py`, `test_attacks_under_dp_complete[4]` | Impl, Unit, Integ, Smoke-real (all seven attacks: R2, R2a, R3a, R4, R5, X4, X4a, X5, including noise-free variants) |
| 18 | Link-prediction evaluation | `03` §11, CR-4 | `evaluate.py` full filtered head + tail, realistic ties, bootstrap CI | None (correct in the revision) | None. L0 shows what the legacy protocol inflated (row 25) | `test_filtered_head_tail_realistic_matches_bruteforce`, `test_ties_are_not_optimistic` | Unit, Smoke-real, Pilot-CPU, used by L0 |
| 19 | Checkpoint selection and early stopping | `03` §7.5, C3 | `federated.py` | Early stopping in DP runs | DP: all R rounds, best-validated checkpoint on V_es (server data) = post-processing; non-private: patience rule | `test_timing_pilot_is_flagged_partial`, offline tests | Impl, Integ, Smoke-real |
| 20 | Pre-registered selection (tuning chain, τ, V1 trigger) | `05` §6, D13–D15 | `selection.py` clip/schedule rules (legacy) | No rules for T1–T3, τ, V1 trigger | `select_rule` (T1, T2a–d, T3), `select_tau` (D14), `v1_trigger` (D15); final tier refuses to select; `scripts/run_plan.py` (stages in order), `scripts/freeze_selections.py` | `test_tuning_chain_reuses_previous_winner`, `test_selections_use_validation_only_and_full_grid` | Impl, regression-tested, **Smoke-real: the full chain ran on the real subsets**, with every rule applied (τ selected for all three datasets; the V1 trigger fired on CoDEx-M) |
| 21 | Membership-inference audit (H3) | `05` §5, D6, MJ-15 | `mia.py` compared training with official test triples | Invalid comparison | Randomised audit pool (10 % per client, inclusion ½; excluded = null records); A1, A2 (primary), A3; AUC, TPR at 1 % / 0.1 % FPR with resolvability flags; one-run ε lower bound with Bonferroni; red-line flag | `test_one_run_bound_behaviour`, `test_mia_audit_pool_and_one_run_bound` | Impl, Unit, Integ, Smoke-real |
| 22 | Statistics | `03` §12, `05`, D9, G14, CR-5 | `stats.py` | Pseudo-replication; exact p limits at n = 5 | One-sided t with 97.5 % bound; log-ratio test; H2 contrast with testability gate; Holm with fixed families | `test_one_sided_and_log_ratio`, `test_h2_contrast_gate_and_holm_family_fixed_membership` | Impl, Unit (no real results yet) |
| 23 | Experiment matrices and runner | `06`, D18 | `runner.py`, p3/p4 matrices | No Phase 5–8 matrices (G2) | `matrices/tune.yaml`, `matrices/confirm.yaml` (all core and extended blocks); profiles full/reduced; seed sets; `exclude`, `_cell`, `keep_weights_when`; `max_seeds_per_block` | `test_confirmatory_matrix_matches_phaseB_plan[full, reduced]` (run count of every block = Phase B CSV; weights 225/150) | Impl, regression-tested, Smoke-real (all 26 blocks of the reduced confirmatory matrix, 0 failures) |
| 24 | Outputs, manifests, schemas | C11, `11_experiment_schemas` | Schemas for Phases 1–4 outputs | New outputs had no schema | Schemas for integrity, attack, MIA, trust_rounds, tuning selection; `validate_run_dir`; `scripts/validate_outputs.py`; manifests for every script step; `weights_only=True` loading | `test_phaseC_schemas.py` (7), `test_all_outputs_match_schemas` | Impl, Unit; real smoke tier: 496 items, 0 failures (after fixing schema defect PC-5) |
| 25 | Legacy replicas and L0 | `06` L0–L4, OP-8 | Legacy replica settings in p3/p4 matrices | No re-evaluation of the saved model | `scripts/legacy_l0_eval.py` (evaluation only; historical file read-only, hash checked) | — | **Executed:** test MRR 0.197 (full filtered head + tail) vs 0.24–0.28 under the legacy protocol (`privacy_implementation_audit.md` §8) |
| 26 | Report tables and figures (Tables 1–14, 2D/3D) | C10 | `reports.py` / `plotting.py` for Phases 3–4 only | No builders for the new tables and 3D figures | Plot export PNG 300 dpi + PDF + SVG only | Legacy report test | **Not implemented** for the new matrices (`remaining_blockers.md` B9) |

**Phase B change list C1–C17** (`03` §15) — status:

| Change | Status |
|---|---|
| C1 | done (rows 9–10) |
| C2 | done (row 20) |
| C3 | done (row 19) |
| C4 | done (rows 16, 20) |
| C5 | done (row 17) |
| C6 | done (row 13) |
| C7 | done (row 21) |
| C8 | done (row 5). There is no separate "fallback flag": the pre-approved fallback is a per-dataset `partition.min_client_frac` override, and it is not needed (WN18RR α = 0.1 is feasible at 3.1 % acceptance) |
| C9 | done via the local-file loader plus the licence gate; PyKEEN `CoDExMedium` remains as an optional source |
| C10 | **partly done**: scripts, Colab kit and figure formats exist; the new table and figure builders do not (row 26) |
| C11 | done |
| C12 | done (`13_documentation/THREAT_MODEL.md`) |
| C13 | done (rows 20, 22) |
| C14 | done and executed (row 25) |
| C15 | done |
| C16 | done |
| C17 | done |
