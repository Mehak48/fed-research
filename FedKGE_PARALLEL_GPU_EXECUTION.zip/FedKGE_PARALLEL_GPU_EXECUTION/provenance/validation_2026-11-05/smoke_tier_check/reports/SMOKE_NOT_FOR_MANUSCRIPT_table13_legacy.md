# Table 13 — original versus revised on FB15k-237

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| source | item | value | validity (Phase A) | n | note | legacy-protocol MRR | eps RDP worst client | legacy naive eps sum |
|---|---|---|---|---|---|---|---|---|
| Reported (original manuscript) | Phase 3 MRR | 0.2858 | TRACED; protocol weaker than stated | 1 |  |  |  |  |
| Reported (original manuscript) | epsilon 15.53 (budget 15.0, delta 1e-5) | 15.53 | INVALID AS A GUARANTEE | 1 |  |  |  |  |
| Reported (original manuscript) | Phase 4 MRR 0.009 / Hits@10 0.020 | 0.009/0.02 | TRACED; confounded comparison | 1 |  |  |  |  |
| Reproduced (L0) | test MRR | PENDING |  |  | needs the owner's checkpoint complete/global_transe_final.pt |  |  |  |
| Reproduced (L1 exact old Phase 3) | test MRR (corrected protocol) | 0.005 (n=1) |  | 1 |  | 0.004 (n=1) | PENDING | PENDING |
| Reproduced (L2 old partition, corrected trainer) | test MRR (corrected protocol) | 0.005 (n=1) |  | 1 |  | 0.005 (n=1) | PENDING | PENDING |
| Reproduced (L3 exact old Phase 4) | test MRR (corrected protocol) | 0.009 (n=1) |  | 1 |  | 0.011 (n=1) | 4.24 (n=1) | 8.00 (n=1) |
| Reproduced (L4a legacy mechanism, main partition) | test MRR (corrected protocol) | 0.009 (n=1) |  | 1 |  | PENDING | 7.33 (n=1) | 11.19 (n=1) |
| Reproduced (L4b trainer fixed) | test MRR (corrected protocol) | 0.005 (n=1) |  | 1 |  | PENDING | 7.33 (n=1) | 11.19 (n=1) |
| Reproduced (L4c formal accounting) | test MRR (corrected protocol) | 0.005 (n=1) |  | 1 |  | PENDING | 7.33 (n=1) | PENDING |
| Newly measured: FedAvg non-private | test MRR | 0.005 (n=1) |  | 1 |  |  | PENDING |  |
| Newly measured: DP-FedAvg eps* = 4 (fixed) | test MRR | 0.005 (n=1) |  | 1 |  |  | 0.97 (n=1) |  |
| Newly measured: DP-FedAvg eps* = 4 (s*) | test MRR | 0.005 (n=1) |  | 1 |  |  | 0.97 (n=1) |  |
| Newly measured: complete method eps* = 4 | test MRR | 0.005 (n=1) |  | 1 |  |  | 0.97 (n=1) |  |
