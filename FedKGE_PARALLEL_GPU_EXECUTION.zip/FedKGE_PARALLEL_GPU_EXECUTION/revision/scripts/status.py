#!/usr/bin/env python3
"""Completion tracker: the status of every approved cell, derived from the run folders (never from a ledger).

  python scripts/status.py [--results R] [--show-failed] [--plan tune|main|legacy]

Writes <R>/PROGRESS.md, PROGRESS.json and PROGRESS_cells.csv and prints the summary. A cell is COMPLETE only if its run
folder says COMPLETE with the current code hash and final.json exists; an interrupted run is INCOMPLETE (it resumes
from its checkpoint on the next call of the same stage); a failed run is FAILED with its error (it is retried on the
next call, and the earlier traceback is kept as error_attempt<k>.txt).
"""
from __future__ import annotations

import argparse
import sys

from _common import CONFIG_DIR, results_root
from fedkge.manifest import load_frozen, progress, write_progress


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results"); ap.add_argument("--show-failed", action="store_true")
    ap.add_argument("--plan", choices=["tune", "main", "legacy"])
    a = ap.parse_args(argv)
    root = results_root(a.results)
    man = load_frozen(CONFIG_DIR)
    write_progress(root, man)
    print((root / "PROGRESS.md").read_text())
    df = progress(root, man, [a.plan] if a.plan else None)
    if a.show_failed:
        bad = df[df["status"].isin(["FAILED", "INCOMPLETE", "STALE_CODE"])]
        print(bad[["plan", "priority", "block", "dataset", "seed", "name", "run_id", "status", "detail"]]
              .to_string(index=False) if len(bad) else "no failed, incomplete or stale cells")
    return 0


if __name__ == "__main__":
    sys.exit(main())
