"""Micro-benchmark of one WN18RR-sized federated round through the integrity layer (hash_only): 1 broadcast + 10
uploads sent, 10 downloads + 10 uploads received and verified. Old = the previous serialise/parse (two payload
copies each), new = the current code. Same bytes and same identifiers in both. CPU of this machine, not a T4 host."""
import json, struct, sys, time
import numpy as np, torch
sys.path.insert(0, sys.argv[1])
import fedkge.integrity as I
new_ser, new_parse = I.serialize, I.parse
def old_ser(t, meta):
    arr = t.detach().to("cpu", torch.float32).contiguous().numpy().astype("<f4", copy=False)
    header = json.dumps({"dtype": "float32-le", "shape": list(arr.shape), **meta}, sort_keys=True).encode()
    return struct.pack("<I", len(header)) + header + arr.tobytes()
def old_parse(data):
    hl = struct.unpack("<I", data[:4])[0]; header = json.loads(data[4:4 + hl])
    shape = [int(x) for x in header["shape"]]; payload = data[4 + hl:]
    if len(payload) != 4 * int(np.prod(shape)): raise ValueError("size")
    return header, np.frombuffer(payload, dtype="<f4").reshape(shape)
def one_round(x, ups):
    L = I.IntegrityLayer("hash_only"); L.begin_round(1)
    env = L.send("global", 1, x); ids = [env.oid]
    for k in range(10): L.receive(env, f"client{k}")
    envs = [L.send(f"client{k}", 1, ups[k]) for k in range(10)]
    for e in envs: L.receive(e, "server"); ids.append(e.oid)
    r = L.end_round(); return r["hash_seconds"] + r["verify_seconds"], r["manifest_id"]
g = torch.Generator().manual_seed(0); x = torch.randn(40943, 100, generator=g); ups = [torch.randn(40943, 100, generator=g) for _ in range(10)]
res = {}
for label, (s, p) in {"old": (old_ser, old_parse), "new": (new_ser, new_parse)}.items():
    I.serialize, I.parse = s, p
    one_round(x, ups); ts = []; mids = set()
    for _ in range(7):
        t, mid = one_round(x, ups); ts.append(t); mids.add(mid)
    res[label] = {"median_s_per_round": float(np.median(ts)), "manifest_ids": sorted(mids)}
res["same_manifest_chain_id"] = res["old"]["manifest_ids"] == res["new"]["manifest_ids"]
res["saving_pct"] = 100 * (1 - res["new"]["median_s_per_round"] / res["old"]["median_s_per_round"])
print(json.dumps(res, indent=1))
