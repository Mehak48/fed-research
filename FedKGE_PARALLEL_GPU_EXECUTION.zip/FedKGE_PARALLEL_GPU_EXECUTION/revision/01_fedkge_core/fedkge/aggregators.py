"""Aggregation rules. Input U: (n, P) tensor of client updates; output an aggregated (P,) update + diagnostics.

fedavg        sum_i (n_i / sum n) U_i                                         (McMahan et al. 2017)
krum          the U_i minimising the sum of squared distances to its n-f-2 nearest neighbours; f = the design
              value round(f_design*K) (2 for K=10), or the true attacker count if larger, also in clean runs
              (Phase B MN-18; no degenerate 'no-defence' setting in clean runs)  (Blanchard et al. 2017)
trimmed_mean  coordinate-wise mean after removing the floor(beta*n) largest and smallest values, beta = max(0.2,
              true attacker fraction)                                         (Yin et al. 2018)
median        coordinate-wise median                                          (Yin et al. 2018)
fltrust       server computes U_0 on a clean root set (vroot sample); TS_i = relu(cos(U_i, U_0));
              U_i rescaled to ||U_0||; aggregate = sum TS_i U_i' / sum TS_i (zero update if all TS_i = 0)
                                                                              (Cao et al. 2021)
proposed      see trust.py
"""
from __future__ import annotations

from typing import Dict, Optional

import numpy as np
import torch

from .trust import TrustState, coordinate_median


def fedavg(U: torch.Tensor, sizes: np.ndarray) -> Dict:
    w = sizes / sizes.sum()
    return {"update": (torch.as_tensor(w, device=U.device, dtype=U.dtype)[:, None] * U).sum(0), "weights": w}


def krum(U: torch.Tensor, f: int) -> Dict:
    n = U.shape[0]
    m = n - f - 2
    if m < 1:
        raise ValueError(f"Krum undefined for n={n}, f={f} (needs n - f - 2 >= 1)")
    D = torch.cdist(U, U) ** 2
    D.fill_diagonal_(float("inf"))
    scores = torch.sort(D, dim=1)[0][:, :m].sum(1)
    sel = int(torch.argmin(scores))
    w = np.zeros(n); w[sel] = 1.0
    return {"update": U[sel].clone(), "weights": w, "selected": sel, "krum_scores": scores.cpu().numpy()}


def trimmed_mean(U: torch.Tensor, beta: float) -> Dict:
    n = U.shape[0]
    k = int(np.floor(beta * n))
    if n - 2 * k < 1:
        raise ValueError("trimmed mean removes all clients")
    s, _ = torch.sort(U, dim=0)
    return {"update": s[k:n - k].mean(0), "weights": np.full(n, np.nan), "trim_k": k}


def median(U: torch.Tensor) -> Dict:
    return {"update": coordinate_median(U), "weights": np.full(U.shape[0], np.nan)}


def fltrust(U: torch.Tensor, root_update: torch.Tensor) -> Dict:
    n0 = torch.linalg.vector_norm(root_update)
    norms = torch.linalg.vector_norm(U, dim=1)
    cos = (U @ root_update) / (norms * n0 + 1e-12)
    ts = torch.relu(cos)
    if float(ts.sum()) <= 0:
        return {"update": torch.zeros_like(root_update), "weights": np.zeros(U.shape[0]),
                "trust_scores": ts.cpu().numpy(), "all_rejected": True}
    Us = U * (n0 / (norms + 1e-12))[:, None]
    w = ts / ts.sum()
    return {"update": (w[:, None] * Us).sum(0), "weights": w.cpu().numpy(), "trust_scores": ts.cpu().numpy(),
            "all_rejected": False}


def robust_parameters(acfg: Dict, n_malicious: int, n_real: int, n_participants: int) -> Dict:
    """Robustness parameters of the baselines at the DESIGN attacker fraction f_design (Phase B, MN-18), also in
    clean runs, or at the true attacker count if that is larger:
      Krum f   = max(true f, round(f_design * K), krum_f_min)
      trim beta = max(beta, true f / n)
    Assumption flags are returned, never silently 'fixed'."""
    f_design = int(round(float(acfg.get("f_design", 0.2)) * n_real))
    krum_f = max(int(n_malicious), f_design, int(acfg.get("krum_f_min", 1)))
    beta = max(float(acfg.get("beta", 0.2)), (n_malicious / n_participants) if n_participants else 0.0)
    return {"krum_f": krum_f, "trim_beta": beta, "f_design_count": f_design,
            "krum_assumption_ok": bool(n_participants > 2 * krum_f + 2),
            "trimmed_assumption_ok": bool(int(np.floor(beta * n_participants)) >= n_malicious),
            "median_assumption_ok": bool(n_malicious < n_participants / 2)}


def aggregate(method: str, U: torch.Tensor, sizes: np.ndarray, acfg: Dict, n_malicious: int,
              trust_state: Optional[TrustState] = None, root_update: Optional[torch.Tensor] = None,
              idx: Optional[np.ndarray] = None, n_real: Optional[int] = None) -> Dict:
    """U: (n, P) updates that passed integrity verification; sizes: their public sizes; idx: their identities."""
    n = U.shape[0]
    rp = robust_parameters(acfg, n_malicious, n_real if n_real is not None else n, n)
    if method == "fedavg":
        out = fedavg(U, sizes)
    elif method == "krum":
        out = krum(U, rp["krum_f"])
    elif method == "trimmed_mean":
        out = trimmed_mean(U, rp["trim_beta"])
    elif method == "median":
        out = median(U)
    elif method == "fltrust":
        if root_update is None:
            raise ValueError("FLTrust needs a root update")
        out = fltrust(U, root_update)
    elif method == "proposed":
        if trust_state is None:
            raise ValueError("proposed aggregator needs a TrustState")
        out = trust_state.aggregate(U, sizes, idx)
    else:
        raise ValueError(f"unknown aggregator {method}")
    out["robust_params"] = rp
    return out


def rejected_mask(method: str, info: Dict, n: int) -> Optional[np.ndarray]:
    """Which clients the rule effectively excluded this round (for detection TPR/FPR). None = not applicable."""
    if method == "proposed":
        return np.asarray(info["flags"], bool) if not info.get("fallback") else np.ones(n, bool)
    if method == "krum":
        m = np.ones(n, bool); m[info["selected"]] = False; return m
    if method == "fltrust":
        return np.asarray(info["trust_scores"]) <= 0
    return None
