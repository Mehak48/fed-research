#!/usr/bin/env python3
"""End-to-end RUNTIME check of the parallel layer on the smoke tier (CPU, real data subsets; software check, never
evidence): the sequential entry points vs the parallel phases with several workers running CONCURRENTLY in separate
results roots that exchange nothing but bundles and packs.

  python parallel/tests/e2e_smoke_equivalence.py --work DIR --data-dir DATA [--tune-mode stage|chain] [--workers 3]

Passes when: (1) the parallel master store holds exactly the run ids of the sequential reference, (2) every run's
final.json is bit-identical in every non-timing field (single-threaded execution), (3) the selections are identical,
(4) the validation tool reports COMPLETE AND COMPATIBLE, (5) the hypothesis table of the analysis is identical.
Writes DIR/e2e_result_<mode>.json.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
PH = REPO / "parallel" / "phases"
ENV = {**os.environ, "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1", "PYTHONHASHSEED": "0"}
SKIP = ("time", "second", "wall", "utc", "duration", "elapsed", "speed", "throughput", "_s", "overhead", "hash_s",
        "verify_s", "store_s")


def sh(*args, check=True, log=None):
    t = time.time()
    p = subprocess.run([str(a) for a in args], cwd=REPO, env=ENV, capture_output=True, text=True)
    if log:
        with open(log, "a") as fh:
            fh.write(f"\n$ {' '.join(map(str, args))}\n{p.stdout}\n{p.stderr}\n")
    if check and p.returncode not in (0,):
        raise SystemExit(f"FAILED ({p.returncode}): {' '.join(map(str, args))}\n{p.stdout[-3000:]}\n{p.stderr[-3000:]}")
    return p.returncode, time.time() - t


def flat(d, pre=""):
    o = {}
    for k, v in d.items():
        if isinstance(v, dict):
            o.update(flat(v, pre + k + "."))
        elif isinstance(v, (int, float, str)) and not isinstance(v, bool):
            o[pre + k] = v
    return o


def compare_runs(a: Path, b: Path):
    ra = {p.name for p in a.iterdir() if (p / "final.json").exists()}
    rb = {p.name for p in b.iterdir() if (p / "final.json").exists()}
    diff = {}
    for r in sorted(ra & rb):
        fa, fb = flat(json.load(open(a / r / "final.json"))), flat(json.load(open(b / r / "final.json")))
        d = {k: (fa.get(k), fb.get(k)) for k in fa.keys() | fb.keys()
             if not any(s in k.lower() for s in SKIP) and fa.get(k) != fb.get(k)
             and not (fa.get(k) != fa.get(k) and fb.get(k) != fb.get(k))}
        if d:
            diff[r] = list(d.items())[:5]
    return {"reference_runs": len(ra), "parallel_runs": len(rb), "only_in_reference": sorted(ra - rb)[:10],
            "only_in_parallel": sorted(rb - ra)[:10], "common": len(ra & rb), "differing": diff}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--work", required=True); ap.add_argument("--data-dir", required=True)
    ap.add_argument("--tune-mode", default="stage", choices=["stage", "chain"])
    ap.add_argument("--workers", type=int, default=3)
    ap.add_argument("--reuse-reference", action="store_true")
    ap.add_argument("--reuse-parallel", action="store_true", help="only re-run the master cycle, analysis, comparison")
    a = ap.parse_args()
    W = Path(a.work).resolve(); W.mkdir(parents=True, exist_ok=True)
    log = W / f"e2e_{a.tune_mode}.log"
    ref = W / "reference"
    py = sys.executable
    t0 = time.time()
    if not (a.reuse_reference and (ref / "smoke" / "runs").exists()):
        shutil.rmtree(ref, ignore_errors=True)
        sh(py, "scripts/build_artifacts.py", "--results", ref, "--tier", "smoke", "--datasets", "fb15k237", "wn18rr",
           "codex_m", "--data-dir", a.data_dir, "--seeds", "42", "--alphas", "0.1", "--central", log=log)
        sh(py, "scripts/run_plan.py", "--results", ref, "--plan", "tune", "--tier", "smoke", "--datasets", "fb15k237",
           "wn18rr", "codex_m", "--device", "cpu", log=log)
        sh(py, "scripts/run_plan.py", "--results", ref, "--plan", "confirm", "--tier", "smoke", "--datasets", "fb15k237",
           "wn18rr", "codex_m", "--device", "cpu", log=log)
        sh(py, "scripts/run_legacy_blocks.py", "--results", ref, "--tier", "smoke", "--device", "cpu", log=log)
        sh(py, "scripts/analyze_results.py", "--results", ref, "--tier", "smoke", log=log)
    t_ref = time.time() - t0
    base = W / f"parallel_{a.tune_mode}"
    if not a.reuse_parallel:
        shutil.rmtree(base, ignore_errors=True)
    common = ["--base", base, "--mode", "smoke"]
    names = [f"w{i}" for i in range(1, a.workers + 1)]
    t1 = time.time()
    for n in ([] if a.reuse_parallel else names):
        sh(py, PH / "phase00_register_worker.py", *common, "--worker", n, "--device", "cpu", log=log)
        sh(py, PH / "phase02_build_artifacts.py", *common, "--worker", n, "--data-dir", a.data_dir, log=log)
    if not a.reuse_parallel:
        sh(py, PH / "phase02_build_artifacts.py", *common, "--master", "--data-dir", a.data_dir, log=log)
        sh(py, PH / "phase03_plan_jobs.py", *common, "--tune-mode", a.tune_mode, log=log)
    cycles = 0
    while True:
        cycles += 1
        procs = [subprocess.Popen([py, str(PH / "run_worker_queue.py"), *map(str, common), "--worker", n, "--device", "cpu"],
                                  cwd=REPO, env=ENV, stdout=open(W / f"{a.tune_mode}_{n}_c{cycles}.log", "w"),
                                  stderr=subprocess.STDOUT) for n in names]
        codes = [p.wait() for p in procs]
        rc, _ = sh(py, PH / "master_cycle.py", *common, check=False, log=log)
        if rc == 0:
            break
        if rc == 1 or any(c not in (0, 3) for c in codes) or cycles > 12:
            raise SystemExit(f"parallel execution did not converge: master exit {rc}, worker exits {codes}; see {log}")
    sh(py, PH / "phase10_analysis.py", *common, log=log)
    t_par = time.time() - t1
    res = {"tune_mode": a.tune_mode, "workers": a.workers, "master_cycles": cycles,
           "seconds_reference": round(t_ref, 1), "seconds_parallel_wall": round(t_par, 1),
           "runs": compare_runs(ref / "smoke" / "runs", base / "master" / "results" / "smoke" / "runs")}
    sr = json.load(open(ref / "smoke" / "selection" / "tuning.json"))
    sp = json.load(open(base / "master" / "results" / "smoke" / "selection" / "tuning.json"))
    res["selections_identical"] = all(sr.get(d) == sp.get(d) for d in ("fb15k237", "wn18rr", "codex_m"))
    rep = json.load(open(base / "master" / "results" / "parallel" / "VALIDATION_REPORT.json"))
    res["validation_verdict"] = rep["verdict"]
    ta = next((ref / "smoke" / "analysis").glob("*table12_hypotheses.csv"), None)
    tb = next((base / "master" / "results" / "smoke" / "analysis").glob("*table12_hypotheses.csv"), None)
    res["hypothesis_table_identical"] = bool(ta and tb and ta.read_text() == tb.read_text())
    bundles = sorted((base / "exchange" / "outbox").glob("*.zip"))
    res["bundles"] = len(bundles)
    res["packs"] = len(list((base / "exchange" / "packs").glob("*.zip")))
    res["PASSED"] = (not res["runs"]["differing"] and not res["runs"]["only_in_reference"]
                     and not res["runs"]["only_in_parallel"] and res["selections_identical"]
                     and res["validation_verdict"].startswith("COMPLETE") and res["hypothesis_table_identical"])
    (W / f"e2e_result_{a.tune_mode}.json").write_text(json.dumps(res, indent=1))
    print(json.dumps({k: v for k, v in res.items() if k != "runs"}, indent=1))
    print("runs:", {k: v for k, v in res["runs"].items() if k != "differing"}, "differing:", len(res["runs"]["differing"]))
    return 0 if res["PASSED"] else 1


if __name__ == "__main__":
    sys.exit(main())
