# Validation tests (Phases 1–4) — 53 tests
Run: `python -m pytest -q 12_validation_tests` (CPU, ~2–4 min). Requires `opacus` for the Opacus comparison.
| File | Catches |
|---|---|
| `test_accountant.py` | reproduces the old per-round ε log exactly; shows the old naive sum ≠ composition; monotonicity; calibration meets ε* and is tight; RDP vs PLD; cumulative trace; schedules; RDP orders cover the optimum; too-small clients fail |
| `test_dp_clipping.py` | per-example norms/clipped sums = Opacus and brute-force autograd (incl. repeated entities); per-example bound; dense noise with std σC; deterministic DP trainer |
| `test_evaluate_sampling.py` | filtered head+tail realistic MRR = brute force; ties not optimistic; filtering; legacy protocol labelled; correct negatives never copy the positive; the old P4 negative bug (~25 % identical) is reproduced only in legacy mode |
| `test_data_partition_config.py` | leakage/id errors detected; artifact hash reproducible + tamper detection; V_sel/V_root disjoint; partition determinism, seed dependence, relation-disjointness, upstream-hash binding, missing partition fails; config guards (warm start, DP epochs, schedule, legacy negatives, budget); hash semantics; missing selection fails |
| `test_pipeline_offline.py` | P1→P4 end-to-end: every output matches its schema; every ε recomputed independently; selections validation-only on full grids; reports watermarked; deterministic rerun; resume after simulated disconnect gives identical results; stale code detected and blocks reports; missing upstream ⇒ FAILED with no final.json; legacy naive stop rule vs RDP |
| `test_no_hardcoded_results.py` | old result literals (0.2858, 0.0940, 15.53, …), ε-from-σ formulas, fake `Qm` CIDs, metric-from-metric formulas, formula learning curves, hard-coded "IMPLEMENTED"/"WITHIN BUDGET", default values in except-blocks — in the core and in every notebook |
