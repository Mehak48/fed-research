#!/usr/bin/env python3
"""Run the validation suite and write a machine-readable report that separates passed / failed / skipped / errors.
  python scripts/run_tests.py [--results results/phaseC] [-- extra pytest args]"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import xml.etree.ElementTree as ET

from _common import REPO, Manifest, results_root


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results")
    ap.add_argument("--name", default="all")
    ap.add_argument("pytest_args", nargs="*")
    a = ap.parse_args(argv)
    root = results_root(a.results)
    man = Manifest(root, f"tests_{a.name}")
    xml = root / "test_reports" / f"junit_{a.name}.xml"
    cmd = [sys.executable, "-m", "pytest", "-q", "-rA", str(REPO / "12_validation_tests"), f"--junitxml={xml}",
           "-p", "no:cacheprovider", *a.pytest_args]
    log = root / "test_reports" / f"pytest_{a.name}.log"
    with open(log, "w") as f:
        rc = subprocess.run(cmd, cwd=REPO, stdout=f, stderr=subprocess.STDOUT).returncode
    rows = []
    for tc in ET.parse(xml).getroot().iter("testcase"):
        status = "passed"
        reason = ""
        for child in tc:
            if child.tag in ("failure", "error"):
                status, reason = ("failed" if child.tag == "failure" else "error"), (child.get("message") or "")[:300]
            elif child.tag == "skipped":
                status, reason = "skipped", (child.get("message") or "")[:300]
        rows.append({"test": f"{tc.get('classname')}::{tc.get('name')}", "status": status,
                     "seconds": float(tc.get("time", 0)), "reason": reason})
    summ = {s: sum(1 for r in rows if r["status"] == s) for s in ("passed", "failed", "error", "skipped")}
    out = root / "test_reports" / f"summary_{a.name}.json"
    out.write_text(json.dumps({"pytest_exit_code": rc, "counts": summ, "tests": rows}, indent=2))
    for p in (xml, log, out):
        man.output(p)
    man.close("COMPLETE" if rc == 0 else "TESTS_FAILED", counts=summ)
    print(json.dumps(summ))
    return rc


if __name__ == "__main__":
    sys.exit(main())
