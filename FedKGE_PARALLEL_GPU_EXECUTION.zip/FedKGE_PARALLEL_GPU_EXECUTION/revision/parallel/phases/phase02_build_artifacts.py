#!/usr/bin/env python3
"""PHASE 02 - deterministic Phase-1 artifacts and base partitions in ONE results root (a worker's or the master's).
CPU, minutes; reuses whatever verifies. Same commands as EXECUTION_GUIDE.md section 3 (scripts/build_artifacts.py).

  python parallel/phases/phase02_build_artifacts.py --base B --worker colab-t4-a --data-dir B/data_cache
  python parallel/phases/phase02_build_artifacts.py --base B --master --data-dir B/data_cache

Research mode builds the tune tier (seed 1001) and the final tier (seeds 42 123 256 512 1024), alpha 0.1 and the
centralised reference; other partitions are built on demand, deterministically, by the job that needs them.
Output: <root>/<tier>/artifacts/p1|p2/... and <root>/parallel/ARTIFACT_HASHES.json (P1 content hash per tier and
dataset). The master refuses any bundle whose data hash differs from its own. Next: the jobs of phase 03's plan.
"""
from __future__ import annotations

import subprocess
import sys

from _cli import finish, layout, parser

from fedkge_parallel.common import (DATASETS, EXIT_CONTRACT, EXIT_OK, REPO, atomic_write_json, read_json, tiers_for,
                                    utc_now)

SEEDS = {"tune": ["1001"], "final": ["42", "123", "256", "512", "1024"]}


def main(argv=None) -> int:
    ap = parser(__doc__)
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--worker"); g.add_argument("--master", action="store_true")
    ap.add_argument("--data-dir", required=True)
    ap.add_argument("--datasets", nargs="+", default=list(DATASETS), choices=list(DATASETS))
    a = ap.parse_args(argv)
    L = layout(a)
    root = L.master if a.master else L.worker(a.worker)
    root.mkdir(parents=True, exist_ok=True)
    tiers = sorted(set(tiers_for(a.mode).values()))
    from fedkge.data import load_artifact
    hashes = {}
    for tier in tiers:
        todo = []
        for ds in a.datasets:
            p1 = root / tier / "artifacts" / "p1" / ds
            try:
                load_artifact(p1)
                print(f"{tier}/{ds}: artifact present and verified (reused)")
            except Exception:
                todo.append(ds)
        if todo:
            seeds = SEEDS.get(tier) or [str(s) for s in __import__("fedkge.config", fromlist=["load_yaml"]).load_yaml(
                REPO / "10_configs" / "tiers" / f"{tier}.yaml")["seeds"]]
            cmd = [sys.executable, "scripts/build_artifacts.py", "--results", str(root), "--tier", tier, "--datasets",
                   *todo, "--data-dir", a.data_dir, "--seeds", *seeds, "--alphas", "0.1", "--central"]
            if subprocess.run(cmd, cwd=REPO).returncode != 0:
                print(f"STOP: artifact build failed for {tier} {todo}"); return finish(EXIT_CONTRACT)
        for ds in a.datasets:
            hashes[f"{tier}/{ds}"] = read_json(root / tier / "artifacts" / "p1" / ds / "manifest.json")["content_hash"]
    atomic_write_json(root / "parallel" / "ARTIFACT_HASHES.json", {"utc": utc_now(), "p1_content_hash": hashes})
    print("P1 content hashes:", hashes)
    return finish(EXIT_OK)


if __name__ == "__main__":
    sys.exit(main())
