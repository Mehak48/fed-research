# Table 9 — attack and defence evaluation

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| dataset | attack | metric | FedAvg clean | FedAvg attacked | method clean | method attacked | method TPR (mean) | method benign FPR (mean) | malicious weight share FedAvg | malicious weight share method | Delta FedAvg | Delta method | E_a (ratio of means) | H2 status | H2 decision | baseline | baseline attacked | descriptive_only |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| FB15k-237 | gaussian | test.mrr | 0.005 (n=1) | 0.005 (n=1) | 0.005 (n=1) | 0.005 (n=1) | 1 | 0 | 0.2193 | 0 |  |  |  | MISSING_RUNS | NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed |  |  |  |
| FB15k-237 | signflip | test.mrr | 0.005 (n=1) | 0.005 (n=1) | 0.005 (n=1) | 0.005 (n=1) | 1 | 0.04167 | 0.2193 | 0 |  |  |  | MISSING_RUNS | NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed |  |  |  |
| FB15k-237 | alie | test.mrr | 0.005 (n=1) | 0.005 (n=1) | 0.005 (n=1) | 0.005 (n=1) | 0 | 0 | 0.2193 | 0.2193 |  |  |  | MISSING_RUNS | NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed |  |  |  |
| FB15k-237 | ipm | test.mrr | 0.005 (n=1) | 0.005 (n=1) | 0.005 (n=1) | 0.005 (n=1) | 1 | 0.04167 | 0.2193 | 0 |  |  |  | MISSING_RUNS | NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed |  |  |  |
| FB15k-237 | targeted | targeted.target_hits@10 | 0.000 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 1 | 0 | 0.2193 | 0 |  |  |  | MISSING_RUNS | NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed |  |  |  |
| FB15k-237 | sybil | test.mrr | 0.005 (n=1) | 0.005 (n=1) | 0.005 (n=1) | 0.005 (n=1) | 0.6667 | 0.03333 | 0.1653 | 0.05995 |  |  |  | MISSING_RUNS | NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed |  |  |  |
| FB15k-237 | adaptive | test.mrr | 0.005 (n=1) | 0.005 (n=1) | 0.005 (n=1) | 0.005 (n=1) | 1 | 0 | 0.2193 | 0 |  |  |  | MISSING_RUNS | NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed |  |  |  |
| FB15k-237 | signflip | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | trimmed_mean | 0.005 (n=1) | True |
| FB15k-237 | signflip | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | median | 0.005 (n=1) | True |
| FB15k-237 | signflip | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | krum | 0.005 (n=1) | True |
| FB15k-237 | signflip | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | fltrust | 0.005 (n=1) | True |
| FB15k-237 | alie | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | trimmed_mean | 0.005 (n=1) | True |
| FB15k-237 | alie | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | median | 0.005 (n=1) | True |
| FB15k-237 | alie | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | krum | 0.005 (n=1) | True |
| FB15k-237 | alie | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | fltrust | 0.005 (n=1) | True |
| FB15k-237 | ipm | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | trimmed_mean | 0.005 (n=1) | True |
| FB15k-237 | ipm | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | median | 0.005 (n=1) | True |
| FB15k-237 | ipm | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | krum | 0.005 (n=1) | True |
| FB15k-237 | ipm | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | fltrust | 0.005 (n=1) | True |
| FB15k-237 | targeted | targeted.target_hits@10 |  |  |  |  |  |  |  |  |  |  |  |  |  | trimmed_mean | 0.000 (n=1) | True |
| FB15k-237 | targeted | targeted.target_hits@10 |  |  |  |  |  |  |  |  |  |  |  |  |  | median | 0.000 (n=1) | True |
| FB15k-237 | targeted | targeted.target_hits@10 |  |  |  |  |  |  |  |  |  |  |  |  |  | krum | 0.000 (n=1) | True |
| FB15k-237 | targeted | targeted.target_hits@10 |  |  |  |  |  |  |  |  |  |  |  |  |  | fltrust | 0.000 (n=1) | True |
| WN18RR | gaussian | test.mrr | 0.001 (n=1) | 0.001 (n=1) | 0.001 (n=1) | 0.001 (n=1) | 1 | 0 | 0.1913 | 0 |  |  |  | MISSING_RUNS | NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed |  |  |  |
| WN18RR | signflip | test.mrr | 0.001 (n=1) | 0.001 (n=1) | 0.001 (n=1) | 0.001 (n=1) | 1 | 0 | 0.1913 | 0 |  |  |  | MISSING_RUNS | NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed |  |  |  |
| WN18RR | alie | test.mrr | 0.001 (n=1) | 0.001 (n=1) | 0.001 (n=1) | 0.001 (n=1) | 0.1667 | 0 | 0.1913 | 0.1412 |  |  |  | MISSING_RUNS | NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed |  |  |  |
| WN18RR | ipm | test.mrr | 0.001 (n=1) | 0.001 (n=1) | 0.001 (n=1) | 0.001 (n=1) | 1 | 0 | 0.1913 | 0 |  |  |  | MISSING_RUNS | NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed |  |  |  |
| WN18RR | targeted | targeted.target_hits@10 | 0.000 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 1 | 0 | 0.1913 | 0 |  |  |  | MISSING_RUNS | NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed |  |  |  |
| WN18RR | sybil | test.mrr | 0.001 (n=1) | 0.001 (n=1) | 0.001 (n=1) | 0.001 (n=1) | 0.6667 | 0.03333 | 0.1362 | 0.04953 |  |  |  | MISSING_RUNS | NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed |  |  |  |
| WN18RR | adaptive | test.mrr | 0.001 (n=1) | 0.002 (n=1) | 0.001 (n=1) | 0.001 (n=1) | 1 | 0 | 0.1913 | 0 |  |  |  | MISSING_RUNS | NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed |  |  |  |
| WN18RR | signflip | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | trimmed_mean | 0.001 (n=1) | True |
| WN18RR | signflip | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | median | 0.001 (n=1) | True |
| WN18RR | signflip | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | krum | 0.001 (n=1) | True |
| WN18RR | signflip | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | fltrust | 0.001 (n=1) | True |
| WN18RR | alie | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | trimmed_mean | 0.001 (n=1) | True |
| WN18RR | alie | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | median | 0.001 (n=1) | True |
| WN18RR | alie | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | krum | 0.001 (n=1) | True |
| WN18RR | alie | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | fltrust | 0.001 (n=1) | True |
| WN18RR | ipm | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | trimmed_mean | 0.001 (n=1) | True |
| WN18RR | ipm | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | median | 0.001 (n=1) | True |
| WN18RR | ipm | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | krum | 0.001 (n=1) | True |
| WN18RR | ipm | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | fltrust | 0.001 (n=1) | True |
| WN18RR | targeted | targeted.target_hits@10 |  |  |  |  |  |  |  |  |  |  |  |  |  | trimmed_mean | 0.000 (n=1) | True |
| WN18RR | targeted | targeted.target_hits@10 |  |  |  |  |  |  |  |  |  |  |  |  |  | median | 0.000 (n=1) | True |
| WN18RR | targeted | targeted.target_hits@10 |  |  |  |  |  |  |  |  |  |  |  |  |  | krum | 0.000 (n=1) | True |
| WN18RR | targeted | targeted.target_hits@10 |  |  |  |  |  |  |  |  |  |  |  |  |  | fltrust | 0.000 (n=1) | True |
| CoDEx-M | gaussian | test.mrr | 0.002 (n=1) | 0.002 (n=1) | 0.002 (n=1) | 0.002 (n=1) | 1 | 0.04167 | 0.19 | 0 |  |  |  | MISSING_RUNS | NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed |  |  |  |
| CoDEx-M | signflip | test.mrr | 0.002 (n=1) | 0.002 (n=1) | 0.002 (n=1) | 0.002 (n=1) | 1 | 0.04167 | 0.19 | 0 |  |  |  | MISSING_RUNS | NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed |  |  |  |
| CoDEx-M | alie | test.mrr | 0.002 (n=1) | 0.002 (n=1) | 0.002 (n=1) | 0.002 (n=1) | 0 | 0 | 0.19 | 0.19 |  |  |  | MISSING_RUNS | NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed |  |  |  |
| CoDEx-M | ipm | test.mrr | 0.002 (n=1) | 0.002 (n=1) | 0.002 (n=1) | 0.002 (n=1) | 1 | 0.04167 | 0.19 | 0 |  |  |  | MISSING_RUNS | NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed |  |  |  |
| CoDEx-M | targeted | targeted.target_hits@10 | 0.000 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 1 | 0.04167 | 0.19 | 0 |  |  |  | MISSING_RUNS | NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed |  |  |  |
| CoDEx-M | sybil | test.mrr | 0.002 (n=1) | 0.002 (n=1) | 0.002 (n=1) | 0.002 (n=1) | 0.6667 | 0.03333 | 0.1271 | 0.04238 |  |  |  | MISSING_RUNS | NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed |  |  |  |
| CoDEx-M | adaptive | test.mrr | 0.002 (n=1) | 0.002 (n=1) | 0.002 (n=1) | 0.002 (n=1) | 1 | 0.04167 | 0.19 | 0 |  |  |  | MISSING_RUNS | NOT EVIDENCE (smoke tier): PENDING (runs missing); enters Holm with p = 1 until computed |  |  |  |
| CoDEx-M | signflip | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | trimmed_mean | 0.002 (n=1) | True |
| CoDEx-M | signflip | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | median | 0.002 (n=1) | True |
| CoDEx-M | signflip | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | krum | 0.002 (n=1) | True |
| CoDEx-M | signflip | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | fltrust | 0.002 (n=1) | True |
| CoDEx-M | alie | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | trimmed_mean | 0.002 (n=1) | True |
| CoDEx-M | alie | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | median | 0.002 (n=1) | True |
| CoDEx-M | alie | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | krum | 0.002 (n=1) | True |
| CoDEx-M | alie | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | fltrust | 0.002 (n=1) | True |
| CoDEx-M | ipm | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | trimmed_mean | 0.002 (n=1) | True |
| CoDEx-M | ipm | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | median | 0.002 (n=1) | True |
| CoDEx-M | ipm | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | krum | 0.002 (n=1) | True |
| CoDEx-M | ipm | test.mrr |  |  |  |  |  |  |  |  |  |  |  |  |  | fltrust | 0.002 (n=1) | True |
| CoDEx-M | targeted | targeted.target_hits@10 |  |  |  |  |  |  |  |  |  |  |  |  |  | trimmed_mean | 0.000 (n=1) | True |
| CoDEx-M | targeted | targeted.target_hits@10 |  |  |  |  |  |  |  |  |  |  |  |  |  | median | 0.000 (n=1) | True |
| CoDEx-M | targeted | targeted.target_hits@10 |  |  |  |  |  |  |  |  |  |  |  |  |  | krum | 0.000 (n=1) | True |
| CoDEx-M | targeted | targeted.target_hits@10 |  |  |  |  |  |  |  |  |  |  |  |  |  | fltrust | 0.000 (n=1) | True |
