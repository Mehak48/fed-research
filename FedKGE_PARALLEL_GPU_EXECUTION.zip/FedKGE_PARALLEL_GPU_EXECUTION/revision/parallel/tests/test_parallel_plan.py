"""Static checks of the job graph and the scheduler on the REAL frozen manifest (no training, CPU, seconds).

What is checked (methodology preservation of the execution layer):
  * every approved cell is executed by exactly one GPU job (tuning re-statement cells by their stage's selection);
  * no job mixes environment groups (tier, dataset), so the environment lock can hold;
  * the scientific dependencies are present and no artificial ones exist (datasets never wait for each other);
  * the gate G-B is a barrier before any further tuning; Stage 4 waits for the freeze of ITS dataset only;
  * the schedule never places a job of a group on a worker of another environment class;
  * run-id materialisation executes a run shared by several cells exactly once.
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fedkge_parallel.cells import REUSE_BLOCKS, approved_cells, cell_hours, load_cost_table  # noqa: E402
from fedkge_parallel.jobs import (Job, build_jobs, check_graph, default_shard_policy, materialize,  # noqa: E402
                                  shard_cells, topo_order, waves)
from fedkge_parallel.schedule import best_assignment, critical_path, plan_summary, simulate  # noqa: E402


@pytest.fixture(scope="module")
def cells():
    return approved_cells("research")


def test_cells_are_the_frozen_manifest(cells):
    by = {}
    for c in cells:
        by[c.plan] = by.get(c.plan, 0) + 1
    assert by == {"tune": 114, "main": 756, "legacy": 30}
    assert len({c.cell_key for c in cells}) == 900
    assert all(c.reuse == (c.block in REUSE_BLOCKS) for c in cells if c.plan == "tune")
    t = load_cost_table()
    total = sum(cell_hours(c, t) for c in cells)
    assert 115 < total < 122          # DEADLINE_PLAN.md: 118.3 GPU-h (stage maxima here: slightly higher)


@pytest.mark.parametrize("tune_mode", ["chain", "stage"])
@pytest.mark.parametrize("nw", [1, 2, 4])
def test_every_cell_exactly_once(cells, tune_mode, nw):
    groups = {f"{t}/{d}": nw for t in ("tune", "final") for d in ("fb15k237", "wn18rr", "codex_m")}
    jobs = build_jobs(cells, "research", tune_mode, default_shard_policy(groups))
    check_graph(jobs, cells)
    owner = {}
    for j in jobs:
        if j.is_worker:
            for k in j.cells:
                assert k not in owner
                owner[k] = j.job_id
    for c in cells:
        if c.plan == "tune" and c.reuse and tune_mode == "stage":
            assert c.cell_key not in owner
        else:
            assert c.cell_key in owner, c.cell_key
    assert abs(sum(j.est_hours for j in jobs if j.is_worker) -
               sum(cell_hours(c) for c in cells)) < 1e-6


def test_dependencies_are_scientific_only(cells):
    jobs = build_jobs(cells, "research", "stage", default_shard_policy({}))
    by = {j.job_id: j for j in jobs}
    for j in jobs:
        if j.kind == "MAIN":
            assert j.deps == [f"SEL-{j.dataset}-s5"] and j.requires_release
        if j.kind == "LEGACY":
            assert j.deps == [] and not j.requires_release
        if j.kind == "TUNESTAGE":
            if j.stage == 0:
                assert j.deps == []
            else:
                assert j.deps == [f"SEL-{j.dataset}-s{j.stage - 1}"]        # stage 1 waits for the gate (SEL-s0)
        for d in j.deps:
            if j.kind != "ANALYSE":
                assert by[d].dataset == j.dataset, (j.job_id, d)            # datasets never wait for each other
    sel0 = by["SEL-fb15k237-s0"]
    assert set(sel0.deps) == {j.job_id for j in jobs if j.kind == "TUNESTAGE" and j.dataset == "fb15k237" and j.stage == 0}
    topo_order(jobs)
    w = waves(jobs)
    assert all(k.startswith(("T-", "L-")) for k in w[0])


def test_chain_mode_graph(cells):
    jobs = build_jobs(cells, "research", "chain", default_shard_policy({}))
    by = {j.job_id: j for j in jobs}
    for ds in ("fb15k237", "wn18rr", "codex_m"):
        assert by[f"T-{ds}-chain"].kind == "TUNECHAIN"
        assert by[f"SEL-{ds}-chain"].deps == [f"T-{ds}-chain"]
        assert len(by[f"T-{ds}-chain"].cells) == 38             # 114 tuning cells / 3
    assert by["ANALYSE"].deps and all(by[d].kind in ("MAIN", "LEGACY") for d in by["ANALYSE"].deps)


def _workers(spec):
    out = []
    for i, (cls, speed) in enumerate(spec):
        out.append({"name": f"w{i}", "env_class": cls, "speed": speed})
    return out


def test_schedule_respects_environment_classes(cells):
    workers = _workers([("T4|torchA", 1.0), ("T4|torchA", 1.0), ("L4|torchA", 2.0)])
    jobs = build_jobs(cells, "research", "chain", default_shard_policy({"final/fb15k237": 2, "final/wn18rr": 2,
                                                                         "final/codex_m": 2}))
    assign, sim = best_assignment(jobs, workers)
    cls = {w["name"]: w["env_class"] for w in workers}
    for j in jobs:
        if j.is_worker:
            assert cls[sim["where"][j.job_id]] == assign[j.env_group]
    for k in topo_order(jobs):
        j = next(x for x in jobs if x.job_id == k)
        for d in j.deps:
            assert sim["finish"][d] <= sim["start"][k] + 1e-9


def test_more_workers_never_slower_and_bounds(cells):
    prev = None
    for n in (1, 2, 3, 4):
        workers = _workers([("T4", 1.0)] * n)
        groups = {f"{t}/{d}": n for t in ("tune", "final") for d in ("fb15k237", "wn18rr", "codex_m")}
        jobs = build_jobs(cells, "research", "chain", default_shard_policy(groups))
        s = plan_summary(jobs, workers)
        assert s["makespan_hours"] >= s["lower_bound_hours"] - 1e-6
        if n == 1:
            # one worker: all GPU work in sequence; master hand-overs overlap with other datasets' work
            assert s["total_gpu_hours_T4"] <= s["makespan_hours"] <= s["total_gpu_hours_T4"] + 4 * 0.25 + 1e-6
        if prev is not None:
            assert s["makespan_hours"] <= prev + 1e-6
        prev = s["makespan_hours"]


def test_materialize_executes_shared_runs_once():
    a = Job("M-x-p1-1of2", "MAIN", "main", "final", "x", priority=1, cells=["c1", "c2"])
    b = Job("M-x-p1-2of2", "MAIN", "main", "final", "x", priority=1, cells=["c3", "c4"])
    c = Job("M-x-p5-1of1", "MAIN", "main", "final", "x", priority=5, cells=["c5"])
    ents = {"c1": {"run_id": "r1"}, "c2": {"run_id": "r2"}, "c3": {"run_id": "r1"}, "c4": {"run_id": "r4"},
            "c5": {"run_id": "r2"}}
    specs = materialize([a, b, c], ents, complete_run_ids={"r4"})
    assert [r["run_id"] for r in specs[0]["runs"]] == ["r1", "r2"]
    assert specs[1]["runs"] == [] and specs[1]["reused_cells"]["c3"]["executed_by"] == "M-x-p1-1of2"
    assert specs[1]["already_complete_cells"] == {"c4": "r4"}
    assert specs[2]["runs"] == [] and specs[2]["reused_cells"]["c5"]["run_id"] == "r2"
    with pytest.raises(KeyError):
        materialize([Job("M", "MAIN", "main", "final", "x", cells=["zz"])], ents, set())


def test_shards_are_balanced_and_deterministic(cells):
    main = [c for c in cells if c.plan == "main" and c.dataset == "wn18rr" and c.priority == 2]
    h = {c.cell_key: cell_hours(c) for c in main}
    s1 = shard_cells(main, 4, h)
    s2 = shard_cells(main, 4, h)
    assert [[c.cell_key for c in s] for s in s1] == [[c.cell_key for c in s] for s in s2]
    loads = [sum(h[c.cell_key] for c in s) for s in s1]
    assert max(loads) - min(loads) <= max(h.values()) + 1e-9
    assert sum(len(s) for s in s1) == len(main)


def test_critical_path_runs_through_tuning(cells):
    workers = _workers([("T4", 1.0)] * 4)
    jobs = build_jobs(cells, "research", "stage", default_shard_policy({}))
    assign, _ = best_assignment(jobs, workers)
    cp = critical_path(jobs, workers, assign)
    assert cp["path"][0].startswith("T-") and "-s0-" in cp["path"][0]
    assert any(p.startswith("SEL-") and p.endswith("-s5") for p in cp["path"])
    assert cp["path"][-1] == "ANALYSE"
