#!/usr/bin/env python3
"""PHASE A ACCOUNTING CHECK -- recompute the privacy loss of the LEGACY Phase 4 run.

Status of every number this script writes: "Calculated from the legacy implementation's parameters".
It is an audit check of the OLD run, NOT a privacy claim for any method, and NOT a Phase C result.

What is being checked
---------------------
Legacy notebook  : files/phase4_ready (1).ipynb  (cells 2, 4, 6), outputs in complete/phase4_results.json
Mechanism        : Opacus 1.6.0 PrivacyEngine.make_private(...), Poisson sampling (DPDataLoader),
                   per-example clipping C = 1.0, noise multiplier sigma = 1.0, accountant = "rdp".
Data loader      : DataLoader(batch_size=256, drop_last=True)  ->  Opacus sets
                   sample_rate q = 1 / len(loader) = 1 / floor(N_k / 256), steps per epoch = int(1 / q).
Per round        : a NEW PrivacyEngine per client per round, ONE local epoch, then
                   eps_round = privacy_engine.get_epsilon(delta = 1e-5)   (a fresh accountant every round).
Reported number  : cumulative_epsilon += mean_k(eps_round_k)  every round  ->  15.5304 after 16 rounds.

What this script computes (all at the legacy parameters, nothing is assumed beyond them)
  A. per-round, per-client epsilon with Opacus' OWN analysis code (loaded from the opacus-1.6.0 wheel)
     and with Google's dp_accounting RDP accountant -> must reproduce the logged values;
  B. the notebook's naive number and a per-client basic-composition bound (with the composed delta);
  C. per-client RDP composition over all executed privacy steps (16 rounds) and the planned 20 rounds,
     at delta = 1e-5 and 1e-6, with Opacus orders, extended orders, and a PLD cross-check;
  D. candidate interpretations of the two audit leads (1.98 and 6.43), each with explicit assumptions.

Usage
  python3 -I phaseA_epsilon_check.py --opacus-rdp <path to opacus/accountants/analysis/rdp.py> --out <json>
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import math
import platform
import sys
from datetime import datetime, timezone

import numpy as np
import scipy
import dp_accounting
from dp_accounting.rdp import rdp_privacy_accountant as g_rdp

# ----------------------------------------------------------------------------------- legacy parameters
# Client sizes: printed by phase4_ready cell 4 and stored in complete/phase3_results.json -> client_summary.
CLIENT_SIZES = [83830, 56322, 41261, 50033, 40669]
BATCH = 256              # ADP_CFG["virtual_batch_size"]
SIGMA = 1.0              # ADP_CFG["sigma_initial"] == ["sigma_final"], schedule "fixed"
CLIP = 1.0               # ADP_CFG["max_grad_norm"]
DELTA = 1e-5             # ADP_CFG["target_delta"]
ROUNDS_EXECUTED = 16     # len(training_history["round"]) in complete/phase4_results.json
ROUNDS_PLANNED = 20      # ADP_CFG["fl_rounds"]
# per-round client epsilons as stored in complete/phase4_results.json (identical every round)
LOGGED_ROUND_EPS = [0.8608765949826953, 0.9421891110082846, 1.0339167150261388,
                    0.9756821280592524, 1.0405739403109002]
LOGGED_FINAL = 15.530363166039272   # complete/phase4_results.json -> final_epsilon

OPACUS_ORDERS = [1 + x / 10.0 for x in range(1, 100)] + list(range(12, 64))   # Opacus 1.x DEFAULT_ALPHAS
EXTENDED_ORDERS = sorted(set(OPACUS_ORDERS + [64, 72, 80, 96, 112, 128, 160, 192, 256, 384, 512, 768, 1024]))


def load_opacus_rdp(path: str):
    spec = importlib.util.spec_from_file_location("opacus_rdp_analysis", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)          # module imports only math, warnings, numpy, scipy.special
    return mod


def opacus_eps(op, q: float, steps: int, sigma: float, delta: float, orders) -> tuple:
    rdp = op.compute_rdp(q=q, noise_multiplier=sigma, steps=steps, orders=orders)
    eps, alpha = op.get_privacy_spent(orders=orders, rdp=rdp, delta=delta)
    return float(eps), float(alpha)


def google_rdp_eps(q: float, steps: int, sigma: float, delta: float, orders) -> tuple:
    acc = g_rdp.RdpAccountant(orders=list(orders))
    acc.compose(dp_accounting.PoissonSampledDpEvent(q, dp_accounting.GaussianDpEvent(sigma)), int(steps))
    eps, alpha = acc.get_epsilon_and_optimal_order(delta)
    return float(eps), float(alpha)


def pld_eps(q: float, steps: int, sigma: float, delta: float, vdi: float = 1e-4) -> float:
    acc = dp_accounting.pld.PLDAccountant(value_discretization_interval=vdi)
    acc.compose(dp_accounting.PoissonSampledDpEvent(q, dp_accounting.GaussianDpEvent(sigma)), int(steps))
    return float(acc.get_epsilon(delta))


def legacy_sampling(n: int, batch: int) -> dict:
    loader_len = n // batch                      # DataLoader(drop_last=True)
    q = 1.0 / loader_len                         # DPDataLoader.from_data_loader: sample_rate = 1/len(loader)
    steps = int(1.0 / q)                         # UniformWithReplacementSampler: steps = int(1/sample_rate)
    return {"n": n, "loader_len": loader_len, "q": q, "steps_per_epoch": steps,
            "expected_batch": n * q}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--opacus-rdp", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    op = load_opacus_rdp(a.opacus_rdp)

    out: dict = {
        "label": "PHASE A ACCOUNTING CHECK of the LEGACY Phase 4 run -- not a final privacy claim",
        "status_of_numbers": "Calculated from the legacy implementation's parameters (audit check only)",
        "created_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "environment": {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__,
                        "dp_accounting": getattr(dp_accounting, "__version__", "unknown"),
                        "opacus_rdp_source": a.opacus_rdp},
        "legacy_parameters": {"client_sizes": CLIENT_SIZES, "batch_size": BATCH, "drop_last": True,
                              "sigma": SIGMA, "clip": CLIP, "delta": DELTA, "local_epochs_per_round": 1,
                              "rounds_executed": ROUNDS_EXECUTED, "rounds_planned": ROUNDS_PLANNED,
                              "privacy_unit": "one training triple (with its data-independent negative) of one client",
                              "adjacency": "add/remove one example (Opacus / dp_accounting default)",
                              "accountant_in_notebook": "Opacus RDP, fresh PrivacyEngine per client per round"},
    }

    # ---------------------------------------------------------------- A. per-round reproduction
    clients = []
    for k, n in enumerate(CLIENT_SIZES):
        s = legacy_sampling(n, BATCH)
        e_op, a_op = opacus_eps(op, s["q"], s["steps_per_epoch"], SIGMA, DELTA, OPACUS_ORDERS)
        e_g, a_g = google_rdp_eps(s["q"], s["steps_per_epoch"], SIGMA, DELTA, OPACUS_ORDERS)
        clients.append({**s, "client": k, "logged_round_eps": LOGGED_ROUND_EPS[k],
                        "recomputed_round_eps_opacus": e_op, "opt_order_opacus": a_op,
                        "abs_diff_vs_log_opacus": abs(e_op - LOGGED_ROUND_EPS[k]),
                        "recomputed_round_eps_dp_accounting_rdp": e_g, "opt_order_dp_accounting": a_g,
                        "abs_diff_vs_log_dp_accounting": abs(e_g - LOGGED_ROUND_EPS[k])})
    out["A_per_round_reproduction"] = clients
    out["A_reproduced_within_1e-6"] = bool(all(c["abs_diff_vs_log_opacus"] < 1e-6 for c in clients))

    # ---------------------------------------------------------------- B. what the notebook reported
    naive = ROUNDS_EXECUTED * float(np.mean(LOGGED_ROUND_EPS))
    basic = {k: ROUNDS_EXECUTED * LOGGED_ROUND_EPS[k] for k in range(len(CLIENT_SIZES))}
    worst_basic = max(basic, key=basic.get)
    out["B_reported_and_basic_composition"] = {
        "notebook_rule": "cumulative_epsilon += mean over clients of a fresh per-round epsilon (every round)",
        "notebook_value_recomputed": naive,
        "notebook_value_logged": LOGGED_FINAL,
        "abs_diff": abs(naive - LOGGED_FINAL),
        "why_not_a_valid_guarantee": [
            "a mean over clients is not a guarantee for any client: privacy is per client (each triple lives on one client)",
            "the delta of the summed rounds was never composed: basic composition of 16 rounds at 1e-5 gives delta = 1.6e-4",
            "summing per-round epsilons ignores RDP composition and is far looser than the accountant's own composition",
        ],
        "per_client_basic_composition_eps": basic,
        "per_client_basic_composition_delta": ROUNDS_EXECUTED * DELTA,
        "worst_client_basic_composition": {"client": worst_basic, "eps": basic[worst_basic],
                                           "delta": ROUNDS_EXECUTED * DELTA},
    }

    # ---------------------------------------------------------------- C. proper RDP composition per client
    comp = []
    for c in clients:
        row = {"client": c["client"], "n": c["n"], "q": c["q"], "steps_per_round": c["steps_per_epoch"]}
        for R in (ROUNDS_EXECUTED, ROUNDS_PLANNED):
            T = R * c["steps_per_epoch"]
            for d in (1e-5, 1e-6):
                tag = f"R{R}_delta{d:.0e}"
                row[f"steps_{tag}"] = T
                row[f"eps_opacus_orders_{tag}"] = opacus_eps(op, c["q"], T, SIGMA, d, OPACUS_ORDERS)[0]
                row[f"eps_dp_accounting_rdp_extended_orders_{tag}"] = google_rdp_eps(c["q"], T, SIGMA, d, EXTENDED_ORDERS)[0]
                row[f"eps_pld_{tag}"] = pld_eps(c["q"], T, SIGMA, d)
        comp.append(row)
    out["C_rdp_composition_per_client"] = comp
    for R in (ROUNDS_EXECUTED, ROUNDS_PLANNED):
        for d in (1e-5, 1e-6):
            tag = f"R{R}_delta{d:.0e}"
            key = f"eps_opacus_orders_{tag}"
            w = max(comp, key=lambda r: r[key])
            out.setdefault("C_worst_client", {})[tag] = {
                "client": w["client"], "n": w["n"], "steps": w[f"steps_{tag}"],
                "eps_rdp_opacus_orders": w[key],
                "eps_rdp_dp_accounting_extended_orders": w[f"eps_dp_accounting_rdp_extended_orders_{tag}"],
                "eps_pld": w[f"eps_pld_{tag}"]}

    # ---------------------------------------------------------------- D. audit leads
    leads = []
    w4 = clients[int(np.argmax([c["logged_round_eps"] for c in clients]))]   # smallest client = worst
    big = clients[0]
    N_all = sum(CLIENT_SIZES)
    cand = [
        ("worst client (Client-4), 16 rounds x 1 epoch, Opacus orders, delta=1e-5", w4["q"], 16 * w4["steps_per_epoch"], 1e-5),
        ("largest client (Client-0), 16 rounds x 1 epoch, Opacus orders, delta=1e-5", big["q"], 16 * big["steps_per_epoch"], 1e-5),
        ("worst client, 16 rounds, delta=1e-6", w4["q"], 16 * w4["steps_per_epoch"], 1e-6),
        ("worst client, 150 epochs (= Phase-3 schedule 50 rounds x 3 local epochs), delta=1e-5", w4["q"], 150 * w4["steps_per_epoch"], 1e-5),
        ("largest client, 150 epochs, delta=1e-5", big["q"], 150 * big["steps_per_epoch"], 1e-5),
        ("worst client, 150 epochs, delta=1e-6", w4["q"], 150 * w4["steps_per_epoch"], 1e-6),
        ("pooled (centralised) data N=272,115, B=256, 16 epochs, delta=1e-5", 1.0 / (N_all // BATCH), 16 * (N_all // BATCH), 1e-5),
        ("pooled (centralised) data N=272,115, B=256, 150 epochs, delta=1e-5", 1.0 / (N_all // BATCH), 150 * (N_all // BATCH), 1e-5),
    ]
    for desc, q, T, d in cand:
        e = opacus_eps(op, q, T, SIGMA, d, OPACUS_ORDERS)[0]
        leads.append({"interpretation": desc, "q": q, "steps": T, "sigma": SIGMA, "delta": d, "eps_rdp": e,
                      "abs_diff_to_1.98": abs(e - 1.98), "abs_diff_to_6.43": abs(e - 6.43)})
    out["D_audit_leads"] = {
        "note": ("1.98 and 6.43 were given as audit leads, not ground truth. Each candidate below states its "
                 "assumptions; a numerical match only shows which assumptions reproduce the lead, not that the "
                 "lead is the right guarantee."),
        "candidates": leads,
        "closest_to_1.98": min(leads, key=lambda r: r["abs_diff_to_1.98"])["interpretation"],
        "closest_to_6.43": min(leads, key=lambda r: r["abs_diff_to_6.43"])["interpretation"],
    }

    with open(a.out, "w") as f:
        json.dump(out, f, indent=2)
    # compact console summary
    print("A reproduced:", out["A_reproduced_within_1e-6"])
    for c in clients:
        print(f"  client {c['client']}: N={c['n']} L={c['loader_len']} steps={c['steps_per_epoch']} q={c['q']:.6f} "
              f"logged={c['logged_round_eps']:.6f} opacus={c['recomputed_round_eps_opacus']:.6f} "
              f"dp_acc={c['recomputed_round_eps_dp_accounting_rdp']:.6f}")
    print("B notebook naive:", naive, "| worst-client basic:", out["B_reported_and_basic_composition"]["worst_client_basic_composition"])
    print("C worst client:", json.dumps(out["C_worst_client"], indent=1))
    for r in leads:
        print(f"  D {r['eps_rdp']:.4f}  {r['interpretation']}")


if __name__ == "__main__":
    main()
