"""Per-priority, per-dataset GPU-hour upper bounds for the frozen schedule (DEADLINE_PLAN.md).

Inputs (both in this package):
  * the owner's measured T4 pilot extrapolation, pilot_extrapolation_20261104T164854Z.csv (run 2 = the slower run),
    inside provenance/phaseC_gpu_pilot_session_20261104/colab_pilot_results_20261104T165553Z_pilot_done.zip;
  * revision/10_configs/manifest/FROZEN_MANIFEST.csv (the approved cells and their priorities).
Method: each run's upper bound is the pilot's hours_upper for its (plan, block, dataset) at its round limit. RC-1 raised
the non-private Stage-4 references from 60 to 100 rounds; those runs are scaled by 100/60 (whole run time, so slightly
pessimistic). Legacy L1-L4: <= 0.18 h per run (the measured DP-run maximum; pilot_plan.md section 5). These are
estimates from 2-round measurements, NOT measurements of complete runs.

  python -I compute_costs.py <pilot_zip> <FROZEN_MANIFEST.csv> <out.csv>
"""
import io, sys, zipfile
import pandas as pd

zp, man_p, out = sys.argv[1:4]
with zipfile.ZipFile(zp) as z:
    name = next(n for n in z.namelist() if n.endswith("pilot_extrapolation_20261104T164854Z.csv"))
    x = pd.read_csv(io.BytesIO(z.read(name)))
x["hours_now"] = x["hours_upper"] * x["rounds"].map(lambda r: 100 / 60 if r == 60 else 1.0)
x.loc[x.plan == "tune", "hours_now"] = x.loc[x.plan == "tune", "hours_upper"]
m = pd.read_csv(man_p)
rows = []
tune = x[x.plan == "tune"].groupby("dataset")["hours_now"].sum()
gate = x[(x.plan == "tune") & (x.block == "T1C")].groupby("dataset")["hours_now"].sum()
for ds in ("fb15k237", "wn18rr", "codex_m"):
    rows.append({"step": "3 gate G-B (T1C)", "priority": "", "dataset": ds, "runs": int(((m.plan == "tune") & (m.block == "T1C") & (m.dataset == ds)).sum()), "gpu_h_upper": gate.get(ds, 0.0)})
    rows.append({"step": "4 tuning (rest)", "priority": "", "dataset": ds, "runs": 33 - 6, "gpu_h_upper": tune.get(ds, 0.0) - gate.get(ds, 0.0)})
per_run = x[(x.plan == "confirm_reduced") & (x.stage == 4)].groupby(["block", "dataset"])["hours_now"].mean()
main = m[m.plan == "main"]
for (prio, ds), g in main.groupby(["priority", "dataset"]):
    h = sum(per_run[(b, ds)] for b in g.block)
    rows.append({"step": "5 main", "priority": int(prio), "dataset": ds, "runs": len(g), "gpu_h_upper": h})
rows.append({"step": "6 replications L1-L4", "priority": 4, "dataset": "fb15k237", "runs": int((m.plan == "legacy").sum()), "gpu_h_upper": 0.18 * int((m.plan == "legacy").sum())})
d = pd.DataFrame(rows); d["gpu_h_upper"] = d["gpu_h_upper"].round(2)
d.to_csv(out, index=False)
print(d.to_string(index=False))
print("\nby step/priority:"); print(d.groupby(["step", "priority"])[["runs", "gpu_h_upper"]].sum().round(1).to_string())
print("\ntotal runs", d.runs.sum(), "total GPU-h", round(d.gpu_h_upper.sum(), 1))
