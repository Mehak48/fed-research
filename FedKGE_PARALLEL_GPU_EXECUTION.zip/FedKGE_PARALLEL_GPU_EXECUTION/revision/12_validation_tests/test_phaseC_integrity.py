"""Phase C - integrity verification in the data path (defect CR-13). The five properties required by the Phase C
brief, plus header/replay checks, the manifest hash chain and the persisted-store tamper test."""
import dataclasses

import numpy as np
import pytest
import torch

from fedkge.integrity import IntegrityLayer, deserialize, object_id, serialize, summarize_stats, tamper_test


def _layer(mode="hash_only", p=0.0, seed=0, root=None):
    return IntegrityLayer(mode, root, 3, p, np.random.default_rng(seed))


def test_1_unchanged_artifact_passes():
    L = _layer(); L.begin_round(1)
    x = torch.randn(1000)
    env = L.send("client0", 1, x)
    got, rec = L.receive(env, "server")
    assert rec.accepted and torch.equal(got, x)
    L.end_round()


def test_2_modified_artifact_fails():
    L = _layer(p=1.0)                                   # every transmitted object corrupted in transit
    L.begin_round(1)
    env = L.send("client0", 1, torch.randn(1000))
    got, rec = L.receive(env, "server")
    assert got is None and not rec.accepted and rec.corrupted_in_transit and rec.reason == "hash mismatch"
    st = L.end_round()
    assert st["n_corrupted"] == 1 and st["n_corrupted_and_rejected"] == 1 and st["n_corrupted_and_consumed"] == 0


def test_3_incorrect_hash_fails():
    L = _layer(); L.begin_round(1)
    env = L.send("client0", 1, torch.randn(100))
    bad = dataclasses.replace(env, oid="sha256-" + "0" * 64)
    got, rec = L.receive(bad, "server")
    assert got is None and rec.reason == "hash mismatch" and not rec.corrupted_in_transit
    assert L.end_round()["n_rejected"] == 1


def test_header_replay_and_wrong_round_fail():
    L = _layer(); L.begin_round(2)
    env = L.send("client0", 2, torch.randn(10))
    replay = dataclasses.replace(env, name="client1")   # valid bytes presented as another client's object
    got, rec = L.receive(replay, "server")
    assert got is None and "header" in rec.reason
    L.end_round()


def test_4_rejected_artifact_is_not_aggregated(offline_round):
    """End-to-end on the synthetic pipeline: with in-transit corruption and verification ON, every corrupted object
    is rejected and none is consumed; the rejected identities have no aggregation weight in that round."""
    integ, rounds, weights = offline_round(mode="hash_only", corrupt_p=0.3)
    assert integ["n_corrupted"] > 0
    assert integ["n_corrupted_and_consumed"] == 0 and integ["detection_rate"] == 1.0
    rej_rounds = rounds[rounds["n_rejected_uploads"] > 0]
    assert len(rej_rounds) > 0
    for _, r in rej_rounds.iterrows():
        assert r["n_participants"] + r["n_rejected_uploads"] + r["n_skipped_broadcast"] >= 1


def test_5_verified_bytes_are_the_bytes_consumed():
    """The receiver's tensor is built from the stored bytes, never from the sender's in-memory tensor: mutating
    the sender's tensor after send() does not change what the receiver consumes, and a corrupted byte (verification
    off) changes exactly the consumed value at that position."""
    x = torch.arange(50, dtype=torch.float32)
    L = _layer(); L.begin_round(1)
    env = L.send("client0", 1, x)
    x += 1000.0                                          # in-memory copy changes after transmission
    got, rec = L.receive(env, "server")
    assert rec.accepted and torch.equal(got, torch.arange(50, dtype=torch.float32))
    L.end_round()
    y = torch.arange(50, dtype=torch.float32)
    L2 = _layer("transport_only", p=1.0, seed=3); L2.begin_round(1)
    env = L2.send("client0", 1, y)
    got, rec = L2.receive(env, "server")
    assert rec.accepted and rec.corrupted_in_transit     # no verification: corrupted bytes are consumed
    assert int((got != y).sum()) == 1 or bool(torch.isnan(got).any())
    st = L2.end_round()
    assert st["n_corrupted_and_consumed"] == 1


def test_5b_aggregator_receives_exactly_the_deserialised_verified_bytes(offline_capture):
    """Instrumented run: the matrix passed to aggregate() equals, row by row, deserialize() of the bytes that
    passed verification in that round."""
    captured = offline_capture()
    assert captured, "aggregate() was never called"
    for U, blobs in captured:
        assert U.shape[0] == len(blobs)
        for row, b in zip(U, blobs):
            assert np.array_equal(row.cpu().numpy(), deserialize(b))


def test_serialisation_roundtrip_and_ids():
    x = torch.randn(37)
    b = serialize(x, {"name": "global", "round": 4})
    assert np.array_equal(deserialize(b), x.numpy()) and object_id(b).startswith("sha256-")
    assert object_id(b) != object_id(serialize(x, {"name": "global", "round": 5}))


def test_persisted_store_tamper_test_and_manifest_chain(tmp_path):
    L = _layer("full_store_last_k", root=tmp_path / "store")
    for rnd in (1, 2, 3, 4):
        L.begin_round(rnd)
        for c in range(3):
            env = L.send(f"client{c}", rnd, torch.randn(20))
            L.receive(env, "server")
        L.end_round()
    assert len(list((tmp_path / "store").glob("round_*"))) == 3
    rep = tamper_test(tmp_path / "store", 0.5, np.random.default_rng(1))
    assert rep["n_tampered"] > 0 and rep["detection_rate"] == 1.0 and rep["false_alarms"] == 0
    s = summarize_stats(L.stats)
    assert s["n_rejected"] == 0 and s["rounds"] == 4


def test_off_mode_rejects_corruption_config():
    with pytest.raises(ValueError):
        IntegrityLayer("off", None, 3, 0.1)
