"""Experiment-matrix expansion, execution with resume, run index, and cost estimation.

Resolution order for one run config (later wins):
  base.yaml -> datasets/<ds>.yaml:run_overrides -> matrix block 'base' -> grid point -> tiers/<tier>.yaml:run_overrides
Tier overrides may only touch execution-size keys (listed in the tier file); overlapping a grid key is an error.

CLI examples
  python -m fedkge.runner --config-dir 10_configs --results /content/drive/MyDrive/fedkge_results \
      --tier final --phase p4 --stage 1 --dataset wn18rr
  python -m fedkge.runner ... --list            (print the expanded run list, run nothing)
  python -m fedkge.runner ... --estimate        (GPU-hours from dev-tier timings)
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from .config import (ConfigError, deep_merge, get_dotted, iter_grid, load_yaml, resolve_placeholders, run_id,
                     set_dotted, validate)
from .io import Paths, RunDir, read_json, sha256_file, write_csv


def _sub_dataset(obj, ds: str):
    if isinstance(obj, dict):
        return {k: _sub_dataset(v, ds) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_sub_dataset(v, ds) for v in obj]
    if isinstance(obj, str):
        return obj.replace("{dataset}", ds)
    return obj


def _placeholders_used(obj, acc=None):
    """Set of placeholder references '<file>.<dotted.key>' used anywhere in obj."""
    acc = set() if acc is None else acc
    if isinstance(obj, dict):
        for v in obj.values(): _placeholders_used(v, acc)
    elif isinstance(obj, list):
        for v in obj: _placeholders_used(v, acc)
    elif isinstance(obj, str) and obj.startswith("${sel:"):
        acc.add(obj[6:-1])
    return acc


def _short(v) -> str:
    if isinstance(v, dict):
        return "{" + ",".join(f"{k}:{_short(x)}" for k, x in v.items()) + "}"
    return str(v)


def _name(grid_point: Dict) -> str:
    return ";".join(f"{k.split('.')[-1]}={_short(v)}" for k, v in grid_point.items()) or "default"


def _block_for_profile(block: Dict, profile: str) -> Optional[Dict]:
    """Profiles (Phase B D18): a block may carry 'reduced: {seeds, grid, datasets}' or 'reduced: drop'. Keys given
    for the profile REPLACE the full-profile keys (no merging of grids)."""
    if profile == "full" or "reduced" not in block:
        return block
    red = block["reduced"]
    if red == "drop":
        return None
    return {**{k: v for k, v in block.items() if k != "reduced"}, **red}


def _priority(block: Dict, cfg: Dict) -> int:
    """Execution priority of one cell (owner decision B2): the block's 'priority', overridden by the first matching
    'priority_when' condition. Execution metadata only - never part of the configuration or the run identity."""
    prio = int(block.get("priority", 0) or 0)
    for cond in block.get("priority_when", []):
        if all(get_dotted(cfg, k, None) == v for k, v in cond["if"].items()):
            return int(cond["priority"])
    return prio


def expand(phase: str, config_dir: Path, paths: Paths, tier: str, datasets: Optional[List[str]] = None,
           stages: Optional[List[int]] = None, blocks: Optional[List[str]] = None,
           tier_file: Optional[str] = None, profile: str = "full", matrix_name: Optional[str] = None,
           symbolic: bool = False) -> List[Dict]:
    """Expand a matrix into one entry per (block, dataset, seed, grid point). symbolic=True (frozen manifest) keeps
    every ${sel:...} placeholder unresolved and does not need selections; such entries have run_id None and an
    unvalidated config. Otherwise every placeholder is resolved, the config validated and its run_id computed."""
    config_dir = Path(config_dir)
    base = load_yaml(config_dir / "base.yaml")
    tier_cfg = load_yaml(config_dir / "tiers" / f"{tier_file or tier}.yaml")
    matrix = load_yaml(config_dir / "matrices" / f"{matrix_name or phase}.yaml")
    tier_over = tier_cfg.get("run_overrides", {})
    seed_sets = matrix.get("seed_sets", {})
    if profile not in ("full", "reduced"):
        raise ConfigError("profile must be 'full' or 'reduced'")
    selections, sel_hashes = {}, {}
    sel_dir = paths.base / "selection"
    if sel_dir.exists() and not symbolic:
        for p in sel_dir.glob("*.json"):
            selections[p.stem] = read_json(p); sel_hashes[p.stem] = sha256_file(p)
    entries: List[Dict] = []
    seen = {}
    for block0 in matrix["blocks"]:
        block = _block_for_profile(block0, profile)
        if block is None:
            continue
        if stages and int(block.get("stage", 1)) not in stages:
            continue
        if blocks and block["block"] not in blocks:
            continue
        bs = block.get("seeds")
        seeds = seed_sets[bs] if isinstance(bs, str) else (bs if bs is not None else tier_cfg["seeds"])
        if tier_cfg.get("max_seeds_per_block"):              # smoke: every block, first seed(s) of its seed set only
            seeds = list(seeds)[: int(tier_cfg["max_seeds_per_block"])]
        ds_list = [d for d in tier_cfg["datasets"] if d in block.get("datasets", tier_cfg["datasets"])]
        if datasets:
            ds_list = [d for d in ds_list if d in datasets]
        points = list(iter_grid(block.get("grid", {})))
        excl = block.get("exclude", [])
        points = [gp for gp in points if gp not in excl]
        if tier == "dev" and tier_cfg.get("dev_first_n_per_block"):
            points = points[: int(tier_cfg["dev_first_n_per_block"])]
        for ds in ds_list:
            ds_cfg = load_yaml(config_dir / "datasets" / f"{ds}.yaml")
            for seed in seeds:
                for gp in points:
                    cfg = deep_merge(base, ds_cfg.get("run_overrides", {}), block.get("base", {}))
                    for k, v in gp.items():
                        if k == "_cell":                       # a whole-config overlay (one cell of a block)
                            cfg = deep_merge(cfg, v)
                            continue
                        cur = get_dotted(cfg, k, None)
                        set_dotted(cfg, k, deep_merge(cur, v) if isinstance(v, dict) and isinstance(cur, dict) else v)
                    for k in _flat_keys(tier_over):
                        if k in gp:
                            raise ConfigError(f"tier override {k} collides with grid key in block {block['block']}")
                    keep = {k: get_dotted(cfg, k) for k in block.get("tier_exempt", [])}
                    cfg = deep_merge(cfg, tier_over)
                    for k, v in keep.items():   # structural settings of a block that tiers must not change
                        set_dotted(cfg, k, v)
                    cfg.update({"tier": tier, "phase": phase, "seed": int(seed), "block": block["block"],
                                "name": _name(gp)})
                    cfg["dataset"] = deep_merge(cfg.get("dataset", {}), {"name": ds})
                    cfg = _sub_dataset(cfg, ds)
                    used = _placeholders_used(cfg)
                    prio = _priority(block, cfg)
                    if symbolic:
                        cfg["selection_refs"] = {u: None for u in sorted(used)}
                        rid = None
                    else:
                        cfg = resolve_placeholders(cfg, selections)
                        # record every selected value this run depends on; analysis re-resolves them and marks the
                        # run STALE_SELECTION if any selection has changed since
                        cfg["selection_refs"] = {u: get_dotted(selections[u.split(".")[0]], u.split(".", 1)[1])
                                                 for u in sorted(used)}
                    for cond in block.get("keep_weights_when", []):     # e.g. [{dp.target_epsilon: 4.0}]
                        if all(get_dotted(cfg, k, None) == v for k, v in cond.items()):
                            set_dotted(cfg, "train.keep_final_weights", True)
                    if not symbolic:
                        validate(cfg)
                        rid = run_id(cfg)
                    entries.append({"phase": phase, "stage": int(block.get("stage", 1)), "block": block["block"],
                                    "name": cfg["name"], "dataset": ds, "seed": int(seed), "run_id": rid, "cfg": cfg,
                                    "priority": prio, "grid_point": gp, "placeholders": sorted(used)})
    # output-only options are not part of the run identity: a run shared by several blocks keeps its final weights
    # if any of those blocks asks for them
    if symbolic:
        return entries
    keep = {}
    for e in entries:
        keep[e["run_id"]] = keep.get(e["run_id"], False) or bool(e["cfg"]["train"].get("keep_final_weights", False))
    for e in entries:
        e["cfg"]["train"]["keep_final_weights"] = keep[e["run_id"]]
    return entries


def partitions_needed(entries: List[Dict]) -> List[Dict]:
    """Every (dataset, canonical partition spec, seed) the expanded runs need (Phase 2 builds exactly these)."""
    from .partition import canonical_spec
    out, seen = [], set()
    for e in entries:
        spec = canonical_spec(e["cfg"]["partition"])
        key = (e["dataset"], json.dumps(spec, sort_keys=True), e["seed"])
        if key not in seen:
            seen.add(key)
            out.append({"dataset": e["dataset"], "spec": spec, "seed": e["seed"]})
    return out


def _flat_keys(d: Dict, prefix: str = "") -> List[str]:
    out = []
    for k, v in d.items():
        if isinstance(v, dict):
            out += _flat_keys(v, prefix + k + ".")
        else:
            out.append(prefix + k)
    return out


def write_index(paths: Paths, phase: str, entries: List[Dict]) -> Path:
    """Merge entries into the phase index (block/name/dataset/seed -> run_id)."""
    p = paths.index(phase)
    new = pd.DataFrame([{k: e[k] for k in ("phase", "stage", "block", "name", "dataset", "seed", "run_id")} for e in entries])
    if p.exists():
        old = pd.read_csv(p)
        new = pd.concat([old, new]).drop_duplicates(subset=["block", "name", "dataset", "seed"], keep="last")
    write_csv(p, new.sort_values(["stage", "block", "dataset", "name", "seed"]))
    return p


def run_entries(entries: List[Dict], paths: Paths, device: Optional[str] = None, stop_on_error: bool = False,
                max_runs: Optional[int] = None, deadline: Optional[float] = None) -> pd.DataFrame:
    """Run the unique runs of `entries` in the given order. Completed current runs are reused; interrupted runs
    resume from their checkpoint. No new run starts after `max_runs` new runs or after the wall-clock `deadline`
    (epoch seconds): those are reported PENDING, never COMPLETE. A run in progress is never cut short here."""
    from .federated import run_experiment
    unique = {}
    for e in entries:
        unique.setdefault(e["run_id"], e)
    todo = list(unique.values())
    status = []
    done = 0
    for i, e in enumerate(todo):
        rd = RunDir(paths.run(e["run_id"]))
        rerun = False
        if rd.is_complete_and_current():
            if e["cfg"]["train"].get("keep_final_weights") and not (rd.path / "final_weights.pt").exists():
                rd.archive_stale("no_final_weights")      # kept for the record; the run is repeated with weights
                rerun = True
            else:
                status.append({"run_id": e["run_id"], "block": e["block"], "status": "COMPLETE(existing)"}); continue
        if (max_runs is not None and done >= max_runs) or (deadline is not None and time.time() >= deadline):
            status.append({"run_id": e["run_id"], "block": e["block"], "status": "PENDING"}); continue
        print(f"\n=== [{i + 1}/{len(todo)}] {e['block']} | {e['dataset']} | seed {e['seed']} | {e['name']}")
        t = time.time()
        try:
            run_experiment(e["cfg"], paths, device, force=rerun)
            status.append({"run_id": e["run_id"], "block": e["block"],
                           "status": "COMPLETE(rerun_for_weights)" if rerun else "COMPLETE", "seconds": time.time() - t})
        except Exception as ex:
            status.append({"run_id": e["run_id"], "block": e["block"], "status": "FAILED", "error": repr(ex)})
            if stop_on_error:
                raise
        done += 1
    return pd.DataFrame(status)


def estimate(entries: List[Dict], paths_dev: Paths) -> pd.DataFrame:
    """GPU-hour estimate from COMPLETE dev-tier runs: seconds per round by (dataset, dp, method) x planned rounds."""
    from .analysis import collect
    per = {}
    for ph in ("p3", "p4"):
        try:
            runs, _ = collect(paths_dev, [ph])
        except Exception:
            continue
        for _, r in runs.iterrows():
            key = (r["cfg.dataset.name"], bool(r["cfg.dp.enabled"]))
            per.setdefault(key, []).append(r["runtime.total_s"] / max(r["rounds_executed"], 1))
    rows = []
    for e in {x["run_id"]: x for x in entries}.values():
        key = (e["dataset"], bool(e["cfg"]["dp"]["enabled"]))
        spr = float(np.median(per[key])) if key in per else np.nan
        rows.append({"block": e["block"], "dataset": e["dataset"], "sec_per_round": spr,
                     "est_hours_upper": spr * e["cfg"]["train"]["rounds_max"] / 3600})
    df = pd.DataFrame(rows)
    return df.groupby(["block", "dataset"]).agg(runs=("sec_per_round", "size"), hours=("est_hours_upper", "sum")).reset_index()


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--config-dir", required=True); ap.add_argument("--results", required=True)
    ap.add_argument("--tier", required=True, choices=["smoke", "dev", "pilot", "tune", "final"])
    ap.add_argument("--phase", required=True)
    ap.add_argument("--stage", type=int, nargs="*"); ap.add_argument("--dataset", nargs="*"); ap.add_argument("--block", nargs="*")
    ap.add_argument("--list", action="store_true"); ap.add_argument("--estimate", action="store_true")
    ap.add_argument("--max-runs", type=int); ap.add_argument("--device")
    ap.add_argument("--profile", choices=["full", "reduced"], default="reduced")
    ap.add_argument("--matrix", help="matrix file name in 10_configs/matrices (default: the phase name)")
    a = ap.parse_args(argv)
    paths = Paths(a.results, a.tier)
    entries = expand(a.phase, Path(a.config_dir), paths, a.tier, a.dataset, a.stage, a.block,
                     profile=a.profile, matrix_name=a.matrix)
    write_index(paths, a.phase, entries)
    if a.list:
        print(pd.DataFrame([{k: e[k] for k in ("block", "dataset", "seed", "name", "run_id")} for e in entries]).to_string())
        return
    if a.estimate:
        print(estimate(entries, Paths(a.results, "dev")).to_string()); return
    st = run_entries(entries, paths, a.device, max_runs=a.max_runs)
    print(st["status"].value_counts().to_string())


if __name__ == "__main__":
    main()


def partition_specs_needed(config_dir: Path, tier: str, tier_file: Optional[str] = None) -> Dict[str, List[Dict]]:
    """All canonical partition specs (per dataset) required by the P3/P4/P6/P7 matrices of this tier.
    Phase 2 builds exactly these, for every seed of the tier."""
    from .partition import canonical_spec
    config_dir = Path(config_dir)
    base = load_yaml(config_dir / "base.yaml")
    tier_cfg = load_yaml(config_dir / "tiers" / f"{tier_file or tier}.yaml")
    out: Dict[str, List[Dict]] = {}
    for mp in sorted((config_dir / "matrices").glob("p*.yaml")):   # every matrix present in this package
        matrix = load_yaml(mp)
        for block in matrix["blocks"]:
            for ds in [d for d in tier_cfg["datasets"] if d in block.get("datasets", tier_cfg["datasets"])]:
                ds_cfg = load_yaml(config_dir / "datasets" / f"{ds}.yaml")
                for gp in iter_grid(block.get("grid", {})):
                    part = deep_merge(base["partition"], ds_cfg.get("run_overrides", {}).get("partition", {}),
                                      block.get("base", {}).get("partition", {}))
                    for k, v in gp.items():
                        if k.startswith("partition."):
                            part[k.split(".", 1)[1]] = v
                    part = deep_merge(part, tier_cfg.get("run_overrides", {}).get("partition", {}))
                    spec = canonical_spec(part)
                    if spec not in out.setdefault(ds, []):
                        out[ds].append(spec)
    return out
