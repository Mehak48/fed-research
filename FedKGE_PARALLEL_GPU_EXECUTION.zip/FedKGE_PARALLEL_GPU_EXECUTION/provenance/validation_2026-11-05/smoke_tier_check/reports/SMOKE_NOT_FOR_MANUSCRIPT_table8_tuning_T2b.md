# Table 8 — Stage 3 selection (T2b); validation only

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| dataset | dp.clip | val_mrr_mean | chosen | tied_within_tolerance |
|---|---|---|---|---|
| codex_m | 0.25 | 0.002015 | True | True |
| codex_m | 0.5 | 0.00201 | False | True |
| codex_m | 1 | 0.002008 | False | True |
| codex_m | 2 | 0.002004 | False | True |
| codex_m | 4 | 0.002004 | False | True |
| fb15k237 | 0.25 | 0.002598 | True | True |
| fb15k237 | 0.5 | 0.002598 | False | True |
| fb15k237 | 1 | 0.002598 | False | True |
| fb15k237 | 2 | 0.002598 | False | True |
| fb15k237 | 4 | 0.002598 | False | True |
| wn18rr | 0.25 | 0.0008412 | True | True |
| wn18rr | 0.5 | 0.0008415 | False | True |
| wn18rr | 1 | 0.0008416 | False | True |
| wn18rr | 2 | 0.0008416 | False | True |
| wn18rr | 4 | 0.0008414 | False | True |
