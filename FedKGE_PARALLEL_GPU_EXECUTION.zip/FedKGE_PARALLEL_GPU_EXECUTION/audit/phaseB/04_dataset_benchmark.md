# 04 — Three-dataset benchmark recommendation (Phase B, item 4)

**Status:** recommendation for decision D5. **No dataset was downloaded.**
- Statistics and licences below come from the sources cited, which were checked on 2026-10-28, or from your own legacy outputs.
- Every count is re-measured on the loaded data in Phase D. Differences are recorded, not hidden.
- Machine-readable: `data/dataset_candidates.csv`.

## 1. Recommendation

| Role | Dataset | Why |
|---|---|---|
| Continuity (required) | **FB15k-237** | the original paper's dataset; inverse leakage of FB15k removed by construction |
| Second | **WN18RR** | the standard second KG-completion benchmark; lexical, very sparse; the hardest regime for dense-noise DP (≈ 47 parameters per training triple) |
| Third (**recommended default**) | **CoDEx-M** | established (EMNLP 2020); MIT-licensed repository; inverse and near-duplicate relations removed by construction; 51 relations; affordable |
| Optional fourth / alternative | YAGO3-10 (or CoDEx-L) | scale; only if the measured cost allows. YAGO3-10 always carries its leakage caveat |

**Selection criteria** (fixed before any result; **expected MRR is not a criterion**, per master prompt §6):
1. an established KG-completion benchmark;
2. a clear licence for research use;
3. documented construction, with test leakage handled;
4. enough relations for the Dirichlet-over-relations partition with 10 clients;
5. compatibility with the existing loader (PyKEEN);
6. cost within a low budget;
7. coverage of different DP regimes.

WN18RR is kept **even though DP utility is expected to be worst there** (RK-1). Dropping it for that reason would be selecting datasets by MRR.

## 2. Candidates compared

Indicators (all **[Calculated – Phase B planning]**, from `data/phaseB_sigma_plan.csv` and `data/per_run_time_estimate.csv`; every dataset in the table has its own rows there):
- **Noise/clip** = per-step noise-to-clip ratio $\sigma\sqrt P/(q\bar N)$ for the mean client at ε = 4, R = 100, design Q. Shown at q = 0.05, and as the range over the tuning grid q = 0.10–0.02.
- **Per-run time** = minutes per run, LOW–HIGH bounds of the cost model, on an *assumed* T4-class GPU (the model's reference class, not a measurement): non-private FedAvg ≤ 60 rounds / DP design Q 100 rounds.

| Dataset | Entities / relations | Train / valid / test | Params per train triple | Noise/clip at q = 0.05 (range over q) | Per-run min (non-private / DP) | Verdict |
|---|---|---|---|---|---|---|
| FB15k-237 | 14,541 / 237 (PyKEEN: 14,505 entities) | 272,115 / 17,535 / 20,466 | 5.4 | 2.64 (1.8–4.4) | 6–20 / 3–33 | **keep** |
| WN18RR | 40,943 / 11 | 86,835 / 3,034 / 3,134 | 47.2 | 13.81 (9.6–22.7) | 2–8 / 3–33 | **include** |
| CoDEx-M | 17,050 / 51 | 185,584 / 10,310 / 10,311 | 9.2 | 4.18 (2.9–6.9) | 4–14 / 3–32 | **third (default)** |
| YAGO3-10 | 123,182 / 37 | 1,079,040 / 5,000 / 5,000 | 11.4 | 1.93 (1.3–3.2) | 26–92 / 8–67 | optional extension |
| CoDEx-L | 77,951 / 69 | 551,193 / 30,622 / 30,622 | 14.2 | 3.00 (2.1–4.9) | 13–45 / 5–49 | clean large alternative |
| CoDEx-S | 2,034 / 42 | 32,888 / 1,827 / 1,828 | 6.3 | 8.21 (5.7–13.5) | 1–3 / 2–26 | too small for 10 clients |
| NELL-995 | not verified here | not verified here | – | – | – | not recommended |
| FB15k, WN18 | – | – | – | – | – | **rejected** (inverse-relation test leakage) |
| UMLS, Kinship, Nations | tiny | – | – | – | – | rejected (too small to federate) |
| Wikidata5M, ogbl-wikikg2 | millions of entities | – | – | – | – | rejected (dense DP noise over 10⁸+ parameters) |

The parameter counts (and therefore the noise ratios) use the published entity counts, except FB15k-237, which uses the PyKEEN count from your legacy logs. Phase D re-measures all of them.

## 3. Per-dataset evidence

### FB15k-237
- **Source.** Toutanova & Chen (2015), "Observed versus latent features for knowledge base and text inference" (CVSC workshop). It is a subset of FB15k (Bordes et al. 2013), derived from Freebase.
- **Construction** (verified in the paper):
  - limited to the 401 most frequent relations;
  - near-duplicate and inverse relations detected by entity-pair overlap (≥ 97 %), keeping one of each group;
  - **validation and test triples removed if their entity pairs are directly linked in training.**
- **Counts.** Official: 14,541 entities, 237 relations, 272,115 / 17,535 / 20,466. Through PyKEEN (legacy-logged): 14,505 entities, 237 relations, 272,115 / 17,526 / 20,438 after removing triples with unseen entities.
- **Licence.**
  - The Microsoft Download Center page (FB15K-237 Knowledge Base Completion Dataset, `FB15K-237.2.zip`, 139.4 MB) states **no licence terms**.
  - A third-party mirror labels it CC BY 4.0, which is not authoritative.
  - → **You must confirm** that research use is acceptable before the licence gate allows a download.
- **Consequences for this study:**
  - the validation/test construction biases any membership audit that uses test triples as non-members (MJ-15). The planned audit therefore draws its non-members from each client's own training triples (`05` §10);
  - Dirichlet α = 0.1 is easily feasible. Simulation on your legacy per-relation counts: 100 % of draws accepted; medians over accepted draws: size Gini 0.16, largest share 15 %;
  - δ × largest client size ≈ 0.04 at δ = 1e-6 (median largest client in the simulation).

### WN18RR
- **Source.** Dettmers et al. (2018, AAAI). It is WN18 (Bordes et al. 2013) with inverse relations removed to fix test leakage, derived from WordNet 3.0 (Miller 1995).
- **Counts.** 40,943 entities, 11 relations, 86,835 / 3,034 / 3,134 (TensorFlow Datasets catalogue; Akrami et al. 2020, Table 1).
- **Licence.** WordNet licence (Princeton): permission "to use, copy, modify and distribute this software and database … for any purpose and without fee or royalty", provided the copyright notice and disclaimer are kept (SPDX: WordNet).
- **Known issues.** Symmetric relations remain. `derivationally_related_form` is symmetric and makes up > 34 % of training (Akrami et al. 2020).
- **Consequences:**
  - only 11 relations, so the Dirichlet partition at α = 0.1 is heavily truncated. Simulation with **unverified** per-relation counts: 3.75 % of draws accepted; medians over accepted draws: size Gini 0.44, largest share 29 %, ≈ 7 relations per client. The binding check runs in Phase D (G15) with the pre-approved fallback (D4);
  - the hardest DP regime (noise/clip 13.8 at q = 0.05; 9.6–22.7 over the tuning grid);
  - δ × largest client size ≈ 0.025 at δ = 1e-6.

### CoDEx-M (recommended third dataset)
- **Source.** Safavi & Koutra (2020), "CoDEx: A Comprehensive Knowledge Graph Completion Benchmark", EMNLP 2020. Extracted from Wikidata and Wikipedia.
- **Construction** (verified in the paper):
  - inverse relations removed "to minimize train/test leakage";
  - relations with > 50 % entity-pair overlap with another relation removed;
  - validation and test restricted to entities and relations seen in training;
  - symmetric relations kept.
- **Counts** (GitHub `tsafavi/codex`): 17,050 entities, 51 relations, 185,584 / 10,310 / 10,311. The validation and test splits also contain hard negative triples, which this study does not use.
- **Licence.** The repository is "licensed under the terms of the MIT license" (verified). The triples come from Wikidata (CC0). Wikipedia text extracts are not used.
- **Loader.** PyKEEN class `CoDExMedium` (verified in the PyKEEN documentation).
- **Partition.** 51 relations, so α = 0.1 is expected to be feasible. It was **not** simulated (no per-relation counts were available here); Phase D checks it.
- **Cost** relative to FB15k-237 per run: about 0.7× (non-private) and 0.87–0.95× (DP, design Q). Reduced core plan: 14–122 GPU-h for this dataset (`data/cost_estimate.csv`).
- **Reference value** (sanity only, reported in the literature under the authors' protocol): TransE MRR 0.303, Hits@1 0.223, Hits@10 0.454. **Not** a target and **not** comparable with our numbers.

### YAGO3-10 (optional fourth dataset / alternative)
- **Source.** Subset of YAGO3 (Mahdisoltani et al. 2015) with entities that have ≥ 10 relations, introduced by Dettmers et al. (2018).
- **Counts.** 123,182 entities, 37 relations, 1,079,040 / 5,000 / 5,000 (Akrami et al. 2020, Table 1).
- **Licence.** YAGO is distributed under Creative Commons Attribution: CC BY 4.0 for the current release according to Wikipedia's infobox. YAGO3's own licence page was not checked here → **confirm**.
- **Known issues** (Akrami et al. 2020, verified):
  - `isAffiliatedTo` and `playsFor` are near-duplicates (35 % and 30 % of training triples; together > 63 % of the test set);
  - 557,696 training triples have duplicates in training;
  - **2,561 of the 5,000 test triples have duplicates in training**;
  - 118 test triples have their reverse in training;
  - a simple rule-based model beats the embedding models (FHits@1 51.6 %);
  - the authors recommend their cleaned YAGO3-10-DR.
- **Consequences:**
  - leakage inflates link-prediction MRR;
  - duplicated facts weaken what triple-level DP protects, because replacing one triple leaves its duplicate (MJ-21);
  - its largest client would hold ≥ 10⁵ triples, so δ = 1e-7 would be used;
  - the cost is the highest of the shortlist: 57–332 GPU-h for this dataset in the reduced core plan, versus 14–122 for CoDEx-M (2.7–4.2×).
- If you prefer YAGO3-10 for familiarity, it can be the third dataset with these caveats stated. That is a legitimate choice, but it is yours to make (D5).

### NELL-995 (considered, not recommended)
- Used by federated-KGE prior work: FedE (NELL-995-Fed3) and DP-Flames.
- Not available in PyKEEN (checked against the documentation's dataset list). Its licence and split statistics were not verified in this session.
- Adding it would need a new loader and a licence check, mainly for continuity with prior work. That prior work uses per-client test sets anyway, so its numbers would not be comparable with ours.

## 4. Protocol per dataset (master prompt §6) — what Phase D will produce

All three datasets go through **one parameterised pipeline**. They are evaluated independently, and **vocabularies are never merged** (the original methodology diagram's cross-dataset clients are excluded).

| Item | How it is produced and recorded |
|---|---|
| Source and licence | dataset card: source URL, citation, licence text, your licence confirmation (date, flag) |
| Entities, relations, triples | before and after the PyKEEN loader (vocabulary from training) |
| Splits | official train / valid / test; V_sel / V_root = 80 / 20 % of valid (seed 0); V_es = 2,000 triples of V_sel |
| Preprocessing and filtering | counts of triples dropped for unseen entities; duplicates; inverse-pair statistic; overlap checks = 0 |
| Removed or duplicate triples | counts per split, in the validation report |
| Client partition procedure | `03` §3; α grid; attempts; acceptance rate; heterogeneity statistics; partition hash |
| Dataset-specific configuration | identical by default. Any deviation (for example the WN18RR minimum-size fallback, or a dataset-specific selected C) is recorded with its reason |
| Reproducibility | split seed 0; partition seed = run seed; content hashes of arrays and files; code hash |

## 5. Licence gate (fixes G12)

- `scripts/download_or_prepare_data.py --dataset <name>` will print the source, licence text and citation, and **refuse to download** unless `--i-confirm-licence` is passed.
- Your confirmation is recorded in the dataset card.
- Datasets already on disk are verified by hash and never re-downloaded silently.

## Sources

- [FB15K-237 Knowledge Base Completion Dataset — Microsoft Download Center](https://www.microsoft.com/en-us/download/details.aspx?id=52312)
- [Toutanova & Chen 2015 — Observed versus latent features for knowledge base and text inference (PDF)](https://www.cs.princeton.edu/~danqic/papers/cvsc2015.pdf)
- [Hugging Face mirror of FB15k-237 (third-party licence label)](https://huggingface.co/datasets/KGraph/FB15k-237/blob/main/README.md)
- [TensorFlow Datasets — WordNet / WN18RR](https://www.tensorflow.org/datasets/catalog/wordnet)
- [SPDX — WordNet License](https://spdx.org/licenses/WordNet.html)
- [CoDEx repository (tsafavi/codex)](https://github.com/tsafavi/codex)
- [CoDEx paper, arXiv 2009.07810](https://arxiv.org/abs/2009.07810)
- [Akrami et al. 2020 — Realistic Re-evaluation of Knowledge Graph Completion Methods](https://arxiv.org/pdf/2003.08001)
- [YAGO (database) — Wikipedia](https://en.wikipedia.org/wiki/YAGO_(database))
- [PyKEEN dataset documentation](https://pykeen.readthedocs.io/en/latest/reference/datasets.html)
- [FedE, arXiv 2010.12882](https://arxiv.org/pdf/2010.12882)
- [DP-Flames (Hu et al., WWW '23), arXiv 2304.02932](https://arxiv.org/pdf/2304.02932v1.pdf)
- [LibKGE results tables (TransE reference values)](https://github.com/uma-pi1/kge)
