# Table 8 — Stage 3 selection (T1_nonprivate); validation only

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| dataset | train.lr | train.batch_size | val_mrr_mean | chosen | tied_within_tolerance |
|---|---|---|---|---|---|
| codex_m | 0.001 | 512 | 0.001868 | False | False |
| codex_m | 0.001 | 4096 | 0.001748 | False | False |
| codex_m | 0.003 | 512 | 0.002122 | False | False |
| codex_m | 0.003 | 4096 | 0.001801 | False | False |
| codex_m | 0.01 | 512 | 0.004766 | True | True |
| codex_m | 0.01 | 4096 | 0.002917 | False | True |
| fb15k237 | 0.001 | 512 | 0.002609 | True | True |
| fb15k237 | 0.001 | 4096 | 0.002609 | False | True |
| fb15k237 | 0.003 | 512 | 0.002642 | False | True |
| fb15k237 | 0.003 | 4096 | 0.002642 | False | True |
| fb15k237 | 0.01 | 512 | 0.003044 | False | True |
| fb15k237 | 0.01 | 4096 | 0.003044 | False | True |
| wn18rr | 0.001 | 512 | 0.0008396 | True | True |
| wn18rr | 0.001 | 4096 | 0.0008405 | False | True |
| wn18rr | 0.003 | 512 | 0.0008397 | False | True |
| wn18rr | 0.003 | 4096 | 0.0008412 | False | True |
| wn18rr | 0.01 | 512 | 0.0008535 | False | True |
| wn18rr | 0.01 | 4096 | 0.0008467 | False | True |
