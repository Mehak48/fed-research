# Table 4 — baseline comparison (clean, eps* = 4)

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| system | dataset | block | seeds_planned | test.mrr | test.hits@10 |
|---|---|---|---|---|---|
| Centralised (non-private) | FB15k-237 | N1 | 5 | 0.112 (n=1) | 0.170 (n=1) |
| FedAvg (non-private) | FB15k-237 | N2 | 5 | 0.005 (n=1) | 0.007 (n=1) |
| DP-FedAvg fixed sigma, eps* = 4 | FB15k-237 | DP1 | 5 | 0.005 (n=1) | 0.007 (n=1) |
| DP-FedAvg selected schedule, eps* = 4 | FB15k-237 | DP2 | 5 | 0.005 (n=1) | 0.007 (n=1) |
| trimmed_mean, eps* = 4 (clean) | FB15k-237 | R1 | 3 | 0.005 (n=1) | 0.007 (n=1) |
| median, eps* = 4 (clean) | FB15k-237 | R1 | 3 | 0.005 (n=1) | 0.007 (n=1) |
| krum, eps* = 4 (clean) | FB15k-237 | R1 | 3 | 0.005 (n=1) | 0.007 (n=1) |
| fltrust, eps* = 4 (clean) | FB15k-237 | R1 | 3 | 0.005 (n=1) | 0.007 (n=1) |
| Proposed trust rule, eps* = 4 (clean) | FB15k-237 | R1p | 5 | 0.005 (n=1) | 0.007 (n=1) |
| Centralised (non-private) | WN18RR | N1 | 5 | 0.015 (n=1) | 0.025 (n=1) |
| FedAvg (non-private) | WN18RR | N2 | 5 | 0.001 (n=1) | 0.003 (n=1) |
| DP-FedAvg fixed sigma, eps* = 4 | WN18RR | DP1 | 5 | 0.001 (n=1) | 0.003 (n=1) |
| DP-FedAvg selected schedule, eps* = 4 | WN18RR | DP2 | 5 | 0.001 (n=1) | 0.003 (n=1) |
| trimmed_mean, eps* = 4 (clean) | WN18RR | R1 | 3 | 0.001 (n=1) | 0.003 (n=1) |
| median, eps* = 4 (clean) | WN18RR | R1 | 3 | 0.001 (n=1) | 0.003 (n=1) |
| krum, eps* = 4 (clean) | WN18RR | R1 | 3 | 0.001 (n=1) | 0.003 (n=1) |
| fltrust, eps* = 4 (clean) | WN18RR | R1 | 3 | 0.001 (n=1) | 0.003 (n=1) |
| Proposed trust rule, eps* = 4 (clean) | WN18RR | R1p | 5 | 0.001 (n=1) | 0.003 (n=1) |
| Centralised (non-private) | CoDEx-M | N1 | 5 | 0.102 (n=1) | 0.180 (n=1) |
| FedAvg (non-private) | CoDEx-M | N2 | 5 | 0.004 (n=1) | 0.012 (n=1) |
| DP-FedAvg fixed sigma, eps* = 4 | CoDEx-M | DP1 | 5 | 0.002 (n=1) | 0.003 (n=1) |
| DP-FedAvg selected schedule, eps* = 4 | CoDEx-M | DP2 | 5 | 0.002 (n=1) | 0.003 (n=1) |
| trimmed_mean, eps* = 4 (clean) | CoDEx-M | R1 | 3 | 0.002 (n=1) | 0.003 (n=1) |
| median, eps* = 4 (clean) | CoDEx-M | R1 | 3 | 0.002 (n=1) | 0.003 (n=1) |
| krum, eps* = 4 (clean) | CoDEx-M | R1 | 3 | 0.002 (n=1) | 0.003 (n=1) |
| fltrust, eps* = 4 (clean) | CoDEx-M | R1 | 3 | 0.002 (n=1) | 0.003 (n=1) |
| Proposed trust rule, eps* = 4 (clean) | CoDEx-M | R1p | 5 | 0.002 (n=1) | 0.003 (n=1) |
