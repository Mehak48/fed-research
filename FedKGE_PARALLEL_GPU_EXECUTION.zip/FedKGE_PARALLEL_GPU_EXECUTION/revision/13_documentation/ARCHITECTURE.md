> **Historical page (original package).** The module table predates the Phase C and final-package modules (selection chain, gates, manifest, hypotheses, paper tables, figures). The current, frozen methodology is `13_documentation/FINAL_METHODOLOGY.md`; the execution procedure is `../EXECUTION_GUIDE.md` and the notebook `../RUN_COMPLETE_FEDKGE_RESEARCH.ipynb`. Kept unchanged below for the record.

# Architecture (Phases 1–4 delivery)

## One engine, thin notebooks
All science lives in the `fedkge` package (`01_fedkge_core/fedkge/`). Notebooks only choose a tier, call the
package, validate outputs and print a status. The **same code path** runs every dataset: a dataset is a config
file (`10_configs/datasets/<ds>.yaml`), never a copied implementation.

```
10_configs (base + dataset + tier + matrix)  ──► runner.expand ──► one resolved config per run (hash = identity)
                                                                    │
P1 data.build_artifact ──► artifacts/p1/<ds>  ─┐                    ▼
P2 partition.build_partition ─► artifacts/p2 ─┴──► federated.run_experiment ──► runs/<run_id>/*
                                                   (train | dp + accountant, evaluate, log, checkpoint)
                                                                    │
                        analysis.collect (validity checks) ◄────────┘
                        selection.select_clip / select_schedule  ──► selection/dp_selection.json
                        reports.write_p3_reports / write_p4_reports ──► reports/p3, reports/p4
```

## Modules
| Module | Role |
|---|---|
| `config.py` | YAML load, deep-merge, validation (fails loudly: no warm start, DP ⇒ 1 local epoch, legacy negatives ⇒ k = 1, …), canonical config hash, `${sel:…}` placeholders |
| `io.py` | results layout, atomic writes, status files (RUNNING/COMPLETE/FAILED), `code_hash()` over result-determining modules, artifact verification, stale-run archiving |
| `data.py` | PyKEEN loaders (FB15k-237, WN18RR, YAGO3-10), smoke subsets, split validation, V_sel/V_root split, early-stopping subset, content hash, dataset card, OLAP roll-ups |
| `partition.py` | IID, Dirichlet-over-relations, legacy relation-disjoint, centralised; canonical specs; statistics; hashed artifacts bound to the Phase 1 hash |
| `model.py`, `sampling.py` | TransE; correct / legacy negative sampling |
| `train.py` | non-DP local training (Adam, fresh state per round) |
| `dp.py` | DP-SGD: Poisson sampling, exact per-example clipping on sparse rows, dense Gaussian noise |
| `accountant.py` | RDP composition, (ε, δ) conversion, σ₀ calibration, schedules, PLD cross-check, legacy per-round ε (replica only) |
| `evaluate.py` | filtered head + tail ranking, realistic/optimistic/pessimistic ties, bootstrap CI, per-relation MRR, legacy protocol (replica only) |
| `federated.py` | round loop orchestrator; writes every run output; checkpoint/resume |
| `runner.py` | matrix expansion, dedup, run index, execution with skip/resume, cost estimate, partition-spec derivation |
| `analysis.py`, `stats.py` | run collection with validity checks; per-seed summaries, paired tests, Holm, Pareto |
| `selection.py` | pre-registered DP selections (validation only, full grid required) |
| `reports.py`, `plotting.py`, `schemas.py` | P3/P4 tables, figures (watermarked outside final), JSON-schema validation |
| `aggregators.py`, `trust.py`, `attacks.py`, `integrity.py`, `mia.py` | already present with fixed interfaces for Phases 6–7; in P3/P4 the orchestrator uses `fedavg`, no attack, hash-only integrity; MIA disabled |

## Results layout
```
RESULTS_ROOT/<tier>/artifacts/p1/<ds>/…        RESULTS_ROOT/<tier>/runs/<run_id>/…
RESULTS_ROOT/<tier>/artifacts/p2/<ds>/<spec>/… RESULTS_ROOT/<tier>/index/{p3,p4}_runs_index.csv
RESULTS_ROOT/<tier>/selection/dp_selection.json RESULTS_ROOT/<tier>/reports/{p1,p2,p3,p4}/…
RESULTS_ROOT/_cache/sigma_calibration.json      (pure function cache: key = all calibration inputs)
```

## Validity chain (automatic invalidation)
Every run records `code_hash`, `data_hash`, `partition_hash`, and the **values** of every selection it used
(`selection_refs`). `analysis.collect` rejects a run as `STALE_CODE / STALE_DATA / STALE_PARTITION /
STALE_SELECTION / WRONG_TIER / FAILED / NOT_RUN`. Reports and selections call `collect(require_all=True)`, so
one stale or missing run blocks them. `run_entries` never reuses a stale run: it archives it to
`<tier>/stale/` and reruns. Upstream artifacts are re-hashed on every load; a mismatch raises `IntegrityError`.
Missing input ⇒ the run is marked FAILED with the traceback in `error.txt`; nothing is substituted.

## Tiers
`smoke` (subsets, 1 seed, 3 rounds), `dev` (full FB15k-237 + WN18RR, seed 42, 20 rounds, first grid point per
block), `final` (all datasets × 5 seeds × full grids, R_max = 100). Tiers write to separate folders; runs carry
their tier; report files from non-final tiers are prefixed `<TIER>_NOT_FOR_MANUSCRIPT_`; `collect` refuses to mix
tiers. `offline` is a synthetic-data variant of `smoke` used only by the test-suite.

## Interfaces fixed for Phases 5–8
P5–P8 will consume: `index/*.csv`, `runs/<id>/{config,final,accountant}.json`, `rounds.csv`,
`selection/dp_selection.json`, `analysis.collect`, `stats.*`, `reports.*`. No format will change.
