"""The master's dependency-driven steps: do every selection / freeze / release whose inputs are complete NOW.

Each step is done at most once and leaves a record in <master>/parallel/steps/<SEL-id>.json. A step whose input runs
are not all imported yet is reported as WAITING (nothing is wrong); a failed gate G-B stops that dataset (research
tiers), exactly as scripts/run_plan.py stops Stage 3 for it.
"""
from __future__ import annotations

from typing import Dict, List

from .common import DATASETS, IntegrityError, atomic_write_json, read_json_or, utc_now
from .store import Master, Waiting


def _done(master: Master, sel_id: str):
    return read_json_or(master.root / "parallel" / "steps" / f"{sel_id}.json", None)


def _mark(master: Master, sel_id: str, rec: Dict) -> None:
    atomic_write_json(master.root / "parallel" / "steps" / f"{sel_id}.json", {**rec, "utc": utc_now()})


def advance(master: Master, datasets=DATASETS) -> List[Dict]:
    plan = master.plan()
    tune_mode = plan["tune_mode"]
    planned = {j["dataset"] for j in plan["jobs"] if j["kind"] in ("TUNECHAIN", "TUNESTAGE")}
    actions = []
    for ds in [d for d in datasets if d in planned]:
        if tune_mode == "chain":
            sid = f"SEL-{ds}-chain"
            if _done(master, sid):
                continue
            rec = master.latest_chain_record(ds)
            if rec is None:
                actions.append({"step": sid, "status": "WAITING", "why": f"no tuning-chain bundle of {ds} imported"})
                continue
            actions.append(_select_and_release(master, sid, ds, list(range(7)), "main", verify_against=rec))
        else:
            for s in range(6):
                sid = f"SEL-{ds}-s{s}"
                prev = _done(master, sid)
                if prev:
                    if prev.get("status") == "GATE_FAILED":
                        break
                    continue
                stages = [s] if s < 5 else [5, 6]
                nxt = f"tune-s{s + 1}" if s < 5 else "main"
                a = _select_and_release(master, sid, ds, stages, nxt)
                actions.append(a)
                if a["status"] != "DONE":
                    break
    return actions


def _select_and_release(master: Master, sid: str, ds: str, stages: List[int], release: str,
                        verify_against=None) -> Dict:
    try:
        res = master.select(ds, stages, verify_against=verify_against)
    except Waiting as e:
        return {"step": sid, "status": "WAITING", "why": str(e)}
    except IntegrityError as e:
        master.log(f"{sid} REFUSED: {e}")
        return {"step": sid, "status": "REFUSED", "why": str(e)}
    if res.get("gate_failed"):
        _mark(master, sid, {"status": "GATE_FAILED", "detail": res["gate_failed"]})
        master.log(f"{sid}: GATE G-B FAILED for {ds}; no later job of {ds} is released "
                   f"(report: {master.paths(master.tiers['tune']).base / 'gates' / 'SANITY_GATE_REPORT.md'})")
        return {"step": sid, "status": "GATE_FAILED", "why": res["gate_failed"]}
    frozen = None
    if release == "main":
        try:
            frozen = master.freeze(ds)
        except IntegrityError as e:
            master.log(f"{sid} FREEZE REFUSED: {e}")
            return {"step": sid, "status": "REFUSED", "why": str(e)}
    pack = master.release(ds, release)
    _mark(master, sid, {"status": "DONE", "stages": stages, "released": release, "pack": str(pack),
                        "frozen_datasets": (frozen or {}).get("datasets"), "selections": res})
    return {"step": sid, "status": "DONE", "pack": str(pack)}
