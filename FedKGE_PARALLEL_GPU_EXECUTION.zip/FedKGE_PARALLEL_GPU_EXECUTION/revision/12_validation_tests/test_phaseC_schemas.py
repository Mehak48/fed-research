"""Phase C - every output of a run is valid against 11_experiment_schemas (gate G-A "schemas valid"), including
the Phase C files: integrity.json, attack.json, mia.json, trust_rounds.csv. Synthetic data (software check only)."""
import json

import jsonschema
import pytest

from conftest import CONFIG_DIR
from fedkge.schemas import validate_file, validate_obj, validate_run_dir

SCHEMA_DIR = CONFIG_DIR.parent / "11_experiment_schemas"
DPQ = {"enabled": True, "sampling": "common_rate", "q": 0.1, "target_epsilon": 4.0, "clip": 1.0,
       "schedule": {"shape": "fixed", "rho": 1.0, "update_every": 5}}


@pytest.mark.parametrize("over", [
    {"dp": DPQ, "aggregation": {"method": "proposed"}, "attack": {"type": "alie", "fraction": 0.2, "knowledge": "white"},
     "integrity": {"mode": "hash_only", "corrupt_p": 0.2}},
    {"dp": DPQ, "mia": {"enabled": True}},
    {"mia": {"enabled": True}},                             # non-private reference audit (block M1): no accountant eps
    {"aggregation": {"method": "krum"}, "attack": {"type": "signflip", "fraction": 0.2}, "integrity": {"mode": "transport_only"}},
], ids=["dp_proposed_alie_corrupt", "dp_mia", "nonprivate_mia", "nonprivate_krum_signflip_transport"])
def test_every_run_output_matches_its_schema(run_cfg, over):
    fin, d = run_cfg(**over)
    checked = {f for f, _ in validate_run_dir(d, SCHEMA_DIR)}
    assert {"config.json", "final.json", "rounds.csv", "trust_rounds.csv"} <= checked
    if over.get("dp"):
        assert "accountant.json" in checked
    if over.get("attack"):
        assert "attack.json" in checked
    if over.get("mia"):
        assert "mia.json" in checked
    if over.get("integrity", {}).get("mode", "hash_only") != "off":
        assert "integrity.json" in checked


def test_schemas_reject_wrong_integrity_and_ipfs_claims(run_cfg):
    fin, d = run_cfg(dp=DPQ, integrity={"mode": "hash_only", "corrupt_p": 0.2})
    rep = json.loads((d / "integrity.json").read_text())
    validate_obj(rep, SCHEMA_DIR, "integrity")
    for bad in ({**rep, "n_corrupted_and_consumed": 1},                    # verification let a corrupted object in
                {**rep, "verified_bytes_are_aggregated": False},
                {**rep, "id_scheme": "IPFS CID"}):                        # never describe the id as an IPFS CID
        with pytest.raises(jsonschema.ValidationError):
            validate_obj(bad, SCHEMA_DIR, "integrity")


def test_mia_schema_requires_the_red_line_flag_only_with_an_accountant(run_cfg):
    fin, d = run_cfg(dp=DPQ, mia={"enabled": True})
    rep = json.loads((d / "mia.json").read_text())
    assert isinstance(rep["eps_accountant"], float)
    with pytest.raises(jsonschema.ValidationError):                  # DP run without the red-line flag: invalid
        validate_obj({k: v for k, v in rep.items() if k != "lower_bound_exceeds_accountant"}, SCHEMA_DIR, "mia")
    validate_obj({**{k: v for k, v in rep.items() if k != "lower_bound_exceeds_accountant"}, "eps_accountant": None},
                 SCHEMA_DIR, "mia")                                  # non-private reference: no flag needed


def test_dataset_card_accepts_codex_m_and_sized_stand_ins(synthetic_paths):
    card = json.loads((synthetic_paths.p1("synthetic") / "dataset_card.json").read_text())
    validate_file(synthetic_paths.p1("synthetic") / "dataset_card.json", SCHEMA_DIR, "dataset_card")
    for name in ("codex_m", "synthetic_fb15k237_sized"):
        validate_obj({**card, "dataset": name}, SCHEMA_DIR, "dataset_card")
    with pytest.raises(jsonschema.ValidationError):
        validate_obj({**card, "dataset": "unknown_kg"}, SCHEMA_DIR, "dataset_card")
