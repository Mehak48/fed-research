"""Execute FEDKGE_PARALLEL_MASTER.ipynb / FEDKGE_PARALLEL_WORKER.ipynb cell by cell, as written, in one namespace per
notebook. After the settings cell only the software-check switches are overridden (smoke mode, CPU, a local BASE,
the recorded licence note, a short session budget). Records every cell's outcome. Used only to validate the
notebooks; never a research run.

  python -I nb_parallel_harness.py <notebook> <base> <package_zip> <report.json> [KEY=VALUE ...]
"""
import json
import shutil
import sys
import time
import traceback
from pathlib import Path

nb_path, base, zip_path, rep_path = map(Path, sys.argv[1:5])
extra = dict(kv.split("=", 1) for kv in sys.argv[5:])
base.mkdir(parents=True, exist_ok=True)
if not (base / zip_path.name).exists():
    shutil.copy2(zip_path, base / zip_path.name)
nb = json.loads(nb_path.read_text())
ns = {"__name__": "__main__"}
OVR = {"BASE": str(base), "MODE": "smoke", "DEVICE": "cpu", "REQUIRE_GPU": False, "DATA_DIR": extra.pop("DATA_DIR"),
       "LICENCE_CONFIRMED": {"fb15k237": True, "wn18rr": True, "codex_m": True},
       "LICENCE_NOTE": "Owner Mehak Ramzan confirmed research use of all three datasets on 2026-11-02 (recorded); "
                       "parallel notebook software check 2026-11-07"}
for k, v in extra.items():
    OVR[k] = float(v) if k in ("MAX_HOURS_THIS_SESSION", "SPEED", "WATCH_MINUTES", "SYNC_HOURS") else v
report, code_i = [], 0
for c in nb["cells"]:
    if c["cell_type"] != "code":
        continue
    code_i += 1
    src = "".join(c["source"])
    if code_i > 1 and "WATCH_MINUTES = 0" in src and "WATCH_MINUTES" in OVR:
        src = src.replace("WATCH_MINUTES = 0", f"WATCH_MINUTES = {OVR['WATCH_MINUTES']}")
    t0 = time.time()
    try:
        exec(compile(src, f"cell{code_i}", "exec"), ns)
        st = "OK"
    except SystemExit as e:
        st = f"SystemExit: {e}"
    except Exception as e:
        st = f"ERROR: {e!r}"
        traceback.print_exc()
    if code_i == 1:
        ns.update(OVR)
    report.append({"code_cell": code_i, "status": st, "seconds": round(time.time() - t0, 1),
                   "first_line": src.splitlines()[0][:90]})
    print(f"\n>>> code cell {code_i}: {st} ({report[-1]['seconds']} s)\n", flush=True)
    if st != "OK":
        break
rep_path.write_text(json.dumps(report, indent=1))
print(json.dumps(report, indent=1))
