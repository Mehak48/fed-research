"""Example plans for 1-4 GPUs (ESTIMATES from the T4 upper-bound cost table; no measurement).

  python parallel/tools/plan_examples.py [--out parallel/PLAN_EXAMPLES.md]

Scenarios: N identical workers of one environment class (N = 1..4), in chain and stage tuning mode, for hand-over
delays of 0.25 h and 1 h; and unequal environments (speed factors are HYPOTHETICAL inputs, not measurements).
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fedkge_parallel.cells import approved_cells  # noqa: E402
from fedkge_parallel.jobs import build_jobs, default_shard_policy  # noqa: E402
from fedkge_parallel.schedule import best_assignment, plan_summary  # noqa: E402

GROUPS = [f"{t}/{d}" for t in ("tune", "final") for d in ("fb15k237", "wn18rr", "codex_m")]


def plan(cells, workers, tune_mode, sync):
    prov = build_jobs(cells, "research", tune_mode, master_sync_hours=sync)
    assign, _ = best_assignment(prov, workers)
    n = {g: sum(1 for w in workers if w["env_class"] == c) for g, c in assign.items()}
    jobs = build_jobs(cells, "research", tune_mode, default_shard_policy(n), master_sync_hours=sync)
    return jobs, plan_summary(jobs, workers)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--out")
    a = ap.parse_args()
    cells = approved_cells("research")
    rows = []
    for n in (1, 2, 3, 4):
        ws = [{"name": f"T4-{i + 1}", "env_class": "Tesla T4 | torch X", "speed": 1.0} for i in range(n)]
        for mode in ("chain", "stage"):
            for sync in (0.25, 1.0):
                jobs, s = plan(cells, ws, mode, sync)
                rows.append((f"{n} identical T4", mode, sync, len([j for j in jobs if j.is_worker]),
                             s["makespan_hours"], s["critical_path"]["hours"], s["total_gpu_hours_T4"],
                             s["makespan_hours"] and s["total_gpu_hours_T4"] / s["makespan_hours"]))
    hetero = {
        "2 T4 (same build) + 1 GPU at 2x (hypothetical)": [("T4-1", "T4", 1.0), ("T4-2", "T4", 1.0), ("fast", "FAST", 2.0)],
        "1 T4 + 1 T4 with another torch build (2 classes)": [("T4-a", "T4|torchA", 1.0), ("T4-b", "T4|torchB", 1.0)],
        "3 T4 + 1 slower GPU at 0.6x (hypothetical)": [("T4-1", "T4", 1.0), ("T4-2", "T4", 1.0), ("T4-3", "T4", 1.0),
                                                       ("slow", "SLOW", 0.6)],
    }
    hrows = []
    for label, spec in hetero.items():
        ws = [{"name": n, "env_class": c, "speed": s} for n, c, s in spec]
        jobs, s = plan(cells, ws, "chain", 0.25)
        hrows.append((label, s["makespan_hours"], s["critical_path"]["hours"], s["assignment"],
                      {w: len(q) for w, q in s["queues"].items()}))
    L = ["# Example plans (estimates)", "",
         "T4 upper bounds from the owner's pilot (parallel/cost_table_T4_upper.csv); hand-over = the time to move a bundle "
         "or pack and run the master cycle. **Estimates, not measurements.**", "",
         "| Workers | Tuning mode | Hand-over h | GPU jobs | Makespan h | Critical path h | Total T4 GPU-h | Mean busy workers |",
         "|---|---|---|---|---|---|---|---|"]
    L += [f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} | {r[4]:.1f} | {r[5]:.1f} | {r[6]:.1f} | {r[7]:.2f} |" for r in rows]
    L += ["", "## Unequal environments (chain mode, hand-over 0.25 h)", "",
          "| Workers | Makespan h | Critical path h | Group → class | Jobs per worker |", "|---|---|---|---|---|"]
    L += [f"| {r[0]} | {r[1]:.1f} | {r[2]:.1f} | {r[3]} | {r[4]} |" for r in hrows]
    txt = "\n".join(L) + "\n"
    if a.out:
        Path(a.out).write_text(txt)
    print(txt)


if __name__ == "__main__":
    main()
