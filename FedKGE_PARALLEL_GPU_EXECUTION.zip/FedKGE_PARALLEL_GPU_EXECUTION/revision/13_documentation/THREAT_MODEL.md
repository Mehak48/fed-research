# THREAT_MODEL — FedKGE revision (from Phase B 03a; added in Phase C, change C12; fixes G3 / X20)

**Status:** threat model of the Phase C implementation (`fedkge/attacks.py`, `integrity.py`, `dp.py`, `trust.py`). Items marked **[Phase C]** in the Phase B draft are now implemented and tested (see `audit/phaseC/implementation_traceability.md`). References like `03 §7.2` point to `audit/phaseB/03_methodology_specification.md`.

## 1. Parties and assets

| Party | Role | Holds |
|---|---|---|
| Clients k = 1..10 | data holders; run local training | private training triples $D_k$; public size $\hat N_k$ (number of records) |
| Server | aggregates; selects models; publishes the global model | server-held validation data $V_{sel}$ and root data $V_{root}$ (benchmark splits, not client data) |
| Content store | holds the serialised updates and models | untrusted storage (simulated locally) |
| Model users | receive the final global model | the published model |

| Asset | Property | Mechanism | Section |
|---|---|---|---|
| Each client's training triples | privacy | client-side DP-SGD | §2 |
| Global model utility | robustness to malicious clients | trust-weighted aggregation (+ baselines) | §3 |
| Transmitted and stored objects | integrity | SHA-256 content addressing in the data path | §4 |

The three properties come from **different mechanisms against different adversaries**. None of them substitutes for another:
- integrity does not stop poisoning;
- trust scoring gives no privacy;
- DP does not authenticate data.

## 2. Privacy adversary (DP guarantee)

- **Who:** the server, any other clients, any coalition of server and clients, and any user of the final model.
- **Behaviour:** no assumption is needed about how they behave.
  - The noise is added by client k itself, inside every step.
  - Clipping bounds each triple's influence for *any* broadcast model, including one crafted by a malicious server.
  - Clients reject broadcasts that fail verification or contain non-finite values, and zero non-finite per-example gradients before clipping, so a crafted inf/NaN model cannot break the bound **[Phase C]** (MN-22).
- **What they see:** every message client k sends (the noised updates $U_k^t$ and their identifiers), every broadcast, and the final model. There is no secure aggregation.
- **What they may know:** the full protocol and all public parameters ($\mathcal E, \mathcal R, \hat N_k, q, C, \sigma_t, T, R$), and **every other triple** of every client. This is the standard worst-case adversary of DP.
- **Goal:** decide whether one specific triple is in $D_k$, or learn anything that depends on that single triple.
- **Guarantee:** $(\varepsilon_k, \delta)$-DP under **zero-out adjacency** (`03` §7.2): two datasets of client k are neighbours if one triple is replaced by a null record with zero gradient.
  - The client's size is therefore the same for neighbours, and publishing it is compatible with the guarantee (fixes CR-14).
  - The bound covers every executed step. The worst-client ε is reported.
- **Out of scope** (stated as limitations):
  - **entities**: an entity that appears in g triples gets only group privacy, which is vacuous for g ≥ 4 at ε = 4 (`03` §7.6);
  - client-level privacy and client participation;
  - **how many triples a client holds** ($\hat N_k$ is public by design);
  - dataset-level properties such as which relations a client mostly holds;
  - correlated or duplicated facts;
  - the privacy cost of hyperparameter tuning (disclosed, not accounted);
  - timing, floating-point and PRNG side channels beyond the non-finite guard;
  - a server that changes the client code or the public parameters. Clients run fixed, published code with parameters fixed before training, so the server cannot change their noise.

**Membership-inference audit (only if D6 keeps H3).**
- **Attacker:** an honest-but-curious server or a user of the final global model, with score access to the final global model (primary, black-box). A white-box variant uses client k's last update (secondary).
- **Prior:** the candidate triple, the vocabulary, and population knowledge.
- **Audit pool:** before training, each client draws an audit pool from its *own* training triples. Each candidate is included in training independently with probability ½; the excluded candidates are the non-members. Members and non-members therefore come from the same distribution (fixes MJ-15). Official test triples are never used as non-members.
- **Primary test:** the relation-calibrated score attack (A2) on the final global model, pooled over all clients (`05` §10).
- **Interpretation:** an empirical lower bound on leakage under specific attacks, not a guarantee. The lower bound on ε comes from the one-run audit (Steinke, Nasr & Jagielski 2023). If it exceeds the accountant's ε in any run, the implementation is presumed wrong and investigated.

## 3. Robustness adversary (poisoning / Byzantine)

- **Who:** a static set $\mathcal M$ of compromised clients, chosen before training with $|\mathcal M| = \mathrm{round}(fK)$; f = 0.2 is the main setting, f ∈ {0.1, 0.3} for sensitivity. Placement is seeded-random; a variant uses the largest clients. Compromised clients **collude**.
- **Sybil variant:** k data-less identities registered before training. Each declares the median honest size.
- **Capabilities:**
  - send any update, including ones crafted from the attacker's own honest computation, from benign statistics (white-box), or from simulating the server's rule (gray-box adaptive);
  - choose whether to add DP noise. Main setting: noise inherited or matched; noise-free is a secondary check (D16, G7);
  - poison its own training data (KG-targeted attack). Its targets are built from its **own** training triples, because it has no access to the evaluator's test set **[Phase C]** (MN-21).
- **Knowledge levels:**
  - black-box: own data plus every broadcast global model;
  - gray-box: plus the aggregation rule and all its parameters (τ, λ, norm bound, reference definition), with benign statistics *estimated* from colluders' updates and the previous global update;
  - white-box: plus the current DP-noised updates of all benign clients (an omniscient upper bound).
- **Cannot:**
  - change honest clients' messages (authenticated channels);
  - change declared sizes after registration;
  - break SHA-256;
  - control the server.
- **Server assumption for robustness claims:** the server runs the aggregation rule faithfully. A malicious server is out of scope *for robustness* (it does not affect the privacy guarantee, §2).
- **Attack budget:** f; strength s = 3 (a priori); ALIE's z from its formula; the adaptive γ from an 81-point grid in [0, 20], keeping the simulated anomaly score at least 5 % below τ; 50 targets × 50 copies for the targeted attack.
- **Success metrics** are defined in `03` §10. **No defence is claimed against attacks that were not run** (master prompt §10).

**Known weaknesses of the proposed rule, stated in advance:**
- crafted updates just below τ (adaptive attack);
- weight inflation through Sybil identities' claimed sizes;
- small-norm "stealth" updates, which pass the norm bound by design;
- false positives on honest non-IID or small clients (RK-3, D15);
- possible loss of detection power under heavy DP noise (RK-2).

## 4. Integrity adversary

- **Who:** anyone who can change bytes in the content store or in transit: storage corruption, a malicious storage or relay operator, transmission errors.
- **Cannot:** change the identifiers. They are delivered over an authenticated channel (for example TLS between each client and the server), or later in signed manifests (not implemented).
- **Guarantee:** a modified object is detected before use and rejected, unless SHA-256 second-preimage resistance is broken. The manifest hash chain makes rewriting earlier rounds detectable.
  - **At the server:** only tensors deserialised from verified bytes are aggregated; a client whose update fails verification is dropped for that round **[Phase C]** (fixes CR-13).
  - **At a client:** a broadcast that fails verification, or contains non-finite values, is not used; the client sends no update that round and reports the failure **[Phase C]**.
- **Not guaranteed:** availability (objects can be deleted); authenticity if the identifier channel is compromised; correctness or benignness of content (a poisoned update hashes correctly); any IPFS property. Identifiers are not CIDs, and IPFS is not used under D7 option (a).

## 5. Assumptions summary (for the paper's threat-model paragraph)

1. The entity and relation vocabularies are public and agreed before training.
2. Client sizes $\hat N_k$ are declared before training and are public. Zero-out adjacency makes this compatible with the DP guarantee.
3. The server holds a validation set that is not client data (a simulation assumption).
4. Clients run the published client code with the public parameters fixed before training.
5. Channels between clients and server are authenticated.
6. **Privacy** needs no assumption about the server or other clients beyond assumption 4. **Robustness** assumes the server aggregates faithfully.
7. Attackers are static and collude; f < 0.5.
8. There is no secure aggregation and no trusted execution environment.
