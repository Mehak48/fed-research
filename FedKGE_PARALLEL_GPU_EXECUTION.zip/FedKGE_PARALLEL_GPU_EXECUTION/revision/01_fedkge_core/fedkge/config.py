"""Configuration: YAML loading, deep-merge, validation (fail loudly), canonical hashing.

A resolved run configuration is a plain nested dict. Its identity is the SHA-256 of the canonical JSON of
all *semantic* fields (block/name/labels excluded), so identical experiments appearing in several blocks
are run once and shared.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, Iterable

import yaml

TIERS = ("smoke", "dev", "pilot", "tune", "final")
DATASETS = ("fb15k237", "wn18rr", "codex_m", "yago310", "synthetic")
PARTITION_SCHEMES = ("iid", "dirichlet_relation", "relation_disjoint_legacy", "centralized")
AGGREGATORS = ("fedavg", "krum", "trimmed_mean", "median", "fltrust", "proposed")
ATTACKS = ("none", "signflip", "gaussian", "alie", "ipm", "targeted", "adaptive", "sybil")
NEG_MODES = ("correct", "p3_legacy", "p4_legacy")
STOP_RULES = ("rdp_budget", "legacy_naive_sum", "none")
DP_MODES = ("calibrated", "fixed_sigma", "no_noise")   # no_noise: DP3 cost-decomposition ablation only (no guarantee)
INTEGRITY_MODES = ("off", "transport_only", "hash_only", "full_store_last_k")
DP_SAMPLING = ("fixed_batch", "common_rate")          # Phase B D11: design A | design Q
NOISE_MODES = ("auto", "inherit", "matched", "none")  # Phase B D16
TARGET_SOURCES = ("attacker_data", "test_legacy")     # MN-21
# Owner decision B4 (2026-11-04): the variant V1 (aggregation.magnitude_reference = size_third) and its D15 switch are
# removed. A configuration that still carries the key is rejected, so no stale V1 setting can enter a run.
REMOVED_KEYS = {("aggregation", "magnitude_reference"): "variant V1 was removed by owner decision B4 (2026-11-04); "
                                                        "only the frozen trust rule exists"}

# Keys that label a run but do not change what is computed -> excluded from the hash.
NON_SEMANTIC_KEYS = {"block", "name", "labels", "notes", "selection_refs"}
# Output-only options (which files a run keeps, not what it computes) -> excluded from the hash, so identical
# experiments listed in several blocks are still one run; runner.expand OR-merges them over the sharing entries.
OUTPUT_ONLY_KEYS = (("train", "keep_final_weights"),)


class ConfigError(ValueError):
    pass


def load_yaml(path: str | Path) -> Dict[str, Any]:
    p = Path(path)
    if not p.exists():
        raise ConfigError(f"config file not found: {p}")
    with open(p) as f:
        data = yaml.safe_load(f) or {}
    if not isinstance(data, dict):
        raise ConfigError(f"{p} must contain a mapping")
    return data


def deep_merge(base: Dict[str, Any], *overlays: Dict[str, Any]) -> Dict[str, Any]:
    out = copy.deepcopy(base)
    for ov in overlays:
        for k, v in (ov or {}).items():
            if isinstance(v, dict) and isinstance(out.get(k), dict):
                out[k] = deep_merge(out[k], v)
            else:
                out[k] = copy.deepcopy(v)
    return out


def set_dotted(cfg: Dict[str, Any], dotted: str, value: Any) -> None:
    keys = dotted.split(".")
    d = cfg
    for k in keys[:-1]:
        if k not in d or not isinstance(d[k], dict):
            d[k] = {}
        d = d[k]
    d[keys[-1]] = value


def get_dotted(cfg: Dict[str, Any], dotted: str, default: Any = KeyError) -> Any:
    d: Any = cfg
    for k in dotted.split("."):
        if not isinstance(d, dict) or k not in d:
            if default is KeyError:
                raise ConfigError(f"missing config key: {dotted}")
            return default
        d = d[k]
    return d


def _canonical(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: _canonical(obj[k]) for k in sorted(obj) if k not in NON_SEMANTIC_KEYS}
    if isinstance(obj, (list, tuple)):
        return [_canonical(x) for x in obj]
    if isinstance(obj, float):
        return float(repr(obj))  # full precision, stable
    return obj


def _without_output_only(cfg: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(cfg)
    for sec, key in OUTPUT_ONLY_KEYS:
        if isinstance(out.get(sec), dict) and key in out[sec]:
            out[sec] = {k: v for k, v in out[sec].items() if k != key}
    return out


def config_hash(cfg: Dict[str, Any]) -> str:
    s = json.dumps(_canonical(_without_output_only(cfg)), sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(s.encode()).hexdigest()


def run_id(cfg: Dict[str, Any]) -> str:
    h = config_hash(cfg)[:16]
    return f"{cfg['phase']}_{cfg['dataset']['name']}_s{cfg['seed']}_{h}"


def _req(cond: bool, msg: str) -> None:
    if not cond:
        raise ConfigError(msg)


def validate(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Validate a fully resolved run config. Raises ConfigError on any inconsistency."""
    for key in ("tier", "phase", "seed", "dataset", "partition", "model", "train", "dp",
                "aggregation", "attack", "integrity", "eval"):
        _req(key in cfg, f"missing top-level key '{key}'")
    _req(cfg["tier"] in TIERS, f"tier must be one of {TIERS}")
    _req(cfg["dataset"]["name"] in DATASETS or str(cfg["dataset"]["name"]).startswith("synthetic_"),
         f"unknown dataset {cfg['dataset']['name']}")
    _req(isinstance(cfg["seed"], int), "seed must be int")
    _req(not (cfg["tier"] in ("tune", "final") and str(cfg["dataset"]["name"]).startswith("synthetic")),
         "synthetic datasets can never be used in the tune or final tiers")

    p = cfg["partition"]
    _req(p["scheme"] in PARTITION_SCHEMES, f"unknown partition scheme {p['scheme']}")
    if p["scheme"] == "centralized":
        _req(p["n_clients"] == 1, "centralized requires n_clients = 1")
    else:
        _req(p["n_clients"] >= 2, "federated runs need n_clients >= 2")
    if p["scheme"] == "dirichlet_relation":
        _req(p.get("alpha", 0) > 0, "dirichlet alpha must be > 0")

    t = cfg["train"]
    _req(t["neg_mode"] in NEG_MODES, f"neg_mode must be in {NEG_MODES}")
    _req(t["neg_samples"] >= 1 and t["batch_size"] >= 1 and t["local_epochs"] >= 1, "bad train sizes")
    if t["neg_mode"] != "correct":
        _req(t["neg_samples"] == 1, "legacy negative modes use exactly 1 negative")
    _req(t["rounds_max"] >= 1, "rounds_max >= 1")
    _req("warm_start" not in t, "warm_start is not supported (it would void DP guarantees)")
    _req(isinstance(t.get("select_best", True), bool), "train.select_best must be a boolean")
    if t.get("stop_after_rounds") is not None:
        _req(cfg["tier"] in ("smoke", "dev", "pilot"), "stop_after_rounds (timing pilot) is not allowed in tune/final tiers")
        _req(1 <= int(t["stop_after_rounds"]) <= int(t["rounds_max"]), "1 <= stop_after_rounds <= rounds_max")

    dp = cfg["dp"]
    if dp["enabled"]:
        _req(dp["mode"] in DP_MODES, f"dp.mode must be in {DP_MODES}")
        _req(dp["clip"] is None or dp["clip"] > 0, "dp.clip > 0 (null = no clipping, DP3-a ablation only)")
        if dp["clip"] is None:
            _req(dp["mode"] == "no_noise", "clip = null is allowed only in the no_noise ablation")
        _req(0 < dp["delta"] < 1, "dp.delta in (0,1)")
        _req(dp["stop_rule"] in STOP_RULES, f"stop_rule in {STOP_RULES}")
        _req(t["local_epochs"] == 1, "DP runs use exactly 1 local epoch per round (accounting unit)")
        samp = dp.get("sampling", "fixed_batch")
        _req(samp in DP_SAMPLING, f"dp.sampling must be in {DP_SAMPLING}")
        if samp == "common_rate":
            _req(dp.get("q") is not None and 0 < float(dp["q"]) < 1, "design Q (common_rate) needs 0 < dp.q < 1")
            _req(not dp.get("legacy_opacus_sampling", False), "legacy Opacus sampling is design A only")
        if t.get("early_stopping", True):
            # C3: DP runs execute all R rounds; early stopping is switched off by the orchestrator (recorded)
            cfg.setdefault("labels", {})["early_stopping_disabled_for_dp"] = True
        if dp["mode"] == "calibrated":
            _req(dp["target_epsilon"] > 0, "calibrated DP needs target_epsilon")
            _req(dp["schedule"]["shape"] in ("fixed", "linear", "exponential", "cosine"), "bad schedule")
            if dp["schedule"]["shape"] == "fixed":
                _req(float(dp["schedule"]["rho"]) == 1.0, "fixed schedule requires rho = 1")
            _req(dp["stop_rule"] != "legacy_naive_sum", "calibrated runs cannot use the legacy stop rule")
        elif dp["mode"] == "no_noise":
            _req(dp["stop_rule"] == "none", "the no_noise ablation has no privacy budget: stop_rule must be 'none'")
        else:
            _req(dp["sigma"] > 0, "fixed_sigma mode needs dp.sigma")
            if dp["stop_rule"] == "rdp_budget":
                _req(dp.get("budget_epsilon") is not None, "fixed_sigma + rdp_budget needs dp.budget_epsilon")
        if dp["stop_rule"] == "legacy_naive_sum":
            _req(dp.get("legacy_opacus_sampling", False), "legacy stop rule only with legacy sampling")

    a = cfg["aggregation"]
    _req(a["method"] in AGGREGATORS, f"aggregation.method in {AGGREGATORS}")
    n_total = p["n_clients"] + (cfg["attack"].get("sybil_k", 0) if cfg["attack"]["type"] == "sybil" else 0)
    atk = cfg["attack"]
    _req(atk["type"] in ATTACKS, f"attack.type in {ATTACKS}")
    _req(atk.get("noise_mode", "auto") in NOISE_MODES, f"attack.noise_mode in {NOISE_MODES}")
    _req(atk.get("target_source", "attacker_data") in TARGET_SOURCES, f"attack.target_source in {TARGET_SOURCES}")
    for (sec, key), why in REMOVED_KEYS.items():
        _req(key not in (cfg.get(sec) or {}), f"{sec}.{key} is not allowed: {why}")
    _req(0 < float(a.get("f_design", 0.2)) < 0.5, "aggregation.f_design in (0, 0.5)")
    if atk["type"] != "none":
        _req(p["scheme"] != "centralized", "attacks require a federation")
        f = n_malicious(cfg)
        _req(f >= 1, "attack configured but zero malicious clients")
        if a["method"] == "krum":
            # Krum needs n > 2f + 2 (Blanchard et al. 2017). Recorded as an assumption flag, not silently fixed.
            cfg.setdefault("labels", {})["krum_assumption_ok"] = bool(n_total > 2 * f + 2)
        if a["method"] == "trimmed_mean":
            k = int(a["beta"] * n_total)
            cfg.setdefault("labels", {})["trimmed_mean_assumption_ok"] = bool(k >= f)
        if a["method"] == "median":
            cfg.setdefault("labels", {})["median_assumption_ok"] = bool(f < n_total / 2)
        if atk["type"] in ("alie", "ipm"):
            _req(atk["knowledge"] == "white", "ALIE/IPM are evaluated with white-box benign statistics")
        if atk["type"] == "adaptive":
            _req(atk["knowledge"] in ("gray", "white"), "adaptive attacker knowledge must be gray or white")
            # crafted against the PROPOSED rule (its tau); may be sent to FedAvg as the paired no-defence
            # reference (block R2a). Recorded, never silently re-targeted.
            cfg.setdefault("labels", {})["adaptive_crafted_against"] = "proposed"
    if a["method"] == "trimmed_mean":
        _req(0 < a["beta"] < 0.5, "trimmed-mean beta in (0, 0.5)")
    if a["method"] == "proposed":
        _req(a["tau"] > 0 and a["lam"] >= 0, "proposed needs tau > 0 and lam >= 0")
    if a["method"] == "fltrust":
        _req(a["root_size"] >= 1, "FLTrust needs root_size >= 1")
    _req(cfg["integrity"]["mode"] in INTEGRITY_MODES, "bad integrity mode")
    cp = float(cfg["integrity"].get("corrupt_p", 0.0))
    _req(0.0 <= cp <= 1.0, "integrity.corrupt_p in [0, 1]")
    _req(not (cp > 0 and cfg["integrity"]["mode"] == "off"), "corruption injection needs a simulated transport")
    m = cfg.get("mia", {}) or {}
    if m.get("enabled"):
        _req(0 < float(m.get("pool_fraction", 0.1)) <= 0.5, "mia.pool_fraction in (0, 0.5]")
        _req(0 < float(m.get("inclusion_p", 0.5)) < 1, "mia.inclusion_p in (0, 1)")
    return cfg


def n_malicious(cfg: Dict[str, Any]) -> int:
    atk = cfg["attack"]
    if atk["type"] == "none":
        return 0
    if atk["type"] == "sybil":
        return int(atk["sybil_k"])
    return int(round(atk["fraction"] * cfg["partition"]["n_clients"]))


def resolve_placeholders(obj: Any, selections: Dict[str, Any]) -> Any:
    """Replace strings of the form '${sel:<file>.<dotted.key>}' with values from selection files.
    Missing selection => ConfigError (the downstream phase cannot run before its selection exists)."""
    if isinstance(obj, dict):
        return {k: resolve_placeholders(v, selections) for k, v in obj.items()}
    if isinstance(obj, list):
        return [resolve_placeholders(v, selections) for v in obj]
    if isinstance(obj, str) and obj.startswith("${sel:") and obj.endswith("}"):
        ref = obj[6:-1]
        file_key, _, dotted = ref.partition(".")
        if file_key not in selections:
            raise ConfigError(f"placeholder {obj} needs selection file '{file_key}.json' which does not exist yet. "
                              "Run the selection step (Phase 5a / Phase 7 tau-selection) first.")
        return get_dotted(selections[file_key], dotted)
    return obj


def iter_grid(grid: Dict[str, Iterable]) -> Iterable[Dict[str, Any]]:
    """Cartesian product over dotted keys, in declared order."""
    import itertools
    keys = list(grid.keys())
    for vals in itertools.product(*[list(grid[k]) for k in keys]):
        yield dict(zip(keys, vals))
