# End-to-end notebook execution (software check, 2026-11-05)

`RUN_COMPLETE_FEDKGE_RESEARCH.ipynb` was executed cell by cell, as written, by `nb_harness.py` on the release
candidate zip of commit `1bffa87`. The final commit `e55400b` changes one documentation line (FINAL_METHODOLOGY.md);
the delivered notebook expects that commit, and the final zip was run through Steps 1-2 as well. After the settings cell, only the
software-check switches were overridden: smoke tier, CPU, a local folder in place of Drive, the recorded licence
note, and `RUN_CPU_CHECKS = True` (to exercise Appendix B).

* `cell_report.json`: 14 / 14 code cells OK (Steps 1-9, Appendix A, Appendix B: 184 tests passed).
* `PROGRESS.md`: after the run, 0 research runs (tune / final tiers) are complete - smoke runs never count.
* `notebook_run_log_without_round_lines.log`: the output, without the per-round training lines.

Not evidence: every number produced in this run is a smoke-tier software check on 3,000-triple subsets.
