"""Pre-registered hypothesis families and descriptive paired comparisons (10_configs/hypotheses.yaml; Phase B 03
sections 12-13; owner decision B5 for the H2b non-inferiority procedure).

Input: the COMPLETE, current runs of the final tier (analysis.collect), the frozen Stage-3 selections, and a callable
that returns a run's environment record (env.json). Output: one record per family member with its estimate, interval,
effect size, one-sided p, Holm-adjusted p and a decision label. Nothing is imputed:
  * a member whose arms lack runs or seeds is MISSING_RUNS and enters Holm with p = 1 (the family is then marked
    PROVISIONAL: its Holm adjustment is not final until every member is computed);
  * a member whose pre-registered gate is not met is NOT_TESTABLE (p = 1), never dropped;
  * a member whose runs come from more than one environment (GPU type, torch, CUDA, device) is INVALID (p = 1);
  * a decision is SUPPORTED only if the Holm-adjusted one-sided p <= alpha. Otherwise it is NOT SUPPORTED, which means
    'inconclusive at this level' - failing to reject H0 never shows the opposite claim;
  * for H2b (non-inferiority, margin 0.95 on the ratio scale) a point estimate above the margin is never evidence;
  * results from any tier other than 'final' are labelled NOT EVIDENCE.
"""
from __future__ import annotations

from typing import Callable, Dict, List, Optional

import numpy as np
import pandas as pd
from scipy import stats as st

from .io import IntegrityError
from .stats import holm_family, log_ratio_test, one_sided_t, paired, robustness_contrast, summarize

EVIDENCE_TIER = "final"
DATASETS = ("fb15k237", "wn18rr", "codex_m")
ENV_KEYS = ("device", "gpu", "torch", "cuda")


def _arm(runs: pd.DataFrame, spec: Dict, ds: str) -> pd.DataFrame:
    if runs is None or runs.empty:
        return pd.DataFrame()
    g = runs[(runs["block"] == spec["block"]) & (runs["dataset"] == ds)]
    for k, v in (spec.get("where") or {}).items():
        if k not in g.columns:
            return g.iloc[0:0]
        g = g[g[k].isna()] if v is None else g[g[k] == v]
    return g


def _by_seed(g: pd.DataFrame, metric: str) -> Dict[int, float]:
    if g.empty or metric not in g.columns:
        return {}
    if g["seed"].duplicated().any():
        raise IntegrityError(f"more than one run per seed in one arm ({sorted(g['run_id'])[:4]})")
    return {int(s): float(v) for s, v in zip(g["seed"], g[metric]) if pd.notna(v)}


def _env_signature(env: Optional[Dict], device: Optional[str]) -> tuple:
    env = env or {}
    return (device, env.get("gpu"), env.get("torch"), env.get("cuda"))


def _homogeneous(groups: List[pd.DataFrame], env_of: Optional[Callable]) -> Optional[str]:
    """None if every run of the member shares one environment; otherwise a description of the mix."""
    if env_of is None:
        return None
    sigs = set()
    for g in groups:
        for _, r in g.iterrows():
            sigs.add(_env_signature(env_of(r["run_id"]), r.get("runtime.device")))
    return None if len(sigs) <= 1 else f"{len(sigs)} environments: {sorted(map(str, sigs))[:3]}"


def _missing(arms: Dict[str, Dict[int, float]], seeds: List[int]) -> List[str]:
    out = []
    for name, a in arms.items():
        miss = sorted(set(seeds) - set(a))
        if miss:
            out.append(f"{name} missing seeds {miss}")
        extra = sorted(set(a) - set(seeds))
        if extra:
            out.append(f"{name} has seeds outside the pre-registered set {extra}")
    return out


def _restrict(a: Dict[int, float], seeds: List[int]) -> Dict[int, float]:
    return {s: a[s] for s in seeds if s in a}


def _base(family: str, member: str, ds: str, attack: Optional[str] = None) -> Dict:
    return {"family": family, "member": member, "dataset": ds, "attack": attack}


def _t_ci(x: np.ndarray) -> List[float]:
    n = len(x)
    if n < 2:
        return [float("nan"), float("nan")]
    half = float(st.t.ppf(0.975, n - 1) * x.std(ddof=1) / np.sqrt(n))
    return [float(x.mean() - half), float(x.mean() + half)]


def _dz(x: np.ndarray) -> float:
    sd = x.std(ddof=1) if len(x) > 1 else float("nan")
    return float(x.mean() / sd) if sd and np.isfinite(sd) and sd > 0 else float("nan")


# ------------------------------------------------------------------------------------------------ the families
def _ratio_member(fam: str, spec: Dict, runs, ds, seeds, metric, env_of) -> Dict:
    rec = _base(fam, ds, ds)
    num, den = _arm(runs, spec["numerator"], ds), _arm(runs, spec["denominator"], ds)
    x, y = _restrict(_by_seed(num, metric), seeds), _restrict(_by_seed(den, metric), seeds)
    rec["arms"] = {"numerator": spec["numerator"], "denominator": spec["denominator"],
                   "run_ids": {"numerator": sorted(num["run_id"]) if len(num) else [],
                               "denominator": sorted(den["run_id"]) if len(den) else []}}
    miss = _missing({"numerator": x, "denominator": y}, seeds)
    if miss:
        return {**rec, "status": "MISSING_RUNS", "reason": "; ".join(miss), "p_one_sided": None}
    mix = _homogeneous([num, den], env_of)
    if mix:
        return {**rec, "status": "INVALID_MIXED_ENVIRONMENT", "reason": mix, "p_one_sided": None}
    if min(min(x.values()), min(y.values())) <= 0:
        return {**rec, "status": "NOT_TESTABLE", "reason": "a metric value is 0 (log-ratio undefined)",
                "p_one_sided": None}
    thr = float(spec["threshold"])
    res = log_ratio_test(x, y, thr)
    lr = np.log(np.array([x[s] for s in res["seeds"]]) / np.array([y[s] for s in res["seeds"]]))
    rec.update({"status": "TESTED", "n_pairs": res["n"], "seeds": res["seeds"], "threshold": thr,
                "estimate": {"ratio_geo_mean": res["ratio_geo_mean"], "ratio_ci95": res["ratio_ci95"],
                             "ratio_lower_one_sided_97_5": float(np.exp(np.log(thr) + res["bound_97_5"])),
                             "per_seed_ratio": {int(s): float(np.exp(v)) for s, v in zip(res["seeds"], lr)},
                             "mean_numerator": float(np.mean(list(x.values()))),
                             "mean_denominator": float(np.mean(list(y.values())))},
                "effect_size_dz": _dz(lr - np.log(thr)), "t": res["t"], "p_one_sided": res["p_one_sided"]})
    return rec


def _h2_member(spec: Dict, att: str, aspec: Dict, runs, ds, seeds, env_of) -> Dict:
    rec = _base("H2", f"{ds}:{att}", ds, att)
    metric = aspec.get("delta_metric", "test.mrr")
    groups = {"fedavg_clean": _arm(runs, spec["fedavg_clean"], ds), "fedavg_attacked": _arm(runs, aspec["fedavg"], ds),
              "method_clean": _arm(runs, spec["method_clean"], ds), "method_attacked": _arm(runs, aspec["method"], ds)}
    vals = {k: _restrict(_by_seed(g, metric), seeds) for k, g in groups.items()}
    rec["arms"] = {"metric": metric, "run_ids": {k: sorted(g["run_id"]) if len(g) else [] for k, g in groups.items()}}
    miss = _missing(vals, seeds)
    if miss:
        return {**rec, "status": "MISSING_RUNS", "reason": "; ".join(miss), "p_one_sided": None}
    mix = _homogeneous(list(groups.values()), env_of)
    if mix:
        return {**rec, "status": "INVALID_MIXED_ENVIRONMENT", "reason": mix, "p_one_sided": None}
    sgn = 1.0 if aspec.get("delta_direction", "decrease") == "increase" else -1.0   # Delta >= 0 means damage
    dF = {s: sgn * (vals["fedavg_attacked"][s] - vals["fedavg_clean"][s]) for s in seeds}
    dP = {s: sgn * (vals["method_attacked"][s] - vals["method_clean"][s]) for s in seeds}
    res = robustness_contrast(dF, dP, float(spec["keep"]))
    aF, aP = np.array([dF[s] for s in seeds]), np.array([dP[s] for s in seeds])
    c = float(spec["keep"]) * aF - aP
    rec.update({"n_pairs": len(seeds), "seeds": list(seeds), "delta_definition":
                ("increase in target success (Hits@10 of the 50 targets)" if sgn > 0 else "clean - attacked test MRR"),
                "estimate": {"mean_delta_fedavg": res["mean_delta_fedavg"], "delta_fedavg_ci95": _t_ci(aF),
                             "mean_delta_method": res["mean_delta_method"], "delta_method_ci95": _t_ci(aP),
                             "E_ratio_of_means": res["E_ratio_of_means"], "contrast_mean": float(c.mean()),
                             "contrast_ci95": _t_ci(c),
                             "attack_effective_lower_97_5": res["attack_effective_bound_97_5"]},
                "effect_size_dz": _dz(c)})
    if not res["testable"]:
        return {**rec, "status": "NOT_TESTABLE", "reason": "attack not effective against FedAvg (one-sided lower "
                "97.5 % bound of mean Delta_FedAvg <= 0)", "p_one_sided": None}
    return {**rec, "status": "TESTED", "p_one_sided": res["p_one_sided"]}


def _h3_member(spec: Dict, runs, ds, seeds, env_of) -> Dict:
    rec = _base("H3", ds, ds)
    metric = spec["metric"]
    g_np, g_dp = _arm(runs, spec["np_arm"], ds), _arm(runs, spec["dp_arm"], ds)
    a_np = {s: v - 0.5 for s, v in _restrict(_by_seed(g_np, metric), seeds).items()}
    a_dp = {s: v - 0.5 for s, v in _restrict(_by_seed(g_dp, metric), seeds).items()}
    rec["arms"] = {"metric": metric, "run_ids": {"np": sorted(g_np["run_id"]) if len(g_np) else [],
                                                 "dp_eps4": sorted(g_dp["run_id"]) if len(g_dp) else []}}
    miss = _missing({"np": a_np, "dp_eps4": a_dp}, seeds)
    if miss:
        return {**rec, "status": "MISSING_RUNS", "reason": "; ".join(miss), "p_one_sided": None}
    all_m1 = runs[(runs["block"] == spec["dp_arm"]["block"]) & (runs["dataset"] == ds)] if len(runs) else runs
    if "mia.lower_bound_exceeds_accountant" in all_m1.columns and \
            all_m1["mia.lower_bound_exceeds_accountant"].fillna(False).astype(bool).any():
        return {**rec, "status": "BLOCKED_RED_LINE", "reason": "an empirical epsilon lower bound exceeds the "
                "accountant's epsilon in a DP audit run: investigate the implementation before using H3",
                "p_one_sided": None}
    mix = _homogeneous([g_np, g_dp], env_of)
    if mix:
        return {**rec, "status": "INVALID_MIXED_ENVIRONMENT", "reason": mix, "p_one_sided": None}
    anp, adp = np.array([a_np[s] for s in seeds]), np.array([a_dp[s] for s in seeds])
    gate = one_sided_t(anp, "greater")
    c = adp - float(spec["factor"]) * anp
    rec.update({"n_pairs": len(seeds), "seeds": list(seeds),
                "estimate": {"mean_advantage_np": float(anp.mean()), "advantage_np_ci95": _t_ci(anp),
                             "mean_advantage_dp_eps4": float(adp.mean()), "advantage_dp_ci95": _t_ci(adp),
                             "relative_reduction": float(1 - adp.mean() / anp.mean()) if anp.mean() != 0 else None,
                             "contrast_mean": float(c.mean()), "contrast_ci95": _t_ci(c),
                             "leakage_lower_97_5": gate["bound_97_5"]},
                "effect_size_dz": _dz(c)})
    if not gate["bound_97_5"] > 0:
        return {**rec, "status": "NOT_TESTABLE", "reason": "no measurable leakage in the non-private arm (one-sided "
                "lower 97.5 % bound of mean(AUC - 0.5) <= 0)", "p_one_sided": None}
    res = one_sided_t(c, "less")
    return {**rec, "status": "TESTED", "t": res["t"], "p_one_sided": res["p_one_sided"]}


def _hs_member(spec: Dict, runs, ds, seeds, metric, schedule: Optional[Dict], env_of) -> Dict:
    rec = _base("HS", ds, ds)
    rec["selected_schedule"] = schedule
    if schedule is not None and schedule.get("shape") == "fixed":
        return {**rec, "status": "NOT_TESTABLE", "reason": "the selected schedule s* is fixed (DP2 = DP1)",
                "p_one_sided": None}
    ga, gb = _arm(runs, spec["a"], ds), _arm(runs, spec["b"], ds)
    a, b = _restrict(_by_seed(ga, metric), seeds), _restrict(_by_seed(gb, metric), seeds)
    rec["arms"] = {"run_ids": {"s_star": sorted(ga["run_id"]) if len(ga) else [],
                               "fixed": sorted(gb["run_id"]) if len(gb) else []}}
    miss = _missing({"selected_schedule": a, "fixed_schedule": b}, seeds)
    if miss:
        return {**rec, "status": "MISSING_RUNS", "reason": "; ".join(miss), "p_one_sided": None}
    mix = _homogeneous([ga, gb], env_of)
    if mix:
        return {**rec, "status": "INVALID_MIXED_ENVIRONMENT", "reason": mix, "p_one_sided": None}
    d = np.array([a[s] - b[s] for s in seeds])
    res = one_sided_t(d, "greater")
    return {**rec, "status": "TESTED", "n_pairs": len(seeds), "seeds": list(seeds),
            "estimate": {"mean_difference": float(d.mean()), "difference_ci95": _t_ci(d),
                         "lower_one_sided_97_5": res["bound_97_5"]},
            "effect_size_dz": _dz(d), "t": res["t"], "p_one_sided": res["p_one_sided"]}


def _decide(members: List[Dict], alpha: float, tier: str, family: str, spec: Dict) -> Dict:
    pmap = {m["member"]: (m["p_one_sided"] if m["status"] == "TESTED" else None) for m in members}
    holm = holm_family(pmap, alpha)
    complete = all(m["status"] != "MISSING_RUNS" for m in members)
    for m in members:
        h = holm[m["member"]]
        m["p_holm"] = h["p_holm"]
        m["alpha"] = alpha
        if m["status"] == "TESTED":
            m["verdict"] = "SUPPORTED" if h["reject"] else "NOT_SUPPORTED"
            if h["reject"]:
                m["decision"] = "SUPPORTED"
            else:
                m["decision"] = f"NOT SUPPORTED (inconclusive at one-sided alpha = {alpha}, Holm)"
            if family == "H2b":
                up = m["estimate"]["ratio_ci95"][1]
                if np.isfinite(up) and up < float(spec["threshold"]):
                    m["decision"] += "; the whole 95 % interval lies below the non-inferiority margin"
        elif m["status"] == "NOT_TESTABLE":
            m["verdict"] = "NOT_TESTABLE"
            m["decision"] = f"NOT TESTABLE ({m['reason']}); enters Holm with p = 1"
        elif m["status"] == "MISSING_RUNS":
            m["verdict"] = "PENDING"
            m["decision"] = "PENDING (runs missing); enters Holm with p = 1 until computed"
        else:
            m["verdict"] = m["status"]
            m["decision"] = f"{m['status']} ({m['reason']}); enters Holm with p = 1"
        if tier != EVIDENCE_TIER:
            m["decision"] = f"NOT EVIDENCE ({tier} tier): " + m["decision"]
        m["evidence"] = tier == EVIDENCE_TIER
    all_supported = complete and all(m.get("verdict") == "SUPPORTED" for m in members)
    return {"family": family, "claim": spec["claim"], "n_members": len(members), "complete": complete,
            "holm_status": "FINAL" if complete else "PROVISIONAL (incomplete family)",
            "holds_on_every_member": all_supported, "members": members}


def evaluate_hypotheses(runs: pd.DataFrame, hyp: Dict, selections: Dict, tier: str,
                        env_of: Optional[Callable] = None, datasets=DATASETS) -> Dict:
    """All pre-registered families, in the pre-registered member order (family size fixed in advance)."""
    seeds = [int(s) for s in hyp["seed_set"]]
    alpha = float(hyp["alpha_one_sided"])
    metric = hyp["metric"]
    F = hyp["families"]
    out = {"tier": tier, "evidence": tier == EVIDENCE_TIER, "alpha_one_sided": alpha, "correction": hyp["correction"],
           "metric": metric, "seed_set": seeds, "families": {}}
    for fam in ("H1", "H2b"):
        members = [_ratio_member(fam, F[fam], runs, ds, seeds, metric, env_of) for ds in datasets]
        out["families"][fam] = _decide(members, alpha, tier, fam, F[fam])
    members = [_h2_member(F["H2"], att, aspec, runs, ds, seeds, env_of)
               for ds in datasets for att, aspec in F["H2"]["attacks"].items()]
    out["families"]["H2"] = _decide(members, alpha, tier, "H2", F["H2"])
    members = [_h3_member(F["H3"], runs, ds, seeds, env_of) for ds in datasets]
    out["families"]["H3"] = _decide(members, alpha, tier, "H3", F["H3"])
    members = [_hs_member(F["HS"], runs, ds, seeds, metric,
                          ((selections.get(ds) or {}).get("T3") or {}).get("dp", {}).get("schedule"), env_of)
               for ds in datasets]
    out["families"]["HS"] = _decide(members, alpha, tier, "HS", F["HS"])
    return out


def hypotheses_table(res: Dict) -> pd.DataFrame:
    rows = []
    for fam, f in res["families"].items():
        for m in f["members"]:
            est = m.get("estimate") or {}
            key = {"H1": "ratio_geo_mean", "H2b": "ratio_geo_mean", "H2": "E_ratio_of_means",
                   "H3": "relative_reduction", "HS": "mean_difference"}[fam]
            ci = {"H1": "ratio_ci95", "H2b": "ratio_ci95", "H2": "contrast_ci95", "H3": "contrast_ci95",
                  "HS": "difference_ci95"}[fam]
            rows.append({"family": fam, "member": m["member"], "dataset": m["dataset"], "attack": m.get("attack"),
                         "status": m["status"], "n_pairs": m.get("n_pairs"), "estimate_name": key,
                         "estimate": est.get(key), "ci95_name": ci, "ci95_low": (est.get(ci) or [None, None])[0],
                         "ci95_high": (est.get(ci) or [None, None])[1], "effect_size_dz": m.get("effect_size_dz"),
                         "p_one_sided": m.get("p_one_sided"), "p_holm": m.get("p_holm"), "verdict": m.get("verdict"),
                         "decision": m.get("decision"),
                         "family_holm_status": f["holm_status"]})
    return pd.DataFrame(rows)


# ------------------------------------------------------------------------------------------------ descriptive
def paired_descriptive(runs: pd.DataFrame, a: Dict, b: Dict, ds: str, metric: str = "test.mrr",
                       label: str = "") -> Dict:
    """Paired (common seeds) difference a - b with 95 % t-interval and the log-ratio. DESCRIPTIVE: never a test."""
    ga, gb = _arm(runs, a, ds), _arm(runs, b, ds)
    x, y = _by_seed(ga, metric), _by_seed(gb, metric)
    common = sorted(set(x) & set(y))
    rec = {"comparison": label, "dataset": ds, "a": a, "b": b, "metric": metric, "n_pairs": len(common),
           "seeds": common, "descriptive_only": True}
    if len(common) < 2:
        return {**rec, "status": "INSUFFICIENT_PAIRS"}
    pr = paired([x[s] for s in common], [y[s] for s in common], common, common)
    out = {**rec, "status": "COMPUTED", "mean_a": float(np.mean([x[s] for s in common])),
           "mean_b": float(np.mean([y[s] for s in common])), "mean_diff": pr["mean_diff"],
           "diff_ci95": [pr["ci95_low"], pr["ci95_high"]], "d_z": pr["d_z"]}
    if all(x[s] > 0 and y[s] > 0 for s in common):
        lr = np.log(np.array([x[s] for s in common]) / np.array([y[s] for s in common]))
        lo, hi = _t_ci(lr)
        out.update({"ratio_geo_mean": float(np.exp(lr.mean())), "ratio_ci95": [float(np.exp(lo)), float(np.exp(hi))]})
    return out


def descriptive_comparisons(runs: pd.DataFrame, datasets=DATASETS) -> pd.DataFrame:
    """The descriptive questions of Phase B 03 section 13.5 that are answerable from the reduced Stage 4."""
    eps4 = {"cfg.dp.target_epsilon": 4.0}
    comps = [("federation cost: FedAvg vs centralised (non-private)", {"block": "N2"}, {"block": "N1"}),
             ("privacy cost: complete method (eps* = 4) vs FedAvg non-private", {"block": "R1p"}, {"block": "N2"}),
             ("DP cost: DP-FedAvg (eps* = 4, s*) vs FedAvg non-private", {"block": "DP2", "where": eps4}, {"block": "N2"}),
             ("schedule inside the method: R1p (s*) vs R1q (fixed sigma)", {"block": "R1p"}, {"block": "R1q"}),
             ("DP3-a settings only (no clip, no noise) vs FedAvg non-private",
              {"block": "DP3", "where": {"cfg.dp.clip": None}}, {"block": "N2"}),
             ("DP3-b clipping only vs DP3-a settings only", {"block": "DP3", "where": {"cfg.dp.clip_is_set": True}},
              {"block": "DP3", "where": {"cfg.dp.clip": None}}),
             ("noise: DP-FedAvg (eps* = 4, s*) vs DP3-b clipping only", {"block": "DP2", "where": eps4},
              {"block": "DP3", "where": {"cfg.dp.clip_is_set": True}})]
    for alpha in ("0.5", "1.0", "iid"):
        w = {"cfg.partition.scheme": "iid"} if alpha == "iid" else {"cfg.partition.scheme": "dirichlet_relation",
                                                                   "cfg.partition.alpha": float(alpha)}
        comps.append((f"heterogeneity: FedAvg non-private at {'IID' if alpha == 'iid' else 'alpha = ' + alpha} vs "
                      "alpha = 0.1", {"block": "N3", "where": w}, {"block": "N2"}))
    for agg in ("trimmed_mean", "median", "krum", "fltrust"):
        comps.append((f"clean utility: {agg} vs the proposed rule (both eps* = 4)",
                      {"block": "R1", "where": {"cfg.aggregation.method": agg}}, {"block": "R1p"}))
    rows = []
    r = runs.copy()
    if len(r) and "cfg.dp.clip" in r.columns:
        r["cfg.dp.clip_is_set"] = r["cfg.dp.clip"].notna()
    for ds in datasets:
        for lab, a, b in comps:
            rows.append(paired_descriptive(r, a, b, ds, label=lab))
    return pd.DataFrame(rows)
