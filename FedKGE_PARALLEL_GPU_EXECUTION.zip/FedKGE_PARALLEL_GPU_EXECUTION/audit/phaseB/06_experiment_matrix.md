# 06 — Baseline, ablation and threshold-sweep matrix (Phase B, item 6)

**Status:** design draft. Nothing has run.
- Machine-readable: `data/experiment_matrix.csv` (one row per block), `drafts/experiment_matrix_draft.yaml` (input for Phase C) and `data/threshold_inventory.csv`.
- Run counts and costs come from `scripts/phaseB_experiment_matrix.py`. The tables below are generated from the same CSV.
- **Naming:** blocks are P2.x, T, L, N, DP, R, I, M, X, O. The DP blocks are DP1, DP1h, DP2, DP2h and DP3; "D1–D18" always means a *decision* (`02`).

## 1. Structure

| Stage | Purpose | Seeds | Evidence? |
|---|---|---|---|
| 0 | Unit and integration tests, including the 26 PyTorch tests not yet run | – | no (software check) |
| 1 | Smoke: every block on 3,000-triple subsets, 3 rounds | 42 | **no**, watermarked `NOT_FOR_MANUSCRIPT` |
| 2 | Pilot / dev gate: timings, sanity, first DP look | 1001 | no |
| 3 | Tuning and selection on **validation only**, under pre-registered rules | 1001 | no (selection only) |
| 4 | Confirmatory core, with selections frozen | S5 for every block that carries a hypothesis test; S10 for the headline blocks in the full profile; S3 for blocks labelled descriptive | **yes** (hypothesis blocks); descriptive otherwise |
| 5 | Extended / sensitivity, labelled as such; optional O1 | S3 (O1: S5) | descriptive only (no pre-registered hypothesis) |

**Profiles** (D18):
- **reduced (recommended first):** every hypothesis block at 5 seeds (S5); descriptive blocks at 3 seeds (S3); smaller sensitivity grids; the S10x extension blocks (DP1h, DP2h) dropped.
- **full:** the headline hypothesis blocks at 10 seeds (S10); larger grids.

**Run totals** (three datasets with CoDEx-M; `data/run_counts.csv`):

| Tier | Full profile | Reduced profile |
|---|---|---|
| Core, Stages 2–4 | 1,485 runs | 837 runs |
| MIA audit M1 (only if D6 keeps H3; 5 seeds in both profiles) | 60 | 60 |
| Extended (Stage 5) | 594 | 432 |
| Optional (O1) | 15 | 15 |

**The complete method** (`03` §0) is the whole pipeline with every component active:
- DP at ε* = 4 with the sampling design (D11), sampling rate q*, clip C*, learning rate lr*, rounds R* and noise schedule s* selected in Stage 3;
- the proposed trust aggregation (`03` §8.3; variant V1 only if its D15 trigger fires) with the selected τ*;
- integrity verification in the data path (`03` §9).

Every robustness block uses the complete method's DP configuration and changes **only** the aggregator or the attack, so the comparisons are clean ablations.

## 2. Baselines vs ablations (master prompt §13)

**Baselines** are different methods or references, compared with the complete method:

| # (master prompt §13) | Comparison | Block(s) |
|---|---|---|
| 1 | Centralised non-private KGE reference | N1 |
| 2 | Federated non-private KGE (FedAvg) | N2 (α = 0.1), N3 (α = 0.5, 1.0, IID) |
| 3 | Federated KGE with DP, without trust (standard DP-SGD + FedAvg; **the DP baseline**) | DP1 (fixed σ), DP2 (selected schedule s*; equals DP1 if s* = fixed) |
| 8 | Alternative aggregation: trimmed mean, median, Krum, FLTrust | R1 (clean), R4 (attacks) |
| 9 | External DP baseline | none reproducible (D17); O1 is a DP-Flames-*inspired* policy, labelled "not a reproduction" |
| – | Local-only training (value of federating) | X6 |
| – | The original method (historical) | L0–L4 (FB15k-237 only) |

**Ablations** remove one component *from the complete method*:

| # (master prompt §13) | Remove | Block(s) | Note |
|---|---|---|---|
| 4 | DP (keep trust) | R5, R5a | the trust rule without DP, clean and attacked |
| 5 | — (the complete method itself) | R1p (clean), R3/R3a (attacked) | |
| 6 | Integrity verification | I1 (off, no corruption), I2 (corruption in transit, on vs off) | utility is identical when nothing is corrupted (by construction) |
| 7 | Poisoning defence (= trust rule) | R2, R2a (FedAvg under the same attacks and DP settings); DP2 at ε* = 4 (clean) | |
| – | Noise schedule | R1q (fixed σ inside the complete method); DP1 vs DP2 (inside FedAvg) | skipped if s* = fixed |
| – | Decomposing the DP cost | DP3 (DP settings without noise or clipping; clipping only) | |

**What may be claimed.**
- A component is claimed to help **only** through a pre-registered hypothesis (`03` §13: H1, H2, H2b, H3, HS), tested one-sided at α = 0.025 with Holm correction within its family.
- Every other comparison is **descriptive**: it reports the paired, seed-level difference with its 95 % interval and is never called significant. One run scoring higher is never evidence.

## 3. Block-level matrix

Datasets: ALL3 = FB15k-237, WN18RR and the third dataset (D5); FB = FB15k-237 only.

Seed sets:
- S_TUNE = {1001} (selection only);
- S1 = {42};
- S3 = {42, 123, 256} (descriptive blocks; a subset of S5, so still paired);
- S5 = {42, 123, 256, 512, 1024} (the roadmap seeds; every hypothesis block);
- S10x = {2048, 4096, 8192, 16384, 32768} (full-profile extension only);
- S10 = S5 ∪ S10x.

DP1h and DP2h run only the S10x seeds at ε* = 4, so that DP1 + DP1h and DP2 + DP2h give 10 seeds for the headline comparisons without repeating any run.

| Block | Stage | Tier | Datasets | Cells / dataset | Seeds (full → reduced) | Runs (full → reduced) | Factors | Answers | Tables |
|---|---|---|---|---|---|---|---|---|---|
| P2.1 | 2 | core | ALL3 | 2 | S_TUNE | 6 | centralised + FedAvg(alpha=0.1); revision defaults (lr 1e-3, B 512) | seconds/round, memory, non-private sanity range | 11 |
| P2.2 | 2 | core | ALL3 | 1 | S_TUNE | 3 | DP eps*=4, fixed sigma, design A (B=512, per-client sigma), C=1, lr 1e-3, R=100 | DP seconds/round; first look at DP utility with the revision's settings | 11 |
| P2.3 | 2 | core | FB | 2 | S_TUNE | 2 | DP eps*=4, design Q (common sampling rate) q in {0.02, 0.10} | design A vs Q on FB | 11 |
| T1 | 3 | core | ALL3 | 12 | S_TUNE | 36 | {centralised, FedAvg alpha=0.1} x lr{1e-3,3e-3,1e-2} x B{512,4096} | fair non-private settings (same tuning budget as DP) | 8 |
| T2a | 3 | core | ALL3 | 9 | S_TUNE | 27 | eps*=4 fixed sigma; q{0.02,0.05,0.10} x lr{1e-3,3e-3,1e-2}; C=1; FedAvg alpha=0.1 | main legitimate DP-utility levers (sampling rate / batch, learning rate) | 8 |
| T2b | 3 | core | ALL3 | 4 | S_TUNE | 12 | C{0.25,0.5,2,4} at the selected (q, lr) (C=1 comes from T2a) | clipping threshold | 8 |
| T2c | 3 | core | ALL3 | 1 | S_TUNE | 3 | R=50 (sigma recalibrated) vs R=100 at the selected settings | training length at fixed eps | 8 |
| T2d | 3 | core | ALL3 | 1 | S_TUNE | 3 | design A (B=512, per-client sigma) at the selected lr and C | sampling design (decision D11) | 8 |
| T3 | 3 | core | ALL3 | 6 | S_TUNE | 18 | {linear, exponential, cosine} x rho{0.25,0.5} at eps*=4; all R rounds executed | schedule selection s* for the 'adaptive DP' claim | 8 |
| L0 | 4 | core | FB | 1 | S1 | 1 | saved legacy Phase 3 model, corrected evaluation; no training | old model under the new protocol | 13 |
| L1 | 4 | core | FB | 1 | S5 | 5 | exact old Phase 3 (5 relation-disjoint clients, 1 negative, 3 local epochs, 50 rounds) | reproduce 0.2858 under the legacy protocol; spread across seeds | 13 |
| L2 | 4 | core | FB | 1 | S5 | 5 | old 5-client partition, corrected trainer + evaluation | partition effect vs trainer/evaluation effect | 13 |
| L3 | 4 | core | FB | 1 | S5 | 5 | exact old Phase 4 (sigma=1, B=256, naive-sum stop) | reproduce 0.009 | 13 |
| L4 | 4 | core | FB | 3 | S5 | 15 | ladder L1 legacy mechanism, L2 trainer fixed, L3 formal accounting (main partition) | why the old DP model collapsed | 6,13 |
| N1 | 4 | core | ALL3 | 1 | S10 → S5 | 30 → 15 | centralised TransE, selected non-private settings | H1 reference | 3,4 |
| N2 | 4 | core | ALL3 | 1 | S10 → S5 | 30 → 15 | FedAvg, Dirichlet alpha=0.1 | federation cost; DP-cost reference | 3,4,5 |
| N3 | 4 | core | ALL3 | 3 | S5 | 45 | alpha{0.5,1.0} + IID | heterogeneity effect | 2,3 |
| DP1 | 4 | core | ALL3 | 4 | S5 | 60 | FedAvg + DP, fixed sigma, eps*{1,2,4,8} (= 'DP without trust' baseline) | privacy-utility curve; fixed arm of HS | 6,7 |
| DP1h | 4 | core | ALL3 | 1 → 0 | S10x → dropped | 15 → 0 | eps*=4 fixed sigma with seeds 2048..32768 (completes 10 seeds) | headline HS fixed arm | 5,12 |
| DP2 | 4 | core | ALL3 | 4 → 1 | S5 | 60 → 15 | FedAvg + DP with the selected schedule s* at eps*{1,2,4,8} (reduced: eps*=4 only; equals DP1 if s* = fixed) | schedule effect at equal eps; clean FedAvg reference of H2/H2b | 3,5,7 |
| DP2h | 4 | core | ALL3 | 1 → 0 | S10x → dropped | 15 → 0 | s* at eps*=4 with seeds 2048..32768 | headline HS / H2 reference | 5,12 |
| DP3 | 4 | core | ALL3 | 2 | S5 → S3 | 30 → 18 | DP training settings without noise or clipping; clipping only (sigma=0) | settings vs clipping vs noise share of the DP cost | 5 |
| R1 | 4 | core | ALL3 | 4 | S5 → S3 | 60 → 36 | complete-method DP config, no attack: trimmed mean (beta 0.2), median, Krum (f 2), FLTrust; robustness parameters at the design value f = 0.2 | clean utility and false-positive rate of baselines | 4,9 |
| R1p | 4 | core | ALL3 | 1 | S10 → S5 | 30 → 15 | complete method, no attack | main result row; benign FPR | 3,4,5,9 |
| R1q | 4 | core | ALL3 | 1 | S5 | 15 | complete method with fixed sigma (skipped if s* = fixed) | schedule ablation inside the method | 5 |
| R2 | 4 | core | ALL3 | 6 | S10 → S5 | 180 → 90 | complete-method DP config with FedAvg; f=0.2; gaussian, signflip, ALIE, IPM, KG-targeted, Sybil | attack impact without defence (= complete method minus defence) | 5,9 |
| R2a | 4 | core | ALL3 | 1 | S10 → S5 | 30 → 15 | FedAvg receiving the adaptive update crafted against the proposed rule | paired no-defence reference for the adaptive attack | 9 |
| R3 | 4 | core | ALL3 | 6 | S10 → S5 | 180 → 90 | complete method; the same 6 attacks | defence effectiveness | 9 |
| R3a | 4 | core | ALL3 | 1 | S10 → S5 | 30 → 15 | complete method; adaptive gray-box attack tailored to the rule | robustness against an attacker who knows the rule | 9 |
| R4 | 4 | core | ALL3 | 24 → 16 | S5 → S3 | 360 → 144 | {trimmed mean, median, Krum, FLTrust} x 6 attacks (reduced: signflip, ALIE, IPM, KG-targeted) | comparison with established defences | 4,9 |
| R5 | 4 | core | ALL3 | 7 | S5 → S3 | 105 → 63 | no DP: FedAvg x{signflip, ALIE, KG-targeted}; proposed x{clean, signflip, ALIE, KG-targeted} | trust without DP (ablation) | 5,9 |
| R5a | 4 | core | ALL3 | 1 | S5 → S3 | 15 → 9 | no DP: proposed x adaptive | trust without DP vs adaptive | 5,9 |
| I1 | 4 | core | ALL3 | 2 | S3 | 18 | integrity OFF for {non-private FedAvg, complete method} (ON runs exist in N2/R1p) | integrity overhead; utility identical when nothing is tampered | 10,11 |
| I2 | 4 | core | ALL3 | 4 → 2 | S3 | 36 → 18 | complete method; transmitted bytes corrupted in transit, p_tamper{0.01,0.1} x integrity{on,off} | what verification buys (rejects corrupted updates); NOT a poisoning defence | 10 |
| M1 | 4 | decision-D6 | ALL3 | 4 | S5 | 60 | audit pool per client, each candidate included with probability 1/2; FedAvg non-private and eps*{1,4,8} | empirical membership leakage (H3, only if retained); one-run audit | 6,7 |
| X1 | 5 | extended | ALL3 | 12 → 6 | S3 | 108 → 54 | FedAvg + DP: alpha{0.5,1.0,IID} x eps*{1,2,4,8} (reduced: alpha{0.5,IID} x eps*{1,4,8}) | 3D surface MRR(eps, alpha) per dataset | 7 |
| X2 | 5 | extended | ALL3 | 26 → 18 | S3 | 234 → 162 | complete method: tau{1.5,2,2.5,3,3.5,4,5} x {clean, ALIE f0.1, f0.2, f0.3} minus 2 core cells (reduced: tau{1.5,2.5,3.5,5} + selected) | 3D threshold-sensitivity surface MRR(tau, f) | 8 |
| X2a | 5 | extended | ALL3 | 6 → 4 | S3 | 54 → 36 | complete method: non-selected tau x adaptive attack, f=0.2 | threshold sensitivity under the adaptive attacker | 8 |
| X3 | 5 | extended | FB | 6 | S3 | 18 | lambda{0,0.25,1.0} x {clean, ALIE} | history-penalty sensitivity | 8 |
| X4 | 5 | extended | ALL3 | 6 → 4 | S3 | 54 → 36 | FedAvg x{ALIE, signflip} x f{0.1,0.3}; proposed x signflip x f{0.1,0.3} (proposed x ALIE is in X2) | degradation references for the (tau, f) surface | 9 |
| X4a | 5 | extended | ALL3 | 2 | S3 | 18 | proposed x adaptive x f{0.1,0.3} | adaptive attacker vs fraction | 9 |
| X5 | 5 | extended | ALL3 | 4 | S3 | 36 | {FedAvg, proposed} x {KG-targeted, Sybil} without DP noise (revision behaviour) | how much detection relies on missing noise | 9 |
| X6 | 5 | extended | ALL3 | 1 | S3 | 9 | each client trains alone (alpha=0.1) | value of federation | 4 |
| X7a | 5 | extended | ALL3 | 3 | S3 | 27 | proposed aggregation, no attack, eps*{1,2,8} | does trust cost clean utility at other privacy levels | 5,7 |
| X7b | 5 | extended | ALL3 | 4 | S3 | 36 | {FedAvg, proposed} x ALIE f0.2 x eps*{2,8} | robustness x privacy interaction | 9 |
| O1 | 5 | optional | ALL3 | 1 | S5 | 15 | validation-triggered sigma decay with an RDP filter (DP-Flames-inspired policy) | stronger 'adaptive DP' variant (decision D12) | 5,7 |

## 4. Threshold inventory (master prompt §12)

Every threshold-like parameter in the legacy code, the manuscript and the revision, and how it is handled.
- Parameters that are **not** thresholds are labelled as such and are not swept just to make the matrix bigger.
- Selection uses **validation data on the tuning seed only**. Rules are frozen and hashed before Stage 4.
- The legacy "τ ∈ {0.05…0.40}, 100 % at every value" table was formula-generated (CR-1). It is withdrawn, not reproduced.

| Parameter | Kind | Legacy → revision | Handling | Grid | Selection rule | Reported in |
|---|---|---|---|---|---|---|
| Trust anomaly threshold tau | threshold (detection) | 0.15 on a loss-consistency score (legacy, not comparable) → 3.0 MAD units | calibrated + sensitivity | {1.5, 2, 2.5, 3, 3.5, 4, 5} | smallest tau with mean benign FPR <= 5 % in clean DP FedAvg runs, tuning seed; selected after the D15 variant is fixed (D14) | Tables 8-9; X2, X2a |
| History penalty lambda | hyperparameter of the trust rule | 0.5 (legacy, loss-based) → 0.5 | fixed a priori + sensitivity | {0, 0.25, 0.5, 1.0} | none (fixed) | Table 8; X3 |
| Norm bound (median norm) | threshold (derived, data-adaptive) | - → on | fixed design element | on | none | 03 section 8.3 |
| Clipping norm C | threshold (per-example gradient norm) | 1.0 → 1.0 (swept 0.25-4) | swept + selected | {0.25, 0.5, 1, 2, 4} | highest validation MRR at eps*=4, tuning seed; ties -> smaller C | Table 8; T2b |
| Privacy budget eps* | operating point | 15 (naive sum, invalid) → 4 (+1,2,8) | pre-declared + full curve | {1, 2, 4, 8} + non-private | not selected (eps*=4 declared a priori) | Tables 6-7; DP1, DP2 |
| delta | operating point | 1e-5 → 1e-6 (+1e-5 reported) | fixed a priori | - | - | Table 6 |
| Noise multiplier sigma | derived | 1.0 / 1.2 fixed → calibrated per eps* | derived by calibration | - | smallest sigma meeting eps* (RDP) | Table 6 |
| Noise schedule shape / rho | hyperparameter (DP) | fixed (claimed adaptive) → fixed; {linear, exponential, cosine} x rho {0.25, 0.5} | swept + selected | 6 schedules + fixed | highest validation MRR at eps*=4, tuning seed; ties -> fixed | Tables 5, 8; T3, DP2 |
| Sampling rate q / expected batch B | hyperparameter (DP) | B=256 (Opacus) → B=512 fixed (design A) | swept + selected | q {0.02, 0.05, 0.10} (design Q); design A vs Q in T2d | highest validation MRR; ties -> larger q; design ties -> Q (D11) | Table 8; T2a, T2d |
| Learning rate | hyperparameter | 1e-3 → 1e-3 | swept + selected (DP and non-private) | {1e-3, 3e-3, 1e-2} | highest validation MRR; ties -> smaller | Table 8; T1, T2a |
| Rounds R | hyperparameter | 50 (P3) / 20 planned, 16 run (P4) → 100 | swept (DP) / early stopping (non-private) | {50, 100} | validation MRR; ties -> 50 | Table 8; T2c |
| Early-stopping patience | threshold (stopping) | none (last round) → 4 evaluations x 5 rounds | fixed a priori | - | - | final.json |
| Dirichlet alpha | non-IID concentration (not a threshold) | relation-disjoint (ID order) → {0.1, 1.0} | all levels reported (not selected) | {0.1, 0.5, 1.0} + IID | none | Tables 2-3, 7; N3, X1 |
| Minimum client size | threshold (feasibility) | - → >= 20 % of mean and >= 1024 | fixed a priori + documented fallback | fallback 10 % of mean (one dataset only) | - | Table 2 |
| Trimmed-mean beta | threshold (robust baseline) | - → 0.2 | design value 0.2, or the true attacker fraction if larger (X4, f = 0.3) | - | - | Table 9 |
| Krum f | threshold (robust baseline) | - → true f (min 1) | design value 2, or the true attacker count if larger | - | - | Table 9 |
| FLTrust root size | baseline parameter | - → 500 from V_root | fixed a priori | - | - | Table 9 |
| Attacker fraction f | attack budget (not a threshold) | 5/10/20 % (1 attacker of 5) → 0.2 main | main + sensitivity | {0.1, 0.2, 0.3} | - | Table 9; X4 |
| Attack strength s | attack budget | POISON_SCALE 2.0 (simulation) → 3.0 | fixed a priori | - | - | attack.json |
| Adaptive attacker margin / gamma grid | attacker threshold | - → 0.05; [0, 20] x 81 | fixed a priori | - | - | attack.json |
| Target success cut-off k | metric threshold | - → Hits@10 | fixed a priori | - | - | Table 9 |
| MIA decision threshold | metric threshold | - → swept (ROC) | swept implicitly | ROC | - | Tables 6-7 (if H3) |
| One-run audit guess count | audit parameter | - → - | fixed a priori | {100, 300, 1000} guesses (proposed) | largest lower bound over the three, each at confidence 1 - 0.05/3 (Bonferroni) | Tables 6-7 (if H3); M1 |
| MIA audit pool size | audit parameter | - → - | fixed a priori | 10 % of each client's training triples; inclusion probability 1/2 (proposed) | - | Tables 6-7 (if H3); M1 |
| Integrity tamper probability | experiment factor | - → - | experiment factor | {0.01, 0.1} | - | Table 10; I2 |
| Selection tie tolerance | selection rule threshold | - → 0.0 | fixed a priori | 0.002 MRR (proposed) | - | selection files |

## 5. Required tables (master prompt §17) → blocks

Every table is generated from saved run records. None is typed by hand.

| # | Table | Source blocks / artifacts |
|---|---|---|
| 1 | Dataset statistics | Phase D dataset cards and validation reports (no training) |
| 2 | Client partition statistics | Phase D partition artifacts, every α × every seed |
| 3 | Main results by dataset | N1 (centralised), N2 (FedAvg), DP2 at ε* = 4 (the DP baseline with the selected schedule; equals DP1 if s* = fixed), R1p (complete method); with provenance labels |
| 4 | Baseline comparison | N1, N2, DP1/DP2, R1, R4, X6 |
| 5 | Ablation study | R1p, R5, R2/R2a, R1q, I1/I2, DP3 |
| 6 | DP privacy accounting | `accountant.json` of every DP run (DP1, DP1h, DP2, DP2h, R*, X*, L3/L4, M1) |
| 7 | Privacy/utility Pareto comparison | DP1, DP2, X1, X7a, N2/N3 (ε = ∞), M1 (if H3) |
| 8 | Threshold sweeps | T2a–T2d, T3 (selection tables), X2, X2a, X3, X1 |
| 9 | Attack and defence evaluation | R1–R5, R2a, R3a, X4, X4a, X5, X7b |
| 10 | Integrity overhead | integrity logs of all runs; I1; I2 |
| 11 | Runtime and communication cost | runtime and communication fields of all runs |
| 12 | Statistical uncertainty | per-seed values, 95 % intervals, d_z, and the Holm-adjusted one-sided tests of every pre-registered family (H1, H2, H2b, H3, HS) |
| 13 | Original vs revised on FB15k-237 | historical values (`result_provenance.csv`, labelled *Reported*), L0–L4 (*Reproduced*), N2, DP1/DP2 and R1p on FB15k-237 (*Newly measured*) |
| 14 | Completion and failure status | run index: planned (this matrix) vs COMPLETE / FAILED / STALE / NOT_RUN, with failure reasons |

## 6. Figure families (master prompt §15) → blocks

| Family | Surface or plot | Axes (all values measured or calculated) | Blocks |
|---|---|---|---|
| A. Dataset comparison | one surface per dataset: test MRR over (ε, α) | ε = calculated worst-client ε; α ∈ {0.1, 0.5, 1.0} with IID as its own category | DP1, X1, N2/N3 |
| B. Privacy/utility | MRR over (ε, schedule), plus a 2D frontier with seed CIs | ε calculated, not σ | DP1, DP2, X7a |
| C. Threshold sensitivity | MRR, and degradation relative to FedAvg, over (τ, f) under ALIE; τ curve under the adaptive attack | τ in MAD units; f ∈ {0.1, 0.2, 0.3} | X2, X2a, X4, R2, R3 |
| D. Baseline comparison | bars or points with CIs; original (*Reported*) vs replica (*Reproduced*) vs revised (*Newly measured*) on FB15k-237; the same revised comparison on the other two datasets | categorical | L0–L4, N1, N2, DP2, R1p, R1, R4 |
| E. Ablations | grouped 2D panels, or 3D bars over (component set × ε) | categorical × ε (**no continuous surface over categories**) | R1p, R5, R2, DP3, X7a, X7b |

Rules for every figure:
- missing cells are shown as missing, with no interpolation;
- seed aggregation is stated;
- descriptive (3-seed) results are labelled as such;
- PNG + PDF + SVG output;
- the plotting script is saved next to the figure;
- a 2D view is added where it is clearer.

## 7. Completion, failure and validity rules

- **Validity.** A run counts only if its code, data, partition and selection hashes are current (the revision's `analysis.collect`). Stale runs are archived and rerun, never mixed in.
- **Smoke and dev runs** are watermarked and rejected by the table builders.
- **Failed runs** keep their traceback (`error.txt`) and appear in Table 14. Nothing is filled in for a missing or failed run.
- **Selections** refuse to run on incomplete grids, and record the rule text, its SHA-256 and the full candidate table.
- **Before Stage 4 starts:**
  1. all selections for the dataset exist;
  2. the decision sheet (02) is approved;
  3. the hypotheses (03 §13) are frozen. Their file hash is recorded in the run configs.
