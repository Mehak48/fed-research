# 11_experiment_schemas (Phases 1–4; Phase C additions)

| Schema | Validates | Checked in |
|---|---|---|
| `dataset_card` | `artifacts/p1/<ds>/dataset_card.json` | P1 notebook, tests |
| `p1_manifest` | `artifacts/p1/<ds>/manifest.json` | P1 notebook, tests |
| `validation_report` | `artifacts/p1/<ds>/validation_report.json` (no leakage, no errors) | P1 notebook |
| `partition_manifest` | `artifacts/p2/<ds>/<spec>/seed<S>_manifest.json` | P2 notebook |
| `partition_stats` | `artifacts/p2/<ds>/<spec>/seed<S>_stats.json` | P2 notebook |
| `run_config` | `runs/<run_id>/config.json` (no `warm_start`) | P3/P4 notebooks |
| `final` | `runs/<run_id>/final.json` (+ `privacy` block for DP runs) | P3/P4 notebooks |
| `accountant` | `runs/<run_id>/accountant.json` (DP runs; `schedule_verified` must be true) | P4 notebook |
| `dp_selection` | `selection/dp_selection.json` | P4 notebook |
| `rounds_csv` | column list of `runs/<run_id>/rounds.csv` | P3/P4 notebooks |
| `runs_index` | column list of `index/<phase>_runs_index.csv` | P3/P4 notebooks |
| `integrity` | `runs/<run_id>/integrity.json` (verification in the data path; NOT a poisoning defence; no IPFS) | Phase C tests, `scripts/validate_outputs.py` |
| `attack` | `runs/<run_id>/attack.json` (resolved noise mode, attacker rows, target source) | Phase C tests, `scripts/validate_outputs.py` |
| `mia` | `runs/<run_id>/mia.json` (audit block M1; primary attack A2; resolvability flags) | Phase C tests, `scripts/validate_outputs.py` |
| `trust_rounds_csv` | column list of `runs/<run_id>/trust_rounds.csv` | Phase C tests, `scripts/validate_outputs.py` |
| `tuning_selection` | `<tier>/selection/tuning.json` (pre-registered tuning chain, D13-D15) | `scripts/validate_outputs.py` |

Validation helpers: `fedkge.schemas.validate_file(path, SCHEMA_DIR, name)`, `validate_rounds_csv`, `validate_csv_columns`.
Whole results tree: `python scripts/validate_outputs.py --tier smoke` (Phase C).
