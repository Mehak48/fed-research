# Validation report — FedKGE complete executable methodology (2026-11-05)

> **What this report is.**
> - **Code-level verification only.** It shows that the software does what the approved methodology says, on synthetic data, on small real-data subsets and on labelled fixture numbers.
> - **It is not experimental validation.** No tuning run, no main experiment and no replication of the research schedule has been executed. There is no MRR, Hits@K, ε, p-value or confidence interval in this package, and none may be quoted from it.
> - The owner starts the 885-run schedule herself. It was not started.

---

## 1. Two kinds of validation

| Kind | Question it answers | Status |
|---|---|---|
| **Code-level verification** (this report) | Does the code implement the frozen method, the approved budget and the safety rules? Does every step run end to end? Are the optimisations execution-equivalent? | **Done.** Evidence in §2 |
| **Experimental validation** | Does the trainer reach a sensible accuracy at full scale on a T4? What are the results? | **Not done.** It starts with the accuracy sanity gate (notebook Step 3) in the owner's first session |

---

## 2. Checks and evidence

| # | Check | Result | Evidence (under `provenance/validation_2026-11-05/` unless stated) |
|---|---|---|---|
| 1 | Baseline test suite on the untouched B2–B5 checkpoint | 133 passed, 0 failed | `test_reports/summary_baseline_checkpoint_133.json` |
| 2 | **Full test suite on the final code** | **184 passed, 0 failed, 0 skipped** | `test_reports/summary_final_code_184.json` |
| 3 | **B3 regression tests** (τ fallback) | 9 tests pass: feasible τ, FPR exactly 5 %, **no feasible τ** (largest grid τ, `rule_met = false`, observed FPR recorded, label carried into Stage 4), wrong direction refused, attack rows and final tier refused, determinism, merging across sessions | `revision/12_validation_tests/test_final_b3_b4_gates_manifest.py` |
| 4 | **B4 regression tests** (V1 removed) | 6 tests pass: V1 and its switch are gone from code, configs and schemas; the old key is rejected; the frozen trust rule is unchanged bit for bit; per-size-group FPR stays a diagnostic | same file; `test_phaseC_trust_attacks.py` |
| 5 | B5: non-inferiority needs the bound; D10 is a flag only; the family size never shrinks | tests pass | same file |
| 6 | Gates and freezing | gate G-B stops tuning (exit 4); the freeze refuses datasets that failed the gate, is append-only, and works one dataset at a time | `test_sanity_gate_*`, `test_freeze_is_gated_append_only_and_per_dataset` |
| 7 | **Frozen manifest and run counts** | rebuilt from the configs and the core code and compared: tune 114 cells = **99 runs**; main **756 runs** (726 if s\* = fixed); legacy **30 runs**; total **885**; 900 unique cell IDs | `python scripts/build_manifest.py --check` |
| 8 | **Unique output destinations** | 885 distinct run folders (855 if s\* = fixed); 0 shared between plans | manifest tests |
| 9 | **Run-order change RC-12** (H3 earlier) | all 900 cells identical in every column except `priority` | `rc12_priority_reorder/RC12_identity_check.json` |
| 10 | **Dependencies** | the exact pinned versions installed; `pip check` clean; the notebook refuses any other version and never reinstalls torch | `provenance/build_environment.json` |
| 11 | **Datasets** | re-downloaded (licence confirmation of 2026-11-02): **byte-identical** to the owner's Colab session; SHA-256 pinned, a mismatch writes nothing | `scripts/prepare_data.py` |
| 12 | **Every block on real-data subsets** (smoke tier: 3,000 training triples, 1 seed per block, 3 rounds) | **291 runs, 0 failures** (tuning 99 + 15 reused, main 186, legacy 6) | `smoke_tier_check/` |
| 13 | **Schemas** | 337 output items in 291 run folders: 0 failures | `smoke_tier_check/schema_validation_smoke_*.json` |
| 14 | **The notebook, in order** | **14 / 14 code cells OK** (exit 0), executed as written on the release-candidate zip (commit `1bffa87`; the final commit `e55400b` changes one documentation line). Local folder for Drive, smoke tier, CPU. It covered Steps 1–9, Appendix A, and Appendix B (184 tests passed). Step 6 found the replications complete and re-ran nothing. The **final zip** was also run through Steps 1–2 (commit, clean tree, code hash, manifest, pinned versions, data checks) | `notebook_execution/` |
| 15 | **Mandatory path** | the notebook's code is valid Python; Steps 1–9 are in order; no smoke, pilot or test-suite training on the mandatory path; gate G-B is the first training and stops the workflow if it fails | `test_final_execution_equivalence.py` (3 tests) |
| 16 | **No software-check number counted as research** | after the notebook run, `PROGRESS.md` showed 0 completed research runs | `notebook_execution/PROGRESS.md` |
| 17 | **Interruption and resume (process level)** | a real DP + proposed-method + SHA-256-integrity run (WN18RR subset) was killed (SIGKILL) after its round-10 checkpoint. Its folder stayed RUNNING, without `final.json`, derived status INCOMPLETE. On resume it continued from round 10 and became COMPLETE (attempt 2). Validation MRR, test MRR and ε are **bit-identical** to an uninterrupted run, and identical to the same run under the previous integrity code | `interruption_resume/` |
| 18 | Interruption and resume (unit level) | an unreadable checkpoint is moved aside and the run restarts; a checkpoint of another run fails loudly; the session budget leaves the rest PENDING (exit 3), never COMPLETE; a retried FAILED run keeps its first traceback; completed runs are skipped | `test_phaseC_pipeline.py`, `test_final_b3_b4_gates_manifest.py` |
| 19 | **Optimisation RC-11 is execution-equivalent** | (a) serialised bytes and SHA-256 identifiers equal the previous implementation for 7 shapes; (b) a WN18RR-sized round gives the same manifest chain ID, with 9 % less integrity time on this CPU; (c) the whole smoke schedule under the previous and the final code: **276 of 291 runs bit-identical**; the other 15 (only the centralised or non-private blocks T1C, N1, N3, R5, M1) are within 3.2 × 10⁻⁶ relative, the same blocks and size as between two executions of the *previous* code. **Re-run single-threaded, all 15 are bit-identical**, so the differences come from CPU thread scheduling, not from RC-11. (d) the killed-and-resumed DP + integrity run gives identical MRR and ε under both codes | `optimisation_equivalence/`; `test_integrity_fast_path_is_byte_identical` |
| 20 | **Reports and figures on fixtures** | analysis, tables (CSV / MD / LaTeX), figures (PNG 300 dpi + PDF + data CSV) and the results draft build from fixture numbers; every file is watermarked `FIXTURE_SYNTHETIC_NOT_RESULTS_`; missing values appear as ⟦PENDING⟧ | `test_final_reporting.py` (8 tests) |
| 21 | **Hard-coded results scan** | no typed-in metric value in the core code, the scripts or the notebooks | `test_no_hardcoded_results.py` |
| 22 | **Simulated numbers cannot pass as evidence** | smoke outputs are prefixed `SMOKE_NOT_FOR_MANUSCRIPT_` and fixture outputs `FIXTURE_SYNTHETIC_NOT_RESULTS_`; on any non-final tier every hypothesis decision reads "NOT EVIDENCE" | smoke reports; `test_fixture_pipeline_end_to_end_is_labelled` |
| 23 | **Deliverable hygiene** | the zip builder refuses dataset files, `triples.npz`, `labels.json` and weights, and writes `provenance/SHA256SUMS.txt`. The final zip was extracted and re-checked: commit, clean tree, manifest, no forbidden file | `provenance/SHA256SUMS.txt`; the delivery check |

---

## 3. What was **not** validated (honest limits)

1. **No GPU run of the final code.** The last GPU session was the owner's Phase C pilot (2026-11-04) on earlier code. The core code changed since (B4, atomic checkpoints, RC-11), so every earlier run is stale by design. The first GPU training of this code is gate G-B (Step 3).
2. **The outcome of gate G-B is unknown.** It is known only after Step 3. On 3-round subsets it records FAILED, as expected, because it is not enforced on that tier.
3. **Full-scale behaviour.** The smoke tier runs every code path, but not full-size memory use on a T4, long training or real early stopping.
4. **GPU hours are estimates.** The ≈ 118 GPU-h upper bound comes from 2-round measurements (`provenance/deadline_cost_model/`). The full study does not fit into this week on one T4 (`DEADLINE_PLAN.md`).
5. **Speed-up on a T4 is not measured.** RC-11 was measured on this CPU only. On the owner's Colab host, integrity work per object took about 2.5 times longer than here, mostly hashing, so the relative gain there is probably smaller. It is not included in any estimate.
6. **Colab itself was simulated.** Drive was a local folder, Colab's pip was the local pinned environment, and the T4 was the CPU. The notebook refuses to continue if any of these differs from what it expects.
7. **L0 was not re-run.** It needs the owner's `complete/global_transe_final.pt`.
8. **Not bitwise repeatable.** Centralised and non-private runs vary by ≤ 3.2 × 10⁻⁶ relative between multi-threaded CPU executions of the *same* code, and GPU runs are not bitwise deterministic. This is documented; the environment lock keeps each comparison in one environment.

---

## 4. Unavoidable issues and how to recover

| Issue | Why it cannot be removed | Recovery |
|---|---|---|
| Not enough GPU time before the deadline | ≈ 118 GPU-h of approved computation | `DEADLINE_PLAN.md`: priorities 1–3 decide all five hypotheses (≈ 58 GPU-h); report a partial study as partial |
| Free-Colab limits and disconnects | Colab publishes no quota | Step 1 → Step 2 → the same step; finished runs are kept and an interrupted run resumes |
| Another GPU type or a torch update | outside the package's control | the environment lock stops the step (exit 5); `EXECUTION_GUIDE.md` §4 |
| Gate G-B fails | a weak trainer would make every later number meaningless | stop; send `SANITY_GATE_REPORT.md` and the T1C run folders; no threshold may be edited |
| τ rule not met | a pre-registered possibility | nothing to do: B3 is applied and labelled |
| Upstream dataset files change | outside the package's control | the pinned checksum stops Step 2; report it |
| Original checkpoint missing (L0) | the owner's file | upload it any time; until then L0 stays PENDING |

---

## 5. How to reproduce these checks

```bash
cd revision
python scripts/run_tests.py --name check           # the full suite (or notebook Appendix B)
python scripts/build_manifest.py --check           # manifest, run counts and code hash
git -c safe.directory='*' -c core.fileMode=false status --porcelain   # must print nothing
```

The commit, the hashes and the tag are in `provenance/GIT_CHECKPOINT.md`.

---

## Addendum 2026-11-07 — parallel GPU execution layer (software checks only)

| # | Check | Result | Evidence (`provenance/validation_2026-11-07_parallel/`) |
|---|---|---|---|
| P1 | Core suite after adding the layer (no core file changed; core code hash `13b56d18…` and frozen manifest `f86054ff…` unchanged) | **184 passed, 0 failed** | `test_report_core.txt` |
| P2 | Parallel-layer tests on the real frozen manifest: every cell exactly once, scientific dependencies only, environment classes respected, atomic exchange, tamper detection, append-only installs, cross-worker lock | **35 passed, 0 failed** | `test_report_parallel.txt` |
| P3 | End to end, smoke tier, 3 concurrent workers vs the sequential entry points, chain mode | **291/291 runs bit-identical**; selections, validation and hypothesis table identical | `e2e_result_chain.json` |
| P4 | The same, stage mode (7 master hand-overs) | **291/291 runs bit-identical**; selections, validation and hypothesis table identical | `e2e_result_stage.json` |
| P5 | The worker and master notebooks from the delivered zip, executed cell by cell (smoke, CPU, local folder, 3 sessions each: plan, budgeted queue with PAUSED, imports, replay, releases) | **every cell OK in all 6 sessions** | `notebook_harness_parallel.json` |

Not verified: GPU execution of the layer, the research tiers, and real Drive sync between simultaneous Colab sessions (`PARALLEL_METHODOLOGY_PRESERVATION.md` §4).
