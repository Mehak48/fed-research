# Phase C — remaining blockers, risks and decisions

**Date:** 2026-11-02, updated 2026-11-04 after the GPU pilot · Each item says who has to act. "Owner" means Mehak; "next step" means work that can continue without a decision. The 2026-11-02 version is kept in `_versions/2026-11-02/`.

**Status in one line:** Phase C is complete and waits for the owner's review. Before Stage 3 (tuning) can start, the owner decides B2–B5. Nothing larger runs before that.

## A. Decisions needed before Stage 3 (tuning)

**B1 — GPU pilot (gate G-B).** **Done (2026-11-04).**

- **What ran:** the owner ran the Colab kit on a Tesla T4.
  - Tests: 130 passed, 1 skipped as expected.
  - GPU smoke: 9 / 9.
  - Pilot: 2 × 18 configurations, 0 failures.
- **Result:** the measurements and plan-level estimate are in `pilot_plan.md` §4–5. The session record is `results/phaseC/colab/session_20261104T163226Z/`.
- **One G-B condition is still open:** the centralised non-private sanity check. It needs converged runs, so it is the first step of Stage 3 (T1C). If it fails, Stage 3 stops.

**B2 — Compute budget and profile.** **Owner decides now, with measured numbers.**

- **Measured upper bounds on a T4** (`pilot_plan.md` §5):

  | Work | Runs | GPU-hours (upper) |
  |---|---|---|
  | Stage 3 tuning | 99 | 12.4 |
  | Stage 4 reduced core | 756 | 91.9 |
  | Legacy replicas L1–L4 | 30 | ≤ 5.4 (not measured) |
  | Stage 5 reduced extended | 423 | 57.3 |
  | Stage 4 full profile | 1,404 | 174.6 |

- **What the bounds leave out:**
  - The real cost is lower for non-private runs, which stop early.
  - It is higher if tuning selects q = 0.02 (about +12–29 % per DP round).
  - Attack crafting, other robust aggregators and the MIA audit add unmeasured extra cost.
- **Free Colab** publishes no GPU limits. At an assumed 10 / 20 / 30 GPU-hours per week, Stage 3 + reduced Stage 4 + L1–L4 (≈ 110 GPU-hours) takes about 11 / 5.5 / 3.7 weeks (`pilot_plan.md` §6).
- **Paid reference point:** Colab Pay As You Go costs $9.99 per 100 compute units (US price, September 2026), about 63–84 T4-hours. Stage 3 + reduced Stage 4 + L1–L4 ≈ 131–173 units, i.e. about two packs. Check the price in your country.
- **Options, in the order that best protects the core claims:** ✂️

  | # | Option | Saving or cost |
  |---|---|---|
  | (a) | **Reduced profile** | −648 runs against the full profile (Stage 4: 756 instead of 1,404) |
  | (b) | **Defer Stage 5** (extended blocks) until Stage 4 is done | −423 runs, −57 GPU-hours |
  | (c) | Run Stage 4 in Phase B's priority order (`07` §6), so a partial Stage 4 still answers the main hypotheses | — |
  | (d) | Drop H3 / M1 (the MIA audit) and rely on the formal guarantee | −60 runs, −7.2 GPU-hours |
  | (e) | Add a second free platform (Kaggle), one dataset per platform | faster calendar; needs a second kit |
  | (f) | Buy Colab units for Stage 4 | about two 100-unit packs |

- **Recommended:** (a) + (b) + (c).
  - Stage 3 on free Colab is realistic: 12.4 GPU-hours.
  - For Stage 4, decide (e) or (f) only once you see how much GPU time free Colab gives you during Stage 3.
- **Never cut:** correct DP, three datasets, ≥ 5 seeds per hypothesis test, the non-private references, validation-only selection.

**B3 — τ rule (D14) may have no feasible value.** **Owner decides now, before seeing data.**

- If no τ on the grid gives benign FPR ≤ 5 % in the clean TAU run, the pipeline stops, by design.
- On the real smoke run (3 rounds) the rule found a feasible τ for all three datasets. Three rounds say little about the real tuning run.
- **Pre-declare the response.** Options:
  - (i) report the method as failing its own rule on that dataset;
  - (ii) use the largest τ on the grid, label the result as "rule not met (benign FPR = x %)", and report it;
  - (iii) drop the dataset from H2.

  Do **not** extend the grid after seeing data.
- **Suggested:** (ii). The failure stays visible, but the confirmatory matrix stays complete. (i) leaves a gap in H2, and (iii) loses evidence.

**B4 — Variant V1 is statistically weak with 10 clients (finding PC-2).** **Owner decides before Stage 3.**

- **The problem:**
  - V1 compares each update's norm with the median of its *size third*. With 10 clients, a third has 3–4 members.
  - The MAD-based scale is very noisy at that size.
  - In the synthetic probe, benign clients reached A_v1 = 9.1, so V1's benign false positives were *higher* than the frozen rule's.
  - The trigger fired on CoDEx-M in the real smoke run, from a single flag among about 12 observations.
- **Options:**
  - (a) keep V1 exactly as pre-registered, with the risk above;
  - (b) **recommended, smallest change:** remove the V1 switch, keep only the frozen rule, and report the benign FPR per size third descriptively;
  - (c) redesign V1. This is new method design and would need justification.
- V1's trigger constants are Phase C details, also pending approval: `reference_tau` = 3.0, `min_fpr_for_ratio` = 0.05.

**B5 — Decisions never answered.** **Owner.**

- **D10 trigger:** 25 % of non-private validation MRR at ε\* = 4 on FB15k-237. Fix it before results exist.
- **H2b "no harm" bound:** clean MRR ≥ 95 % of FedAvg under the same DP settings. This is a new threshold.
- **MIA settings:** audit pool 10 % per client, inclusion ½, guesses {100, 300, 1000}, confidence 0.95.
- **Folder layout:** restructuring to `src/`, `scripts/`, `configs/`, `tests/` was **not** done. The layout was kept and `scripts/` added. Is that acceptable?
- **Git:** should the Phase C changes be committed? **Recommended before Stage 3,** so that every tuning result points to a commit. Today, runs are identified by the core code hash and the code zip's SHA-256.

## B. Open items that do not block Stage 3

| ID | Item | Status / next step |
|---|---|---|
| B6 | WN18RR α = 0.1 partitions are a heavily truncated Dirichlet (3.1 % of draws accepted on the real counts) | Feasible, so no fallback. State it in the paper; compare heterogeneity by measured statistics (G15 resolved) |
| B7 | WN18RR drops 210 validation and 210 test triples with entities unseen in training (PyKEEN convention) | Keep, as designed (D5 / `04`). State it, because some papers rank all 3,134 test triples |
| B8 | Gate G-A "every block completes in smoke" on the real data | **Met.** Tuning chain: 6 stages, every rule applied. Reduced confirmatory matrix: all 28 blocks, 322 runs, 0 failures (26 blocks have runs of their own; DP2 and R1q coincide with DP1 and R1p because the smoke chain selected the fixed schedule). **Correction, 2026-11-04:** the 2026-11-02 report missed the legacy replicas L1–L4 (PC-7). They have now run too: 6 / 6. Schemas: 506 items, 0 failures |
| B9 | Builders for the paper's Tables 1–14 and the 2D/3D figures (C10) are **not implemented** for the new matrices | Next step. Needed before the Stage 4 analysis. Figures only from executed runs |
| B10 | Not implemented: X6 (local-only baseline), O1 (validation-triggered σ decay with an RDP filter) | Out of Phase C (Phase B: optional). No IPFS, by decision D7 |
| B11 | Privacy cost of hyperparameter tuning is not accounted | Disclosed in `accountant.json` and `DP_MECHANISM.md`; OP-2 is the alternative |
| B12 | Missing inputs: the professor's review (M1), the owner's additional roadmap changes (M2), confirmation that `fedkge_revision_P1-P4.zip` is "Proprietary Learning Reveal" (M3), a repository link (M6) | **Owner.** Nothing was invented in their place |
| B13 | Different environments: torch 2.14.1 here, 2.11.0+cu130 on Colab. Colab can also update its image during a multi-week campaign | Never mix environments inside one comparison. `env.json` records the environment per run. The Stage 3 kit will record and check the GPU type and torch version every session, and refuse to continue a dataset's stage in a different environment |
| B14 | `MASTER_EXECUTION_ORDER.md`, `COLAB_RUNBOOK.md`, `EXECUTION_PLAN.md` still describe the original notebooks | Next step (documentation only) |
| B15 | The GPU code path had never executed | **Done (2026-11-04):** 9 GPU smoke runs and 36 pilot runs on a T4, 0 failures |
| B16 | **Run identity does not include the device.** A CPU run and a GPU run of the same configuration get the same `run_id`, and CPU and CUDA random streams differ | Keep CPU and GPU results in **separate results roots** (the Colab kits use a fresh folder on Drive). The Stage 3 kit's environment check (B13) guards this |
| B17 | **GPU determinism is not bitwise-tested.** The code does not switch on CUDA's deterministic mode. Same seed twice on the same T4: logged values identical to 4 decimals in 18 / 18 configurations | Disclose. Claim bitwise reproducibility on CPU only (tested). Paired comparisons are unaffected in expectation |
| B18 | **Integrity overhead depends on the hardware:** 12–52 % of a federated round on the T4, ≤ 3 % on the CPU (`pilot_plan.md` §4) | Any overhead statement in the paper names the hardware and comes from the I1 block runs, not from the pilot |

## C. What Phase C resolved

**Since the handoff brief (2026-11-02):**

- The datasets were downloaded with the owner's recorded licence confirmation. Split counts equal the official counts.
- Real-data smoke: 33 of 33 runs complete (11 profiles × 3 datasets).
- Partition feasibility was measured on the real counts (G15).
- L0 executed. The legacy non-private model scores **MRR 0.197** under the corrected protocol, against the reported 0.2858.
- Defect PC-1 was found and fixed. Schemas were added for every Phase C output, and schema defect PC-5 was fixed.
- Gate G-A met for the tuning chain and the confirmatory matrix (see B8 for the 2026-11-04 correction).
- A measured CPU pilot ran on the full data. The free-Colab GPU kit was prepared.

**On 2026-11-04 (GPU pilot and closing checks):**

- **GPU pilot on the owner's T4:**
  - tests 130 passed / 1 skipped as expected;
  - GPU smoke 9 / 9;
  - pilot 2 × 18, 0 failures.
  - The Colab artifacts are hash-identical to the local build.
- **Defect PC-6 found in the Colab record and fixed.** A forced rerun (the pilot, small runs) wrote over a completed run folder. It now moves the earlier folder to `<tier>/stale/` first. Two new tests were added. The suite is now **133 passed, 0 failed, 0 errors, 0 skipped**.
- **Gap PC-7 found and closed.** The legacy blocks L1–L4 had not been part of the every-block smoke check. `scripts/run_legacy_blocks.py` was added, and the smoke run completed 6 / 6.
- Schema validation of the whole smoke tier: 506 items, 0 failures.
