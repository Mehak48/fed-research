"""Publication figures from RECORDED runs only (final package, section G of the owner's final directive).

Rules (Phase B 06 section 6 and the data-visualisation method used for this package):
  * every figure is drawn from a data table built from run records; that table is saved next to the figure (CSV) so
    every plotted value can be checked, and the figure manifest records its SHA-256;
  * missing cells are shown as missing (never interpolated); seed aggregation is stated (mean +- 95 % t-interval);
  * categorical colours in a fixed order (validated palette: CVD-safe on adjacent pairs) plus a second encoding
    (marker or hatch) so identity never relies on colour alone; one y-axis per panel;
  * PNG (300 dpi) and PDF; figures from any tier other than 'final' carry a visible watermark;
  * a figure whose inputs do not exist is NOT drawn; the manifest says why (e.g. 3D surfaces that need the deferred
    Stage 5 blocks X1/X2).
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Callable, Dict, List, Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from .paper import DATASETS, DS_NAME, EPS4, banner, prefix, seedsum, select  # noqa: E402

SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
MARKERS = ["o", "s", "^", "D", "v", "P", "X", "*"]
HATCHES = ["", "//", "\\\\", "xx", "..", "--", "++", "oo"]
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
plt.rcParams.update({"font.size": 8, "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2,
                     "ytick.color": INK2, "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6,
                     "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
                     "lines.linewidth": 2.0, "pdf.fonttype": 42, "savefig.bbox": "tight"})


class Recorder:
    def __init__(self, out_dir: Path, tier: str):
        self.out, self.tier, self.items = Path(out_dir), tier, []
        self.out.mkdir(parents=True, exist_ok=True)

    def save(self, fig, fid: str, title: str, data: pd.DataFrame, blocks: List[str], caption: str) -> None:
        b = banner(self.tier)
        if b:
            fig.text(0.5, 0.5, b, ha="center", va="center", fontsize=13, color="#e34948", alpha=0.35, rotation=20,
                     transform=fig.transFigure, wrap=True)
        stem = self.out / f"{prefix(self.tier)}{fid}"
        files = []
        for ext in (".png", ".pdf"):
            fig.savefig(stem.with_suffix(ext), dpi=300)
            files.append(stem.with_suffix(ext).name)
        plt.close(fig)
        data_p = stem.with_name(stem.name + "_data.csv")
        data.to_csv(data_p, index=False)
        n_runs = int(data["n"].sum()) if "n" in data.columns else None
        self.items.append({"id": fid, "title": title, "status": "GENERATED", "files": files, "data": data_p.name,
                           "data_sha256": hashlib.sha256(data_p.read_bytes()).hexdigest(), "source_blocks": blocks,
                           "n_runs_plotted": n_runs, "tier": self.tier, "watermark": b, "caption": caption})

    def skip(self, fid: str, title: str, reason: str, blocks: List[str]) -> None:
        self.items.append({"id": fid, "title": title, "status": "NOT_GENERATED", "reason": reason,
                           "source_blocks": blocks, "tier": self.tier})

    def write_manifest(self, extra: Dict) -> Path:
        p = self.out / f"{prefix(self.tier)}FIGURE_MANIFEST.json"
        p.write_text(json.dumps({**extra, "figures": self.items}, indent=2, default=str))
        lines = [f"# Figure manifest ({self.tier} tier)", ""]
        if banner(self.tier):
            lines += [f"> **{banner(self.tier)}**", ""]
        lines += ["| Figure | Status | Files | Data table | Source blocks | Note |", "|---|---|---|---|---|---|"]
        for it in self.items:
            lines.append(f"| {it['id']}: {it['title']} | {it['status']} | {', '.join(it.get('files', []))} | "
                         f"{it.get('data', '')} | {', '.join(it['source_blocks'])} | "
                         f"{it.get('reason') or it.get('caption', '')} |")
        p.with_suffix(".md").write_text("\n".join(lines) + "\n")
        return p


def _err(ax, x, s: Dict, color, marker, label=None, **kw):
    if s.get("status") != "OK":
        return
    lo = s["mean"] - s["ci95_low"] if np.isfinite(s.get("ci95_low", np.nan)) else 0
    hi = s["ci95_high"] - s["mean"] if np.isfinite(s.get("ci95_high", np.nan)) else 0
    ax.errorbar([x], [s["mean"]], yerr=[[lo], [hi]], fmt=marker, color=color, ms=6, capsize=3, elinewidth=1.2,
                label=label, mec="white", mew=0.8, **kw)


def _empty(ax, text: str = "no recorded runs") -> None:
    """Missing is shown as missing: an explicit note, never an interpolated or invented value."""
    ax.text(0.5, 0.5, text, transform=ax.transAxes, ha="center", va="center", fontsize=7, color=INK2)


def _eps_axis(ax) -> None:
    from matplotlib.ticker import NullFormatter, NullLocator, ScalarFormatter
    ax.set_xscale("log")
    ax.set_xticks([1, 2, 4, 8])
    ax.xaxis.set_major_formatter(ScalarFormatter())
    ax.xaxis.set_minor_locator(NullLocator()); ax.xaxis.set_minor_formatter(NullFormatter())
    ax.set_xlim(0.7, 11)


def _avail(runs, blocks) -> bool:
    return runs is not None and not runs.empty and runs["block"].isin(blocks).any()


# ------------------------------------------------------------------------------------------------ F1 privacy-utility
def fig_privacy_utility(R: Recorder, runs: pd.DataFrame) -> None:
    fid, title, blocks = "F1_utility_vs_privacy", "Test MRR versus the accounted privacy budget", ["DP1", "DP2", "R1p", "N2", "N1"]
    if not _avail(runs, ["DP1"]):
        return R.skip(fid, title, "no DP1 runs recorded", blocks)
    rows = []
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.6), sharey=False)
    for ax, ds in zip(axes, DATASETS):
        xs, ys = [], []
        for eps in (1.0, 2.0, 4.0, 8.0):
            g = select(runs, "DP1", ds, {"cfg.dp.target_epsilon": eps})
            u, e = seedsum(g, "test.mrr"), seedsum(g, "privacy.eps")
            rows.append({"dataset": ds, "system": "DP-FedAvg fixed sigma (DP1)", "target_eps": eps,
                         "eps_measured": e.get("mean"), **{k: u.get(k) for k in ("mean", "ci95_low", "ci95_high", "n")}})
            if u.get("status") == "OK" and e.get("status") == "OK":
                _err(ax, e["mean"], u, SERIES[0], MARKERS[0], label="DP-FedAvg, fixed σ" if not xs else None)
                xs.append(e["mean"]); ys.append(u["mean"])
        if len(xs) > 1:
            ax.plot(xs, ys, color=SERIES[0], lw=1.2, alpha=0.7)
        for k, (lab, blk, w) in enumerate((("DP-FedAvg, s*", "DP2", EPS4), ("Complete method", "R1p", None)), start=1):
            g = select(runs, blk, ds, w)
            u, e = seedsum(g, "test.mrr"), seedsum(g, "privacy.eps")
            rows.append({"dataset": ds, "system": lab, "target_eps": 4.0, "eps_measured": e.get("mean"),
                         **{kk: u.get(kk) for kk in ("mean", "ci95_low", "ci95_high", "n")}})
            if u.get("status") == "OK" and e.get("status") == "OK":
                _err(ax, e["mean"] * (1 + 0.04 * k), u, SERIES[k], MARKERS[k], label=lab)
        for k, (lab, blk) in enumerate((("FedAvg non-private", "N2"), ("Centralised non-private", "N1")), start=3):
            u = seedsum(select(runs, blk, ds), "test.mrr")
            rows.append({"dataset": ds, "system": lab, "target_eps": np.inf, "eps_measured": np.inf,
                         **{kk: u.get(kk) for kk in ("mean", "ci95_low", "ci95_high", "n")}})
            if u.get("status") == "OK":
                ax.axhline(u["mean"], color=SERIES[k], lw=1.2, ls=["--", ":"][k - 3], label=f"{lab} (ε = ∞)")
        _eps_axis(ax); ax.set_title(DS_NAME[ds], fontsize=9, color=INK)
        if not ax.lines and not ax.collections:
            _empty(ax)
    axes[1].set_xlabel("accounted worst-client ε (RDP, δ = 1e-6), log scale")
    axes[0].set_ylabel("test MRR (filtered)")
    h, lab = axes[0].get_legend_handles_labels()
    fig.legend(h, lab, loc="lower center", ncol=3, bbox_to_anchor=(0.5, -0.24), fontsize=7)
    R.save(fig, fid, title, pd.DataFrame(rows), blocks,
           "Mean ± 95 % t-interval over the confirmatory seeds; x = accounted worst-client ε of the executed runs "
           "(not the target); non-private references drawn as horizontal lines at ε = ∞.")


# ------------------------------------------------------------------------------------------------ F2 main comparison
def fig_main(R: Recorder, runs: pd.DataFrame) -> None:
    fid, title = "F2_dataset_comparison", "Main comparison across the three benchmarks"
    systems = [("Centralised", "N1", None), ("FedAvg", "N2", None), ("DP-FedAvg (ε*=4)", "DP2", EPS4),
               ("Complete method (ε*=4)", "R1p", None)]
    blocks = [b for _, b, _ in systems]
    if not _avail(runs, blocks):
        return R.skip(fid, title, "no N1/N2/DP2/R1p runs recorded", blocks)
    rows = []
    fig, ax = plt.subplots(figsize=(6.0, 2.6))
    w = 0.18
    for i, ds in enumerate(DATASETS):
        for k, (lab, blk, wh) in enumerate(systems):
            s = seedsum(select(runs, blk, ds, wh), "test.mrr")
            rows.append({"dataset": ds, "system": lab, **{kk: s.get(kk) for kk in ("mean", "ci95_low", "ci95_high", "n")}})
            x = i + (k - 1.5) * (w + 0.02)
            if s.get("status") == "OK":
                ax.bar(x, s["mean"], width=w, color=SERIES[k], hatch=HATCHES[k], edgecolor="white", lw=0.8,
                       label=lab if i == 0 else None)
                if np.isfinite(s["ci95_low"]):
                    ax.errorbar(x, s["mean"], yerr=[[s["mean"] - s["ci95_low"]], [s["ci95_high"] - s["mean"]]],
                                color=INK, capsize=2, lw=1)
            else:
                ax.text(x, 0.0, "n/a", ha="center", va="bottom", fontsize=6, color=INK2, rotation=90)
    ax.set_xticks(range(3)); ax.set_xticklabels([DS_NAME[d] for d in DATASETS])
    ax.set_ylabel("test MRR (filtered)"); ax.legend(ncol=2, fontsize=7)
    R.save(fig, fid, title, pd.DataFrame(rows), blocks, "Bars: mean over seeds; whiskers: 95 % t-interval; n/a: "
           "no recorded runs.")


# ------------------------------------------------------------------------------------------------ F3 robustness
def fig_robustness(R: Recorder, hyp: Optional[Dict]) -> None:
    fid, title, blocks = "F3_robustness_attacks", "Attack damage: FedAvg versus the complete method", ["DP2", "R1p", "R2", "R2a", "R3", "R3a"]
    mem = (hyp or {}).get("families", {}).get("H2", {}).get("members", [])
    have = [m for m in mem if m.get("estimate")]
    if not have:
        return R.skip(fid, title, "no computed H2 members (attack runs not recorded)", blocks)
    rows = []
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.8), sharey=False)
    atts = ["gaussian", "signflip", "alie", "ipm", "sybil", "adaptive"]   # targeted: own measure, figure F3b
    for ax, ds in zip(axes, DATASETS):
        for j, att in enumerate(atts):
            m = next((x for x in mem if x["dataset"] == ds and x["attack"] == att), None)
            est = (m or {}).get("estimate") or {}
            for k, (key, ci, lab) in enumerate((("mean_delta_fedavg", "delta_fedavg_ci95", "FedAvg"),
                                                ("mean_delta_method", "delta_method_ci95", "Complete method"))):
                v = est.get(key)
                rows.append({"dataset": ds, "attack": att, "arm": lab, "mean_delta": v,
                             "ci95_low": (est.get(ci) or [None, None])[0], "ci95_high": (est.get(ci) or [None, None])[1],
                             "status": (m or {}).get("status"), "n": (m or {}).get("n_pairs") or 0})
                if v is None:
                    continue
                x = j + (k - 0.5) * 0.36
                ax.bar(x, v, width=0.34, color=SERIES[k], hatch=HATCHES[k], edgecolor="white", lw=0.8,
                       label=lab if j == 0 else None)
                lo, hi = est.get(ci) or [np.nan, np.nan]
                if lo is not None and np.isfinite(lo):
                    ax.errorbar(x, v, yerr=[[v - lo], [hi - v]], color=INK, capsize=2, lw=1)
            if m and m["status"] == "NOT_TESTABLE":
                ax.text(j, 0, "n.t.", ha="center", va="bottom", fontsize=6, color=INK2)
        ax.axhline(0, color=INK2, lw=0.8)
        ax.set_xticks(range(len(atts))); ax.set_xticklabels(atts, rotation=45, ha="right", fontsize=7)
        ax.set_title(DS_NAME[ds], fontsize=9)
    axes[0].set_ylabel("damage Δ = clean − attacked test MRR")
    axes[0].legend(fontsize=7, loc="upper left")
    R.save(fig, fid, title, pd.DataFrame(rows), blocks, "Paired by seed; Δ = clean − attacked test MRR, mean ± 95 % "
           "t-interval. n.t. = H2 member not testable (attack not effective against FedAvg). The targeted attack "
           "is measured differently and is shown in F3b.")
    rows = []
    fig, ax = plt.subplots(figsize=(4.2, 2.4))
    for i, ds in enumerate(DATASETS):
        m = next((x for x in mem if x["dataset"] == ds and x["attack"] == "targeted"), None)
        est = (m or {}).get("estimate") or {}
        for k, (key, ci, lab) in enumerate((("mean_delta_fedavg", "delta_fedavg_ci95", "FedAvg"),
                                            ("mean_delta_method", "delta_method_ci95", "Complete method"))):
            v = est.get(key)
            rows.append({"dataset": ds, "arm": lab, "mean_rise_target_hits10": v, "status": (m or {}).get("status"),
                         "n": (m or {}).get("n_pairs") or 0})
            if v is None:
                continue
            x = i + (k - 0.5) * 0.36
            ax.bar(x, v, width=0.34, color=SERIES[k], hatch=HATCHES[k], edgecolor="white", label=lab if i == 0 else None)
            lo, hi = est.get(ci) or [np.nan, np.nan]
            if lo is not None and np.isfinite(lo):
                ax.errorbar(x, v, yerr=[[v - lo], [hi - v]], color=INK, capsize=2, lw=1)
    ax.axhline(0, color=INK2, lw=0.8)
    ax.set_xticks(range(3)); ax.set_xticklabels([DS_NAME[d] for d in DATASETS])
    ax.set_ylabel("rise in target Hits@10"); ax.legend(fontsize=7, loc="upper left")
    R.save(fig, "F3b_targeted_attack", "Targeted poisoning: rise in target success", pd.DataFrame(rows), blocks,
           "50 attacker-chosen false tails; success = ranked in the top 10 (raw ranking) on the final model; paired "
           "by seed, mean ± 95 % t-interval.")


# ------------------------------------------------------------------------------------------------ F4 aggregators
def fig_aggregators(R: Recorder, runs: pd.DataFrame) -> None:
    fid, title, blocks = "F4_aggregation_comparison", "Aggregation rules: clean and attacked utility", ["DP2", "R1", "R1p", "R2", "R3", "R4"]
    if not _avail(runs, ["R1", "R4", "R1p"]):
        return R.skip(fid, title, "no R1/R1p/R4 runs recorded", blocks)
    aggs = [("FedAvg", "fedavg"), ("Trimmed mean", "trimmed_mean"), ("Median", "median"), ("Krum", "krum"),
            ("FLTrust", "fltrust"), ("Proposed", "proposed")]
    conds = ["clean", "signflip", "alie", "ipm", "targeted"]
    rows = []
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.6))
    for ax, ds in zip(axes, DATASETS):
        M = np.full((len(aggs), len(conds)), np.nan)
        for i, (lab, a) in enumerate(aggs):
            for j, c in enumerate(conds):
                if c == "clean":
                    g = select(runs, "DP2", ds, EPS4) if a == "fedavg" else (select(runs, "R1p", ds) if a == "proposed"
                                                                             else select(runs, "R1", ds, {"cfg.aggregation.method": a}))
                else:
                    g = select(runs, "R2", ds, {"cfg.attack.type": c}) if a == "fedavg" else (
                        select(runs, "R3", ds, {"cfg.attack.type": c}) if a == "proposed" else
                        select(runs, "R4", ds, {"cfg.attack.type": c, "cfg.aggregation.method": a}))
                s = seedsum(g, "test.mrr")
                rows.append({"dataset": ds, "aggregator": lab, "condition": c, **{k: s.get(k) for k in ("mean", "n")}})
                if s.get("status") == "OK":
                    M[i, j] = s["mean"]
        im = ax.imshow(M, cmap="Blues", aspect="auto")
        for (i, j), v in np.ndenumerate(M):
            ax.text(j, i, "n/a" if np.isnan(v) else f"{v:.3f}", ha="center", va="center", fontsize=5.5,
                    color=INK2 if np.isnan(v) else (INK if v < np.nanmax(M) * 0.6 else "white"))
        ax.set_xticks(range(len(conds))); ax.set_xticklabels(conds, rotation=45, ha="right", fontsize=6.5)
        ax.set_yticks(range(len(aggs))); ax.set_yticklabels([a for a, _ in aggs], fontsize=6.5)
        ax.set_title(DS_NAME[ds], fontsize=9); ax.grid(False)
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    R.save(fig, fid, title, pd.DataFrame(rows), blocks, "Mean test MRR under the complete method's DP configuration "
           "(ε* = 4). Baselines R1/R4 use 3 seeds (descriptive); FedAvg and the proposed rule use 5. n/a = not recorded.")


# ------------------------------------------------------------------------------------------------ F5 convergence
def fig_convergence(R: Recorder, runs: pd.DataFrame, rounds_of: Callable) -> None:
    fid, title = "F5_convergence", "Validation MRR (early-stopping subset) over federated rounds"
    systems = [("FedAvg non-private", "N2", None), ("DP-FedAvg fixed σ", "DP1", EPS4), ("DP-FedAvg s*", "DP2", EPS4),
               ("Complete method", "R1p", None)]
    blocks = [b for _, b, _ in systems]
    if not _avail(runs, blocks):
        return R.skip(fid, title, "no N2/DP1/DP2/R1p runs recorded", blocks)
    rows = []
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.5))
    for ax, ds in zip(axes, DATASETS):
        for k, (lab, blk, w) in enumerate(systems):
            g = select(runs, blk, ds, w)
            curves = []
            for rid in g["run_id"] if len(g) else []:
                rr = rounds_of(rid)
                if rr is not None and "val_es_mrr" in rr:
                    c = rr.dropna(subset=["val_es_mrr"])[["round", "val_es_mrr"]].set_index("round")["val_es_mrr"]
                    curves.append(c.rename(rid))
            if not curves:
                continue
            C = pd.concat(curves, axis=1)
            mean, lo, hi = C.mean(axis=1), C.min(axis=1), C.max(axis=1)
            ax.plot(mean.index, mean.values, color=SERIES[k], marker=MARKERS[k], ms=3, markevery=4, lw=1.5, label=lab)
            ax.fill_between(mean.index, lo.values, hi.values, color=SERIES[k], alpha=0.15, lw=0)
            rows += [{"dataset": ds, "system": lab, "round": int(r), "mean": float(m), "min": float(a), "max": float(b),
                      "n": int(C.loc[r].notna().sum())} for r, m, a, b in zip(mean.index, mean, lo, hi)]
        ax.set_title(DS_NAME[ds], fontsize=9); ax.set_xlabel("round")
    axes[0].set_ylabel("validation MRR (V_es)"); axes[0].legend(fontsize=6.5)
    if not rows:
        plt.close(fig)
        return R.skip(fid, title, "no rounds.csv with validation evaluations found", blocks)
    R.save(fig, fid, title, pd.DataFrame(rows), blocks, "Line: mean over seeds; band: min-max over seeds. Non-private "
           "runs stop early; DP runs execute all R rounds (the best-validated checkpoint is evaluated once on test).")


# ------------------------------------------------------------------------------------------------ F6 MIA
def _roc(scores: np.ndarray, member: np.ndarray):
    o = np.argsort(-scores)
    y = member[o].astype(bool)
    tpr = np.r_[0, np.cumsum(y) / max(y.sum(), 1)]
    fpr = np.r_[0, np.cumsum(~y) / max((~y).sum(), 1)]
    return fpr, tpr


def fig_mia(R: Recorder, runs: pd.DataFrame, mia_scores_of: Callable) -> None:
    fid, title, blocks = "F6_membership_inference", "Membership-inference audit (attack A2, pre-registered)", ["M1"]
    if not _avail(runs, ["M1"]):
        return R.skip(fid, title, "no M1 runs recorded", blocks)
    cfgs = [("non-private", {"cfg.dp.enabled": False}, None),
            ("ε* = 1", {"cfg.dp.enabled": True, "cfg.dp.target_epsilon": 1.0}, 1.0),
            ("ε* = 4", {"cfg.dp.enabled": True, "cfg.dp.target_epsilon": 4.0}, 4.0),
            ("ε* = 8", {"cfg.dp.enabled": True, "cfg.dp.target_epsilon": 8.0}, 8.0)]
    rows = []
    fig, axes = plt.subplots(2, 3, figsize=(7.2, 4.6))
    grid = np.linspace(0, 1, 201)
    for col, ds in enumerate(DATASETS):
        ax, axr = axes[0][col], axes[1][col]
        for k, (lab, w, eps) in enumerate(cfgs):
            g = select(runs, "M1", ds, w)
            s = seedsum(g, "mia.auc")
            rows.append({"dataset": ds, "configuration": lab, "panel": "auc", **{kk: s.get(kk) for kk in
                                                                                 ("mean", "ci95_low", "ci95_high", "n")}})
            _err(ax, k, s, SERIES[k], MARKERS[k])
            tprs = []
            for rid in g["run_id"] if len(g) else []:
                sc = mia_scores_of(rid)
                if sc is None or sc.empty:
                    continue
                f, t = _roc(sc["A2"].to_numpy(float), sc["member"].to_numpy(int))
                tprs.append(np.interp(grid, f, t))
            if tprs:
                mt = np.mean(tprs, axis=0)
                axr.plot(grid, mt, color=SERIES[k], lw=1.3, label=lab, marker=MARKERS[k], ms=3, markevery=40)
                rows += [{"dataset": ds, "configuration": lab, "panel": "roc", "fpr": float(a), "tpr": float(b),
                          "n": len(tprs)} for a, b in zip(grid[::20], mt[::20])]
                if eps is not None:
                    epsm = seedsum(g, "privacy.eps").get("mean", eps)
                    axr.plot(grid, np.minimum(1, np.exp(epsm) * grid + 1e-6), color=SERIES[k], lw=0.8, ls=":")
        ax.axhline(0.5, color=INK2, lw=0.8, ls="--")
        if not select(runs, "M1", ds).shape[0]:
            _empty(ax); _empty(axr)
        ax.set_xticks(range(len(cfgs))); ax.set_xticklabels([c for c, _, _ in cfgs], fontsize=6.5, rotation=30)
        ax.set_title(DS_NAME[ds], fontsize=9)
        axr.plot([0, 1], [0, 1], color=INK2, lw=0.8, ls="--")
        axr.set_xscale("log"); axr.set_yscale("log"); axr.set_xlim(1e-3, 1); axr.set_ylim(1e-3, 1)
        axr.set_xlabel("FPR")
    axes[0][0].set_ylabel("A2 ROC-AUC"); axes[1][0].set_ylabel("TPR"); axes[1][0].legend(fontsize=6)
    R.save(fig, fid, title, pd.DataFrame(rows), blocks, "Top: AUC mean ± 95 % t-interval (dashed = chance). Bottom: "
           "mean ROC over seeds (log-log); dotted = DP bound TPR ≤ e^ε·FPR + δ at the accounted ε. Audit pool 10 % per "
           "client, inclusion probability ½; the guarantee remains the accountant's (ε, δ).")


# ------------------------------------------------------------------------------------------------ F7 integrity
def fig_integrity(R: Recorder, runs: pd.DataFrame, rounds_of: Callable, env_of: Callable) -> None:
    fid, title, blocks = "F7_integrity_overhead", "Integrity verification cost per round (hardware named)", ["N2", "R1p", "I1"]
    if not _avail(runs, ["I1"]):
        return R.skip(fid, title, "no I1 runs recorded", blocks)
    confs = [("FedAvg on", "N2", None), ("FedAvg off", "I1", {"cfg.dp.enabled": False}),
             ("Complete on", "R1p", None), ("Complete off", "I1", {"cfg.dp.enabled": True})]
    rows, hw = [], set()
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.5), sharey=False)
    for ax, ds in zip(axes, DATASETS):
        for k, (lab, blk, w) in enumerate(confs):
            g = select(runs, blk, ds, w)
            tr, it = [], []
            for rid in g["run_id"] if len(g) else []:
                rr = rounds_of(rid)
                hw.add(str((env_of(rid) or {}).get("gpu") or "CPU"))
                if rr is not None and len(rr):
                    tr.append((rr["t_local_s"] + rr["t_agg_s"]).mean()); it.append(rr["t_integrity_s"].mean())
            if not tr:
                continue
            t, i_ = float(np.mean(tr)), float(np.mean(it))
            ax.bar(k, t, color=SERIES[0], edgecolor="white", label="training + aggregation" if k == 0 else None)
            ax.bar(k, i_, bottom=t, color=SERIES[1], hatch="//", edgecolor="white", label="integrity" if k == 0 else None)
            rows.append({"dataset": ds, "configuration": lab, "train_agg_s_per_round": t, "integrity_s_per_round": i_,
                         "n": len(tr)})
        ax.set_xticks(range(len(confs))); ax.set_xticklabels([c for c, _, _ in confs], rotation=30, ha="right",
                                                              fontsize=6.5)
        ax.set_title(DS_NAME[ds], fontsize=9)
    axes[0].set_ylabel("seconds per round"); axes[0].legend(fontsize=6.5, loc="upper left")
    if not rows:
        plt.close(fig)
        return R.skip(fid, title, "no per-round timings found", blocks)
    fig.suptitle(f"hardware: {', '.join(sorted(hw))}", fontsize=7, color=INK2, y=1.02)
    R.save(fig, fid, title, pd.DataFrame(rows), blocks, f"Operational overhead measured on {', '.join(sorted(hw))}; "
           "integrity time (serialise, SHA-256, verify) is reported separately from training time. Not a poisoning "
           "defence.")


# ------------------------------------------------------------------------------------------------ F8 ablations
def fig_ablation(R: Recorder, runs: pd.DataFrame) -> None:
    fid, title = "F8_ablations", "Ablation of the complete method (ε* = 4)"
    r = runs.copy() if runs is not None else pd.DataFrame()
    if len(r) and "cfg.dp.clip" in r.columns:
        r["cfg.dp.clip_is_set"] = r["cfg.dp.clip"].notna()
    systems = [("complete", "R1p", None), ("− schedule", "R1q", None), ("− trust", "DP2", EPS4),
               ("− integrity", "I1", {"cfg.dp.enabled": True}),
               ("− DP (trust only)", "R5", {"cfg.aggregation.method": "proposed", "cfg.attack.type": "none"}),
               ("DP settings only", "DP3", {"cfg.dp.clip": None}), ("+ clipping only", "DP3", {"cfg.dp.clip_is_set": True})]
    blocks = sorted({b for _, b, _ in systems})
    if not _avail(r, blocks):
        return R.skip(fid, title, "no ablation runs recorded", blocks)
    rows = []
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.6))
    for ax, ds in zip(axes, DATASETS):
        for k, (lab, blk, w) in enumerate(systems):
            s = seedsum(select(r, blk, ds, w), "test.mrr")
            rows.append({"dataset": ds, "system": lab, **{kk: s.get(kk) for kk in ("mean", "ci95_low", "ci95_high", "n")}})
            if s.get("status") == "OK":
                ax.bar(k, s["mean"], color=SERIES[k % 8], hatch=HATCHES[k % 8], edgecolor="white")
                if np.isfinite(s["ci95_low"]):
                    ax.errorbar(k, s["mean"], yerr=[[s["mean"] - s["ci95_low"]], [s["ci95_high"] - s["mean"]]],
                                color=INK, capsize=2, lw=1)
            else:
                ax.text(k, 0, "n/a", ha="center", va="bottom", fontsize=6, color=INK2, rotation=90)
        ax.set_xticks(range(len(systems))); ax.set_xticklabels([s for s, _, _ in systems], rotation=45, ha="right",
                                                                fontsize=6.5)
        ax.set_title(DS_NAME[ds], fontsize=9)
    axes[0].set_ylabel("test MRR (filtered)")
    R.save(fig, fid, title, pd.DataFrame(rows), blocks, "Each bar removes one component (descriptive; paired "
           "differences with intervals are in the descriptive comparison table). R5 is non-private; DP3 is 3 seeds.")


# ------------------------------------------------------------------------------------------------ F9 3D
def fig_3d(R: Recorder, runs: pd.DataFrame) -> None:
    fid, title, blocks = "F9_3d_privacy_utility_bars", "Test MRR over dataset and privacy budget (3D bars)", ["DP1", "N2"]
    if not _avail(runs, ["DP1"]):
        R.skip(fid, title, "no DP1 runs recorded", blocks)
    else:
        from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
        levels = [("1", {"cfg.dp.target_epsilon": 1.0}, "DP1"), ("2", {"cfg.dp.target_epsilon": 2.0}, "DP1"),
                  ("4", {"cfg.dp.target_epsilon": 4.0}, "DP1"), ("8", {"cfg.dp.target_epsilon": 8.0}, "DP1"),
                  ("∞ (non-private)", None, "N2")]
        rows = []
        fig = plt.figure(figsize=(5.2, 3.8))
        ax = fig.add_subplot(111, projection="3d")
        for i, ds in enumerate(DATASETS):
            for j, (lab, w, blk) in enumerate(levels):
                s = seedsum(select(runs, blk, ds, w), "test.mrr")
                rows.append({"dataset": ds, "eps_level": lab, **{k: s.get(k) for k in ("mean", "ci95_low", "ci95_high", "n")}})
                if s.get("status") == "OK":
                    ax.bar3d(j - 0.3, i - 0.3, 0, 0.6, 0.6, s["mean"], color=SERIES[i], alpha=0.85, edgecolor="white",
                             linewidth=0.4)
        ax.set_xticks(range(len(levels))); ax.set_xticklabels([l for l, _, _ in levels], fontsize=6)
        ax.set_yticks(range(3)); ax.set_yticklabels([DS_NAME[d] for d in DATASETS], fontsize=6)
        ax.set_xlabel("target ε*", fontsize=7); ax.set_zlabel("test MRR", fontsize=7)
        R.save(fig, fid, title, pd.DataFrame(rows), blocks, "Categorical bars (no surface is interpolated between "
               "categories); fixed-σ DP-FedAvg at each ε*, non-private FedAvg as ε = ∞. Values with intervals: F1 and "
               "Table 7.")
    for f2, t2, need in (("F10_3d_surface_eps_alpha", "MRR surface over (ε, α)", ["X1"]),
                         ("F11_3d_surface_tau_f", "MRR surface over (τ, attacker fraction)", ["X2", "X4"])):
        if _avail(runs, need):
            R.skip(f2, t2, "Stage 5 runs exist but Stage 5 is outside the approved budget; not drawn", need)
        else:
            R.skip(f2, t2, "requires the Stage 5 blocks " + ", ".join(need) + ", deferred by owner decision B2", need)


# ------------------------------------------------------------------------------------------------ F12 FPR / legacy
def fig_fpr_thirds(R: Recorder, runs: pd.DataFrame) -> None:
    fid, title, blocks = "F12_benign_fpr_by_size_third", "Benign false-positive rate of the trust rule by client size (diagnostic)", ["R1p"]
    if not _avail(runs, ["R1p"]):
        return R.skip(fid, title, "no R1p runs recorded", blocks)
    rows = []
    fig, ax = plt.subplots(figsize=(4.6, 2.4))
    for i, ds in enumerate(DATASETS):
        g = select(runs, "R1p", ds)
        for k in range(3):
            s = seedsum(g, f"anomaly_scores.benign_fpr_at_cfg_tau_by_size_third.{k}")
            rows.append({"dataset": ds, "size_third": ["small", "middle", "large"][k],
                         **{kk: s.get(kk) for kk in ("mean", "ci95_low", "ci95_high", "n")}})
            if s.get("status") == "OK":
                x = i + (k - 1) * 0.26
                ax.bar(x, s["mean"], width=0.24, color=SERIES[k], hatch=HATCHES[k], edgecolor="white",
                       label=["small third", "middle third", "large third"][k] if i == 0 else None)
    ax.axhline(0.05, color=INK2, ls="--", lw=0.8, label="5 % (τ rule limit, overall)")
    ax.set_xticks(range(3)); ax.set_xticklabels([DS_NAME[d] for d in DATASETS]); ax.set_ylabel("benign FPR")
    ax.legend(fontsize=6.5)
    R.save(fig, fid, title, pd.DataFrame(rows), blocks, "Owner decision B4: reported descriptively; the size thirds "
           "never change the rule. Clean complete-method runs at the selected τ*.")


def fig_legacy(R: Recorder, legacy_table: Optional[pd.DataFrame]) -> None:
    fid, title, blocks = "F13_original_vs_revised_fb15k237", "Original (reported) versus reproduced versus newly measured (FB15k-237)", ["R3_legacy", "R3_fixed", "R4_legacy", "L1_legacy", "L2_trainer_fixed", "L3_accounting_fixed", "N2", "DP2", "R1p"]
    if legacy_table is None or legacy_table.empty:
        return R.skip(fid, title, "no legacy table", blocks)
    t = legacy_table[legacy_table["item"].astype(str).str.contains("MRR")].copy()

    def num(v):
        try:
            return float(str(v).split()[0].split("/")[0])
        except Exception:
            return np.nan
    t["value_num"] = t["value"].map(num)
    t = t[np.isfinite(t["value_num"])]
    if t.empty or t["source"].str.startswith("Reported").all():
        return R.skip(fid, title, "no reproduced or newly measured values recorded yet (reported values alone are "
                      "not plotted)", blocks)
    fig, ax = plt.subplots(figsize=(6.0, 2.8))
    cls = t["source"].map(lambda s: 0 if s.startswith("Reported") else (1 if s.startswith("Reproduced") else 2))
    for k, (_, r) in enumerate(t.iterrows()):
        c = int(cls.loc[r.name])
        ax.barh(k, r["value_num"], color=SERIES[c], hatch=HATCHES[c], edgecolor="white")
    ax.set_yticks(range(len(t))); ax.set_yticklabels(t["source"], fontsize=6)
    ax.invert_yaxis(); ax.set_xlabel("MRR (each under its own protocol: see the source label)")
    R.save(fig, fid, title, t.assign(n=t.get("n", 1)), blocks, "Reported = the original manuscript's value under its "
           "original protocol (Phase A provenance); Reproduced = legacy replicas; Newly measured = the revised study. "
           "Protocols differ: compare within a label class.")
