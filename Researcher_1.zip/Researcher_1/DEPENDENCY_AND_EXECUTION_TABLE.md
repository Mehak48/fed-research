# Dependencies and execution table (three researchers)

## What depends on what

| Question | Answer |
|---|---|
| Which notebooks must run first? | In every account: `00_SETUP_ONCE_PER_ACCOUNT.ipynb`. Then the tuning notebook of the dataset (`U01`, `U02`, `U03`). |
| Which notebooks need outputs of other notebooks? | Every Stage-4 notebook (`Uxx_MAIN_<dataset>`) needs `SETTINGS_<dataset>.zip`, written by `Uxx_TUNE_<dataset>`. Nothing else is passed between notebooks. |
| Which notebooks are independent? | The three tuning notebooks (of each other). All Stage-4 notebooks (of each other, once their dataset is tuned). The two replication notebooks `U24`, `U25` (of everything). |
| Which can run at the same time on different computers? | Everything that belongs to different researchers. Inside one researcher: any two different Stage-4 notebooks, if two GPU sessions are available. |
| Does any experiment depend on another researcher's results? | **No.** Tuning and Stage 4 of a dataset are with the same researcher. |
| Can the tuning dependency be removed? | No. Stage 4 uses the values selected in tuning; that is the approved protocol. It is kept, inside one researcher. |
| What is passed between researchers? | Only at the end: `RESULTS_Researcher_1.zip` and `RESULTS_Researcher_2.zip` go to Researcher 3. |

## The three kits

| ZIP | Notebooks to run | Execution order | Requires another researcher's results? | Estimated T4 GPU-hours |
|---|---|---|---|---|
| `Researcher_1.zip` | `00_SETUP_ONCE_PER_ACCOUNT.ipynb`, `01_OPTIONAL_T4_BENCHMARK.ipynb` (optional), `U01_TUNE_fb15k237.ipynb`, `U04_MAIN_fb15k237.ipynb`, `U05_MAIN_fb15k237.ipynb`, `U10_MAIN_fb15k237.ipynb`, `U11_MAIN_fb15k237.ipynb`, `U12_MAIN_fb15k237.ipynb`, `U13_MAIN_fb15k237.ipynb`, `U21_MAIN_fb15k237.ipynb`, `U24_LEGACY_fb15k237.ipynb`, `U25_LEGACY_fb15k237.ipynb`, `U26_MAIN_fb15k237.ipynb`, `U29_MAIN_fb15k237.ipynb`, `U30_MAIN_fb15k237.ipynb`, `U31_MAIN_fb15k237.ipynb`, `U32_MAIN_fb15k237.ipynb`, `U41_MAIN_fb15k237.ipynb`, `U42_MAIN_fb15k237.ipynb`, `U43_MAIN_fb15k237.ipynb`, `99_EXPORT_RESULTS_Researcher_1.ipynb` | setup → `U01_TUNE_fb15k237.ipynb` → the other notebooks in number order → export. `U24`, `U25` may run at any time. | No | at most 45.1 (18 notebooks, 315 runs) |
| `Researcher_2.zip` | `00_SETUP_ONCE_PER_ACCOUNT.ipynb`, `01_OPTIONAL_T4_BENCHMARK.ipynb` (optional), `U02_TUNE_wn18rr.ipynb`, `U06_MAIN_wn18rr.ipynb`, `U07_MAIN_wn18rr.ipynb`, `U14_MAIN_wn18rr.ipynb`, `U15_MAIN_wn18rr.ipynb`, `U16_MAIN_wn18rr.ipynb`, `U17_MAIN_wn18rr.ipynb`, `U22_MAIN_wn18rr.ipynb`, `U27_MAIN_wn18rr.ipynb`, `U33_MAIN_wn18rr.ipynb`, `U34_MAIN_wn18rr.ipynb`, `U35_MAIN_wn18rr.ipynb`, `U36_MAIN_wn18rr.ipynb`, `U44_MAIN_wn18rr.ipynb`, `U45_MAIN_wn18rr.ipynb`, `U46_MAIN_wn18rr.ipynb`, `99_EXPORT_RESULTS_Researcher_2.ipynb` | setup → `U02_TUNE_wn18rr.ipynb` → the other notebooks in number order → export. | No | at most 38.5 (16 notebooks, 285 runs) |
| `Researcher_3.zip` | `00_SETUP_ONCE_PER_ACCOUNT.ipynb`, `01_OPTIONAL_T4_BENCHMARK.ipynb` (optional), `U03_TUNE_codex_m.ipynb`, `U08_MAIN_codex_m.ipynb`, `U09_MAIN_codex_m.ipynb`, `U18_MAIN_codex_m.ipynb`, `U19_MAIN_codex_m.ipynb`, `U20_MAIN_codex_m.ipynb`, `U23_MAIN_codex_m.ipynb`, `U28_MAIN_codex_m.ipynb`, `U37_MAIN_codex_m.ipynb`, `U38_MAIN_codex_m.ipynb`, `U39_MAIN_codex_m.ipynb`, `U40_MAIN_codex_m.ipynb`, `U47_MAIN_codex_m.ipynb`, `U48_MAIN_codex_m.ipynb`, `U49_MAIN_codex_m.ipynb`, `99_EXPORT_RESULTS_Researcher_3.ipynb`, `MERGE_AND_ANALYSE.ipynb` | setup → `U03_TUNE_codex_m.ipynb` → the other notebooks in number order → export; then `MERGE_AND_ANALYSE.ipynb` (CPU). | No for the experiments. The final merge needs the export files of Researchers 1 and 2. | at most 35.3 (15 notebooks, 285 runs) |

**About the hours.** They are upper bounds from the owner's T4 pilot of 2026-11-04, measured with the old kernel and one process per GPU. The package's closed-form kernel was 1.4–2.1× faster on a CPU, and 43 of the 49 notebooks may use two processes on the GPU if a measurement on that GPU shows a gain of at least 1.25×. Neither effect was measured on a T4, so the real hours are unknown: at most the bound, and expected to be lower. The integration notebook's CPU time was not measured on the research tier.

Plan hash `f203881f7ffad0ab`, units hash `cb9810b58849833a`, core code hash `94e4155d1b53635c`.
