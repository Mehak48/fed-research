# Table 7 — privacy/utility (Pareto)

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| dataset | system | target_eps | measured_eps_worst_client | test_mrr | n | pareto |
|---|---|---|---|---|---|---|
| FB15k-237 | DP-FedAvg fixed sigma | 1 | 0.2301 | 0.005 (n=1) | 1 | True |
| FB15k-237 | DP-FedAvg fixed sigma | 2 | 0.4674 | 0.005 (n=1) | 1 | True |
| FB15k-237 | DP-FedAvg fixed sigma | 4 | 0.965 | 0.005 (n=1) | 1 | False |
| FB15k-237 | DP-FedAvg fixed sigma | 8 | 2.056 | 0.005 (n=1) | 1 | True |
| FB15k-237 | DP-FedAvg selected schedule | 4 | 0.965 | 0.005 (n=1) | 1 | False |
| FB15k-237 | Complete method | 4 | 0.965 | 0.005 (n=1) | 1 | False |
| FB15k-237 | FedAvg non-private (eps = inf) | inf | inf | 0.005 (n=1) | 1 |  |
| WN18RR | DP-FedAvg fixed sigma | 1 | 0.2301 | 0.001 (n=1) | 1 | True |
| WN18RR | DP-FedAvg fixed sigma | 2 | 0.4674 | 0.001 (n=1) | 1 | False |
| WN18RR | DP-FedAvg fixed sigma | 4 | 0.965 | 0.001 (n=1) | 1 | False |
| WN18RR | DP-FedAvg fixed sigma | 8 | 2.056 | 0.001 (n=1) | 1 | False |
| WN18RR | DP-FedAvg selected schedule | 4 | 0.965 | 0.001 (n=1) | 1 | False |
| WN18RR | Complete method | 4 | 0.965 | 0.001 (n=1) | 1 | False |
| WN18RR | FedAvg non-private (eps = inf) | inf | inf | 0.001 (n=1) | 1 |  |
| CoDEx-M | DP-FedAvg fixed sigma | 1 | 0.2301 | 0.002 (n=1) | 1 | True |
| CoDEx-M | DP-FedAvg fixed sigma | 2 | 0.4674 | 0.002 (n=1) | 1 | True |
| CoDEx-M | DP-FedAvg fixed sigma | 4 | 0.965 | 0.002 (n=1) | 1 | False |
| CoDEx-M | DP-FedAvg fixed sigma | 8 | 2.056 | 0.002 (n=1) | 1 | True |
| CoDEx-M | DP-FedAvg selected schedule | 4 | 0.965 | 0.002 (n=1) | 1 | False |
| CoDEx-M | Complete method | 4 | 0.965 | 0.002 (n=1) | 1 | True |
| CoDEx-M | FedAvg non-private (eps = inf) | inf | inf | 0.004 (n=1) | 1 |  |
