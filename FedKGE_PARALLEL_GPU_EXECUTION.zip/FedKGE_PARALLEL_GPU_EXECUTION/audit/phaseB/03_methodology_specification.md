# 03 — Proposed methodology specification (Phase B, item 3)

**Status:** design draft for your review. It is not implemented and not executed. It builds on the revision package (File 2, provisionally identified) and on decisions D1–D18, which are **pending approval**. Where a decision changes something here, the section says so. Items that the revision code does **not** do yet are marked **[Phase C]**.
**Scope:** the complete training, privacy, aggregation, integrity, attack, evaluation and statistics protocol, plus a manuscript-ready algorithm (§14). The threat model is in `03a_threat_model.md`.
**No number in this document is an experimental result.**

---

## 0. The method in one paragraph

K = 10 clients hold disjoint parts of a knowledge graph's training triples. Each round, every client starts from the current global TransE model and runs one local epoch of differentially private SGD with an Adam optimiser:
- each triple is sampled independently;
- each triple's gradient, including its 64 data-independent negatives, is clipped to norm C;
- Gaussian noise is added to every coordinate.

The client then sends its model difference, identified by a SHA-256 hash. The server:
1. verifies each received object against its identifier;
2. scores each update for anomalies (direction and magnitude relative to robust references);
3. aggregates with trust weights;
4. periodically checks a server-held validation set.

The privacy guarantee is triple-level (ε, δ)-DP for each client, under zero-out adjacency (§7.2), from Rényi-DP composition over every executed step. Model selection uses validation data only, and the test set is evaluated once.

**The complete method** (used in `06` and in §13) is this whole pipeline with every component active:
- DP at ε* = 4, with the sampling design (D11), sampling rate q*, clip C*, learning rate lr*, rounds R* and noise schedule s* chosen in Stage 3;
- the proposed trust aggregation: the rule of §8.3, plus variant V1 only if its D15 trigger fires, with the selected τ*;
- integrity verification in the data path (§9).

---

## 1. Notation

| Symbol | Meaning |
|---|---|
| $\mathcal E, \mathcal R$ | entity and relation vocabularies (public), $n_E = \lvert\mathcal E\rvert$, $n_R = \lvert\mathcal R\rvert$ |
| $d$ | embedding dimension (100) |
| $\theta = (\mathbf E, \mathbf W)$ | parameters: $\mathbf E \in \mathbb R^{n_E \times d}$, $\mathbf W \in \mathbb R^{n_R \times d}$; $P = (n_E + n_R)\,d$ |
| $\mathcal T_{tr}, \mathcal T_{va}, \mathcal T_{te}$ | official training, validation and test splits; $\mathcal T_{all} = \mathcal T_{tr} \cup \mathcal T_{va} \cup \mathcal T_{te}$ |
| $V_{sel}, V_{root}$ | fixed 80 % / 20 % split of $\mathcal T_{va}$ (seed 0): model selection / FLTrust root data |
| $V_{es} \subset V_{sel}$ | fixed 2,000-triple subset for periodic checks |
| $K$, $D_k$ | number of clients (10); training records of client $k$ ($D_k$ disjoint, $\bigcup_k D_k = \mathcal T_{tr}$) |
| $\hat N_k$ | client $k$'s **public** size: the number of records in $D_k$. It equals the true number of triples in the experiments and is identical for zero-out neighbours (§7.2) |
| $R$, $t$ | maximum rounds (100, subject to tuning), round index |
| $T$, $s$ | local DP steps per round, step index |
| $q, C, \sigma_t$ | Poisson sampling rate, clipping norm, noise multiplier in round $t$ |
| $\varepsilon^\star, \delta$ | target privacy budget (primary 4), $\delta = 10^{-6}$ |
| $U_k^t$ | client $k$'s transmitted update in round $t$ |
| $\tau, \lambda$ | trust anomaly threshold (MAD units), history penalty |
| $f$ | fraction of malicious clients; $\mathcal M$ the malicious set |

---

## 2. Data and splits

1. **Loading.** Datasets are loaded through PyKEEN (FB15k-237, WN18RR, and CoDEx-M or YAGO3-10 per D5). The vocabulary is the training vocabulary; validation and test triples containing unseen entities are removed by the loader, and the counts before and after are recorded (MN-20).
2. **Validation checks** (revision `data.validate_splits`):
   - IDs are in range;
   - duplicates are counted;
   - train/valid/test overlap is **0**;
   - the inverse-pair statistic is reported.
3. **Splits are never partitioned.** Only $\mathcal T_{tr}$ is split across clients. $V_{sel}$, $V_{root}$ and $\mathcal T_{te}$ stay global benchmark splits held by the evaluator. This keeps the evaluation identical to the centralised literature protocol. The consequence is that results are **not comparable** with per-client test-set protocols such as FedE.
4. **Simulation assumption.** A server-held (public) validation set exists. Selection on it is therefore post-processing with respect to client data (§7.5). In a real deployment without such a set, model selection would itself consume privacy. This is stated as a limitation.
5. **Licence gate.** No dataset is downloaded without an explicit confirmation flag (G12); see `04_dataset_benchmark.md` §5.

---

## 3. Client construction (non-IID partitions)

**Dirichlet over relations** (main; revision `partition.assign`). For each relation $r$ with training-triple index set $I_r$ ($n_r = |I_r|$):

$$
\mathbf p_r \sim \mathrm{Dir}(\alpha\,\mathbf 1_K),\qquad
c_{r,j} = \Big\lfloor n_r \textstyle\sum_{i \le j} p_{r,i} \Big\rfloor \ (j < K),
$$

The relation's triples are shuffled with the seeded generator, and positions $(c_{r,j-1}, c_{r,j}]$ go to client $j$.

- **Acceptance rule.** A draw is accepted iff $\min_k N_k \ge m = \max(1024,\ 0.2\,|\mathcal T_{tr}|/K)$. Otherwise the draw is repeated from the same seeded stream, up to 20,000 attempts, and then the run fails. The number of attempts is logged.
- **Consequence.** Accepted partitions follow a *truncated* Dirichlet distribution (MN-9).
- **Grid.** $\alpha \in \{0.1, 0.5, 1.0\}$ with $K = 10$; $\alpha = 0.1$ is the main setting (D4).

**References.**
- IID: a random permutation split into $K$ near-equal parts.
- Centralised: $K = 1$.
- Legacy: relations sorted by ID and cut into 5 chunks with `np.array_split` (replica blocks only).

**Fallback** (pre-approved in D4). If a partition is infeasible in Phase D: report it, then relax the 0.2 factor to 0.1 for that dataset only. $K$ is never changed.

**Heterogeneity statistics** (Table 2). These are *measured* and used to compare datasets, because $\alpha$ is not comparable across datasets with 11 vs 237 relations (`data/phaseB_partition_feasibility.csv`).
- Per client: share of triples; number of relations and entities; Jensen–Shannon divergence and Hellinger distance of its relation distribution from the global one.
- Summary: Gini of client sizes; largest share; max/min size ratio; mean JS divergence; mean pairwise entity Jaccard similarity.

**Partition audit** (master prompt §9). Every partition is checked for:
- full coverage, no overlap and valid IDs;
- the minimum size;
- deterministic re-derivation from (seed, specification, data hash);
- a hash bound to the Phase 1 data hash.

Scope note (MN-17): this models relation-composition and quantity skew. It does **not** model entity-community skew.

---

## 4. Model

$$
f(h, r, t) = -\big\lVert n(\mathbf e_h) + \mathbf w_r - n(\mathbf e_t) \big\rVert_2,\qquad n(\mathbf x) = \mathbf x / \lVert \mathbf x \rVert_2 .
$$

- **Initialisation.** $\mathbf e, \mathbf w \sim \mathcal U\big(-6/\sqrt d,\ 6/\sqrt d\big)^d$, from a run-seeded generator.
- **No warm start** from any trained model (CR-7; rejected by config validation).
- $d = 100$ (continuity with the original paper).

---

## 5. Local objective and negative sampling

**Per-triple loss** (margin $\gamma = 1$, $k = 64$ negatives):

$$
\ell(x; \theta) = \frac1k \sum_{j=1}^{k} \big[\,\gamma - f(x) + f(\tilde x_j)\,\big]_+ ,
$$

**Negatives.** $\tilde x_j$ replaces the head (probability ½) or the tail of $x = (h, r, t)$ with an entity drawn uniformly from $\mathcal E \setminus \{h\}$ (or $\setminus \{t\}$).
- Negatives are **data-independent**: they are never filtered against the client's other triples. This is required for the DP analysis (§7.2), and the absence of false-negative filtering is accepted.
- Legacy negative modes exist only in replica blocks (CR-11).

**Local objective:** $L_k(\theta) = \frac1{\hat N_k}\sum_{x \in D_k} \ell(x;\theta)$, where a null record (§7.2) has loss 0.

---

## 6. Federated protocol

| # | Step (master prompt §8) | Where | Specification |
|---|---|---|---|
| 1 | Preprocessing | evaluator / Phase 1 | §2 |
| 2 | Client construction | evaluator / Phase 2 | §3 (simulation of a natural split) |
| 3 | Global initialisation and broadcast | server → clients | §4; each client verifies the broadcast's identifier and that every value is finite before using it (§9) **[Phase C]** |
| 4 | Client selection | server | **all K clients every round** (no client subsampling, so no amplification is claimed from it) |
| 5 | Local training | client | non-private: one epoch of minibatch Adam (lr $\eta$, batch $B$), fresh optimiser state each round; private: §7.3 |
| 6 | Update transfer | client → server | $U_k^t = \theta_k^t - \theta^{t-1}$ (dense, float32), plus identifier $\mathrm{id}(U_k^t)$ |
| 7 | Clipping and noise | client | inside every DP step (§7.3); the server adds no noise |
| 8 | Trust computation | server | §8.3, using transmitted updates and public sizes **only** |
| 9 | Aggregation | server | §8 |
| 10 | Integrity verification | server (and clients for the broadcast) | §9; **before** aggregation, on the received bytes **[Phase C]** |
| 11 | Global update | server | $\theta^t = \theta^{t-1} + \Delta^t$ (server learning rate 1) |
| 12 | Validation and stopping | server | filtered MRR on $V_{es}$ every 5 rounds; non-private runs stop after 4 evaluations without improvement; **DP runs execute all R rounds** (D13, G6); keep the best-validated checkpoint |
| 13 | Final test | evaluator | the selected checkpoint is evaluated **once** on $V_{sel}$ and $\mathcal T_{te}$ (§11) |

**No secure aggregation is used:** the server sees every individual update. Clients' training losses are *not* transmitted. They appear only in the experimenter's logs, and server-side logic never uses them (CR-6).

---

## 7. Privacy mechanism and accounting

### 7.1 Definitions

A randomised mechanism $\mathcal A$ is $(\varepsilon, \delta)$-DP if, for all adjacent $D \simeq D'$ and all measurable $S$:

$$
\Pr[\mathcal A(D) \in S] \le e^\varepsilon \Pr[\mathcal A(D') \in S] + \delta .
$$

It is $(\alpha, \rho)$-RDP if $D_\alpha(\mathcal A(D) \,\Vert\, \mathcal A(D')) \le \rho$ (Mironov 2017).

### 7.2 Privacy unit and adjacency (D2; fixes CR-14)

- **Unit:** one training triple of one client.
- **Adjacency: zero-out** (Kairouz et al. 2021; Ponomareva et al. 2023). $D_k \simeq D_k'$ if one is obtained from the other by **replacing one triple with a null record $\bot$**, whose loss and gradient are identically 0.
  - Neighbours therefore have the **same size** $\hat N_k$, which is public.
  - The size enters the FedAvg and trust weights, the normalisation $q\hat N_k$, and (under design A) $q_k$ and $T_k$. Because it is identical for neighbours, publishing it reveals nothing about which triples a client holds.
  - Under plain add/remove adjacency, publishing the exact size would be a leak (CR-14).
- **Protected object:** for each client $k$, the sequence of everything it transmits, $\mathcal A_k(D_k) = (U_k^1, \dots, U_k^{R_{exec}})$, where each round adaptively depends on the public broadcasts. The broadcasts are themselves functions of earlier transmissions.
- **Public parameters**, fixed before training: $\mathcal E$, $\mathcal R$, $\hat N_k$, $q$, $C$, $\{\sigma_t\}$, $T$, $R$, $\eta$, $k$, $\gamma$, $d$.
- **Sensitivity.** Negatives are drawn independently of the data (§5), and every per-triple gradient is clipped to $\lVert \bar g_x \rVert_2 \le C$, with non-finite gradients set to 0 (§7.6). Replacing one triple by $\bot$ changes the sum of clipped gradients in a step by at most $C$ in $\ell_2$, and only when that position is sampled.
- **Consequence for accounting.** The pair of output distributions is exactly the one analysed for the Poisson-subsampled Gaussian under add/remove adjacency. The RDP and PLD bounds below, and every ε number in Phase B, are unchanged.

### 7.3 Mechanism (client side, one round)

**Design Q** (offered next to design A; T2d decides, D11). One step $s = 1, \dots, T$, with $T = \mathrm{round}(1/q)$:

1. **Poisson sampling:** $S_s = \{x \in D_k : b_x = 1\}$ with $b_x \sim \mathrm{Bernoulli}(q)$ independently.
2. **Per-triple gradients** $g_x = \nabla_\theta\, \ell(x; \theta_{s-1})$, each with its own negatives. Rows of the same entity appearing several times inside one example are summed *before* the norm is taken (revision `dp.per_example_clipped_sum`).
3. **Clipping:** $\bar g_x = g_x \cdot \min\!\big(1,\ C/(\lVert g_x \rVert_2 + 10^{-6})\big)$, with $\bar g_x = 0$ if $g_x$ is not finite **[Phase C]**.
4. **Noise on every coordinate**, including rows no sampled triple touched:
   $\tilde G_s = \sum_{x \in S_s} \bar g_x + \mathcal N(0,\ \sigma_t^2 C^2 \mathbf I_P)$.
5. **Normalisation and optimiser step:** $\hat g_s = \tilde G_s / (q \hat N_k)$, then $\theta_s = \mathrm{AdamStep}(\theta_{s-1}, \hat g_s)$, with fresh Adam state each round (post-processing).

The client then releases $U_k^t = \theta_T - \theta^{t-1}$.

**Design A** (revision default). Expected batch $B$ is fixed, $q_k = B/\hat N_k$, $T_k = \mathrm{round}(\hat N_k/B)$, and $\sigma_{k,t}$ is calibrated per client. **Both designs give every client $\varepsilon_k \le \varepsilon^\star$.**

### 7.4 Accounting and calibration

**Composition.** Each step is the Poisson-subsampled Gaussian mechanism with sensitivity $C$ and noise multiplier $\sigma_t$. With $\rho_{SGM}(\alpha; q, \sigma)$ its RDP (Mironov, Talwar & Zhang 2019), adaptive composition over all executed steps gives

$$
\varepsilon^{RDP}_k(\alpha) = \sum_{t=1}^{R_{exec}} T \cdot \rho_{SGM}(\alpha; q, \sigma_t),
$$

**Conversion** to $(\varepsilon, \delta)$, as implemented in `dp_accounting` (Balle et al. 2020):

$$
\varepsilon_k(\delta) = \min_{\alpha > 1}\Big[\varepsilon^{RDP}_k(\alpha) + \log\frac{\alpha - 1}{\alpha} - \frac{\log \delta + \log \alpha}{\alpha - 1}\Big],
$$

**Orders.** Any finite set of orders gives a valid upper bound; coarser sets are slightly conservative. Orders whose series fail to converge are excluded, which can only increase ε.
- **Reported ε** comes from the run-time accountant with the revision's `MAIN_ORDERS` (1.25–4.5 in steps of 0.25–0.5, the integers 5–63, and 64, 80, 96, 128, 160, 192, 256).
- **The Phase B planning script** used a denser set (Opacus defaults 1.1–10.9 and 12–63, plus 64–1024). This explains, for example, 7.9975 vs 7.9829 at the same σ in cross-check case 4 of `data/phaseB_sigma_plan.json`.

**Calibration** (D3). With a deterministic schedule $\sigma_t = \sigma_0\, g(t)$ fixed before training:

$$
\sigma_0^\star = \min\{\sigma_0 : \varepsilon_k(\delta; \sigma_0 g(1), \dots, \sigma_0 g(R)) \le \varepsilon^\star\},
$$

found by bisection, rounded up, so every client ends at or below $\varepsilon^\star$. Under design Q, $\sigma_0^\star$ is the same for all clients and datasets. Under design A, it is per client.

**Planning values** (q = 0.05, R = 100, δ = 1e-6; `data/phaseB_sigma_plan.csv`):

| ε* | 1 | 2 | 4 | 8 |
|---|---|---|---|---|
| σ₀* | 10.20 | 5.42 | 2.96 | 1.72 |

**Schedules** (D12). $g$ is piecewise constant in blocks of $u = 5$ rounds, with block position $x_b = b/(n_b - 1)$ and end ratio $\rho = \sigma_{last}/\sigma_0 \in \{0.25, 0.5\}$:

| Shape | $g$ |
|---|---|
| fixed | $1$ |
| linear | $1 - (1-\rho)x_b$ |
| exponential | $\rho^{x_b}$ |
| cosine | $\rho + (1-\rho)\tfrac{1 + \cos(\pi x_b)}{2}$ |

Every schedule is calibrated to the same $\varepsilon^\star$, so a schedule cannot win by spending more privacy. Optional (D12-b, block O1): σ decays when server-side validation stalls, accounted with an RDP filter (Feldman & Zrnic 2021).

**Cross-checks, stated precisely** (`data/phaseB_sigma_plan.json`).

| Check | What it is | Result at four operating points |
|---|---|---|
| Revision's `calibrate_sigma0` vs this script | *same library, different code path* | within 0.2 % |
| Own numerical integration of $\rho_{SGM}$ (scipy quadrature, orders ≤ 256) | independent of `dp_accounting` (own code) | ε within 1.4·10⁻⁴ of the `dp_accounting` RDP value |
| PRV accountant (Gopi et al. 2021; package `prv-accountant`) | different library and method | brackets the `dp_accounting` PLD value; both ≈ 0.93 × RDP, e.g. PRV [3.719, 3.739] vs PLD 3.730 when RDP = 4.000 |

In Phase C, every reported ε is recomputed from the logged $(q, T, \{\sigma_t\}, R_{exec})$ with RDP and PRV.

### 7.5 Post-processing

These do not increase $\varepsilon_k$:
- Adam;
- normalisation inside the score;
- trust scoring and aggregation (which use only $U^t$ and $\hat N$);
- checkpoint selection on server-held $V_{sel}$;
- all evaluation.

Early stopping is not used in DP runs, so the reported ε is exactly the ε of all $R$ executed rounds.

### 7.6 What the guarantee covers and what it does not

**Covered:** whether a given triple is in $D_k$ (as opposed to a null record), given the public size $\hat N_k$. This holds against any party that sees client $k$'s messages: the server, other clients and any coalition of them, and users of the final model.
- The noise is added by the client, and clipping bounds the sensitivity for *any* broadcast model, so no trust in the server is needed for privacy.
- Clients reject non-finite broadcasts, and non-finite per-example gradients are set to 0 before clipping, so a crafted inf/NaN broadcast cannot break the clipping bound **[Phase C]** (MN-22).

**Not covered** (stated in the paper):
1. **Entities.** An entity in $g$ triples gets only group privacy, $(g\varepsilon,\ g\,e^{(g-1)\varepsilon}\delta)$. At ε = 4 and δ = 1e-6 that is (8, 1.1·10⁻⁴) for $g = 2$, (12, 8.9·10⁻³) for $g = 3$, and vacuous for $g \ge 4$. Entities appear in about 37.5 training triples on average in FB15k-237, so **there is no meaningful entity-level protection**.
2. how many triples a client holds ($\hat N_k$ is public);
3. client participation;
4. which relations a client mostly holds, and its data distribution (dataset-level properties);
5. duplicated or correlated facts (acute in YAGO3-10, MJ-21);
6. the privacy cost of hyperparameter tuning: each tuning run trained on client data and is **not** included in ε (disclosed; OP-2);
7. floating-point and PRNG side channels beyond the non-finite guard (MN-14);
8. the server's validation data, which are assumed not to be client data (§2.4).

**Reported for every DP configuration** (master prompt §7-G):
- the adjacency (zero-out);
- ε (RDP) for the worst client and per client, at δ = 1e-6 and 1e-5;
- ε (PLD) and ε (PRV, upper value) for the worst client;
- σ₀ and the full σ schedule;
- C, q (and $q_k$ under design A), T, R planned and executed, total steps per client;
- smallest and largest $\hat N_k$, and δ × largest $\hat N_k$;
- the accountant, orders and library versions;
- the assumptions above.

---

## 8. Aggregation rules

All rules receive the $n$ transmitted updates $U_i \in \mathbb R^P$ that passed integrity verification, plus the public sizes $\hat N_i$ ($n = K$, plus Sybil identities if any). They output $\Delta^t$.

### 8.1 FedAvg

$\Delta = \sum_i \frac{\hat N_i}{\sum_j \hat N_j} U_i$ (McMahan et al. 2017).

### 8.2 Robust baselines

**Robustness parameters** are set to the **design value** $f_{design} = 0.2$, including in clean runs, or to the true attacker count if that is larger (f = 0.3 runs). This avoids degenerate "no-defence" configurations in clean runs, such as a trimmed mean with β = 0. Assumption violations are flagged (MN-18).

- **Coordinate-wise median** (Yin et al. 2018). Valid if $f < n/2$.
- **Trimmed mean** with $\beta = 0.2$ (0.3 when f = 0.3): remove the $\lfloor \beta n\rfloor$ largest and smallest values per coordinate, then average.
- **Krum** (Blanchard et al. 2017) with f = 2 (3 when f = 0.3). Selects $\arg\min_i \sum_{j \in \mathcal N_i} \lVert U_i - U_j\rVert^2$ over the $n - f - 2$ nearest neighbours. Requires $n > 2f + 2$.
- **FLTrust** (Cao et al. 2021).
  - Root set: 500 triples from $V_{root}$.
  - The server computes $U_0$ by one non-private local epoch on the root set.
  - $\mathrm{TS}_i = \mathrm{ReLU}(\cos(U_i, U_0))$ and $\bar U_i = U_i\,\lVert U_0\rVert / \lVert U_i \rVert$.
  - $\Delta = \sum_i \mathrm{TS}_i \bar U_i / \sum_i \mathrm{TS}_i$, or $0$ if all scores are 0.
  - Note: $U_0$ is noise-free, so under DP the cosine scores may all be small (RK-6). This is reported, not tuned around.

### 8.3 Proposed trust-weighted aggregation (revision `trust.py`, frozen per D15)

| Quantity | Definition |
|---|---|
| Reference | $U_{ref} = \mathrm{median}_i\, U_i$ (coordinate-wise; uses no server data) |
| Direction anomaly | $a_i = 1 - \cos(U_i, U_{ref}) \in [0, 2]$ |
| Magnitude anomaly | $m_i = \big\lvert \log\big(\lVert U_i\rVert / \mathrm{med}_j \lVert U_j \rVert\big)\big\rvert$ |
| Robust standardisation | $z(x)_i = \dfrac{x_i - \mathrm{med}(x)}{1.4826\,\mathrm{MAD}(x) + 10^{-12}}$ |
| Anomaly score | $A_i = \max\big(z(a)_i,\ z(m)_i\big)$ |
| Flag | $\phi_i = \mathbb 1[A_i > \tau]$ |
| History | $h_i \leftarrow h_i + \phi_i$, starting from $h_i = 0$ |
| Trust | $\mathrm{tr}_i = (1 - \phi_i)\, e^{-\lambda h_i}$ |
| Norm bound | $\tilde U_i = U_i \cdot \min\big(1,\ \mathrm{med}_j\lVert U_j\rVert / \lVert U_i \rVert\big)$ |
| Weights | $w_i = \hat N_i\,\mathrm{tr}_i \big/ \textstyle\sum_j \hat N_j\,\mathrm{tr}_j$ |
| Aggregate | $\Delta = \sum_i w_i \tilde U_i$; if $\sum_j \hat N_j\,\mathrm{tr}_j = 0$, then $\Delta = U_{ref}$ (fallback, logged) |

Settings: $\lambda = 0.5$ (a priori; sensitivity checked in X3); $\tau$ chosen by the FPR rule of D14, **after** the D15 variant is fixed.

**Properties** (answers to master prompt §10).
- **Initialisation:** all clients trusted ($h = 0$).
- **Dynamics:** history only grows; there is no forgiveness. A false flag permanently down-weights a client by $e^{-\lambda}$ per flag.
- **Normalisation:** weights sum to 1.
- **Extremes:** MAD = 0 is guarded by $10^{-12}$; if every client is flagged, the median fallback is used.
- **Penalising honest non-IID or small clients:** possible (RK-3). Measured as benign FPR by client-size third, every round.
- **Server observability:** only $U_i$ and $\hat N_i$.
- **Privacy:** pure post-processing of DP outputs. It costs no privacy and provides none.
- **Manipulation:**
  - an attacker who knows the rule can craft updates just below $\tau$ (adaptive attack, §10);
  - Sybil identities can inflate weight through claimed sizes;
  - small-norm "stealth" updates pass the norm bound by design.

**Variant V1** (the only variant; applied only through the D15 trigger). The magnitude anomaly uses $m_i = \lvert \log(\lVert U_i\rVert / \mathrm{med}_{j \in S(i)} \lVert U_j\rVert) \rvert$, where $S(i)$ is the set of clients in the same declared-size third as client $i$ in the current round. It uses only published updates and public sizes, so it is post-processing.

---

## 9. Integrity verification (D7; fixes CR-13)

| Item | Specification |
|---|---|
| Objects | every client update $U_k^t$ and every broadcast global model $\theta^t$ |
| Serialisation | `len(header)` ‖ JSON header (sorted keys: name, round, dtype, shape) ‖ float32 little-endian payload |
| Identifier | `"sha256-" ‖ hex(SHA-256(bytes))`; **not** an IPFS CID (no multihash/CIDv1/UnixFS) |
| Manifest | per round: {round, all object ids, id of the previous manifest} (hash chain) |
| Protocol | sender computes the id and sends it over the authenticated channel; bytes go to the content store (untrusted); receiver fetches, recomputes and compares |
| Data path | **only the tensor deserialised from verified bytes is aggregated** **[Phase C]** |
| On mismatch at the server | the object is rejected (the client is dropped for that round), logged and counted |
| On a failed or non-finite broadcast at a client | the client sends no update that round and reports the failure **[Phase C]** |
| Guarantee | any change to covered bytes (payload + header, including round and name) is detected, assuming SHA-256 second-preimage resistance and authentic identifiers |
| Not guaranteed | authenticity of the identifier itself without an authenticated channel or signatures; availability; that the content is benign (a poisoned update hashes correctly); IPFS properties (DHT, pinning, replication) |
| Measured | bytes serialised per round; hash, verify, store and fetch seconds; rejection counts; with corruption injection (block I2), detection rate (must be 1.0) and utility with verification on vs off |

**Corruption model for I2.** Each transmitted object is independently corrupted in transit with probability $p_{tamper}$ (one uniformly chosen payload byte is XOR-ed with 0xFF).
- With integrity off, corrupted tensors enter aggregation. One flipped exponent byte can produce huge or NaN values.
- With integrity on, they are rejected.

This measures what verification buys. It is **not** a poisoning defence.

---

## 10. Attacks (threat model in `03a_threat_model.md`)

**Common settings.**
- The malicious set $\mathcal M$ ($|\mathcal M| = \mathrm{round}(fK)$) is fixed before training by seeded random placement; a variant places attackers on the largest clients.
- $f = 0.2$ is the main setting; $\{0.1, 0.3\}$ are sensitivity checks.
- Each round, an attacker first computes its honest update $U_m^{h}$ with the client protocol on $D_m$, with DP when DP is on.
- Strength $s = 3$ a priori (revision default; MN-19).

| Attack | Malicious update | Knowledge | Noise mode under DP (D16) | In revision code? |
|---|---|---|---|---|
| Gaussian | $\mathcal N\big(0, (s\lVert U_m^h\rVert)^2/P\ \mathbf I\big)$ | black-box | inherit (norm tied to the noisy honest update) | yes |
| Sign-flip (scaled) | $-s\,U_m^h$ | black-box | inherit | yes |
| ALIE (Baruch et al. 2019) | $\mu - z\,\hat\sigma$ (coordinate-wise benign mean and std), $z = \Phi^{-1}\!\big((n - s')/n\big)$, $s' = \lfloor n/2 + 1\rfloor - f$ | white-box | matched: isotropic noise added so the norm equals $\lVert U_m^h\rVert$ | crafting yes; matching **[Phase C]** |
| IPM (Xie et al. 2019) | $-s\,\mu$ | white-box | matched | crafting yes; matching **[Phase C]** |
| KG-targeted poisoning | 50 targets $(h, r, t^\ast)$: $(h, r)$ drawn from the **attacker's own training triples**, $t^\ast$ a random entity the evaluator confirms is a *false* tail; 50 copies of each added to $D_m$; DP training on $D_m \cup$ poison, then scaled by $s$ | black-box | inherit | revision trains the attacker **without** DP and draws targets from the **test set** → **[Phase C]** (MN-21) |
| Adaptive, AGR-tailored (Shejwalkar & Houmansadr 2021) | $\hat\mu - \gamma\hat\sigma$, with $\gamma$ = the largest value on an 81-point grid in [0, 20] whose *simulated* proposed anomaly score stays $\le \tau(1 - 0.05)$ | gray-box (colluders' updates + previous global update) | matched | crafting yes; matching and use against FedAvg (R2a) **[Phase C]** |
| Sybil | $k$ data-less identities send $-s\,\Delta^{t-1}$ + jitter and claim the median size | black-box | matched | crafting yes; matching **[Phase C]** |

The noise-free variants (the revision's current behaviour) are run only in block X5. For FedAvg under the adaptive attack (R2a), the update is crafted with the same $\gamma$ search against the proposed rule.

**Success metrics** (computed per seed; all differences are paired).
- **Untargeted degradation:** $\Delta_a = \mathrm{MRR}^{clean} - \mathrm{MRR}^{a}$, with the same aggregator and configuration. Relative: $\Delta_a / \mathrm{MRR}^{clean}$.
- **Defence effectiveness against FedAvg — a ratio of means:**
  $E_a = 1 - \overline{\Delta_a^{complete}} \,/\, \overline{\Delta_a^{FedAvg}}$, where the bars are means over seeds and both arms use the same DP configuration.
  - It is defined only when the attack is effective against FedAvg (the lower bound of $\overline{\Delta^{FedAvg}}$ is > 0).
  - Per-seed ratios are **not** used, because they are unstable.
  - It is tested as a linear contrast (§13.2).
- **Targeted success:** $\mathrm{TS} = \frac{1}{50}\sum \mathbb 1[\mathrm{rank}(t^\ast \mid h, r) \le 10]$, raw ranking on the final model. Damage is $\mathrm{TS}^a - \mathrm{TS}^{clean}$.
- **Detection** (rules that flag or select clients):
  - per round, $\mathrm{TPR} = |\text{flagged} \cap \mathcal M| / |\mathcal M|$ and $\mathrm{FPR} = |\text{flagged} \setminus \mathcal M| / (n - |\mathcal M|)$;
  - averaged over rounds;
  - **benign FPR also reported by client-size third** and in clean runs.
- **Malicious weight share:** $\sum_{i \in \mathcal M} w_i$ per round.
- **Defence overhead:** aggregation seconds per round.

---

## 11. Evaluation metrics

**Filtered ranking** (both directions). For each test triple $(h, r, t)$, the tail query $(h, r, ?)$ scores every $e \in \mathcal E$. Every $e \ne t$ with $(h, r, e) \in \mathcal T_{all}$ is removed (filtered setting), and the head query is handled symmetrically. Then:

$$
\mathrm{rank}_{opt} = 1 + \#\{e : s_e > s_t\},\qquad
\mathrm{rank}_{pes} = \mathrm{rank}_{opt} + \#\{e \ne t : s_e = s_t\},\qquad
\mathrm{rank} = \tfrac12(\mathrm{rank}_{opt} + \mathrm{rank}_{pes}) \ \ (\text{realistic}).
$$

- **Averaging convention:** micro-average over $Q = 2|\mathcal T_{te}|$ queries: $\mathrm{MRR} = \frac1Q \sum_q 1/\mathrm{rank}_q$ and $\mathrm{Hits@}k = \frac1Q\sum_q \mathbb 1[\mathrm{rank}_q \le k]$ for $k \in \{1, 3, 10\}$.
- **Also stored, labelled separately:** head-only and tail-only metrics; optimistic and pessimistic MRR; macro-average over relations of per-relation MRR; query-bootstrap 95 % interval, which is within-run uncertainty only (MN-13).
- **Leakage check:** evaluation never uses training triples as queries. Validation is used only for selection, and the test set is evaluated exactly once per run.
- **Convergence:** per round, the mean client loss (logs only), validation MRR every 5 rounds, the ε trace and the update norm.
- **Communication:** per round, upload $\approx K(4P + \text{header})$ bytes and download $K \cdot 4P$ bytes. These are computed bytes, not measured network time. FB15k-237: $4P$ = 5.9 MB, so ≈ 118 MB per round.
- **Runtime:** local-training, aggregation, integrity and evaluation seconds; the device is recorded.
- **Privacy:** §7.6. **Integrity:** §9. **Attacks:** §10.

---

## 12. Statistical analysis

- **Unit of analysis:** one run (dataset, configuration, seed) yields one test value from its selected checkpoint. Rounds are never treated as replicates (CR-5).
- **Pairing:** the same seed gives the same partition, initialisation and attacker placement across configurations, so comparisons are paired by seed.
- **Per configuration:** all per-seed values; mean; SD (ddof = 1); 95 % t-interval.
- **Comparisons:** mean paired difference with 95 % t-interval; $d_z = \bar d / s_d$; paired t-test.
  - Ratios use the log scale: mean of $\log(x_A/x_B)$ with a t-interval, then exponentiate.
- **Hypothesis tests:** **one-sided at α = 0.025**, with Holm correction within each family (§13).
- **Exact sign-flip tests are secondary.** Their minimum p is:

  | Seeds | Two-sided | One-sided |
  |---|---|---|
  | 5 | 0.0625 | 1/32 ≈ 0.031 |
  | 10 | 0.002 | 1/1024 |

  So with 5 seeds no exact test can reject at the one-sided 0.025 level; only the t-test can (G14).
- **Primary evidence:** effect sizes and intervals.
- **Seeds** (D8, D13):
  - selection uses tuning seed 1001 only;
  - every block that carries a hypothesis test uses at least the 5 confirmatory seeds {42, 123, 256, 512, 1024}; in the full profile the headline blocks get five more (S10x, `06` §3);
  - blocks with 3 seeds are descriptive and labelled as such.
- **Failures** are reported in Table 14 and never dropped silently.

---

## 13. Pre-registered hypotheses and decision rules (D9)

Fixed before Stage 4. Every hypothesis may fail, and failures are reported as failures.

**General rule.**
- Each hypothesis is a **family** of one-sided paired t-tests, at α = 0.025 with Holm correction over all pre-registered members.
- A member that is "not testable" enters with p = 1, so the family size cannot shrink after seeing the data.
- A per-dataset (or per-attack) conclusion uses its Holm-adjusted p.
- A statement that a hypothesis holds "on all datasets" requires every member to pass.
- Unadjusted 95 % intervals are always reported alongside.

Notation: $M$ = test MRR, $s$ = seed.

### 13.1 H1 — Utility retention under privacy (original threshold 90 %)

- **Ratio:** for each dataset, $\rho_s = M_s(\text{complete method},\ \varepsilon^\star = 4) / M_s(\text{centralised, non-private})$ (R1p vs N1).
- **Test:** H0: $\mathbb E[\log\rho] \le \log 0.9$ vs H1: $> \log 0.9$, a one-sided paired t-test on $\log\rho_s$.
- **Family:** 3 datasets.

Reported descriptively next to it:
- federation cost: FedAvg / centralised, both non-private (N2 / N1);
- privacy cost: complete method / FedAvg non-private;
- the DP3 decomposition into settings, clipping and noise.

### 13.2 H2 — Robustness (original threshold 35 %)

For each dataset and each attack $a$ (6 attacks + adaptive = 7), both arms use the complete method's DP configuration:
- $\Delta^F_s = M_s(\text{FedAvg, clean}) - M_s(\text{FedAvg}, a)$, from DP2 at ε* = 4 and R2/R2a;
- $\Delta^P_s = M_s(\text{complete, clean}) - M_s(\text{complete}, a)$, from R1p and R3/R3a.

For the targeted attack, $\Delta$ is the increase in target success.

**Testability gate:** the attack must be effective, i.e. the one-sided lower 97.5 % bound of $\bar\Delta^F$ is > 0. Otherwise the member is "not testable" with p = 1.

**Test:** with $c_s = 0.65\,\Delta^F_s - \Delta^P_s$, H0: $\mathbb E[c] \le 0$.
- Rejecting H0 is equivalent to $E_a \ge 0.35$, with $E_a$ defined as the ratio of means (§10).
- Family: 3 datasets × 7 attacks = 21 members.

**H2b — no harm.**
- H0: $\mathbb E[\log(M^{P,clean}/M^{F,clean})] \le \log 0.95$, comparing R1p with DP2 at ε* = 4.
- Family: 3 datasets.

H2 is evaluated under DP. The non-private version (R5) is reported descriptively as an ablation.

### 13.3 H3 — Membership leakage (only if D6 keeps it; original threshold 25 %)

- **Audit design (block M1, 5 seeds):** each client's audit pool is drawn from its training triples, and each candidate is included in training with probability ½. Excluded candidates are replaced by null records, so the audit targets exactly the zero-out guarantee of §7.2 (`05_privacy_utility_plan.md` §10).
- **Primary attack (pre-registered):** A2, the relation-calibrated score on the final global model, pooled over all clients. $A_s = \mathrm{AUC}_s - 0.5$. A1 and A3 are secondary (`05` §10).
- **Testability:** the one-sided lower 97.5 % bound of $\bar A^{np}$ (FedAvg, non-private) must be > 0. Otherwise H3 is reported as "not testable: no measurable leakage", with p = 1.
- **Test:** H0: $\mathbb E[A^{dp} - 0.75\,A^{np}] \ge 0$ vs H1: $< 0$, where $A^{dp}$ is FedAvg + DP at $\varepsilon^\star = 4$.
- **Attribution:** the reduction is attributed to DP only, because both arms use FedAvg. Family: 3 datasets.

### 13.4 HS — Scheduled noise ("adaptive DP")

- **Difference:** $\Delta_s = M_s(\text{FedAvg} + \text{DP}, s^\star) - M_s(\text{FedAvg} + \text{DP, fixed})$ at $\varepsilon^\star = 4$ (DP2 vs DP1).
- **Test:** H0: $\mathbb E[\Delta] \le 0$. Family: 3 datasets.
- **Not testable** if tuning selects the fixed schedule ($s^\star$ = fixed).
- Also reported descriptively inside the complete method (R1p vs R1q).
- The schedule $s^\star$ is selected on the tuning seed only, so there is no double use of data.

### 13.5 Descriptive questions (no significance claims)

Heterogeneity (N3, X1), τ and f sensitivity (X2, X4), baseline ranking (R1, R4), integrity overhead (I1, I2), legacy replication (L0–L4), the DP-cost decomposition (DP3) and trust without DP (R5).

---

## 14. Algorithm 1 (manuscript-ready)

```
Algorithm 1  Triple-level DP federated TransE with trust-weighted aggregation and integrity verification
Public: vocabulary (E, R), client sizes N̂_k, d, k, γ, η, q, C, schedule σ_1..σ_R (calibrated to ε*), R, τ, λ
Server
 1: θ⁰ ← Init(seed);  h_i ← 0 for all i;  best ← (−∞, ⊥)
 2: for t = 1, …, R do
 3:     publish θ^{t−1} with id(θ^{t−1})              ▷ clients check id and finiteness; on failure they skip the round
 4:     for each client k = 1..K in parallel do                 ▷ full participation
 5:         U_k^t ← ClientUpdate(k, θ^{t−1}, σ_t); send id(U_k^t) on the authenticated channel; put bytes in the store
 6:     A ← ∅
 7:     for each k: b ← Fetch(id(U_k^t)); if SHA256(b) = id(U_k^t) then A ← A ∪ {(k, Deserialize(b))} else log rejection
 8:     Δ^t ← Aggregate(A, {N̂_k}; rule)                         ▷ FedAvg | TM | Median | Krum | FLTrust | Trust(τ, λ)
 9:     θ^t ← θ^{t−1} + Δ^t;  append manifest_t = (ids, id(manifest_{t−1}))
10:     if t mod 5 = 0 then v ← MRR(θ^t; V_es); if v > best.v then best ← (v, θ^t)
11:     if not DP and 4 evaluations without improvement then break   ▷ DP runs execute all R rounds
12: return best.θ;  evaluate once on V_sel and T_te;  ε_k ← RDP accountant over all executed steps (PLD, PRV cross-checks)

ClientUpdate(k, θ, σ)                                           ▷ private version, design Q
13: θ' ← θ;  reset Adam state
14: for s = 1, …, T = round(1/q) do
15:     S ← {x ∈ D_k : Bernoulli(q)};  draw k uniform negatives per x ∈ S (data-independent)
16:     G ← Σ_{x∈S} clip_C(finite(∇_θ ℓ(x; θ'))) + N(0, σ²C² I_P)
17:     θ' ← AdamStep(θ', G / (q N̂_k))
18: return θ' − θ
```

---

## 15. What Phase C must change in the revision package (implementation plan; pending approval)

| # | Change | Fixes |
|---|---|---|
| C1 | Sampling design Q (common q, T = round(1/q), expected batch q·N̂_k) next to design A; config validation for both | MJ-16, D11 |
| C2 | Tunable DP and non-private knobs (q or B, lr, C, R) with pre-registered selection rules restricted to the tuning seed; selection hashes frozen | MJ-17–19, D13 |
| C3 | DP runs: early stopping off, keep the best-validated checkpoint; non-private runs: patience rule | G6 |
| C4 | Log anomaly scores in **every** run (FedAvg too) for the τ rule; τ selection by benign FPR after the D15 decision; variant V1 behind a flag (off) | MJ-5, D14, D15 |
| C5 | Attack noise modes (inherit / matched / none); KG-targeted attacker trains with DP and draws targets from its own data; adaptive crafting usable against FedAvg (R2a); robustness parameters at the design value f = 0.2 | G7, D16, MN-18, MN-21 |
| C6 | Integrity in the data path (serialise → store → fetch → verify → deserialise → aggregate); corruption injection; integrity-off mode; identifier-authenticity assumption documented | CR-13, D7 |
| C7 | MIA (if D6 keeps it): randomised audit pool (inclusion probability ½), primary attack A2 pooled, TPR at 1 % and 0.1 % FPR, one-run audit lower bound, DP-bound overlay | MJ-15, D6 |
| C8 | α = 0.5 partitions; partition audit report; dataset-specific fallback flag | G4, G15, D4 |
| C9 | CoDEx-M loader (PyKEEN `CoDExMedium`) and a licence-confirmation gate before any download | D5, G12 |
| C10 | `scripts/` entry points; local and Colab/Kaggle commands; tables 1–14 and 3D/2D figures from records only; PNG + PDF + SVG | G5, G13, MN-7 |
| C11 | Checkpoints compatible with `weights_only=True`; device and GPU recorded; option to keep final weights only for selected blocks | MN-16, D18 |
| C12 | `THREAT_MODEL.md` (from 03a) added to the repository | G3 |
| C13 | Statistics: log-ratio tests, the H2 linear contrast, Holm families with fixed membership, tuning/confirmatory seed separation enforced | D9, D13 |
| C14 | Script to re-evaluate the saved legacy checkpoint under the corrected protocol (L0) | OP-8 |
| C15 | Run the 26 PyTorch-dependent tests, then all new tests, **before** any GPU run (Stage 0 gate) | G1 |
| C16 | Non-finite guards: clients reject non-finite or unverified broadcasts; non-finite per-example gradients are zeroed before clipping | MN-22 |
| C17 | Zero-out adjacency stated in `DP_MECHANISM.md` and recorded in every `accountant.json`; ε also recomputed with the PRV accountant | CR-14, CR-2 |

## References

- Abadi et al. 2016 (DP-SGD, CCS) *[standard]*
- Akrami et al. 2020 (SIGMOD; YAGO3-10 leakage) — verified
- Balle et al. 2020 (RDP conversion, AISTATS) *[standard]*
- Baruch et al. 2019 (ALIE, NeurIPS) *[standard]*
- Blanchard et al. 2017 (Krum, NeurIPS) *[standard]*
- Cao et al. 2021 (FLTrust, NDSS) *[standard]*
- Feldman & Zrnic 2021 (Rényi filter, NeurIPS) *[standard]*
- Gopi, Lee & Wutschitz 2021 (PRV accountant, NeurIPS) — library used in Phase B
- Hu et al. 2023 (DP-Flames, WWW '23, DOI 10.1145/3543507.3583450) — verified
- Kairouz et al. 2021 (zero-out adjacency, ICML) *[standard]*
- McMahan et al. 2017 (FedAvg, AISTATS) *[standard]*
- Mironov 2017 (RDP, CSF) *[standard]*
- Mironov, Talwar & Zhang 2019 (sampled Gaussian RDP) *[standard]*
- Ponomareva et al. 2023 (How to DP-fy ML, JAIR) *[standard]*
- Safavi & Koutra 2020 (CoDEx, EMNLP) — verified
- Shejwalkar & Houmansadr 2021 (AGR-tailored attacks, NDSS) *[standard]*
- Steinke, Nasr & Jagielski 2023 (privacy auditing with one training run, NeurIPS) *[standard]*
- Toutanova & Chen 2015 (FB15k-237 construction) — verified
- Xie et al. 2019 (IPM, UAI) *[standard]*
- Yin et al. 2018 (median / trimmed mean, ICML) *[standard]*

"*[standard]*" = well-known reference not re-fetched in this session. Every citation is checked against its source in the manuscript phase (CL-31).
