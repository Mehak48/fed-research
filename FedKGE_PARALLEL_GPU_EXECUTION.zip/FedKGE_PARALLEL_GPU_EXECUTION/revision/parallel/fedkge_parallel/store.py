"""The master store: the single results root that is analysed.

IMPORT (phase 09) accepts a run only if ALL of these hold, otherwise the run (or the whole bundle) is refused and
reported, never silently dropped or repaired:
  * the bundle's bytes equal its sidecar and every member equals its recorded SHA-256;
  * same core code hash and (research tiers) same frozen-manifest hash as the master;
  * ENVIRONMENT: the bundle's signature equals the one recorded for (tier, dataset) in the master's
    ENVIRONMENT_LOCK.json (first import records it; enforced on the research tiers, recorded on check tiers);
  * the run is COMPLETE with the current code hash, its tier and dataset match, and run_id(config.json) equals its
    folder name (so the configuration cannot have been altered);
  * its data hash equals the master's Phase-1 artifact and its partition hash equals the master's partition (built
    deterministically from the master's own data when missing);
  * every selected value it used (selection_refs) equals the master's current selection, where the master has it.
A run already in the master with identical files is skipped; one with DIFFERENT files is kept as it is and the
incoming copy is quarantined under <tier>/parallel_conflicts/ (two executions of one run must never be mixed).

SELECT / FREEZE / RELEASE (phase 06) re-derive every Stage-3 selection on the master from the imported runs with the
SAME functions as scripts/run_plan.py (tune_select: fedkge.selection, gate G-B, tau rule with fallback B3, D10) and
freeze them with scripts/freeze_selections.py. In chain mode the worker's own selection must be reproduced exactly.
"""
from __future__ import annotations

import json
import os
import shutil
import tempfile
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd

from .bundles import export_pack, list_verified, open_zip
from .cells import approved_cells, entry_cell_key, expand_plan
from .common import (CONFIG_DIR, RESEARCH_TIERS, IntegrityError, JobLog, Layout, Paths, RunDir, atomic_replace_dir,
                     atomic_write_json, code_hash, read_json, read_json_or, sha256_bytes, sha256_file, tiers_for,
                     utc_now, write_json)
from .jobs import Job, materialize


class Waiting(IntegrityError):
    """A master step cannot run YET: some of its input runs are not in the master store (nothing is wrong)."""


def _results_root(root: Path) -> Path:
    from _common import results_root
    return results_root(str(root))


class Master:
    def __init__(self, layout: Layout, mode: str = "research", log: Optional[JobLog] = None):
        self.layout = layout.ensure()
        self.mode = mode
        self.tiers = tiers_for(mode)
        self.root = _results_root(layout.master)
        self.log = log or JobLog(self.root / "parallel" / "logs" / "master.log")
        self.ledger_path = self.root / "parallel" / "IMPORT_LEDGER.json"

    # ------------------------------------------------------------------------------------------------ helpers
    def paths(self, tier: str) -> Paths:
        return Paths(self.root, tier)

    def ledger(self) -> Dict:
        return read_json_or(self.ledger_path, {"bundles": {}})

    def plan(self) -> Dict:
        if not self.layout.plan_file.exists():
            raise SystemExit("no plan yet: run phase 03 (plan jobs) first")
        return read_json(self.layout.plan_file)

    def plan_jobs(self) -> List[Job]:
        return [Job.from_dict(d) for d in self.plan()["jobs"]]

    def _p1_hash(self, tier: str, ds: str) -> str:
        m = self.paths(tier).p1(ds) / "manifest.json"
        if not m.exists():
            raise IntegrityError(f"the master has no Phase-1 artifact for {tier}/{ds}: run phase 02 for the master "
                                 f"(--root master) before importing")
        return read_json(m)["content_hash"]

    def _partition_hash(self, tier: str, ds: str, spec: Dict, seed: int) -> str:
        from fedkge.data import load_artifact
        from fedkge.partition import build_partition, canonical_spec, load_partition, spec_key
        paths = self.paths(tier)
        spec = canonical_spec(spec)
        mp = paths.p2(ds) / spec_key(spec) / f"seed{seed}_manifest.json"
        if not mp.exists():
            d = load_artifact(paths.p1(ds))
            try:
                load_partition(paths.p2(ds), spec, seed, d.content_hash)
            except IntegrityError:
                build_partition(d.train, d.num_relations, spec, seed, paths.p2(ds), d.content_hash)
        return read_json(mp)["content_hash"]

    def _stage_map(self) -> Dict:
        if not hasattr(self, "_stages"):
            self._stages = {(c.phase, c.block): c.stage for c in approved_cells(self.mode)}
        return self._stages

    def _lock(self, tier: str) -> Dict:
        return read_json_or(self.paths(tier).base / "ENVIRONMENT_LOCK.json",
                            {"tier": tier, "fields": None, "datasets": {}})

    def env_check(self, tier: str, ds: str, sig: Optional[Dict], source: str) -> None:
        """One environment per (tier, dataset) across ALL workers (the core lock, extended across results roots)."""
        from fedkge.config import load_yaml
        cfg = load_yaml(CONFIG_DIR / "gates.yaml")["environment_lock"]
        enforce = tier in cfg.get("enforce_on_tiers", [])
        if sig is None:
            if enforce:
                raise IntegrityError(f"{source}: no environment signature recorded for {tier}/{ds}")
            return
        p = self.paths(tier).base / "ENVIRONMENT_LOCK.json"
        lock = self._lock(tier)
        lock["fields"] = list(cfg["fields"])
        rec = lock["datasets"].get(ds)
        if rec is None:
            lock["datasets"][ds] = {"signature": sig, "recorded_utc": utc_now(), "sessions": [utc_now()],
                                    "note": f"first imported from {source}"}
        else:
            diff = {k: (rec["signature"].get(k), sig.get(k)) for k in cfg["fields"] if rec["signature"].get(k) != sig.get(k)}
            if diff and enforce:
                raise IntegrityError(f"{source}: environment of {tier}/{ds} differs from the one already in the master "
                                     f"store {diff}; these runs cannot join the same comparison. Rerun them on a worker "
                                     f"of the recorded class, or start this (tier, dataset) group again")
            if diff:
                rec.setdefault("mismatches_not_enforced", []).append({"source": source, "diff": diff})
            rec.setdefault("sessions", []).append(utc_now())
        p.parent.mkdir(parents=True, exist_ok=True)
        write_json(p, lock)

    # ------------------------------------------------------------------------------------------------- import
    def import_all(self) -> Dict:
        import shutil as _sh
        for tier in set(self.tiers.values()):         # leftovers of an interrupted import (never a real run folder)
            runs = self.paths(tier).base / "runs"
            for d in (runs.glob(".incoming-*") if runs.exists() else []):
                _sh.rmtree(d, ignore_errors=True)
        led = self.ledger()
        summary = {"imported": [], "skipped_known": 0, "refused": []}
        for zp, sha in list_verified(self.layout.outbox):
            if sha in led["bundles"] and led["bundles"][sha].get("status") != "REFUSED":
                summary["skipped_known"] += 1
                continue                       # refused bundles are re-examined (e.g. after phase 02 on the master)
            try:
                rec = self.import_bundle(zp, sha)
                summary["imported"].append(rec)
            except IntegrityError as e:
                self.log(f"REFUSED {zp.name}: {e}")
                rec = {"bundle": zp.name, "status": "REFUSED", "reason": str(e), "utc": utc_now()}
                summary["refused"].append(rec)
            led = self.ledger()
            led["bundles"][sha] = rec
            atomic_write_json(self.ledger_path, led)
        not_ready = [p.name for p in sorted(self.layout.outbox.glob("*.zip")) if p not in
                     {z for z, _ in list_verified(self.layout.outbox)}]
        summary["not_yet_verifiable"] = not_ready
        return summary

    def import_bundle(self, zp: Path, sha: str) -> Dict:
        from fedkge.config import get_dotted, run_id as cfg_run_id
        from fedkge.runner import write_index
        z, meta = open_zip(zp)
        if meta.get("kind") != "result_bundle":
            raise IntegrityError("not a result bundle")
        tier, ds = meta["tier"], meta["dataset"]
        if tier not in self.tiers.values():
            raise IntegrityError(f"tier {tier} does not belong to mode {self.mode}")
        if meta["code_hash"] != code_hash():
            raise IntegrityError(f"core code hash {meta['code_hash'][:12]} differs from the master's {code_hash()[:12]}")
        if tier in RESEARCH_TIERS:
            man = read_json(CONFIG_DIR / "manifest" / "FROZEN_MANIFEST.json")["content_sha256"]
            if meta.get("frozen_manifest_content_sha256") != man:
                raise IntegrityError("the bundle was produced against a different frozen manifest")
        p1 = self._p1_hash(tier, ds)
        if meta.get("data_hash") != p1:
            raise IntegrityError(f"data hash {str(meta.get('data_hash'))[:12]} differs from the master's {p1[:12]}")
        self.env_check(tier, ds, meta.get("env_signature"), zp.name)
        paths = self.paths(tier)
        sel_cache: Dict[str, Optional[Dict]] = {}
        out = {"bundle": zp.name, "sha256": sha, "job_id": meta["job_id"], "worker": meta["worker"], "tier": tier,
               "dataset": ds, "imported": [], "identical_already_present": [], "conflicts": [], "refused_runs": {},
               "deferred_selection_checks": [], "incomplete_in_bundle": meta.get("incomplete", {}), "utc": utc_now(),
               "status": "IMPORTED"}
        rows = []
        stage_of = self._stage_map()
        for rid, rrec in sorted(meta["runs"].items()):
            try:
                files = {rel: z.read(f"runs/{rid}/{rel}") for rel in rrec["files"]}
                for rel, data in files.items():
                    if sha256_bytes(data) != rrec["files"][rel]:
                        raise IntegrityError(f"{rel} differs from its recorded SHA-256")
                for need in ("config.json", "final.json", "status.json", "env.json"):
                    if need not in files:
                        raise IntegrityError(f"{need} missing")
                cfg, fin, st = (json.loads(files[n]) for n in ("config.json", "final.json", "status.json"))
                if st.get("status") != "COMPLETE" or st.get("code_hash") != code_hash() or fin.get("code_hash") != code_hash():
                    raise IntegrityError("not COMPLETE with the current code hash")
                if fin["tier"] != tier or cfg["tier"] != tier or fin["dataset"] != ds:
                    raise IntegrityError("tier or dataset does not match the bundle")
                if cfg_run_id(cfg) != rid:
                    raise IntegrityError("run_id(config.json) differs from the folder name")
                if fin["data_hash"] != p1:
                    raise IntegrityError("STALE_DATA")
                if fin["partition_hash"] != self._partition_hash(tier, ds, cfg["partition"], int(fin["seed"])):
                    raise IntegrityError("STALE_PARTITION: the master's partition differs")
                env = json.loads(files["env.json"])
                sig = meta.get("env_signature") or {}
                if sig and env.get("torch") != sig.get("torch"):
                    raise IntegrityError(f"env.json torch {env.get('torch')} differs from the bundle signature")
                for ref, val in (cfg.get("selection_refs") or {}).items():
                    fname, dotted = ref.split(".", 1)
                    if fname not in sel_cache:
                        sp = paths.selection(fname)
                        sel_cache[fname] = read_json(sp) if sp.exists() else None
                    cur = get_dotted(sel_cache[fname], dotted, None) if sel_cache[fname] is not None else None
                    if cur is None:
                        out["deferred_selection_checks"].append(rid)
                    elif cur != val:
                        raise IntegrityError(f"STALE_SELECTION: {ref} = {val!r}, master has {cur!r}")
                self._place_run(paths, rid, files, zp.stem, out)
                rows.append({"phase": cfg["phase"], "stage": None, "block": cfg["block"], "name": cfg["name"],
                             "dataset": ds, "seed": int(cfg["seed"]), "run_id": rid})
            except IntegrityError as e:
                out["refused_runs"][rid] = str(e)
        if rows:                       # index rows of the imported runs (the master's own expansion re-writes them)
            df = pd.DataFrame(rows)
            for ph, g in df.groupby("phase"):
                ents = [{"phase": ph, "stage": stage_of.get((ph, r["block"]), 0), "block": r["block"], "name": r["name"],
                         "dataset": r["dataset"], "seed": r["seed"], "run_id": r["run_id"]} for r in g.to_dict("records")]
                write_index(paths, ph, ents)
        if meta["job_kind"] == "TUNECHAIN":
            dst = self.root / "parallel" / "worker_records" / zp.stem
            for name in meta["files_sha256"]:
                if name.startswith("worker/"):
                    p = dst / name[len("worker/"):]
                    p.parent.mkdir(parents=True, exist_ok=True)
                    p.write_bytes(z.read(name))
        if out["refused_runs"]:
            out["status"] = "PARTIALLY_IMPORTED"
        self.log(f"import {zp.name}: {len(out['imported'])} new, {len(out['identical_already_present'])} identical, "
                 f"{len(out['conflicts'])} conflict(s), {len(out['refused_runs'])} refused")
        return out

    def _place_run(self, paths: Paths, rid: str, files: Dict[str, bytes], bundle: str, out: Dict) -> None:
        dst = paths.run(rid)
        if dst.exists():
            rd = RunDir(dst)
            if rd.is_complete_and_current():
                same = all((dst / rel).exists() and sha256_file(dst / rel) == sha256_bytes(b) for rel, b in files.items())
                if same:
                    out["identical_already_present"].append(rid)
                    return
                q = paths.base / "parallel_conflicts" / f"{rid}__{bundle}"
                for rel, b in files.items():
                    (q / rel).parent.mkdir(parents=True, exist_ok=True)
                    (q / rel).write_bytes(b)
                out["conflicts"].append({"run_id": rid, "kept": "the copy already in the master store",
                                         "quarantined": str(q)})
                return
            rd.archive_stale("superseded_by_import")
        (paths.base / "runs").mkdir(parents=True, exist_ok=True)
        tmp = Path(tempfile.mkdtemp(prefix=f".incoming-{rid}-", dir=paths.base / "runs"))
        for rel, b in files.items():
            (tmp / rel).parent.mkdir(parents=True, exist_ok=True)
            (tmp / rel).write_bytes(b)
        atomic_replace_dir(tmp, dst)
        out["imported"].append(rid)

    # ------------------------------------------------------------------------------------- selection & freeze
    def _tune_context(self):
        from fedkge.config import load_yaml
        tier = self.tiers["tune"]
        rules = load_yaml(CONFIG_DIR / "selection_rules.yaml")
        gates = load_yaml(CONFIG_DIR / "gates.yaml")
        seeds = list(load_yaml(CONFIG_DIR / "tiers" / f"{tier}.yaml")["seeds"])
        if tier == "tune" and seeds != list(rules["tuning_seeds"]):
            raise IntegrityError("tune tier seeds differ from the pre-registered tuning seeds")
        return tier, rules, gates, seeds

    def select_stage(self, ds: str, stage: int, man) -> Dict:
        """Exactly one iteration of scripts/run_plan.py's tuning loop, without training: expand the stage with the
        master's selections so far, require every run COMPLETE in the master store, index, select."""
        import run_plan
        from fedkge.manifest import check_entries_against_manifest
        from fedkge.runner import write_index
        tier, rules, gates, seeds = self._tune_context()
        paths = self.paths(tier)
        entries = expand_plan("tune", tier, paths, [ds], [stage])
        if tier in RESEARCH_TIERS:
            check_entries_against_manifest(entries, self._frozen(), "tune", require_all=False)
        missing = sorted({e["run_id"] for e in entries if not RunDir(paths.run(e["run_id"])).is_complete_and_current()})
        if missing:
            raise Waiting(f"stage {stage} of {ds}: {len(missing)} run(s) not yet in the master store: "
                                 f"{missing[:4]} - import their bundles first")
        run_plan.ensure_partitions(entries, paths, man)
        write_index(paths, "tune", entries)
        return run_plan.tune_select(stage, paths, rules, gates, seeds, [ds], man)

    def _frozen(self) -> Dict:
        from fedkge.manifest import verify_frozen
        return verify_frozen(CONFIG_DIR)

    def select(self, ds: str, stages: List[int], verify_against: Optional[Path] = None) -> Dict:
        """Run select_stage for the given stages in order. GateStop (research) is returned, not raised."""
        import run_plan
        from _common import Manifest
        man = Manifest(self.root, f"parallel_select_{ds}_s{'-'.join(map(str, stages))}")
        out = {}
        try:
            for s in stages:
                out[f"stage{s}"] = self.select_stage(ds, s, man)
                self.log(f"{ds} stage {s} selections: {json.dumps(out[f'stage{s}'], default=str)}")
        except run_plan.GateStop as e:
            man.close("GATE_G-B_FAILED", reason=str(e))
            return {"gate_failed": str(e), "stages": out}
        except Waiting as e:
            man.close("WAITING_FOR_IMPORTS", reason=str(e))
            raise
        except IntegrityError as e:
            man.close("REFUSED", reason=str(e))
            raise
        if verify_against is not None:
            w = read_json(verify_against)
            m = read_json(self.paths(self.tiers["tune"]).selection("tuning"))
            if w.get(ds) != m.get(ds):
                man.close("SELECTION_MISMATCH")
                raise IntegrityError(f"{ds}: the master's replayed selection differs from the worker's "
                                     f"(worker {w.get(ds)}, master {m.get(ds)}); nothing is frozen")
            out["verified_against_worker"] = str(verify_against)
        man.close("COMPLETE", selections=out)
        return out

    def latest_chain_record(self, ds: str) -> Optional[Path]:
        recs = sorted((self.root / "parallel" / "worker_records").glob(f"T-{ds}-chain__*"),
                      key=lambda r: r.name.rsplit("__", 1)[-1])          # newest bundle (UTC stamp) last
        for r in reversed(recs):
            p = r / "selection" / "tuning.json"
            if p.exists():
                return p
        return None

    def freeze(self, ds: str) -> Optional[Dict]:
        if self.mode != "research":
            self.log(f"{self.mode} tier: nothing to freeze (the check tier reads its own selections)")
            return None
        import freeze_selections
        try:
            code = freeze_selections.main(["--results", str(self.root), "--datasets", ds])
        except SystemExit as e:
            raise IntegrityError(f"freeze refused for {ds}: {e}")
        if code != 0:
            raise IntegrityError(f"freeze refused for {ds} (exit {code})")
        return read_json(self.paths("final").base / "selection" / "FROZEN.json")

    # ------------------------------------------------------------------------------------------------ release
    def _complete_ids(self, tier: str) -> set:
        base = self.paths(tier).base / "runs"
        return {p.name for p in base.iterdir() if RunDir(p).is_complete_and_current()} if base.exists() else set()

    def release(self, ds: str, what: str) -> Optional[Path]:
        """Materialise the next jobs of `ds` (what = 'main' or 'tune-s<k>') and publish them in a release pack."""
        from fedkge.manifest import check_entries_against_manifest, resolve
        from fedkge.runner import write_index
        import run_plan
        from _common import Manifest
        jobs = self.plan_jobs()
        man = Manifest(self.root, f"parallel_release_{ds}_{what}")
        if what == "main":
            tier = self.tiers["main"]
            paths = self.paths(tier)
            if tier == "final":
                run_plan.require_frozen_selections(paths, [ds])
            entries = expand_plan("main", tier, paths, [ds])
            if tier in RESEARCH_TIERS:
                check_entries_against_manifest(entries, self._frozen(), "main", require_all=True)
                rp = paths.base / "manifest" / "resolved_main.json"
                old = [c for c in read_json_or(rp, {"cells": []})["cells"] if c["dataset"] != ds]
                write_json(rp, {"cells": old + resolve(entries, self._frozen(), "main")})
            sel_jobs = sorted([j for j in jobs if j.kind == "MAIN" and j.dataset == ds],
                              key=lambda j: (j.priority, j.shard))
            files = {f"{tier}/selection/tuning.json": paths.selection("tuning")}
            if tier == "final":
                files[f"{tier}/selection/FROZEN.json"] = paths.base / "selection" / "FROZEN.json"
            info = {"frozen_sha256": sha256_file(paths.selection("tuning")) if tier == "final" else None}
        else:
            stage = int(what.split("-s")[1])
            tier = self.tiers["tune"]
            paths = self.paths(tier)
            entries = expand_plan("tune", tier, paths, [ds], [stage])
            sel_jobs = sorted([j for j in jobs if j.kind == "TUNESTAGE" and j.dataset == ds and j.stage == stage],
                              key=lambda j: j.shard)
            files = {f"{tier}/selection/tuning.json": paths.selection("tuning"),
                     f"{tier}/gates/sanity_gate.json": paths.base / "gates" / "sanity_gate.json"}
            info = {"frozen_sha256": None}
        run_plan.ensure_partitions(entries, paths, man)
        for ph in sorted({e["phase"] for e in entries}):
            write_index(paths, ph, [e for e in entries if e["phase"] == ph])
        by_key = {entry_cell_key("main" if what == "main" else "tune", e): e for e in entries}
        specs = materialize(sel_jobs, by_key, self._complete_ids(tier))
        for s in specs:
            atomic_write_json(self.layout.plan_dir / "jobs" / f"{s['job_id']}.json", {**s, "requires_release": True,
                                                                                    "released_utc": utc_now()})
        info["selection_sha256"] = {k: sha256_file(v) for k, v in files.items() if Path(v).exists()}
        pack = export_pack(self.layout, tier, ds, what, {k: v for k, v in files.items() if Path(v).exists()}, specs,
                           info, self.log)
        man.close("COMPLETE", pack=str(pack), jobs=[s["job_id"] for s in specs])
        return pack

