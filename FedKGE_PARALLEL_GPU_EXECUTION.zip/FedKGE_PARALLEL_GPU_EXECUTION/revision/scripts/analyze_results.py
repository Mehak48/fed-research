#!/usr/bin/env python3
"""Statistical analysis of the recorded runs (pre-registered hypotheses H1, H2, H2b, H3, HS; descriptive comparisons).

  python scripts/analyze_results.py --tier final [--results R]       -> <R>/final/analysis/
  python scripts/analyze_results.py --tier smoke                     -> watermarked software check
  python scripts/analyze_results.py --fixture --out DIR               -> FIXTURE software check (random numbers)

Reads only COMPLETE, current runs (analysis.collect); missing, failed or stale runs are reported, never imputed.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from _common import CONFIG_DIR, REPO, Manifest, results_root


def make_context(a):
    if a.fixture:
        from fedkge.fixtures import FixtureContext
        return FixtureContext(CONFIG_DIR, REPO.parent)
    from fedkge.context import ResultsContext
    return ResultsContext(results_root(a.results), a.tier, CONFIG_DIR, REPO.parent)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results"); ap.add_argument("--tier", default="final", choices=["final", "smoke"])
    ap.add_argument("--fixture", action="store_true", help="software check on labelled random numbers")
    ap.add_argument("--out", help="output folder (default <results>/<tier>/analysis)")
    a = ap.parse_args(argv)
    from fedkge.reporting import run_analysis
    ctx = make_context(a)
    if a.fixture and not a.out:
        ap.error("--fixture needs --out (fixture outputs never go into a results root)")
    out = Path(a.out) if a.out else ctx.paths.base / "analysis"
    man = None if a.fixture else Manifest(ctx.root, f"analysis_{a.tier}")
    res = run_analysis(ctx, out)
    for fam, f in res["families"].items():
        print(f"{fam}: {f['holm_status']}; " + ", ".join(f"{m['member']}={m['decision'][:40]}" for m in f["members"][:7]))
    if man:
        man.output(out); man.close("COMPLETE", families={k: v["holm_status"] for k, v in res["families"].items()})
    print(json.dumps({"out": str(out), "tier": ctx.tier}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
