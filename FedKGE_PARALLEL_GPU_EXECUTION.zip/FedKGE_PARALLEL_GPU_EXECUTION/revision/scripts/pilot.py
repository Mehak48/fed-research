#!/usr/bin/env python3
"""Measured pilot (Phase C step 7 / Phase B Stage 2): timing runs that execute a few rounds of the real
configurations (true sigma, q, steps, clipping, dense noise, integrity, trust) on full-size data, then extrapolate
per-run and plan-level cost from the MEASURED seconds. Metrics of these partial runs are never evidence.

  python scripts/pilot.py --datasets fb15k237 wn18rr codex_m --rounds 2 [--device cuda]
  python scripts/pilot.py --datasets synthetic_fb15k237_sized ... --rounds 2      (size-matched stand-ins, see below)

Every (dataset, configuration) runs in its own subprocess, so the peak resident memory (and, on CUDA, the peak
allocated GPU memory) belongs to that run alone. Storage = size of the run directory (final weights kept).

A dataset config with `size_proxy_for: <benchmark>` is a SIZE-MATCHED SYNTHETIC stand-in: its cost is used for the
benchmark's extrapolation (cost depends on sizes, not content), and every output row says so.

Extrapolation: the tuning (Stage 3) and confirmatory (Stages 4-5) matrices are expanded exactly as the runner
expands them, with placeholder selections (q = 0.05, R = 100, design Q, tau = 3), and every UNIQUE run gets a
measured per-round cost: non-private central / federated; design A; design Q with cost(q) = a + b/q fitted to the
q = 0.10 and q = 0.02 measurements (T = 1/q steps of q*N examples: per-example work constant, per-step work such as
dense noise scales with 1/q); plus the measured overhead of the proposed aggregator with hash-only integrity.
Upper bound: every run executes rounds_max (non-private early stopping only shortens runs). NOT measured (listed in
the output): attack crafting, robust baselines other than the proposed method, the MIA audit, the legacy replicas.

Outputs (results/phaseC/pilot/, UTC-stamped, never overwritten): pilot_measurements_<ts>.csv,
pilot_extrapolation_<ts>.csv, pilot_summary_<ts>.json.
"""
from __future__ import annotations

import argparse
import json
import resource
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import pandas as pd

from _common import CONFIG_DIR, Manifest, results_root
from small_run import make_cfg
from fedkge.config import load_yaml, run_id

# timing configurations: (label, small_run profile, overlay, planned rounds R)
CONFIGS = [
    ("np_central", "np_central", {"train": {"eval_every": 1}}, 60),
    ("np_fed", "np_fed", {"train": {"eval_every": 1}}, 60),
    ("dp_fedA_B512", "dp_a", {"train": {"eval_every": 1}}, 100),
    ("dp_fed_q0.10", "dp_q", {"dp": {"q": 0.1}, "train": {"eval_every": 1}}, 100),
    ("dp_fed_q0.02", "dp_q", {"dp": {"q": 0.02}, "train": {"eval_every": 1}}, 100),
    ("complete_q0.10", "complete", {"dp": {"q": 0.1}, "train": {"eval_every": 1}}, 100),
]
EVAL_EVERY_PLANNED = 5          # base.yaml train.eval_every (validation passes during a planned run)
MARK = "PILOT_RESULT "


def dir_mb(p: Path) -> float:
    return sum(f.stat().st_size for f in p.rglob("*") if f.is_file()) / 1e6 if p.exists() else 0.0


def proxy_of(ds: str) -> str | None:
    return load_yaml(CONFIG_DIR / "datasets" / f"{ds}.yaml").get("size_proxy_for")


# ------------------------------------------------------------------------------------------------ one measured run
def worker(a) -> int:
    from fedkge.federated import run_experiment
    from fedkge.io import Paths
    label, prof, extra, R = next(c for c in CONFIGS if c[0] == a.config)
    extra = {**extra, "train": {**extra.get("train", {}), "keep_final_weights": True}}
    cfg = make_cfg(a.dataset, "pilot", prof, 1001, R, extra, stop_after=a.rounds)
    paths = Paths(Path(a.results), "pilot")
    rid = run_id(cfg)
    rec = {"dataset": a.dataset, "size_proxy_for": proxy_of(a.dataset), "config": label, "planned_rounds": R,
           "measured_rounds": a.rounds, "run_id": rid}
    t0 = time.time()
    try:
        fin = run_experiment(cfg, paths, a.device, force=True)
        rr = pd.read_csv(paths.run(rid) / "rounds.csv")
        n_eval = int(rr["val_es_mrr"].notna().sum()) if "val_es_mrr" in rr else 0
        rt = fin["runtime"]
        rec.update({"status": "COMPLETE", "device": rt["device"], "num_params": fin["num_params"],
                    "local_s_per_round": float(rr["t_local_s"].mean()), "agg_s_per_round": float(rr["t_agg_s"].mean()),
                    "integrity_s_per_round": float(rr["t_integrity_s"].mean()) if "t_integrity_s" in rr else 0.0,
                    "val_eval_s_per_pass": rt["es_eval_s"] / max(n_eval, 1), "final_eval_s": rt["final_eval_s"],
                    "total_s": rt["total_s"], "gpu_peak_allocated_mb": rt.get("gpu_peak_allocated_mb"),
                    "run_dir_mb": dir_mb(paths.run(rid)),
                    "final_weights_mb": (paths.run(rid) / "final_weights.pt").stat().st_size / 1e6
                    if (paths.run(rid) / "final_weights.pt").exists() else None,
                    "eps_after_measured_rounds": (fin.get("privacy") or {}).get("eps")})
        per_round = rec["local_s_per_round"] + rec["agg_s_per_round"] + rec["integrity_s_per_round"]
        rec["per_round_s"] = per_round
        rec["extrapolated_run_hours"] = (R * per_round + (R // EVAL_EVERY_PLANNED) * rec["val_eval_s_per_pass"]
                                         + rec["final_eval_s"]) / 3600
    except Exception as e:                                   # recorded, never hidden
        rec.update({"status": "FAILED", "error": repr(e)})
    rec["wall_s"] = time.time() - t0
    rec["peak_rss_mb"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024     # this process = this run
    print(MARK + json.dumps(rec, default=str), flush=True)
    return 0 if rec["status"] == "COMPLETE" else 1


# ------------------------------------------------------------------------------------------------ extrapolation
def _fake_selection(base: Path, tier: str) -> None:
    sel = {ds: {"T1_nonprivate": {"train": {"lr": 0.001, "batch_size": 512}},
                "T1_central": {"train": {"lr": 0.001, "batch_size": 512}},
                "T2a": {"dp": {"q": 0.05}, "train": {"lr": 0.003}}, "T2b": {"dp": {"clip": 1.0}},
                "T2c": {"train": {"rounds_max": 100}}, "T2d": {"dp": {"sampling": "common_rate"}},
                "T3": {"dp": {"schedule": {"shape": "cosine", "rho": 0.5}}},
                "tau": {"aggregation": {"tau": 3.0}}}
           for ds in ("fb15k237", "wn18rr", "codex_m")}
    d = base / tier / "selection"
    d.mkdir(parents=True, exist_ok=True)
    (d / "tuning.json").write_text(json.dumps(sel))


def planned_runs() -> pd.DataFrame:
    """Every unique run of the tune matrix and of the confirm matrix (both profiles), with its cost class."""
    from fedkge.io import Paths
    from fedkge.runner import expand
    rows = []
    with tempfile.TemporaryDirectory() as tmp:
        for tier, mat, profiles in (("tune", "tune", ("full",)), ("final", "confirm", ("reduced", "full"))):
            _fake_selection(Path(tmp), tier)
            for prof in profiles:
                seen = set()
                for e in expand(tier, CONFIG_DIR, Paths(tmp, tier), tier, profile=prof, matrix_name=mat):
                    if e["run_id"] in seen:
                        continue
                    seen.add(e["run_id"])
                    c = e["cfg"]
                    dp, part, agg = c["dp"], c["partition"], c["aggregation"]
                    if not dp["enabled"]:
                        cls = "np_central" if part["scheme"] == "centralized" else "np_fed"
                    else:
                        cls = "dp_A" if dp["sampling"] == "fixed_batch" else "dp_Q"
                    rows.append({"plan": "tune" if tier == "tune" else f"confirm_{prof}", "stage": e["stage"],
                                 "block": e["block"], "dataset": e["dataset"], "cls": cls,
                                 "q": float(dp.get("q", 0.0)) if dp["enabled"] else None,
                                 "rounds": int(c["train"]["rounds_max"]),
                                 "proposed": agg.get("method") == "proposed",
                                 "attack": c["attack"]["type"], "mia": bool(c.get("mia", {}).get("enabled")),
                                 "other_aggregator": agg.get("method") not in ("fedavg", "proposed")})
    return pd.DataFrame(rows)


def extrapolate(meas: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    ok = meas[meas["status"] == "COMPLETE"].copy()
    ok["bench"] = ok["size_proxy_for"].fillna(ok["dataset"])
    m = {(r.bench, r.config): r for r in ok.itertuples()}
    plan = planned_runs()
    hours, missing = [], set()
    for r in plan.itertuples():
        def get(cfg_label):
            x = m.get((r.dataset, cfg_label))
            if x is None:
                missing.add((r.dataset, cfg_label))
            return x
        if r.cls in ("np_central", "np_fed"):
            x = get(r.cls); per = x.per_round_s if x is not None else None
        elif r.cls == "dp_A":
            x = get("dp_fedA_B512"); per = x.per_round_s if x is not None else None
        else:
            x10, x02 = get("dp_fed_q0.10"), get("dp_fed_q0.02")
            x = x10
            if x10 is not None and x02 is not None:
                b = (x02.per_round_s - x10.per_round_s) / (1 / 0.02 - 1 / 0.10)
                a = x10.per_round_s - b / 0.10
                per = a + b / r.q
            else:
                per = None
        if per is not None and r.proposed:
            xc, x10 = get("complete_q0.10"), m.get((r.dataset, "dp_fed_q0.10"))
            if xc is not None and x10 is not None:
                per += max(0.0, xc.per_round_s - x10.per_round_s)
        if per is None or x is None:
            hours.append(None); continue
        h = (r.rounds * per + (r.rounds // EVAL_EVERY_PLANNED) * x.val_eval_s_per_pass + x.final_eval_s) / 3600
        hours.append(h)
    plan["hours_upper"] = hours
    unmeasured = {"per_plan": {p: {"attack_runs": int((g["attack"] != "none").sum()), "mia_runs": int(g["mia"].sum()),
                                   "other_aggregator_runs": int(g["other_aggregator"].sum())}
                               for p, g in plan.groupby("plan")},
                  "note": "these runs ARE in the estimate with their training cost; only the extra cost of attack "
                          "crafting, robust aggregation and the MIA audit is not measured",
                  "missing_measurements": sorted(f"{d}:{c}" for d, c in missing)}
    return plan, unmeasured


# ------------------------------------------------------------------------------------------------ driver
def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results"); ap.add_argument("--datasets", nargs="+")
    ap.add_argument("--rounds", type=int, default=2); ap.add_argument("--device", default=None)
    ap.add_argument("--configs", nargs="*", help="subset of config labels")
    ap.add_argument("--extrapolate-only", nargs="+", metavar="CSV",
                    help="no runs: extrapolate from saved pilot_measurements CSVs (a later file overrides an earlier "
                         "measurement of the same dataset and configuration, e.g. a clean re-measurement)")
    ap.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("--dataset", help=argparse.SUPPRESS); ap.add_argument("--config", help=argparse.SUPPRESS)
    a = ap.parse_args(argv)
    if a.worker:
        return worker(a)
    root = results_root(a.results)
    stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    if a.extrapolate_only:
        man = Manifest(root, "pilot_extrapolation")
        frames = [pd.read_csv(f).assign(_src=str(f)) for f in a.extrapolate_only]
        meas = pd.concat(frames, ignore_index=True).drop_duplicates(["dataset", "config"], keep="last")
        for f in a.extrapolate_only:
            man.output(f)
        return _finish(meas, root, stamp, man, a)
    if not a.datasets:
        ap.error("--datasets is required")
    man = Manifest(root, "pilot")
    rows = []
    for ds in a.datasets:
        for label, *_ in CONFIGS:
            if a.configs and label not in a.configs:
                continue
            cmd = [sys.executable, str(Path(__file__).resolve()), "--worker", "--results", str(root), "--dataset", ds,
                   "--config", label, "--rounds", str(a.rounds)] + (["--device", a.device] if a.device else [])
            p = subprocess.run(cmd, capture_output=True, text=True)
            log = root / "logs" / f"pilot_{stamp}_{ds}_{label}.log"
            log.write_text(p.stdout + "\n--- stderr ---\n" + p.stderr)
            rec = next((json.loads(line[len(MARK):]) for line in p.stdout.splitlines() if line.startswith(MARK)), None)
            if rec is None:
                rec = {"dataset": ds, "config": label, "status": "CRASHED", "error": p.stderr[-2000:]}
            if rec["status"] != "COMPLETE":
                man.warn(f"{ds}/{label}: {rec.get('error', rec['status'])}")
            rows.append(rec)
            print(json.dumps({k: rec.get(k) for k in ("dataset", "config", "status", "per_round_s", "final_eval_s",
                                                       "extrapolated_run_hours", "peak_rss_mb", "run_dir_mb")}), flush=True)
    meas = pd.DataFrame(rows)
    out = root / "pilot" / f"pilot_measurements_{stamp}.csv"
    meas.to_csv(out, index=False); man.output(out)
    return _finish(meas, root, stamp, man, a)


def _finish(meas: pd.DataFrame, root: Path, stamp: str, man: Manifest, a) -> int:
    plan, unmeasured = extrapolate(meas)
    o2 = root / "pilot" / f"pilot_extrapolation_{stamp}.csv"
    plan.to_csv(o2, index=False); man.output(o2)
    tot = (plan.groupby("plan").agg(unique_runs=("block", "size"), runs_with_estimate=("hours_upper", "count"),
                                    hours_upper=("hours_upper", "sum")).reset_index().to_dict("records"))
    by_stage = (plan.groupby(["plan", "stage"]).agg(runs=("block", "size"), hours_upper=("hours_upper", "sum"))
                .reset_index().to_dict("records"))
    devices = sorted(set(meas.get("device", pd.Series(dtype=str)).dropna()))
    dsets = sorted(set(meas["dataset"]))
    summ = {"datasets": dsets, "size_proxies": {d: proxy_of(d) for d in dsets},
            "measurement_sources": sorted(set(meas["_src"])) if "_src" in meas else "this run",
            "measured_rounds": a.rounds, "n_runs": len(meas), "n_failed": int((meas["status"] != "COMPLETE").sum()),
            "devices": devices, "totals": tot, "by_stage": by_stage, "not_in_estimate": unmeasured,
            "notes": ["hours are UPPER bounds on the measured device (every run executes rounds_max)",
                      "CPU timings are not GPU timings; the Phase B GPU estimate is not verified by a CPU pilot",
                      "size-matched synthetic stand-ins give cost only; partition sizes on the real data differ"]}
    o3 = root / "pilot" / f"pilot_summary_{stamp}.json"
    o3.write_text(json.dumps(summ, indent=2, default=str)); man.output(o3)
    man.close("COMPLETE" if summ["n_failed"] == 0 else "SOME_FAILED", n_runs=summ["n_runs"], n_failed=summ["n_failed"])
    print(json.dumps({"totals": tot, "not_in_estimate": unmeasured}, indent=1, default=str))
    return 0 if summ["n_failed"] == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
