"""Pre-registered gates and diagnostics around Stage 3 (10_configs/gates.yaml; owner approval register 2026-11-04).

sanity_gate        Gate G-B, the fully trained accuracy sanity check. An AUTOMATIC PREREQUISITE of Stage 3: the
                   centralised non-private TransE (tuning block T1C, fully trained with early stopping) at its
                   pre-registered T1_central configuration must reach at least `ratio` x the published TransE MRR on
                   every requested dataset (validation MRR; the test split is never read). On the tune tier a
                   failure STOPS Stage 3 and writes a diagnostic report. The published values are a trainer check
                   only: never targets, never tuned towards, never compared in tables.
d10_trigger        D10 utility review trigger (owner decision B5): r = best DP FedAvg validation MRR at eps* = 4 /
                   best non-private FedAvg validation MRR on FB15k-237 (tuning runs, validation only). r < 0.25 is a
                   FLAG carried into every report. It never changes the matrix, the selections or the privacy
                   mechanism, and it is not permission to rework unsuccessful results.
environment lock   One environment per comparison (remaining blockers B13, B16): the first execution of a
                   (tier, dataset) records its environment signature; a later session with a different signature is
                   refused for that tier and dataset, because the run identity does not include the device and
                   CPU / different GPUs / different torch builds give different random streams.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Dict, Iterable, List, Optional

import numpy as np
import pandas as pd

from .io import IntegrityError, Paths, read_json, utc_now, write_json


class GateFailed(RuntimeError):
    """A pre-registered gate failed; the stage must stop (the diagnostic report says why)."""


class EnvironmentMismatch(RuntimeError):
    """This session's environment differs from the one recorded for a (tier, dataset)."""


def block_hash(block: Dict) -> str:
    return hashlib.sha256(json.dumps(block, sort_keys=True).encode()).hexdigest()


# ------------------------------------------------------------------------------------------------ G-B sanity gate
def sanity_gate(runs: pd.DataFrame, selection: Dict, gate: Dict, tier: str, datasets: Iterable[str]) -> Dict:
    """Evaluate gate G-B on COMPLETE, current T1C runs (analysis.collect output) and the T1_central selection."""
    src = runs[runs["block"] == gate["source_block"]] if len(runs) else runs
    ratio = float(gate["ratio"])
    metric = gate["metric"]
    out: Dict = {"gate": "G-B fully trained accuracy sanity check", "tier": tier, "evaluated_utc": utc_now(),
                 "enforced": tier in gate.get("enforce_on_tiers", []), "rule": gate, "rule_sha256": block_hash(gate),
                 "datasets": {}}
    for ds in datasets:
        ref = gate["published_transe_mrr"].get(ds)
        if ref is None:
            out["datasets"][ds] = {"status": "NO_REFERENCE_VALUE", "passed": False}
            continue
        thr = ratio * float(ref["value"])
        g = src[src["dataset"] == ds] if len(src) else src
        chosen = ((selection.get(ds) or {}).get(gate["selection_rule"]) or {}).get("train")
        if g is None or len(g) == 0 or chosen is None:
            out["datasets"][ds] = {"status": "MISSING_RUNS_OR_SELECTION", "passed": False, "threshold": thr}
            continue
        row = g[(g["cfg.train.lr"].astype(float) == float(chosen["lr"])) &
                (g["cfg.train.batch_size"].astype(int) == int(chosen["batch_size"]))]
        if len(row) != 1:
            raise IntegrityError(f"sanity gate/{ds}: the selected T1_central configuration {chosen} matches "
                                 f"{len(row)} runs (expected exactly 1)")
        val = float(row[metric].iloc[0])
        cand = [{"lr": float(r["cfg.train.lr"]), "batch_size": int(r["cfg.train.batch_size"]), metric: float(r[metric]),
                 "rounds_executed": int(r["rounds_executed"]), "selected_round": int(r["selected_round"]),
                 "rounds_max": int(r["cfg.train.rounds_max"]), "stop_reason": str(r["stop_reason"]),
                 "run_id": r["run_id"]} for _, r in g.sort_values(["cfg.train.lr", "cfg.train.batch_size"]).iterrows()]
        passed = bool(np.isfinite(val) and val >= thr)
        out["datasets"][ds] = {
            "status": "PASSED" if passed else "FAILED", "passed": passed, "selected_config": chosen,
            "selected_val_mrr": val, "max_val_mrr_over_candidates": max(c[metric] for c in cand),
            "published_transe_mrr": float(ref["value"]), "published_source": ref["source"], "ratio": ratio,
            "threshold": thr, "margin_to_threshold": val - thr,
            "n_candidates_hitting_rounds_max": sum(c["rounds_executed"] >= c["rounds_max"] for c in cand),
            "candidates": cand}
    out["all_passed"] = bool(out["datasets"]) and all(d.get("passed") for d in out["datasets"].values())
    return out


def write_gate_report(res: Dict, out_dir: Path) -> Dict[str, Path]:
    """sanity_gate.json + SANITY_GATE_REPORT.md (with recovery instructions if anything failed). Results of datasets
    evaluated in earlier sessions are kept (one dataset per session is allowed); `res` decides only for its own
    requested datasets."""
    out_dir = Path(out_dir)
    jp = out_dir / "sanity_gate.json"
    prev = read_json(jp) if jp.exists() else None
    if prev is not None and prev.get("rule_sha256") != res["rule_sha256"]:
        raise IntegrityError("the sanity-gate rule changed since an earlier evaluation; refusing to mix")
    merged = dict(res)
    merged["datasets"] = {**((prev or {}).get("datasets") or {}), **res["datasets"]}
    merged["evaluations"] = ((prev or {}).get("evaluations") or []) + [
        {"utc": res["evaluated_utc"], "datasets": {k: v.get("status") for k, v in res["datasets"].items()}}]
    merged["all_passed_this_evaluation"] = res["all_passed"]
    merged["all_recorded_passed"] = all(d.get("passed") for d in merged["datasets"].values())
    merged.pop("all_passed", None)
    write_json(jp, merged)
    res = {**merged, "all_passed": res["all_passed"]}
    lines = [f"# Gate G-B — fully trained accuracy sanity check ({res['tier']} tier)", "",
             f"Evaluated {res['evaluated_utc']} · rule SHA-256 `{res['rule_sha256'][:16]}…` · "
             f"enforced on this tier: **{res['enforced']}**", "",
             "Pass rule: validation MRR of the pre-registered T1_central configuration (centralised, non-private, "
             f"fully trained) ≥ {res['rule']['ratio']:.4f} × the published TransE MRR. The published values are a "
             "trainer check only, never a target.", "",
             "| Dataset | Status | Selected val MRR | Threshold | Published (source) | Candidates at R_max |",
             "|---|---|---|---|---|---|"]
    for ds, d in res["datasets"].items():
        if "selected_val_mrr" in d:
            lines.append(f"| {ds} | **{d['status']}** | {d['selected_val_mrr']:.4f} | {d['threshold']:.4f} | "
                         f"{d['published_transe_mrr']} ({d['published_source']}) | "
                         f"{d['n_candidates_hitting_rounds_max']} of {len(d['candidates'])} |")
        else:
            lines.append(f"| {ds} | **{d['status']}** | – | {d.get('threshold', float('nan')):.4f} | – | – |")
    if not res["all_passed"]:
        lines += ["", "## Result: the gate did NOT pass", ""]
        if res["enforced"]:
            lines += ["**Stage 3 has stopped.** No tuning run after T1C was started. Do not lower the ratio, do not "
                      "change the grid, and do not tune towards the published value.", ""]
        else:
            lines += ["This tier does not enforce the gate (software check only); nothing here is evidence.", ""]
        lines += ["Recovery (EXECUTION_GUIDE.md, 'Sanity gate failed'):",
                  "1. Keep every T1C run folder; nothing is deleted.",
                  "2. Read each candidate's `log.txt` and `rounds.csv`: does the validation MRR still rise at the last "
                  "evaluation (candidates at R_max > 0 means possible under-training)? Is the loss finite and falling?",
                  "3. Check the data: `artifacts/p1/<dataset>/validation_report.json` must say ok, split counts must "
                  "equal the official counts.",
                  "4. Send this report, `sanity_gate.json` and the T1C run folders to the maintainer for a trainer "
                  "investigation. The study cannot claim a working baseline until the cause is found and fixed, and "
                  "any fix changes the code hash, so every earlier run is re-executed."]
    else:
        lines += ["", "## Result: passed", "", "Stage 3 continues with the remaining tuning stages."]
    mp = out_dir / "SANITY_GATE_REPORT.md"
    mp.parent.mkdir(parents=True, exist_ok=True)
    mp.write_text("\n".join(lines) + "\n")
    return {"json": jp, "md": mp}


# ------------------------------------------------------------------------------------------------ D10 diagnostic
def d10_trigger(runs: pd.DataFrame, cfg: Dict, tier: str) -> Dict:
    """D10 / B5 utility review trigger. Validation metrics of tuning runs only. FLAG ONLY."""
    ds = cfg["dataset"]
    g = runs[runs["dataset"] == ds] if len(runs) else runs
    out: Dict = {"diagnostic": "D10 DP utility review trigger", "tier": tier, "dataset": ds, "evaluated_utc": utc_now(),
                 "rule": cfg, "rule_sha256": block_hash(cfg), "action": "flag_only",
                 "consequence": "none: the matrix, the selections and the privacy mechanism are unchanged (B5)"}
    if g is None or len(g) == 0:
        out.update({"status": "NOT_EVALUATED", "reason": f"no tuning runs for {ds} in this call", "triggered": None})
        return out
    num = g[g["block"].isin(cfg["numerator_blocks"])]
    den = g[g["block"].isin(cfg["denominator_blocks"])]
    if num.empty or den.empty:
        out.update({"status": "NOT_EVALUATED", "reason": "numerator or denominator runs missing", "triggered": None})
        return out
    if not num["cfg.dp.enabled"].astype(bool).all() or (num["cfg.dp.target_epsilon"].astype(float) != 4.0).any():
        raise IntegrityError("D10 numerator must contain DP runs at eps* = 4 only")
    if den["cfg.dp.enabled"].astype(bool).any():
        raise IntegrityError("D10 denominator must contain non-private runs only")
    bn, bd = num.loc[num["val.mrr"].astype(float).idxmax()], den.loc[den["val.mrr"].astype(float).idxmax()]
    r = float(bn["val.mrr"]) / float(bd["val.mrr"]) if float(bd["val.mrr"]) > 0 else float("nan")
    trig = bool(np.isfinite(r) and r < float(cfg["threshold"]))
    out.update({"status": "TRIGGERED" if trig else "NOT_TRIGGERED", "triggered": trig, "r": r,
                "threshold": float(cfg["threshold"]),
                "numerator": {"val_mrr": float(bn["val.mrr"]), "run_id": bn["run_id"], "block": bn["block"],
                              "n_runs": int(len(num))},
                "denominator": {"val_mrr": float(bd["val.mrr"]), "run_id": bd["run_id"], "block": bd["block"],
                                "n_runs": int(len(den))},
                "label": (f"D10 FLAG: DP utility r = {r:.3f} < {cfg['threshold']} on {ds} (validation, tuning seed); "
                          "reported as a diagnostic, nothing was changed" if trig else
                          f"D10 not triggered: r = {r:.3f} >= {cfg['threshold']} on {ds}")})
    return out


# ------------------------------------------------------------------------------------------------ environment lock
def environment_signature(device: Optional[str] = None) -> Dict:
    import platform
    import torch
    use_cuda = (device or ("cuda" if torch.cuda.is_available() else "cpu")).startswith("cuda")
    return {"device_type": "cuda" if use_cuda else "cpu",
            "gpu_name": torch.cuda.get_device_name(0) if use_cuda and torch.cuda.is_available() else None,
            "torch": torch.__version__, "cuda": torch.version.cuda if use_cuda else None,
            "python_minor": ".".join(platform.python_version_tuple()[:2])}


def check_environment_lock(paths: Paths, datasets: Iterable[str], device: Optional[str], cfg: Dict,
                           session_note: str = "") -> Dict:
    """Record (first use) or verify (later sessions) the environment of every requested dataset of this tier.
    Raises EnvironmentMismatch with an explanation. Not enforced on software-check tiers (smoke, dev, pilot)."""
    sig = environment_signature(device)
    sig = {k: sig[k] for k in cfg["fields"]}
    p = paths.base / "ENVIRONMENT_LOCK.json"
    lock = read_json(p) if p.exists() else {"tier": paths.tier, "fields": list(cfg["fields"]), "datasets": {}}
    enforce = paths.tier in cfg.get("enforce_on_tiers", [])
    problems = []
    for ds in datasets:
        rec = lock["datasets"].get(ds)
        if rec is None:
            lock["datasets"][ds] = {"signature": sig, "recorded_utc": utc_now(), "sessions": [utc_now()],
                                    "note": session_note}
            continue
        diff = {k: {"recorded": rec["signature"].get(k), "now": sig.get(k)} for k in cfg["fields"]
                if rec["signature"].get(k) != sig.get(k)}
        if diff:
            problems.append((ds, diff))
        else:
            rec.setdefault("sessions", []).append(utc_now())
    if problems and enforce:
        msg = "; ".join(f"{ds}: " + ", ".join(f"{k} recorded {v['recorded']!r} now {v['now']!r}" for k, v in d.items())
                        for ds, d in problems)
        raise EnvironmentMismatch(
            f"environment differs from the one recorded for tier '{paths.tier}' ({msg}). Runs of one comparison must "
            "share one environment. Reconnect until the recorded GPU type is assigned, or reinstall the recorded torch "
            "version; if that is impossible, give the affected dataset a fresh results root and rerun its whole stage "
            f"there (EXECUTION_GUIDE.md, 'Environment changed'). Lock file: {p}")
    write_json(p, lock)
    return {"signature": sig, "lock_file": str(p), "enforced": enforce,
            "mismatches_not_enforced": [ds for ds, _ in problems] if not enforce else []}
