"""The job graph.

A JOB is a set of approved cells that one GPU worker executes inside its own results root, or one master step.
Jobs never change a cell: they only group cells and order them. Dependencies are the scientific ones:

  research mode, tuning per dataset (two equivalent ways; choose with --tune-mode):
    chain:  T-<ds>-chain  ->  SEL-<ds>-chain (master: replay + verify the selections, gate, tau, D10, freeze)
    stage:  T-<ds>-s0-*  -> SEL-<ds>-s0 (gate G-B)  -> T-<ds>-s1-* -> SEL-<ds>-s1 -> ... -> T-<ds>-s5-*
            -> SEL-<ds>-s5 (stages 5 and 6: tau, D10, freeze)
  then      M-<ds>-p<prio>-<i>of<n>   (all Stage-4 cells of <ds>; they need only the frozen selections of <ds>)
  anytime   L-fb15k237-<i>of<n>       (legacy replicas: no Stage-3 selection, frozen run ids)
  last      ANALYSE (master; may also run earlier on partial results, which stay PENDING)

Datasets never wait for each other: every selection rule is evaluated per dataset (fedkge.selection.select_rule groups
by dataset; the gate, tau and D10 are per dataset; the freeze is append-only per dataset).
"""
from __future__ import annotations

import math
from dataclasses import asdict, dataclass, field
from typing import Callable, Dict, List, Optional

from .cells import Cell, cell_hours, load_cost_table
from .common import DATASETS, canonical_hash, tiers_for

WORKER_KINDS = ("TUNECHAIN", "TUNESTAGE", "MAIN", "LEGACY")
MASTER_KINDS = ("SELECT", "ANALYSE")
TUNE_STAGES_WITH_RUNS = (0, 1, 2, 3, 4, 5)          # stage 6 (TAU) re-uses the T3 winner: selection only
PLAN_SCHEMA = 1


@dataclass
class Job:
    job_id: str
    kind: str
    plan: Optional[str]
    tier: Optional[str]
    dataset: Optional[str]
    stage: Optional[int] = None
    priority: Optional[int] = None
    shard: int = 1
    n_shards: int = 1
    cells: List[str] = field(default_factory=list)
    deps: List[str] = field(default_factory=list)
    est_hours: float = 0.0               # GPU-hours on a Tesla T4 (upper bound); master jobs: sync overhead
    env_group: Optional[str] = None      # '<tier>/<dataset>': one environment per group (environment lock)
    requires_release: bool = False       # needs a release pack from the master before it may start
    runs: Optional[List[Dict]] = None    # [{run_id, cell_keys}] once the run ids are known
    note: str = ""

    def to_dict(self) -> Dict:
        return asdict(self)

    @staticmethod
    def from_dict(d: Dict) -> "Job":
        return Job(**{k: d[k] for k in Job.__dataclass_fields__ if k in d})

    @property
    def is_worker(self) -> bool:
        return self.kind in WORKER_KINDS


def shard_cells(cells: List[Cell], n: int, hours: Dict[str, float]) -> List[List[Cell]]:
    """Longest-processing-time split into n shards of similar estimated cost; deterministic. Inside each shard the
    original (seed-major, matrix) order is kept, so paired arms of one seed finish close together."""
    n = max(1, min(n, len(cells)))
    order = {c.cell_key: i for i, c in enumerate(cells)}
    load = [0.0] * n
    out: List[List[Cell]] = [[] for _ in range(n)]
    for c in sorted(cells, key=lambda c: (-hours[c.cell_key], order[c.cell_key])):
        j = min(range(n), key=lambda i: (load[i], i))
        out[j].append(c)
        load[j] += hours[c.cell_key]
    return [sorted(s, key=lambda c: order[c.cell_key]) for s in out if s]


def default_shard_policy(n_workers: Dict[str, int], target_job_hours: float = 3.0) -> Callable:
    """n_workers: env_group -> number of workers that will share that group. Each job should fit comfortably in one
    session (target_job_hours) and every worker of the group should get work."""
    def policy(group: str, kind: str, n_runs: int, total_hours: float) -> int:
        nw = max(1, int(n_workers.get(group, 1)))
        if n_runs <= 1:
            return 1
        if kind == "TUNESTAGE":
            return min(nw, n_runs)
        n = max(min(nw, n_runs), math.ceil(total_hours / target_job_hours))
        return max(1, min(n, n_runs, 4 * nw))
    return policy


def _seed_major(cells: List[Cell]) -> List[Cell]:
    return sorted(cells, key=lambda c: (c.seed, c.block, c.name))


def build_jobs(cells: List[Cell], mode: str, tune_mode: str = "chain", shard_policy: Optional[Callable] = None,
               datasets=DATASETS, master_sync_hours: float = 0.25) -> List[Job]:
    if tune_mode not in ("chain", "stage"):
        raise ValueError("tune_mode must be 'chain' or 'stage'")
    tiers = tiers_for(mode)
    policy = shard_policy or default_shard_policy({})
    table = load_cost_table() if mode == "research" else None
    hours = {c.cell_key: cell_hours(c, table) for c in cells}
    jobs: List[Job] = []
    final_sel: Dict[str, str] = {}
    for ds in datasets:
        tune = [c for c in cells if c.plan == "tune" and c.dataset == ds]
        if not tune:
            continue
        g_tune = f"{tiers['tune']}/{ds}"
        if tune_mode == "chain":
            jobs.append(Job(f"T-{ds}-chain", "TUNECHAIN", "tune", tiers["tune"], ds, cells=[c.cell_key for c in tune],
                            est_hours=sum(hours[c.cell_key] for c in tune), env_group=g_tune,
                            note="Stage 3 for one dataset in order (scripts/run_plan.py --plan tune): stage 0, gate "
                                 "G-B, stages 1-6 with a selection after every stage"))
            jobs.append(Job(f"SEL-{ds}-chain", "SELECT", "tune", tiers["tune"], ds, deps=[f"T-{ds}-chain"],
                            est_hours=master_sync_hours, note="master: import, replay and verify the worker's "
                            "selections stage by stage, gate G-B, tau, D10, freeze (G-C), release the Stage-4 jobs"))
            final_sel[ds] = f"SEL-{ds}-chain"
        else:
            prev_sel: Optional[str] = None
            for s in TUNE_STAGES_WITH_RUNS:
                new = [c for c in tune if c.stage == s and not c.reuse]
                total = sum(hours[c.cell_key] for c in new)
                shards = shard_cells(new, policy(g_tune, "TUNESTAGE", len(new), total), hours) if new else []
                ids = []
                for i, sh in enumerate(shards, 1):
                    jid = f"T-{ds}-s{s}-{i}of{len(shards)}"
                    jobs.append(Job(jid, "TUNESTAGE", "tune", tiers["tune"], ds, stage=s, shard=i, n_shards=len(shards),
                                    cells=[c.cell_key for c in sh], deps=[prev_sel] if prev_sel else [],
                                    est_hours=sum(hours[c.cell_key] for c in sh), env_group=g_tune,
                                    requires_release=prev_sel is not None,
                                    note=f"Stage-3 tuning stage {s}" + (" (gate G-B source: T1C)" if s == 0 else "")))
                    ids.append(jid)
                sel = f"SEL-{ds}-s{s}"
                jobs.append(Job(sel, "SELECT", "tune", tiers["tune"], ds, stage=s, deps=ids, est_hours=master_sync_hours,
                                note=("master: T1_central selection + gate G-B; releases stage 1 only if it passes"
                                      if s == 0 else f"master: selection after stage {s}" +
                                      ("; stage 6 (tau, D10) and the freeze (G-C); releases Stage 4" if s == 5 else
                                       f"; releases stage {s + 1}"))))
                prev_sel = sel
            final_sel[ds] = f"SEL-{ds}-s5"
        main = _seed_major([c for c in cells if c.plan == "main" and c.dataset == ds])
        g_main = f"{tiers['main']}/{ds}"
        for p in sorted({c.priority for c in main}):
            pc = [c for c in main if c.priority == p]
            total = sum(hours[c.cell_key] for c in pc)
            shards = shard_cells(pc, policy(g_main, "MAIN", len(pc), total), hours)
            for i, sh in enumerate(shards, 1):
                jobs.append(Job(f"M-{ds}-p{p}-{i}of{len(shards)}", "MAIN", "main", tiers["main"], ds, priority=p, shard=i,
                                n_shards=len(shards), cells=[c.cell_key for c in sh], deps=[final_sel[ds]],
                                est_hours=sum(hours[c.cell_key] for c in sh), env_group=g_main, requires_release=True,
                                note=f"Stage-4 priority {p}"))
    leg = _seed_major([c for c in cells if c.plan == "legacy"])
    if leg:
        g = f"{tiers['legacy']}/fb15k237"
        total = sum(hours[c.cell_key] for c in leg)
        shards = shard_cells(leg, policy(g, "LEGACY", len(leg), total), hours)
        for i, sh in enumerate(shards, 1):
            jobs.append(Job(f"L-fb15k237-{i}of{len(shards)}", "LEGACY", "legacy", tiers["legacy"], "fb15k237",
                            priority=4, shard=i, n_shards=len(shards), cells=[c.cell_key for c in sh],
                            est_hours=sum(hours[c.cell_key] for c in sh), env_group=g,
                            note="legacy replicas L1-L4: no Stage-3 selection needed (frozen run ids)"))
    gpu_jobs = [j.job_id for j in jobs if j.kind in ("MAIN", "LEGACY")]
    jobs.append(Job("ANALYSE", "ANALYSE", None, tiers["main"], None, deps=gpu_jobs, est_hours=master_sync_hours,
                    note="master: validate, statistical analysis, report, export (may also run earlier on partial "
                         "results: everything missing stays PENDING)"))
    # run ids known without any selection (stage 0/1 cells, legacy cells) are written into the job now
    by_key = {c.cell_key: c for c in cells}
    for j in jobs:
        if j.kind in ("TUNESTAGE", "LEGACY") and all(by_key[k].run_id for k in j.cells):
            j.runs = _runs_from_cells([by_key[k] for k in j.cells])
    check_graph(jobs, cells)
    return jobs


def _runs_from_cells(cells: List[Cell]) -> List[Dict]:
    out: Dict[str, List[str]] = {}
    for c in cells:
        out.setdefault(c.run_id, []).append(c.cell_key)
    return [{"run_id": r, "cell_keys": ks} for r, ks in out.items()]


def check_graph(jobs: List[Job], cells: List[Cell]) -> None:
    """Static checks: unique ids, known deps, acyclic, every approved cell covered by exactly one worker job (tuning
    re-statement cells belong to their stage's selection), no worker job mixes environment groups."""
    ids = [j.job_id for j in jobs]
    if len(ids) != len(set(ids)):
        raise AssertionError("duplicate job ids")
    known = set(ids)
    for j in jobs:
        for d in j.deps:
            if d not in known:
                raise AssertionError(f"{j.job_id}: unknown dependency {d}")
    topo_order(jobs)
    owner: Dict[str, str] = {}
    for j in jobs:
        if not j.is_worker:
            continue
        for k in j.cells:
            if k in owner:
                raise AssertionError(f"cell {k} in two jobs: {owner[k]} and {j.job_id}")
            owner[k] = j.job_id
    for c in cells:
        if c.cell_key not in owner and not (c.plan == "tune" and c.reuse):
            raise AssertionError(f"approved cell {c.cell_key} is in no job")
    by_key = {c.cell_key: c for c in cells}
    for j in jobs:
        groups = {f"{by_key[k].tier}/{by_key[k].dataset}" for k in j.cells}
        if j.is_worker and len(groups) != 1:
            raise AssertionError(f"{j.job_id} mixes environment groups {groups}")


def topo_order(jobs: List[Job]) -> List[str]:
    deps = {j.job_id: set(j.deps) for j in jobs}
    order, ready = [], sorted(k for k, v in deps.items() if not v)
    done = set()
    while ready:
        k = ready.pop(0)
        order.append(k); done.add(k)
        for j, d in deps.items():
            if j not in done and j not in order and j not in ready and d <= done:
                ready.append(j)
        ready.sort()
    if len(order) != len(deps):
        raise AssertionError(f"dependency cycle among {sorted(set(deps) - set(order))[:5]}")
    return order


def waves(jobs: List[Job]) -> List[List[str]]:
    """Dependency depth ignoring resources: every job of wave w can start once waves < w are done (and, in practice,
    as soon as its OWN dependencies are done - a job never waits for a whole wave)."""
    by = {j.job_id: j for j in jobs}
    depth: Dict[str, int] = {}
    for k in topo_order(jobs):
        depth[k] = 1 + max((depth[d] for d in by[k].deps), default=-1)
    out: List[List[str]] = [[] for _ in range(max(depth.values()) + 1)] if depth else []
    for k, d in depth.items():
        out[d].append(k)
    return [sorted(w) for w in out]


def plan_hash(jobs: List[Job]) -> str:
    return canonical_hash([{k: v for k, v in j.to_dict().items() if k != "runs"} for j in jobs])


def materialize(jobs: List[Job], entries_by_key: Dict[str, Dict], complete_run_ids: set) -> List[Dict]:
    """Assign the run ids that the master's expansion gives to the cells of these jobs (in job order: a run shared by
    several cells - e.g. DP2 = DP1 at eps* = 4 when the fixed schedule is selected - is executed by the FIRST job only;
    the later cells are recorded as re-using it). Runs already COMPLETE in the master store are not executed again."""
    owned: Dict[str, str] = {}
    specs = []
    for j in jobs:
        runs: Dict[str, List[str]] = {}
        reused, done = {}, {}
        for k in j.cells:
            if k not in entries_by_key:
                raise KeyError(f"{j.job_id}: cell {k} not produced by the master's expansion")
            rid = entries_by_key[k]["run_id"]
            if rid in owned and owned[rid] != j.job_id:
                reused[k] = {"run_id": rid, "executed_by": owned[rid]}
                continue
            owned[rid] = j.job_id
            if rid in complete_run_ids:
                done[k] = rid
                continue
            runs.setdefault(rid, []).append(k)
        d = j.to_dict()
        d["runs"] = [{"run_id": r, "cell_keys": ks} for r, ks in runs.items()]
        d["reused_cells"] = reused
        d["already_complete_cells"] = done
        specs.append(d)
    return specs
