"""Phase C - trust aggregation (subsets of verified identities, B4 removal of variant V1, robust-baseline parameters) and attack
mechanics (noise modes, norm matching, targets from attacker data, adaptive search with the attacker's own noise).
All inputs are SYNTHETIC: these tests check implementation correctness, never that the defence works."""
import numpy as np
import pytest
import torch

from fedkge.aggregators import aggregate, robust_parameters
from fedkge.attacks import (_adaptive_search, craft, make_targets_from_attacker_data, match_norm,
                            resolve_noise_mode)
from fedkge.trust import TrustState, anomaly_scores, size_thirds


def _benign(n=9, P=200, seed=0):
    g = torch.Generator().manual_seed(seed)
    base = torch.randn(P, generator=g)
    return base + 0.3 * torch.randn(n, P, generator=g)


def test_history_only_updates_present_identities():
    U = _benign(6)
    U[1] = -10 * U[1]                                   # an obvious outlier in row 1 = identity 2
    ts = TrustState(10, tau=3.0, lam=0.5, norm_bound=True)
    idx = np.array([0, 2, 4, 5, 7, 9])
    info = ts.aggregate(U, np.ones(6), idx)
    assert info["flags"][1]                             # row 1 = identity 2
    assert ts.history[2] == 1 and ts.history[[1, 3, 6, 8]].sum() == 0
    assert abs(info["weights"].sum() - 1) < 1e-9 and info["weights"][1] == 0


def test_b4_variant_v1_and_its_switch_are_removed():
    """Owner decision B4 (2026-11-04): only the frozen rule exists; size thirds are a diagnostic, not a rule input."""
    import inspect
    sizes = np.array([100, 110, 120, 1000, 1100, 1200, 5000, 5200, 5400])
    assert list(size_thirds(sizes)) == [0, 0, 0, 1, 1, 1, 2, 2, 2]        # diagnostic grouping is kept
    assert "groups" not in inspect.signature(anomaly_scores).parameters
    with pytest.raises(TypeError):
        TrustState(9, 3.0, 0.5, True, magnitude_reference="size_third")
    with pytest.raises(TypeError):
        TrustState(9, 3.0, 0.5, True, declared_sizes=sizes)
    U = _benign(9)
    U[:3] *= 3.0                                        # small clients: larger updates - the rule does not adapt
    sc = anomaly_scores(U)
    norms = U.norm(dim=1)
    med = norms.median() if len(norms) % 2 else None
    assert torch.allclose(sc["m"], torch.log((norms + 1e-12) / (med + 1e-12)).abs())   # global median reference
    assert "v1_fallback_rows" not in sc


def test_frozen_rule_unchanged_by_b4():
    """The frozen rule's scores and weights are identical to a direct implementation of 03 section 8.3."""
    U = _benign(7, P=50, seed=3)
    U[2] = -4 * U[2]
    ts = TrustState(7, tau=3.0, lam=0.5, norm_bound=True)
    info = ts.aggregate(U, np.arange(1, 8, dtype=float))
    ref = U.median(dim=0).values                          # n odd: coordinate median = torch median
    cos = (U @ ref) / (U.norm(dim=1) * ref.norm() + 1e-12)
    a = 1 - cos
    m = torch.log(U.norm(dim=1) / U.norm(dim=1).median()).abs()
    z = lambda x: (x - x.median()) / (1.4826 * (x - x.median()).abs().median() + 1e-12)
    A = torch.maximum(z(a), z(m)).numpy()
    assert np.allclose(info["A"], A, atol=1e-6) and info["flags"][2] and info["flags"].sum() == (A > 3.0).sum()
    w = np.arange(1, 8) * (~(A > 3.0)) * np.exp(-0.5 * (A > 3.0))
    assert np.allclose(info["weights"], w / w.sum())


def test_robust_parameters_at_design_value():
    rp = robust_parameters({"f_design": 0.2, "beta": 0.2, "krum_f_min": 1}, n_malicious=0, n_real=10, n_participants=10)
    assert rp["krum_f"] == 2 and rp["trim_beta"] == 0.2 and rp["krum_assumption_ok"]
    rp3 = robust_parameters({"f_design": 0.2, "beta": 0.2}, n_malicious=3, n_real=10, n_participants=10)
    assert rp3["krum_f"] == 3 and abs(rp3["trim_beta"] - 0.3) < 1e-12 and rp3["trimmed_assumption_ok"]
    out = aggregate("krum", _benign(10), np.ones(10), {"f_design": 0.2}, 0, n_real=10)
    assert out["robust_params"]["krum_f"] == 2


def test_match_norm_hits_target_or_leaves_large_updates():
    g = torch.Generator().manual_seed(1)
    V = torch.randn(500, generator=g) * 0.1
    xi = torch.randn(500, generator=g)
    out = match_norm(V, 5.0, xi)
    assert abs(float(out.norm()) - 5.0) < 1e-4
    big = torch.randn(500, generator=g) * 10
    assert torch.equal(match_norm(big, 1.0, xi), big)


def test_noise_mode_resolution():
    assert resolve_noise_mode("alie", "auto", True) == "matched"
    assert resolve_noise_mode("signflip", "auto", True) == "inherit"
    assert resolve_noise_mode("sybil", "auto", True) == "matched"
    assert resolve_noise_mode("alie", "auto", False) == "none"
    assert resolve_noise_mode("targeted", "none", True) == "none"
    with pytest.raises(ValueError):
        resolve_noise_mode("alie", "inherit", True)
    with pytest.raises(ValueError):
        resolve_noise_mode("signflip", "matched", True)


def test_targets_come_from_attacker_data_and_are_false():
    rng = np.random.default_rng(0)
    att = np.array([[0, 0, 1], [0, 0, 2], [3, 1, 4], [5, 2, 6]])
    all_true = np.vstack([att, [[7, 0, 8], [3, 1, 9]]])
    T = make_targets_from_attacker_data(att, all_true, 20, 3, rng)
    pairs = {(h, r) for h, r, _ in att.tolist()}
    known = {}
    for h, r, t in all_true.tolist():
        known.setdefault((h, r), set()).add(t)
    for h, r, ts in T.tolist():
        assert (h, r) in pairs and ts not in known[(h, r)] and ts != h


def test_matched_alie_has_attacker_norm_and_sybil_uses_dp_noise():
    benign = _benign(8, 300)
    honest = [benign[0] * 2.0, benign[1] * 2.0]
    out = craft({"type": "alie", "knowledge": "white"}, honest, benign, torch.zeros(300), 10, 2,
                {"tau": 3.0}, torch.Generator().manual_seed(0), noise_mode="matched")
    for u, h in zip(out["updates"], honest):
        assert abs(float(u.norm()) - float(h.norm())) < 1e-3
    z = [torch.randn(300), torch.randn(300)]
    prev = torch.ones(300)
    out = craft({"type": "sybil", "strength": 3.0}, [], benign, prev, 12, 2, {"tau": 3.0},
                torch.Generator().manual_seed(0), noise_mode="matched", sybil_noise=z)
    assert torch.allclose(out["updates"][0], -3.0 * prev + z[0])
    with pytest.raises(ValueError):
        craft({"type": "sybil", "strength": 3.0}, [], benign, prev, 12, 2, {"tau": 3.0},
              torch.Generator().manual_seed(0), noise_mode="matched", sybil_noise=None)


def test_adaptive_search_respects_threshold_including_own_noise():
    sur = _benign(5, 200)
    mu, sd = sur.mean(0), sur.std(0)
    xi = torch.randn(200, generator=torch.Generator().manual_seed(3))
    fin = lambda V: match_norm(V, float(sur[0].norm()) * 1.2, xi)
    res = _adaptive_search(mu, sd, sur, 2, tau=3.0, margin=0.05, gamma_max=20.0, grid=41, finish=fin)
    if res["feasible"]:
        U = torch.cat([sur, res["update"].unsqueeze(0).expand(2, -1)], 0)
        assert bool((anomaly_scores(U)["A"][-2:] <= 3.0 * 0.95 + 1e-9).all())


def test_synthetic_outlier_is_flagged_SANITY_ONLY():
    """Implementation sanity on synthetic data (NOT evidence that the defence works on benchmarks)."""
    U = _benign(10)
    U[0] = -5 * U[0]
    ts = TrustState(10, 3.0, 0.5, True)
    info = ts.aggregate(U, np.ones(10))
    assert info["flags"][0] and info["flags"][1:].sum() <= 1
