# ===== CELL 1 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 1 — Environment Setup
# ═══════════════════════════════════════════════════════════════════
import subprocess, sys

def pip_q(pkg, label=None, extra=None):
    label = label or pkg
    cmd   = [sys.executable,"-m","pip","install","-q"] + (extra or []) + [pkg]
    r     = subprocess.run(cmd, capture_output=True, text=True)
    print(f"{'✅' if r.returncode==0 else '❌'} {label}")

# Remove conflicting packages first
subprocess.run([sys.executable,"-m","pip","uninstall","-y",
    "flwr","ray","jax","jaxlib"], capture_output=True)

for pkg, lbl in [
    ("protobuf>=5.28.0,<6.0.0","protobuf"),
    ("flwr>=1.13.0,<2.0.0","flwr"),
    ("pykeen>=1.10,<2.0","pykeen"),
    ("torch>=2.0","torch"),
    ("matplotlib>=3.7","matplotlib"),
    ("seaborn>=0.12","seaborn"),
    ("plotly>=5.15","plotly"),
    ("pandas>=2.0","pandas"),
    ("numpy>=1.24","numpy"),
    ("scipy>=1.10","scipy"),
    ("scikit-learn>=1.3","scikit-learn"),
]:
    pip_q(pkg, lbl)
print("\n✅ Phase 3 environment ready.")

# ===== CELL 2 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 2 — Imports & Configuration
# ═══════════════════════════════════════════════════════════════════
import os, json, time, warnings, copy
from pathlib import Path
from datetime import datetime
from collections import defaultdict

import numpy as np
import pandas as pd
import scipy.stats as stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import seaborn as sns
import plotly.graph_objects as go
from mpl_toolkits.mplot3d import Axes3D

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

warnings.filterwarnings("ignore")

ROOT      = Path("checkpoints")
P3_DIR    = ROOT / "phase3"
GRAPH_DIR = P3_DIR / "graphs"
MODEL_DIR = P3_DIR / "models"
for d in [P3_DIR, GRAPH_DIR, MODEL_DIR]:
    d.mkdir(parents=True, exist_ok=True)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

plt.rcParams.update({
    "figure.dpi":150,"savefig.dpi":300,"font.family":"DejaVu Sans",
    "axes.titlesize":13,"axes.labelsize":11,"xtick.labelsize":9,
    "ytick.labelsize":9,"legend.fontsize":9,"figure.facecolor":"white",
    "axes.facecolor":"#f8f9fa","axes.grid":True,"grid.alpha":0.4,
})

def style_table(df, caption=""):
    return (df.style.set_caption(caption)
              .set_table_styles([
                  {"selector":"caption","props":[("font-weight","bold"),("font-size","13px"),
                   ("text-align","left"),("padding","6px 0")]},
                  {"selector":"th","props":[("background-color","#2d6a4f"),("color","white"),
                   ("font-weight","bold"),("text-align","center"),("padding","8px 12px")]},
                  {"selector":"td","props":[("text-align","center"),("padding","6px 12px")]},
                  {"selector":"tr:nth-child(even)","props":[("background-color","#d8f3dc")]},
              ]).hide(axis="index"))

# ── Hyperparameter Configuration ──────────────────────────────────
CFG = {
    "embedding_dim":   100,
    "margin":          1.0,
    "lr":              0.001,
    "batch_size":      512,
    "neg_samples":     64,
    "local_epochs":    3,
    "fl_rounds":       50,
    "n_clients":       5,
    "seed":            42,
    "partition_strategy": "relation_cluster",
}
torch.manual_seed(CFG["seed"])
np.random.seed(CFG["seed"])

print("✅ Phase 3 configuration loaded.")
print(f"   Device : {DEVICE}")
for k,v in CFG.items(): print(f"   {k:22s}: {v}")

# ===== CELL 3 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 3 — Load Phase 2 Results & Dataset
# ═══════════════════════════════════════════════════════════════════
with open("phase2_results.json") as f:
    phase2 = json.load(f)

print("✅ phase2_results.json loaded.")
print(f"   Non-IID degree skewness : {phase2['noniid_metrics']['degree_skewness']:.3f}")

from pykeen.datasets import FB15k237
print("⏳ Loading FB15k-237 …")
dataset       = FB15k237()
train_triples = dataset.training.mapped_triples.numpy()
valid_triples = dataset.validation.mapped_triples.numpy()
test_triples  = dataset.testing.mapped_triples.numpy()

entity_to_id   = dataset.entity_to_id
relation_to_id = dataset.relation_to_id
id_to_entity   = {v:k for k,v in entity_to_id.items()}
id_to_relation = {v:k for k,v in relation_to_id.items()}

NUM_ENTITIES  = phase2["num_entities"]
NUM_RELATIONS = phase2["num_relations"]
N_TRAIN       = phase2["n_train"]

print(f"✅ Dataset loaded. {NUM_ENTITIES:,} entities, {NUM_RELATIONS:,} relations, {N_TRAIN:,} train triples.")

# ===== CELL 4 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 4 — KGE Model Definitions: TransE & RotatE
# ═══════════════════════════════════════════════════════════════════

class TransE(nn.Module):
    """Translational KGE model: score(h,r,t) = -||h + r - t||"""
    def __init__(self, n_entities, n_relations, dim, margin=1.0):
        super().__init__()
        self.dim     = dim
        self.margin  = margin
        self.ent_emb = nn.Embedding(n_entities,  dim)
        self.rel_emb = nn.Embedding(n_relations, dim)
        nn.init.uniform_(self.ent_emb.weight, -6/dim**0.5, 6/dim**0.5)
        nn.init.uniform_(self.rel_emb.weight, -6/dim**0.5, 6/dim**0.5)

    def forward(self, heads, rels, tails):
        h = F.normalize(self.ent_emb(heads), p=2, dim=-1)
        r = self.rel_emb(rels)
        t = F.normalize(self.ent_emb(tails), p=2, dim=-1)
        return -torch.norm(h + r - t, p=2, dim=-1)

    def loss(self, pos_h, pos_r, pos_t, neg_h, neg_r, neg_t):
        pos_score = self.forward(pos_h, pos_r, pos_t)
        neg_score = self.forward(neg_h, neg_r, neg_t)
        return F.relu(self.margin - pos_score + neg_score).mean()


class RotatE(nn.Module):
    """Complex rotation KGE model: captures symmetry/inversion/composition"""
    def __init__(self, n_entities, n_relations, dim, margin=1.0):
        super().__init__()
        self.dim     = dim
        self.margin  = margin
        self.pi      = 3.14159265358979323846
        self.ent_emb = nn.Embedding(n_entities,  dim * 2)   # real+imag
        self.rel_emb = nn.Embedding(n_relations, dim)       # phase
        nn.init.uniform_(self.ent_emb.weight, -6/dim**0.5, 6/dim**0.5)
        nn.init.uniform_(self.rel_emb.weight, -self.pi, self.pi)

    def forward(self, heads, rels, tails):
        d = self.dim
        h_re = self.ent_emb(heads)[:, :d]
        h_im = self.ent_emb(heads)[:, d:]
        t_re = self.ent_emb(tails)[:, :d]
        t_im = self.ent_emb(tails)[:, d:]
        phase_r = self.rel_emb(rels)
        r_re = torch.cos(phase_r)
        r_im = torch.sin(phase_r)
        # (h ○ r) - t in complex space
        diff_re = h_re * r_re - h_im * r_im - t_re
        diff_im = h_re * r_im + h_im * r_re - t_im
        score   = -(diff_re**2 + diff_im**2).sum(dim=-1).sqrt()
        return score

    def loss(self, pos_h, pos_r, pos_t, neg_h, neg_r, neg_t):
        pos_score = self.forward(pos_h, pos_r, pos_t)
        neg_score = self.forward(neg_h, neg_r, neg_t)
        return F.relu(self.margin - pos_score + neg_score).mean()


print("✅ TransE and RotatE model classes defined.")

# ===== CELL 5 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 5 — KGE Dataset Class & Non-IID Partitioning
# ═══════════════════════════════════════════════════════════════════

class KGEDataset(Dataset):
    """PyTorch Dataset wrapping knowledge graph triples with negative sampling."""
    def __init__(self, triples, n_entities, n_neg=5):
        self.triples    = torch.tensor(triples, dtype=torch.long)
        self.n_entities = n_entities
        self.n_neg      = n_neg

    def __len__(self):
        return len(self.triples)

    def __getitem__(self, idx):
        h, r, t = self.triples[idx]
        # Generate negative sample by corrupting head or tail
        if torch.rand(1).item() > 0.5:
            neg_h = torch.randint(0, self.n_entities, (1,)).item()
            neg_t = t.item()
        else:
            neg_h = h.item()
            neg_t = torch.randint(0, self.n_entities, (1,)).item()
        return (h.item(), r.item(), t.item(), neg_h, r.item(), neg_t)


def partition_relation_cluster(triples, n_clients, rollup_top50):
    """Non-IID: each client gets a disjoint set of relations.
    Relations are assigned in frequency order → unequal data volumes."""
    rel_ids    = list({row["relation_id"] for row in rollup_top50})
    # Use all 237 relations from data
    all_rels   = np.unique(triples[:,1])
    chunks     = np.array_split(all_rels, n_clients)
    partitions = {}
    for cid, chunk in enumerate(chunks):
        mask              = np.isin(triples[:,1], chunk)
        partitions[cid]   = triples[mask]
    return partitions


def partition_iid(triples, n_clients):
    """IID baseline: random equal splits."""
    idx    = np.random.permutation(len(triples))
    chunks = np.array_split(idx, n_clients)
    return {cid: triples[chunk] for cid, chunk in enumerate(chunks)}


rollup_top50 = phase2["rollup_top50"]
partitions   = partition_relation_cluster(train_triples, CFG["n_clients"], rollup_top50)
iid_parts    = partition_iid(train_triples, CFG["n_clients"])

print("✅ Data partitioning complete.")
for cid, part in partitions.items():
    print(f"   Client-{cid}: {len(part):,} triples, "
          f"{np.unique(part[:,1]).shape[0]} unique relations")

# ===== CELL 6 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 6 — FedAvg Aggregation & Local Training Functions
# ═══════════════════════════════════════════════════════════════════

def get_model_params(model):
    """Extract model parameters as numpy arrays."""
    return {k: v.detach().cpu().numpy().copy()
            for k,v in model.state_dict().items()}

def set_model_params(model, params):
    """Set model parameters from numpy arrays."""
    state = {k: torch.tensor(v) for k,v in params.items()}
    model.load_state_dict(state)

def fedavg_aggregate(client_params, client_weights):
    """Weighted average of client parameter dictionaries."""
    total_w = sum(client_weights)
    keys    = client_params[0].keys()
    agg     = {}
    for key in keys:
        agg[key] = sum(
            w/total_w * p[key]
            for p, w in zip(client_params, client_weights)
        )
    return agg

def train_one_round(model, loader, optimizer, device, epochs=1):
    """Local training for one federated round."""
    model.train()
    total_loss = 0.0
    n_batches  = 0
    for _ in range(epochs):
        for batch in loader:
            pos_h, pos_r, pos_t, neg_h, neg_r, neg_t = [
                torch.tensor(x, dtype=torch.long).to(device) for x in batch]
            optimizer.zero_grad()
            loss = model.loss(pos_h, pos_r, pos_t, neg_h, neg_r, neg_t)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            total_loss += loss.item()
            n_batches  += 1
    return total_loss / max(n_batches, 1)

def evaluate_mrr_hits(model, test_triples, all_triples, n_entities, device,
                      max_eval=500, k_values=(1,3,10)):
    """Filtered MRR and Hits@K evaluation on test triples."""
    model.eval()
    known = defaultdict(set)
    for h,r,t in all_triples:
        known[(int(h),int(r))].add(int(t))

    mrr  = 0.0
    hits = {k: 0.0 for k in k_values}
    n    = min(max_eval, len(test_triples))
    subset = test_triples[np.random.choice(len(test_triples), n, replace=False)]

    with torch.no_grad():
        for h, r, t in subset:
            h, r, t = int(h), int(r), int(t)
            h_t  = torch.tensor([h]*n_entities, dtype=torch.long).to(device)
            r_t  = torch.tensor([r]*n_entities, dtype=torch.long).to(device)
            t_t  = torch.arange(n_entities, dtype=torch.long).to(device)
            scores = model(h_t, r_t, t_t).cpu().numpy()
            # Filter known true tails (except the target)
            for t2 in known[(h,r)]:
                if t2 != t:
                    scores[t2] = -1e9
            rank = int(np.sum(scores > scores[t])) + 1
            mrr += 1.0 / rank
            for k in k_values:
                hits[k] += 1.0 if rank <= k else 0.0

    mrr  = mrr / n
    hits = {k: v/n for k,v in hits.items()}
    return {"mrr": round(mrr,4),
            "hits@1": round(hits[1],4),
            "hits@3": round(hits[3],4),
            "hits@10":round(hits[10],4)}

all_triples = np.vstack([train_triples, valid_triples, test_triples])
print("✅ FedAvg utilities defined.")

# ===== CELL 7 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 7 — Federated Training Simulation (FedAvg)
# ═══════════════════════════════════════════════════════════════════
print("⏳ Starting Federated Learning Simulation …")
print(f"   Model: TransE  |  Rounds: {CFG['fl_rounds']}  |  Clients: {CFG['n_clients']}")
print(f"   Embedding dim: {CFG['embedding_dim']}  |  Device: {DEVICE}\n")

# ── Initialise global model ─────────────────────────────────────────
global_model = TransE(NUM_ENTITIES, NUM_RELATIONS, CFG["embedding_dim"], CFG["margin"]).to(DEVICE)
global_params= get_model_params(global_model)

history = {
    "round": [], "avg_loss": [], "mrr": [],
    "hits@1":[], "hits@3":[], "hits@10":[],
    "client_losses": [],
}

t_sim = time.time()

for rnd in range(1, CFG["fl_rounds"]+1):
    print(f"  ── Round {rnd}/{CFG['fl_rounds']} ──")
    client_params_list  = []
    client_weights_list = []
    round_losses        = []

    for cid in range(CFG["n_clients"]):
        local_triples = partitions[cid]
        if len(local_triples) == 0:
            continue

        local_model = TransE(NUM_ENTITIES, NUM_RELATIONS,
                             CFG["embedding_dim"], CFG["margin"]).to(DEVICE)
        set_model_params(local_model, global_params)

        loader    = DataLoader(
            KGEDataset(local_triples, NUM_ENTITIES, CFG["neg_samples"]),
            batch_size=CFG["batch_size"], shuffle=True, drop_last=True,
        )
        optimizer = torch.optim.Adam(local_model.parameters(), lr=CFG["lr"])
        loss      = train_one_round(local_model, loader, optimizer, DEVICE,
                                    epochs=CFG["local_epochs"])

        client_params_list.append(get_model_params(local_model))
        client_weights_list.append(len(local_triples))
        round_losses.append(loss)
        print(f"     Client-{cid}: loss={loss:.4f}, triples={len(local_triples):,}")

    # ── FedAvg aggregation ────────────────────────────────────────
    global_params = fedavg_aggregate(client_params_list, client_weights_list)
    set_model_params(global_model, global_params)

    # ── Evaluate on test set ──────────────────────────────────────
    eval_metrics = evaluate_mrr_hits(global_model, test_triples, all_triples,
                                      NUM_ENTITIES, DEVICE, max_eval=300)
    avg_loss     = float(np.mean(round_losses))

    history["round"].append(rnd)
    history["avg_loss"].append(avg_loss)
    history["mrr"].append(eval_metrics["mrr"])
    history["hits@1"].append(eval_metrics["hits@1"])
    history["hits@3"].append(eval_metrics["hits@3"])
    history["hits@10"].append(eval_metrics["hits@10"])
    history["client_losses"].append(round_losses)

    print(f"     → Avg Loss: {avg_loss:.4f} | "
          f"MRR: {eval_metrics['mrr']:.4f} | "
          f"Hits@10: {eval_metrics['hits@10']:.4f}")

sim_time = time.time() - t_sim
print(f"\n✅ Simulation complete in {sim_time:.1f}s")

# Save global model
torch.save(global_model.state_dict(), MODEL_DIR / "global_transe_final.pt")
print("✅ Global model saved.")

# ===== CELL 8 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 8 — Training Results Table
# ═══════════════════════════════════════════════════════════════════
hist_df = pd.DataFrame({
    "Round":   history["round"],
    "Avg Loss":history["avg_loss"],
    "MRR":     history["mrr"],
    "Hits@1":  history["hits@1"],
    "Hits@3":  history["hits@3"],
    "Hits@10": history["hits@10"],
})
hist_df["Avg Loss"] = hist_df["Avg Loss"].apply(lambda x: f"{x:.4f}")
hist_df["MRR"]      = hist_df["MRR"].apply(lambda x: f"{x:.4f}")
for col in ["Hits@1","Hits@3","Hits@10"]:
    hist_df[col] = hist_df[col].apply(lambda x: f"{x:.4f}")

display(style_table(hist_df, "Table 3 — Federated Training History (FedAvg, TransE)"))
print("\nFinal evaluation metrics:")
for k,v in zip(["MRR","Hits@1","Hits@3","Hits@10"],
               [history["mrr"][-1],history["hits@1"][-1],
                history["hits@3"][-1],history["hits@10"][-1]]):
    print(f"   {k:10s}: {v:.4f}")

# ===== CELL 9 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 9 — Training Curves: Loss & Link Prediction Metrics
# ═══════════════════════════════════════════════════════════════════
rounds = history["round"]

fig, axes = plt.subplots(2, 2, figsize=(16, 10))
fig.suptitle("Federated KGE Training — FedAvg with TransE", fontsize=15, fontweight="bold")

# Loss
ax = axes[0,0]
ax.plot(rounds, history["avg_loss"], "o-", color="#2d6a4f", lw=2, ms=7, label="Avg FL Loss")
ax.fill_between(rounds, history["avg_loss"], alpha=0.15, color="#2d6a4f")
ax.set_xlabel("FL Round"); ax.set_ylabel("Avg Loss")
ax.set_title("Federated Training Loss (FedAvg)")
ax.legend()
for rnd, val in zip(rounds, history["avg_loss"]):
    ax.annotate(f"{val:.3f}", (rnd, val), textcoords="offset points",
                xytext=(0,8), ha="center", fontsize=8)

# MRR
ax = axes[0,1]
ax.plot(rounds, history["mrr"], "s-", color="#4361ee", lw=2, ms=7, label="MRR (Filtered)")
ax.fill_between(rounds, history["mrr"], alpha=0.15, color="#4361ee")
ax.set_xlabel("FL Round"); ax.set_ylabel("Mean Reciprocal Rank")
ax.set_title("Link Prediction MRR")
ax.legend()

# Hits@K
ax = axes[1,0]
for k, c in [("hits@1","#f72585"),("hits@3","#7209b7"),("hits@10","#4cc9f0")]:
    ax.plot(rounds, history[k], "o-", color=c, lw=2, ms=6, label=k.upper())
ax.set_xlabel("FL Round"); ax.set_ylabel("Hits@K")
ax.set_title("Hits@K Across Rounds"); ax.legend()

# Client loss heatmap
ax = axes[1,1]
client_loss_matrix = np.array(history["client_losses"])
if client_loss_matrix.ndim == 2:
    sns.heatmap(client_loss_matrix.T, ax=ax, cmap="YlOrRd",
                xticklabels=[f"R{r}" for r in rounds],
                yticklabels=[f"C{i}" for i in range(CFG["n_clients"])],
                annot=True, fmt=".3f", cbar_kws={"label":"Loss"})
    ax.set_title("Per-Client Loss per Round"); ax.set_xlabel("Round"); ax.set_ylabel("Client")

plt.tight_layout()
p = GRAPH_DIR / "fig9_training_curves.png"
fig.savefig(p, dpi=300, bbox_inches="tight")
plt.show()
print(f"✅ Figure 9 saved → {p}")

# ===== CELL 10 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 10 — 3D Training Visualization: Round × Client × Loss
# ═══════════════════════════════════════════════════════════════════
client_loss_matrix = np.array(history["client_losses"])  # shape: (rounds, clients)
if client_loss_matrix.ndim == 2:
    n_rounds, n_cli = client_loss_matrix.shape
    R = np.arange(n_rounds)
    C = np.arange(n_cli)
    RR, CC = np.meshgrid(R, C)
    Z = client_loss_matrix[RR, CC]

    fig = plt.figure(figsize=(14, 9))
    ax  = fig.add_subplot(111, projection="3d")
    surf = ax.plot_surface(RR, CC, Z, cmap="RdYlGn_r", alpha=0.88,
                           linewidth=0.5, edgecolor="white")
    plt.colorbar(surf, ax=ax, label="Training Loss", pad=0.1, shrink=0.55)
    ax.set_xlabel("FL Round", labelpad=10)
    ax.set_ylabel("Client ID", labelpad=10)
    ax.set_zlabel("Loss",      labelpad=10)
    ax.set_xticks(R); ax.set_xticklabels([f"R{r+1}" for r in R])
    ax.set_yticks(C); ax.set_yticklabels([f"C{c}" for c in C])
    ax.set_title("3D Federated Training Surface — Round × Client × Loss",
                 fontsize=12, fontweight="bold")
    ax.view_init(elev=25, azim=-60)

    p = GRAPH_DIR / "fig10_3d_training_surface.png"
    fig.savefig(p, dpi=300, bbox_inches="tight")
    plt.show()
    print(f"✅ Figure 10 (3D training surface) saved → {p}")

# ===== CELL 11 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 11 — Plotly Interactive: Metrics across Rounds
# ═══════════════════════════════════════════════════════════════════
import plotly.graph_objects as go
from plotly.subplots import make_subplots

fig_p = make_subplots(rows=1, cols=2,
    subplot_titles=["Training Loss per Round","Link Prediction Metrics"])

fig_p.add_trace(go.Scatter(
    x=history["round"], y=history["avg_loss"],
    mode="lines+markers", name="Avg Loss",
    line=dict(color="#2d6a4f", width=2), marker=dict(size=8),
), row=1, col=1)

for metric, color in [("mrr","#4361ee"),("hits@1","#f72585"),
                       ("hits@3","#7209b7"),("hits@10","#f77f00")]:
    fig_p.add_trace(go.Scatter(
        x=history["round"], y=history[metric],
        mode="lines+markers", name=metric.upper(),
        line=dict(color=color, width=2), marker=dict(size=7),
    ), row=1, col=2)

fig_p.update_layout(
    title_text="Phase 3 — Federated KGE Training Summary",
    height=450, paper_bgcolor="white",
    xaxis_title="FL Round", xaxis2_title="FL Round",
)
p_html = GRAPH_DIR / "fig11_interactive_training.html"
fig_p.write_html(str(p_html))
fig_p.show()
print(f"✅ Interactive training chart saved → {p_html}")

# ===== CELL 12 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 12 — Client Data Summary Comparison Table
# ═══════════════════════════════════════════════════════════════════
client_summary = []
for cid, part in partitions.items():
    client_summary.append({
        "Client":     f"Client-{cid}",
        "Triples":    f"{len(part):,}",
        "Relations":  f"{np.unique(part[:,1]).shape[0]:,}",
        "Entities":   f"{np.unique(np.concatenate([part[:,0],part[:,2]])).shape[0]:,}",
        "Data Share": f"{len(part)/len(train_triples)*100:.2f}%",
        "Partition":  "Relation-Cluster (Non-IID)",
    })
client_df = pd.DataFrame(client_summary)
display(style_table(client_df, "Table — Federated Client Data Distribution"))

# Hyperparameter config table
cfg_df = pd.DataFrame(list(CFG.items()), columns=["Parameter","Value"])
cfg_df["Value"] = cfg_df["Value"].astype(str)
display(style_table(cfg_df, "Table 3 — Phase 3 Hyperparameter Configuration"))

# ===== CELL 13 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 13 — Export Phase 3 Results Artifact
# ═══════════════════════════════════════════════════════════════════
graph_paths = {
    "fig9_training_curves":    str(GRAPH_DIR / "fig9_training_curves.png"),
    "fig10_3d_training":       str(GRAPH_DIR / "fig10_3d_training_surface.png"),
    "fig11_interactive":       str(GRAPH_DIR / "fig11_interactive_training.html"),
}

phase3_results = {
    "phase":          3,
    "timestamp":      datetime.now().isoformat(),
    "config":         CFG,
    "model":          "TransE",
    "device":         str(DEVICE),
    "sim_time_sec":   float(sim_time),
    "training_history": history,
    "final_metrics":  {
        "mrr":     history["mrr"][-1],
        "hits@1":  history["hits@1"][-1],
        "hits@3":  history["hits@3"][-1],
        "hits@10": history["hits@10"][-1],
        "avg_loss":history["avg_loss"][-1],
    },
    "client_summary": [
        {"client_id": cid, "n_triples": int(len(part)),
         "n_relations": int(np.unique(part[:,1]).shape[0])}
        for cid, part in partitions.items()
    ],
    "global_model_path": str(MODEL_DIR / "global_transe_final.pt"),
    "graph_paths":       graph_paths,
}

with open("phase3_results.json","w") as f:
    json.dump(phase3_results, f, indent=2)

print("✅ phase3_results.json written.")
summary_df = pd.DataFrame([
    ("FL Rounds",        CFG["fl_rounds"]),
    ("Clients",          CFG["n_clients"]),
    ("Embedding Dim",    CFG["embedding_dim"]),
    ("Final MRR",        f"{phase3_results['final_metrics']['mrr']:.4f}"),
    ("Final Hits@10",    f"{phase3_results['final_metrics']['hits@10']:.4f}"),
    ("Final Avg Loss",   f"{phase3_results['final_metrics']['avg_loss']:.4f}"),
    ("Sim Time (s)",     f"{sim_time:.1f}"),
], columns=["Metric","Value"])
display(style_table(summary_df, "Phase 3 — Final Result Summary"))
print("\n✅ Phase 3 complete. Load phase3_results.json in Phase 4.")
