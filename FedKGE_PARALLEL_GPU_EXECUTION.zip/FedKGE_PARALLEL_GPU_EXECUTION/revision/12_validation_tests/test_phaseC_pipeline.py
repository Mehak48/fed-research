"""Phase C - integration (complete small federated rounds with every mechanism on), reproducibility and failure
paths, on the synthetic offline dataset (CPU). Synthetic outcomes are never evidence."""
import json

import numpy as np
import pandas as pd
import pytest
import torch

from conftest import synthetic_base_cfg
from fedkge import accountant as A
from fedkge.config import ConfigError, validate
from fedkge.io import IntegrityError, read_json

DPQ = {"enabled": True, "sampling": "common_rate", "q": 0.1, "target_epsilon": 4.0, "clip": 1.0,
       "schedule": {"shape": "fixed", "rho": 1.0, "update_every": 5}}


def _recompute(acc):
    orders = acc["orders_used"]
    for c in acc["per_client"]:
        sig = acc["sigma_schedule_per_client"][c["client"]][:acc["rounds_executed"]]
        ks = c["steps_executed_per_round"]
        rdp = A.composed_rdp(c["q"], ks, sig, orders)
        e = A.eps_from_rdp(rdp, acc["delta"], orders) if rdp.any() else 0.0
        assert abs(e - c["eps_rdp"]) < 1e-9


def test_full_round_dp_q_proposed_integrity_attack(run_cfg):
    fin, d = run_cfg(dp=DPQ, aggregation={"method": "proposed"},
                     attack={"type": "alie", "fraction": 0.2, "knowledge": "white"})
    acc = read_json(d / "accountant.json")
    assert acc["adjacency"].startswith("zero-out") and acc["sampling_design"] == "common_rate"
    assert len({tuple(s) for s in acc["sigma_schedule_per_client"]}) == 1          # one sigma (design Q)
    assert abs(acc["eps_rdp_public_api_worst_client"] - acc["eps_worst_client"]) < 1e-6
    assert acc["eps_worst_client"] <= 4.0 + 1e-9 and acc["schedule_verified"]
    _recompute(acc)
    integ = read_json(d / "integrity.json")
    assert integ["verified_bytes_are_aggregated"] and integ["n_rejected"] == 0
    att = read_json(d / "attack.json")
    assert att["noise_mode"] == "matched"
    tr = pd.read_csv(d / "trust_rounds.csv")
    assert {"A", "size_third", "flag_at_tau", "trust"} <= set(tr.columns)
    assert "A_v1" not in tr.columns                                     # variant V1 removed (owner decision B4)
    assert fin["early_stopping_active"] is False and fin["best_checkpoint_selection"] is True
    assert fin["rounds_executed"] == 3


def test_fedavg_runs_log_anomaly_scores_and_design_a(run_cfg):
    fin, d = run_cfg(dp={"enabled": True, "target_epsilon": 4.0})
    tr = pd.read_csv(d / "trust_rounds.csv")
    assert set(tr["aggregator"]) == {"fedavg"} and "A" in tr
    assert "anomaly_scores" in fin and "benign_fpr_at_cfg_tau_by_size_third" in fin["anomaly_scores"]
    acc = read_json(d / "accountant.json")
    assert acc["sampling_design"] == "fixed_batch"


@pytest.mark.parametrize("atk", [{"type": "targeted", "fraction": 0.2}, {"type": "sybil", "sybil_k": 2},
                                 {"type": "signflip", "fraction": 0.2},
                                 {"type": "adaptive", "fraction": 0.2, "knowledge": "gray"}])
def test_attacks_under_dp_complete(run_cfg, atk):
    fin, d = run_cfg(dp=DPQ, attack=atk)
    att = read_json(d / "attack.json")
    assert att["noise_mode"] in ("inherit", "matched")
    if atk["type"] == "targeted":
        assert att["target_source"].startswith("training triples")
        assert np.isfinite(fin["targeted"]["target_hits@10"])


def test_corruption_with_and_without_verification(run_cfg):
    fin_on, d_on = run_cfg(dp=DPQ, integrity={"mode": "hash_only", "corrupt_p": 0.3})
    on = read_json(d_on / "integrity.json")
    assert on["n_corrupted"] > 0 and on["n_corrupted_and_consumed"] == 0 and on["detection_rate"] == 1.0
    fin_off, d_off = run_cfg(dp=DPQ, integrity={"mode": "transport_only", "corrupt_p": 0.3})
    off = read_json(d_off / "integrity.json")
    assert off["n_corrupted_and_consumed"] == off["n_corrupted"] > 0 and off["n_rejected"] == 0


def test_dp3_no_noise_ablation_has_no_guarantee(run_cfg):
    fin, d = run_cfg(dp={**DPQ, "mode": "no_noise", "stop_rule": "none", "clip": None,
                         "pld_crosscheck": False, "prv_crosscheck": False})
    assert "privacy" not in fin and fin["privacy_ablation"]["mode"] == "no_noise"
    assert not (d / "accountant.json").exists()


def test_timing_pilot_is_flagged_partial(run_cfg):
    fin, d = run_cfg(train={"rounds_max": 6, "stop_after_rounds": 2}, dp=DPQ)
    assert fin["partial_run"] and fin["rounds_executed"] == 2
    acc = read_json(d / "accountant.json")
    assert acc["rounds_planned"] == 6 and acc["rounds_executed"] == 2


def test_mia_audit_pool_and_one_run_bound(run_cfg):
    fin, d = run_cfg(dp=DPQ, mia={"enabled": True, "pool_fraction": 0.2})
    m = read_json(d / "mia.json")
    assert m["primary_attack"] == "A2" and m["n_candidates"] > 0
    assert m["lower_bound_exceeds_accountant"] is False
    sc = pd.read_csv(d / "mia_scores.csv")
    assert set(sc["member"]) <= {0, 1} and len(sc) == m["n_candidates"]


def test_reproducible_same_seed(run_cfg):
    f1, _ = run_cfg(dp=DPQ, aggregation={"method": "proposed"})
    f2, _ = run_cfg(dp=DPQ, aggregation={"method": "proposed"})
    assert f1["val"]["mrr"] == f2["val"]["mrr"] and f1["test"]["mrr"] == f2["test"]["mrr"]
    assert f1["privacy"]["eps"] == f2["privacy"]["eps"]


@pytest.mark.parametrize("over,msg", [
    ({"dp": {"enabled": True, "sampling": "common_rate", "q": 1.5}}, "design Q"),
    ({"integrity": {"mode": "off", "corrupt_p": 0.1}}, "corruption"),
    ({"attack": {"type": "alie", "fraction": 0.2, "knowledge": "white", "noise_mode": "bogus"}}, "noise_mode"),
    ({"tier": "final"}, "synthetic"),
    ({"train": {"stop_after_rounds": 1}, "tier": "tune", "dataset": {"name": "fb15k237"}}, "stop_after_rounds"),
    ({"dp": {"enabled": True, "clip": None}}, "clip"),
    ({"aggregation": {"magnitude_reference": "global"}}, "magnitude_reference"),   # B4: the key itself is rejected
    ({"train": {"warm_start": "x"}}, "warm_start"),
])
def test_invalid_configs_fail_loudly(over, msg):
    cfg = synthetic_base_cfg(**over)
    with pytest.raises(ConfigError) as e:
        validate(cfg)
    assert msg.split()[0].lower() in str(e.value).lower()


def test_malformed_checkpoint_is_never_trusted(run_cfg, synthetic_paths):
    """Final package: an unreadable checkpoint (e.g. a partial write from before atomic checkpoints) is never used.
    It is kept as checkpoint.unreadable-*.pt and the run restarts from round 1 - the same computation as a fresh run."""
    from fedkge.config import run_id
    from fedkge.federated import run_experiment
    cfg = synthetic_base_cfg(dp=DPQ, train={"rounds_max": 4})
    fresh = run_experiment(cfg, synthetic_paths, "cpu", force=True)
    d = synthetic_paths.run(run_id(cfg))
    (d / "status.json").write_text(json.dumps({"status": "RUNNING", "code_hash": read_json(d / "status.json")["code_hash"]}))
    (d / "checkpoint.pt").write_bytes(b"not a checkpoint")
    fin = run_experiment(cfg, synthetic_paths, "cpu")
    assert read_json(d / "status.json")["status"] == "COMPLETE"
    assert list(d.glob("checkpoint.unreadable-*.pt")) and not (d / "checkpoint.pt").exists()
    assert "could not be read" in (d / "log.txt").read_text()
    assert fin["val"]["mrr"] == fresh["val"]["mrr"] and fin["test"]["mrr"] == fresh["test"]["mrr"]


def test_checkpoint_of_another_run_still_fails_loudly(run_cfg, synthetic_paths):
    import torch
    from fedkge.config import run_id
    from fedkge.federated import run_experiment
    from fedkge.io import code_hash
    cfg = synthetic_base_cfg(dp=DPQ, train={"rounds_max": 4, "lr": 0.002})
    d = synthetic_paths.run(run_id(cfg))
    d.mkdir(parents=True, exist_ok=True)
    torch.save({"run_id": "someone_else", "code_hash": code_hash()}, d / "checkpoint.pt")
    with pytest.raises(RuntimeError, match="different run"):
        run_experiment(cfg, synthetic_paths, "cpu", force=True)
    assert read_json(d / "status.json")["status"] == "FAILED"


def test_missing_dataset_files_fail(tmp_path):
    from fedkge.data import build_artifact
    with pytest.raises(IntegrityError):
        build_artifact({"name": "wn18rr", "source": "local_files"}, tmp_path / "p1", data_dir=tmp_path / "nothing")


# ------------------------------------------------------------------- defect PC-6: a rerun never writes over a run
def test_forced_rerun_keeps_the_earlier_complete_run(run_cfg, synthetic_paths):
    """The pilot and small_run always force. The earlier completed folder must survive byte for byte."""
    _, d = run_cfg(train={"rounds_max": 2})
    before = {f.name: f.read_bytes() for f in d.iterdir() if f.is_file()}
    _, d2 = run_cfg(train={"rounds_max": 2})
    assert d2 == d and read_json(d / "status.json")["status"] == "COMPLETE"
    kept = list((synthetic_paths.base / "stale").glob(f"{d.name}.forced_rerun-*"))
    assert any({f.name: f.read_bytes() for f in k.iterdir() if f.is_file()} == before for k in kept)


def test_archive_names_never_collide(tmp_path):
    from fedkge.io import RunDir
    for i in range(3):                                   # three archives of one run id, usually within one second
        d = tmp_path / "tier" / "runs" / "rid"
        d.mkdir(parents=True)
        (d / "x.txt").write_text(str(i))
        RunDir(d).archive_stale("forced_rerun")
    kept = sorted(p.read_text() for p in (tmp_path / "tier" / "stale").glob("rid.forced_rerun-*/x.txt"))
    assert kept == ["0", "1", "2"] and not (tmp_path / "tier" / "runs" / "rid").exists()
