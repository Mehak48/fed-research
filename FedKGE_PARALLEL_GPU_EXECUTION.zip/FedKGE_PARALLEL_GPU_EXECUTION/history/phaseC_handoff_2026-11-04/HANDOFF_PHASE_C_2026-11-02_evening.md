# FedKGE project — handoff brief for the next AI

**Snapshot:** 2026-11-02, evening update (it supersedes the morning version, kept as `HANDOFF_PHASE_C_2026-11-02_morning.md`)
**Project owner:** Mehak Ramzan · **Prepared by:** Claude (the AI that did Phases A, B and C so far)

**Where the project stands:**

- Phases A (audit) and B (design) are **complete**.
- Phase C (repair, test, prepare) is **complete up to the GPU pilot**:
  - the code is repaired and tested;
  - the datasets are downloaded (with the owner's licence confirmation) and verified;
  - smoke runs on the real data are done, and L0 is done;
  - a measured pilot ran on CPU;
  - all seven Phase C reports are written.
- **Waiting for the owner on two things:**
  1. the **GPU pilot on her free Google Colab** (kit ready);
  2. the open decisions in `audit/phaseC/remaining_blockers.md` (B2–B5).
- **Phase C is not signed off.** Do not start tuning (Stage 3) or confirmatory runs (Stage 4) before both are done.

---

## 0. Read this first (rules that override everything else)

The owner wants a **scientifically defensible IEEE paper, not one that only looks convincing**. She wants brutal honesty, scope creep flagged, and small verified steps. Her instructions are in `instructions/`; `4_phaseC_instructions.txt` is the active one.

1. **Never fabricate results.** Never fill gaps with estimates. Never claim that something ran when it did not. Never make tables or figures from invented values.
2. **Never overwrite or delete:**
   - the original code;
   - historical results (`files/`, `complete/`, read-only `audit/` from Phases A and B);
   - failed or inconvenient runs. Superseded items are moved aside, never deleted.
3. **Datasets.**
   - The owner confirmed research use of all three on 2026-11-02. Her words are stored in every `data_cache/<dataset>/source_manifest.json` (`operator_note`).
   - **Never put dataset files (or `triples.npz` / `labels.json` artifacts) into a deliverable.** This package contains none.
   - To re-download, use `scripts/prepare_data.py` with that recorded note.
4. **Do not launch tuning or the full matrix** before the owner has reviewed the GPU pilot and the budget.
5. **Make no claims of:**
   - client-level DP;
   - IPFS (none exists);
   - SHA-256 integrity as a poisoning defence;
   - any result from smoke or pilot runs.

   ε is never hard-coded.
6. **Synthetic data is for software tests only.**
7. **Selection uses validation data only.** The final tier refuses to select.
8. **Keep the approved design.** If something is invalid or infeasible:
   - stop;
   - explain;
   - propose the smallest justified fix;
   - wait for approval.
9. **Do not invent the professor's review.** It was never supplied.
10. **Git:** nothing is committed yet. Commit only if the owner asks (B5 asks her).
11. **Never edit `revision/01_fedkge_core/fedkge/*.py` while tests or runs execute.** The code hash changes, and the runs become stale.

---

## 1. Package contents

```
fedkge_phaseC_handoff/
├── HANDOFF_PHASE_C.md            ← this file
├── instructions/                 ← the owner's own messages (1 master prompt, 2 clarification, 3 Phase B, 4 Phase C)
├── audit/                        ← Phase A (read-only), Phase B design, and audit/phaseC/ (the 7 Phase C reports)
├── revision/                     ← THE CODE (git repo, branch phaseC, tag baseline-revision-P1-P4; changes uncommitted)
│   ├── README.md                 ← exact commands and result paths
│   ├── scripts/, colab/          ← entry points; free-Colab GPU pilot kit
│   └── results/phaseC/           ← official Phase C outputs (no dataset files, no model weights)
├── colab_kit/                    ← fedkge_code_phaseC.zip + phaseC_pilot_colab.ipynb (hash filled in) + SHA256SUMS
├── phaseC_changes.patch, phaseC_git_status.txt
├── phaseC_dev_probes/            ← early synthetic probes (not results)
└── reference/legacy_code_extracted/  ← code cells of the original P3 / P4 notebooks
```

**Not included:**

- dataset files (re-download them with `prepare_data.py`);
- model weights;
- the venv (5.3 GB);
- the owner's original uploads, including `complete/global_transe_final.pt`. Ask her for it if L0 is needed again.

---

## 2. The project in brief

- **Original paper:** "Privacy-Preserving Federated Knowledge Graph Embedding with Adaptive Differential Privacy, IPFS-Based Model Integrity and Trust-Weighted Aggregation on Non-IID Distributed Data" (TransE, FB15k-237, 5 clients).
- **Phase A:** not submittable.
  - Only two real experiments existed, both single-seed with a weak evaluation: a non-private one (MRR 0.2858) and a DP one (MRR 0.009).
  - The reported ε = 15.53 was invalid. The valid worst-client value is ε ≈ 1.98 at δ = 10⁻⁵.
  - Phases 5–8 numbers were hard-coded or simulated.
- **Revised study (Phase B, approved direction):**

| Area | Approved design |
|---|---|
| Datasets | FB15k-237, WN18RR, CoDEx-M |
| Clients and partitions | 10 clients; Dirichlet-over-relations partitions, α ∈ {0.1, 0.5, 1.0}; IID; centralised reference |
| Privacy | Triple-level DP per client, zero-out adjacency; ε ∈ {1, 2, 4, 8} (ε\* = 4), δ = 10⁻⁶ |
| Baselines | DP-FedAvg (main privacy baseline); robust baselines |
| Proposed method | Trust-weighted aggregation (frozen rule + variant V1) |
| Attacks | Main fraction f = 0.2 (0.1 / 0.3 sensitivity); attackers inherit or match the DP noise |
| Integrity | SHA-256 in the data path |
| H3 | MIA audit |
| Seeds | 5 / 10 |
| Selection | Validation-only, pre-registered |
| Order | Staged: tests → smoke → pilot → tuning → confirmatory |

---

## 3. Phases A and B — complete (do not redo)

**Phase A files:**

- `audit/initial_methodology_audit.md` (start with §0);
- `audit/artifact_inventory.md`;
- `audit/result_provenance.csv`.

**Phase B files** (in `audit/phaseB/`):

| File | Contents |
|---|---|
| `02_design_decisions.md` | D1–D18 and the approval sheet |
| `03_methodology_specification.md`, `03a_threat_model.md` | The method, privacy model and threat model |
| `05_privacy_utility_plan.md` | Hypotheses and tests |
| `06_experiment_matrix.md` | Every block with its run counts |
| `07_compute_feasibility.md` | Unverified GPU estimates and stage gates G-A…G-D |
| `08_open_questions.md` | Open questions for the owner |

The owner approved the D1–D18 direction in her Phase C instructions.

---

## 4. Phase C — what is done (details in `audit/phaseC/`)

| Report | Contents |
|---|---|
| `implementation_traceability.md` | 26 components: specification → code path → defect → repair → test → status. Also covers Phase B changes C1–C17 |
| `code_changes.md` | Every changed file with its reason; new defects PC-1…PC-4 |
| `privacy_implementation_audit.md` | The 11-point privacy model, verified against the code; accountant validation; L0 and the gap analysis |
| `test_report.md` | Passed / failed / skipped / not-run, by group A–F; smoke and other executions |
| `environment_report.md` | Machine, versions, network; dataset sources, licences and measured statistics; partition feasibility; Colab |
| `pilot_plan.md` | CPU pilot measurements, extrapolation, the GPU pilot procedure, stage plan |
| `remaining_blockers.md` | B1–B15: who must act on what |

**Key facts established (all measured or executed; none is a result of the revised method):**

| Fact | Value |
|---|---|
| Datasets | Split counts equal the official counts (FB15k-237 272,115 / 17,535 / 20,466; WN18RR 86,835 / 3,034 / 3,134; CoDEx-M 185,584 / 10,310 / 10,311). After dropping triples with entities unseen in training: FB valid/test −9/−28, WN18RR −210/−210, CoDEx-M 0 |
| Partition acceptance at α = 0.1 (real counts) | FB15k-237 100 %, **WN18RR 3.1 %**, CoDEx-M 67 %. Feasible, so no fallback, but WN18RR is a heavily truncated Dirichlet that must be disclosed |
| **L0**: the legacy non-private model, re-evaluated | **Test MRR 0.197** (full filtered, head + tail; tail only 0.268, head 0.126). Under the legacy protocol (300 random test triples, tail only): 0.240–0.280. The reported **0.2858 is protocol-inflated** |
| Accountant | 96 operating points × 5 methods, 0 failed checks (run twice) |
| Tests | Final suite on the final code: **131 passed, 0 failed, 0 errors, 0 skipped** (53 legacy + 78 Phase C). All test inputs are synthetic or analytic |
| Real-data smoke | 11 profiles × 3 datasets: 33 / 33 complete. Every block in smoke (gate G-A): the tuning chain ran all 6 stages with every pre-registered rule applied, and the reduced confirmatory matrix ran all 26 blocks. That is 421 runs with 0 failures |
| Schema validation (real smoke tier) | 496 outputs (454 run directories), 0 failures, after fixing schema defect PC-5 |
| CPU pilot, full data, 2 rounds | 18 / 18 configurations complete (+1 clean re-measurement). Per round on 2 CPU cores: FB15k-237 45–78 s, WN18RR 18–34 s, CoDEx-M 31–49 s. Peak RAM 1.1–2.2 GB. Upper bounds on this CPU: tuning 112 CPU-h, reduced Stage 4 874 CPU-h, so a GPU is required. Per run, this CPU takes 1.4–3.9× Phase B's HIGH GPU estimate (`audit/phaseC/pilot_plan.md`) |
| New defects found | PC-1 (smoke subset cut training to 300 triples): fixed. PC-3 (`keep_final_weights` split shared runs): fixed. PC-2 (variant V1 statistically weak with 10 clients; its trigger also fired on noise in the real smoke run): **owner decision (B4)**. PC-4 and PC-5 were my own check and schema mistakes, both fixed |

---

## 5. What is left (ordered)

**1. Owner: run the GPU pilot on free Colab** (`colab_kit/`):

- upload `fedkge_code_phaseC.zip` to `MyDrive/fedkge_phaseC/`;
- open `phaseC_pilot_colab.ipynb`, choose a T4 GPU, and `Run all` (about 45–75 minutes);
- send back `colab_pilot_results_<UTC>.zip`.

The kit checks the zip's SHA-256, runs the tests (expect 1 skipped), downloads the data with the recorded confirmation, runs 9 GPU smoke runs, then the pilot. It always writes a results zip, even when a step fails.

The kit was dry-run end to end on CPU (WN18RR only; Colab-only parts replaced). The GPU path is still untested.

**2. Analyse the GPU pilot:**

```bash
python scripts/pilot.py --extrapolate-only <colab pilot_measurements CSV>
```

- Compare with Phase B's GPU estimates. Write the GPU section of `pilot_plan.md`.
- Gate G-B also needs the centralised non-private sanity check. It comes from the T1C tuning runs.
- If the GPU smoke fails, fix the CUDA path. This path has never executed: there is no GPU here.

**3. Owner decisions** (`remaining_blockers.md`):

| Decision | Topic |
|---|---|
| B2 | Budget and profile; what to defer on free Colab |
| B3 | Response if the τ rule has no feasible value |
| B4 | Variant V1 (recommended: remove the switch, report FPR per size third descriptively) |
| B5 | D10 trigger 25 %, H2b 95 %, MIA settings, folder layout, git commit |

**4. Prepare Stage 3 for free Colab:**

- Write a session-safe notebook around `scripts/run_plan.py --plan tune --tier tune`. Runs resume, completed runs are skipped, and results stay on Drive.
- Re-run the test suite on the final code.

**5. Stage 3, Stage 4 and analysis:** see the "Not before approval" commands in `revision/README.md`. Also implement the table and figure builders (B9) before the Stage 4 analysis, generating figures only from executed runs.

---

## 6. Glossary

**Defect IDs:**

- CR / MJ / MN / OP / G: Phase B register (`audit/phaseB/data/defect_register.csv`);
- PC-1…PC-4: found in Phase C (`code_changes.md` §7).

**Decisions:** D1–D18. **Gates:** G-A (tests and smoke), G-B (pilot), G-C (selections frozen), G-D (hypotheses frozen, budget).

**Blocks:**

- N: non-private;
- DP1–3: DP-FedAvg, the complete method, the no-noise ablation;
- R: robustness;
- I: integrity;
- M1: MIA;
- X: extended;
- L0–L4: legacy;
- T1–T3, TAU: tuning.

**Sampling designs:**

- A: expected batch 512, per-client σ;
- Q: common q, T = 1/q, one σ.

**Tiers:** smoke (subsets, one seed per block), pilot (full data, timing), tune (seed 1001), final (confirmatory; selections frozen).
