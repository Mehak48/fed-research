#!/usr/bin/env python3
"""Writes FEDKGE_PARALLEL_WORKER.ipynb and FEDKGE_PARALLEL_MASTER.ipynb next to revision/ (maintainer tool).

  python colab/make_parallel_notebooks.py --commit <git commit> --manifest-sha <content sha256> --code-hash <hash>

WORKER notebook: one copy per GPU environment (Colab session, or any Jupyter with a GPU). It sets up and verifies the
package exactly like RUN_COMPLETE_FEDKGE_RESEARCH.ipynb, registers the worker, prepares data and artifacts for this
environment, then runs this worker's queue from the plan. MASTER notebook: CPU is enough; it plans, imports bundles,
does the selections / freeze / releases, validates, analyses and exports.
Both notebooks start no smoke test, pilot or benchmark; the kernel never imports the project (fresh interpreters).
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

MD, CODE = "markdown", "code"

SETUP = r'''import os, sys, json, time, shutil, zipfile, subprocess, pathlib, re, platform
SESSION_T0 = time.time()
print("Python", sys.version.split()[0], "|", platform.platform())
assert (3, 10) <= sys.version_info[:2] <= (3, 13), "Python outside the tested range 3.10-3.13: use a standard runtime"
import torch
print("torch", torch.__version__, "| CUDA build", torch.version.cuda, "| GPU available", torch.cuda.is_available())
if REQUIRE_GPU:
    assert torch.cuda.is_available(), "No GPU in this runtime: Runtime > Change runtime type > GPU, then run again"
    print("GPU:", torch.cuda.get_device_name(0))

def sh(*args, cwd=None, check=True):
    print("$", " ".join(str(a) for a in args), flush=True)
    p = subprocess.Popen([str(a) for a in args], cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    out = []
    for line in p.stdout:
        out.append(line); print(line, end="", flush=True)
    p.wait()
    if check and p.returncode != 0:
        raise RuntimeError(f"command failed with exit code {p.returncode}")
    return p.returncode

def hours_left():
    return max(0.0, MAX_HOURS_THIS_SESSION - (time.time() - SESSION_T0) / 3600)

try:
    from google.colab import drive
    drive.mount("/content/drive")
except ImportError:
    print("not on Colab: make sure BASE is a folder this machine can read and write")
BASE_P = pathlib.Path(BASE); BASE_P.mkdir(parents=True, exist_ok=True)
zp = BASE_P / PACKAGE_ZIP
assert zp.exists(), f"Upload {PACKAGE_ZIP} into {BASE_P} first"
WORK = pathlib.Path(os.environ.get("FEDKGE_WORK", "/content/fedkge_pkg"))
shutil.rmtree(WORK, ignore_errors=True); WORK.mkdir(parents=True)
with zipfile.ZipFile(zp) as z:
    bad = [n for n in z.namelist() if n.startswith("/") or ".." in n.split("/")]
    assert not bad, f"unsafe paths in the zip: {bad[:3]}"
    z.extractall(WORK)
REPO = next(WORK.glob("*/revision"))
GIT = ["git", "-c", "safe.directory=*", "-c", "core.fileMode=false"]
head = subprocess.run(GIT + ["rev-parse", "HEAD"], cwd=REPO, capture_output=True, text=True).stdout.strip()
dirty = subprocess.run(GIT + ["status", "--porcelain"], cwd=REPO, capture_output=True, text=True).stdout.strip()
assert head == EXPECTED_GIT_COMMIT, f"the code is commit {head}, expected {EXPECTED_GIT_COMMIT}: wrong or changed zip"
assert not dirty, f"files differ from the committed version:\n{dirty[:500]}"
sh(sys.executable, "-m", "pip", "install", "-q", *[f"{k}=={v}" for k, v in PINNED.items()])
import importlib.metadata as md
wrong = {k: md.version(k) for k in PINNED if md.version(k) != PINNED[k]}
assert not wrong, f"installed versions differ from the pins: {wrong} - restart the runtime and run from the top"
ch = subprocess.run([sys.executable, "-c", "import sys; sys.path.insert(0, '01_fedkge_core'); from fedkge.io import code_hash; print(code_hash())"],
                    cwd=REPO, capture_output=True, text=True).stdout.strip().splitlines()[-1]
assert ch == EXPECTED_CORE_CODE_HASH, f"core code hash {ch} != {EXPECTED_CORE_CODE_HASH}"
sh(sys.executable, "scripts/build_manifest.py", "--check", cwd=REPO)
m = json.loads((REPO / "10_configs" / "manifest" / "FROZEN_MANIFEST.json").read_text())
assert m["content_sha256"] == EXPECTED_MANIFEST_CONTENT_SHA256, "frozen manifest differs from the package's"
PH = REPO / "parallel" / "phases"
COMMON = ["--base", BASE, "--mode", MODE]
print("SETUP COMPLETE: commit", head[:12], "| base", BASE)'''

FIXED = r'''# ===================== fixed by the package (do not edit) =====================
EXPECTED_GIT_COMMIT = "__EXPECTED_GIT_COMMIT__"
EXPECTED_MANIFEST_CONTENT_SHA256 = "__EXPECTED_MANIFEST_SHA__"
EXPECTED_CORE_CODE_HASH = "__EXPECTED_CODE_HASH__"
PINNED = {"numpy": "2.5.3", "scipy": "1.18.1", "pandas": "3.0.5", "PyYAML": "6.0.3", "jsonschema": "4.26.0",
          "matplotlib": "3.11.2", "dp-accounting": "0.6.0", "prv-accountant": "0.2.0", "opacus": "1.6.0",
          "pytest": "9.1.1"}'''

DATA = r'''cmd = [sys.executable, PH / "phase01_prepare_data.py", *COMMON, "--data-dir", DATA_DIR]
if all(LICENCE_CONFIRMED.values()) and LICENCE_NOTE.strip():
    cmd += ["--i-confirm-licence", "--operator-note", LICENCE_NOTE]
sh(*cmd, cwd=REPO)
'''

WORKER = [
(MD, r"""# FedKGE parallel execution — GPU WORKER notebook

Use **one copy of this notebook per GPU environment** (one Colab session, or any Jupyter machine with a GPU). Every worker works in its own folder `BASE/workers/<WORKER_NAME>/` and exchanges results with the master only through files: result bundles in `BASE/exchange/outbox/`, release packs in `BASE/exchange/packs/`.

**Order:** 1 settings → 2 setup → 3 register → 4 data and artifacts → 5 run my queue. In every later session: 1 → 2 → 4 (minutes, nothing is rebuilt) → 5.

**Rules that keep the science intact**
- Never run two sessions with the **same** `WORKER_NAME` at the same time.
- Keep one GPU type and one torch build per worker. The master refuses results whose environment differs from the one already recorded for that tier and dataset.
- Several Colab accounts must **not** be used to get around Colab's limits. Colab does not allow it. A worker is an environment you are genuinely entitled to use."""),
(CODE, r'''BASE = "/content/drive/MyDrive/FedKGE"        # the SHARED folder (all workers and the master use the same one)
PACKAGE_ZIP = "FedKGE_PARALLEL_GPU_EXECUTION.zip"
WORKER_NAME = "colab-t4-a"                     # unique per environment; letters, digits, - _ .
SPEED = 1.0                                    # your estimate relative to a Tesla T4 (planning only)
MODE = "research"
MAX_HOURS_THIS_SESSION = 10.5                  # no NEW run starts after this many hours
DATA_DIR = BASE + "/data_cache"                # this environment's copy of the datasets (never exchanged)
LICENCE_CONFIRMED = {"fb15k237": False, "wn18rr": False, "codex_m": False}
LICENCE_NOTE = ""                              # who confirmed, when, for what
DEVICE, REQUIRE_GPU = "cuda", True
''' + FIXED + '\nprint("settings loaded")'),
(MD, "## 2. Setup and verification (no training)"),
(CODE, SETUP),
(MD, "## 3. Register this worker\nRecords this environment's lock signature (GPU name, torch, CUDA, Python) in `BASE/exchange/registry/`. The master plans with it."),
(CODE, r'''sh(sys.executable, PH / "phase00_register_worker.py", *COMMON, "--worker", WORKER_NAME, "--device", DEVICE,
   "--speed", str(SPEED), cwd=REPO)'''),
(MD, "## 4. Datasets and artifacts for this environment\nThe licence gate prints each dataset's terms. Nothing is downloaded before you confirm in cell 1. The preprocessing is deterministic, so the master checks that its data hash equals yours."),
(CODE, DATA + r'''sh(sys.executable, PH / "phase02_build_artifacts.py", *COMMON, "--worker", WORKER_NAME, "--data-dir", DATA_DIR, cwd=REPO)'''),
(MD, "## 5. Run my queue\nRuns the jobs that the plan gives this worker, in order. Jobs that wait for a release from the master are skipped and tried again later. Each job ends with a result bundle in the outbox. **EXIT 3** means the session budget is used up, or a job waits for the master: run the master cycle, then this cell again. Finished runs never run twice. An interrupted run resumes from its checkpoint."),
(CODE, r'''rc = sh(sys.executable, PH / "run_worker_queue.py", *COMMON, "--worker", WORKER_NAME, "--device", DEVICE,
        "--max-hours", f"{hours_left():.3f}", cwd=REPO, check=False)
print({0: "QUEUE COMPLETE", 1: "some runs FAILED (they are retried next time)", 3: "PAUSED or waiting for the master",
       5: "ENVIRONMENT MISMATCH", 6: "MANIFEST MISMATCH", 7: "INPUT CONTRACT VIOLATED"}.get(rc, rc))'''),
(MD, "## 6. My status"),
(CODE, r'''rec = pathlib.Path(BASE) / "workers" / WORKER_NAME / "results" / "parallel" / "receipts"
for p in sorted(rec.glob("*.json")):
    r = json.loads(p.read_text()); print(p.stem, "exit", r["exit_code"], {s: list(r["runs"].values()).count(s) for s in set(r["runs"].values())})
print("bundles:", len(list((pathlib.Path(BASE) / "exchange" / "outbox").glob(f"*__{WORKER_NAME}__*.zip"))))'''),
]

MASTER = [
(MD, r"""# FedKGE parallel execution — MASTER notebook (CPU is enough)

The master owns the **only** results store that is analysed (`BASE/master/results`). It plans the jobs, imports the workers' result bundles after checking them, makes the pre-registered Stage-3 selections, freezes them, and releases the dependent jobs. It also validates, analyses and exports.

**Order:** 1 settings → 2 setup → 3 data and master artifacts → (once every GPU worker ran its cell 3) 4 plan → 5 master cycle, which you repeat whenever bundles arrive → 6 analysis and report → 7 export."""),
(CODE, r'''BASE = "/content/drive/MyDrive/FedKGE"
PACKAGE_ZIP = "FedKGE_PARALLEL_GPU_EXECUTION.zip"
MODE = "research"
TUNE_MODE = "chain"            # chain: Stage 3 of a dataset on one worker in one go; stage: split every tuning stage
SYNC_HOURS = 0.25              # your hand-over delay estimate (planning only)
MAX_HOURS_THIS_SESSION = 11.5
DATA_DIR = BASE + "/data_cache"
LICENCE_CONFIRMED = {"fb15k237": False, "wn18rr": False, "codex_m": False}
LICENCE_NOTE = ""
L0_CHECKPOINT = ""             # optional: path of your original complete/global_transe_final.pt
DEVICE, REQUIRE_GPU = "cpu", False
''' + FIXED + '\nprint("settings loaded")'),
(MD, "## 2. Setup and verification"),
(CODE, SETUP),
(MD, "## 3. Datasets and the master's own artifacts\nThe master rebuilds the deterministic artifacts from its own copy of the data. It refuses every bundle whose data hash or partition hash differs."),
(CODE, DATA + r'''sh(sys.executable, PH / "phase02_build_artifacts.py", *COMMON, "--master", "--data-dir", DATA_DIR, cwd=REPO)'''),
(MD, "## 4. Plan the jobs\nRun this after every GPU worker has registered (worker cell 3). The job definitions are frozen at the first call. Later calls only re-plan who runs what, for example after you add a worker. Read `BASE/exchange/plan/PLAN.md` and give each worker its `QUEUE_<name>.md`."),
(CODE, r'''sh(sys.executable, PH / "phase03_plan_jobs.py", *COMMON, "--tune-mode", TUNE_MODE, "--sync-hours", str(SYNC_HOURS), cwd=REPO)
print((pathlib.Path(BASE) / "exchange" / "plan" / "PLAN.md").read_text()[:4000])'''),
(MD, "## 5. Master cycle: import → selections, freeze, releases → validation\nRun it whenever a worker has finished a job, or set `WATCH_MINUTES` so it repeats every 5 minutes. A refused bundle is listed with its reason. Nothing is deleted or overwritten."),
(CODE, r'''WATCH_MINUTES = 0
sh(sys.executable, PH / "master_cycle.py", *COMMON, "--watch-minutes", str(WATCH_MINUTES), cwd=REPO, check=False)
print((pathlib.Path(BASE) / "master" / "results" / "parallel" / "VALIDATION_REPORT.md").read_text()[:5000])'''),
(MD, "## 6. Analysis and report (safe at any time: anything missing stays PENDING)"),
(CODE, r'''sh(sys.executable, PH / "phase10_analysis.py", *COMMON, cwd=REPO, check=False)
args = [sys.executable, PH / "phase11_report_export.py", *COMMON, "--no-export"]
if L0_CHECKPOINT: args += ["--l0-checkpoint", L0_CHECKPOINT]
sh(*args, cwd=REPO, check=False)'''),
(MD, "## 7. Export (no dataset files, no weights)"),
(CODE, r'''sh(sys.executable, PH / "phase11_report_export.py", *COMMON, cwd=REPO)'''),
]


def build(cells, commit, manifest_sha, code_hash):
    out = []
    for i, (kind, src) in enumerate(cells):
        src = src.replace("__EXPECTED_GIT_COMMIT__", commit).replace("__EXPECTED_MANIFEST_SHA__", manifest_sha) \
                 .replace("__EXPECTED_CODE_HASH__", code_hash)
        c = {"cell_type": kind, "id": f"cell-{i:02d}", "metadata": {}, "source": src.splitlines(keepends=True)}
        if kind == CODE:
            c.update({"execution_count": None, "outputs": []})
        out.append(c)
    return {"cells": out, "metadata": {"accelerator": "GPU", "colab": {"provenance": []},
                                       "kernelspec": {"display_name": "Python 3", "name": "python3"},
                                       "language_info": {"name": "python"}}, "nbformat": 4, "nbformat_minor": 5}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--commit", required=True); ap.add_argument("--manifest-sha", required=True)
    ap.add_argument("--code-hash", required=True)
    ap.add_argument("--out-dir", default=str(Path(__file__).resolve().parents[2]))
    a = ap.parse_args()
    for name, cells in (("FEDKGE_PARALLEL_WORKER.ipynb", WORKER), ("FEDKGE_PARALLEL_MASTER.ipynb", MASTER)):
        p = Path(a.out_dir) / name
        p.write_text(json.dumps(build(cells, a.commit, a.manifest_sha, a.code_hash), indent=1, ensure_ascii=False) + "\n")
        print("wrote", p)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
