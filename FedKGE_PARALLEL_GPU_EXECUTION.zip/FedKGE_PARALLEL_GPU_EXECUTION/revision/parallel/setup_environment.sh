#!/usr/bin/env bash
# Environment setup for a terminal worker or master (lab server, cloud VM, local machine).
# Colab users do not need this: the notebooks install the same pins themselves.
#
#   cd FedKGE_PARALLEL_GPU_EXECUTION/revision && bash parallel/setup_environment.sh [--venv ../.venv]
#
# * Keeps the platform's own torch if one is installed (GPU machines ship a CUDA build; never replace it).
#   Without torch it installs the tested torch==2.14.1 from PyPI (a CUDA build that also runs on CPU).
# * Installs every other package at the exact version the test suite passed with (requirements-parallel.txt).
# * Verifies the package: git commit clean, frozen manifest and core code hash.
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "${1:-}" == "--venv" ]]; then
  python3 -m venv "${2:-../.venv}"; source "${2:-../.venv}/bin/activate"
fi
python3 - <<'PY'
import sys
assert (3, 10) <= sys.version_info[:2] <= (3, 13), f"Python {sys.version.split()[0]} is outside the tested range 3.10-3.13"
PY
if ! python3 -c "import torch" 2>/dev/null; then
  python3 -m pip install "torch==2.14.1"
fi
python3 -m pip install -r parallel/requirements-parallel.txt
python3 -c "import torch; print('torch', torch.__version__, '| CUDA available', torch.cuda.is_available())"
if git rev-parse HEAD >/dev/null 2>&1; then
  echo "git commit: $(git rev-parse HEAD)"
  test -z "$(git -c core.fileMode=false status --porcelain)" || { echo "STOP: files differ from the committed version"; exit 1; }
fi
python3 scripts/build_manifest.py --check
python3 -c "import sys; sys.path.insert(0, '01_fedkge_core'); from fedkge.io import code_hash; print('core code hash', code_hash())"
echo "SETUP COMPLETE. Next: export FEDKGE_PARALLEL_BASE=<shared folder>; python3 parallel/phases/phase00_register_worker.py --worker <name>"
