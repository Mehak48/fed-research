# Git checkpoint of the package (owner decision B5)

| Item | Value |
|---|---|
| Repository | `revision/` (local git repository; no remote push) |
| Branch | `phaseC` |
| **Final commit** | `485a29c433a09a7084abda0bc7f7f3f3ae774f91` (parallel GPU execution layer, 2026-11-07; methodology unchanged) |
| Tag | `parallel-gpu-execution-2026-11-07` on `485a29c`; `complete-executable-methodology-2026-11-05` stays on `e55400b` and `final-execution-package-2026-11-05` on `09fa02d` (history) |
| Commits in this package | `485a29c` parallel layer (`revision/parallel/`, parallel notebook generator; no core, config or manifest change) · `e55400b` documentation (Step 1a) · `1bffa87` integrity fast path, H3 earlier (RC-12), 9-step notebook · `9c4e04e` freeze per dataset · `09fa02d` notebook generator fix · `e388404` B3/B4/B5, gate G-B, frozen manifest, analysis and reporting |
| Earlier commits | `6e2ea67` B2–B5 checkpoint (approval register) · `334afaf` baseline: fedkge_revision_P1-P4.zip as delivered |
| Core (result-determining) code hash | `13b56d1823783c02b78c72cf15d6a7423a1ce03402135c232b98c7c0151c02d4` |
| Analysis code hash | `48ce1e38c83fe2dd93971346e78a35e8411c0b68f2d03f9be1372fb70a8cb5e1` |
| Frozen manifest content SHA-256 | `f86054ff06d4f450b378dfa587fa15f3b9571d3961e440abac01f2c543e2121d` |
| Frozen manifest file SHA-256 | `0ffa3d948cec18fc096792965d54109b93c3c377c580e4295e284539dcd5b708` |
| hypotheses.yaml SHA-256 | `bd144d7031afcd664e3e312536c9108935e5cfce013bc5573409f4364fd3e608` (unchanged) |
| selection_rules.yaml SHA-256 | `0a74381e7ce3ec155df02ab50d6a04c248df69efa6407b9d4c98d0c28f73e537` (unchanged) |
| gates.yaml SHA-256 | `2735e79cd6ff11bd95c8713374b6f94f923db3d4aa9261ea9e3ed05fa0f1758f` (unchanged) |
| matrices/confirm.yaml SHA-256 | `4b6a3bba1de3df10fd4cfe4a750fee9d8ff13f9d7027f5601306ac172281d8a1` (priorities only, RC-12) |

**How the checkpoint is enforced:**

- `RUN_COMPLETE_FEDKGE_RESEARCH.ipynb`, `FEDKGE_PARALLEL_WORKER.ipynb` and `FEDKGE_PARALLEL_MASTER.ipynb` (outside the repository) carry the expected commit, core code hash and manifest hash.
  - Step 1c refuses a different commit or any modified tracked file.
  - Step 1d refuses a different core code hash or manifest.
- Every run records `git_commit` and `code_hash` in env.json, status.json and final.json. `analysis.collect` uses only runs whose code hash equals the current one.
- `scripts/build_manifest.py --check` rebuilds the manifest from the configs and the core code and compares the two.

**Verify locally:**
```bash
cd revision
git -c safe.directory='*' log --oneline -3          # top: 485a29c Parallel GPU execution layer: independent jobs, ...
git -c safe.directory='*' -c core.fileMode=false status --porcelain   # must print nothing
python scripts/build_manifest.py --check
```
