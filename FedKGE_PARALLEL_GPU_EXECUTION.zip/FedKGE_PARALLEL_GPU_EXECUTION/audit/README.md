# Phase A audit — index

Phase A of the FedKGE methodology repair: **inventory and audit only**. Nothing in this folder is a new experimental result, and no original file was modified.

| File | What it is |
|---|---|
| `initial_methodology_audit.md` | **Main deliverable.** Defects by severity, privacy re-accounting, provenance summary, File 2 review, roadmap consolidation, contradictions, draft methodology direction, plan, IEEE-readiness, open questions |
| `artifact_inventory.md` | **Deliverable.** Every supplied artifact: purpose, status, dependencies, reproducibility; files still needed |
| `result_provenance.csv` | 47 manuscript claims + 5 Phase A calculations: source, re-derived value, trace class, validity |
| `data/artifact_inventory.csv` | 251 files with SHA-256, duplicate detection and audit metadata |
| `data/phaseA_epsilon_check.json` | recomputed privacy loss of the legacy DP run (labelled "audit check — not a privacy claim") |
| `data/revision_tests_phaseA.log`, `data/revision_tests_phaseA_junit.xml` | revision test suite: 27 passed, 26 not runnable (no PyTorch) |
| `scripts/phaseA_inventory.py` | builds the inventory CSV |
| `scripts/phaseA_epsilon_check.py` | privacy recomputation (Opacus 1.6.0 analysis code + `dp_accounting` RDP + PLD) |
| `scripts/phaseA_build_provenance.py` | re-derives every manuscript number from the legacy outputs |

## Reproduce

Requirements: Python ≥ 3.10, `numpy`, `scipy`, `dp-accounting`, and the Opacus 1.6.0 wheel (only its pure-Python file `opacus/accountants/analysis/rdp.py` is loaded, so PyTorch is not needed).

```bash
pip install dp-accounting numpy scipy
pip download --no-deps opacus==1.6.0 -d wheels && unzip -q wheels/opacus-1.6.0-py3-none-any.whl -d wheels/opacus_src

# privacy recomputation
python3 -I scripts/phaseA_epsilon_check.py \
    --opacus-rdp wheels/opacus_src/opacus/accountants/analysis/rdp.py \
    --out data/phaseA_epsilon_check.json

# provenance (needs the extracted File 5 'complete/' folder and the sigma=1.2 log, attachment 1272c771)
python3 -I scripts/phaseA_build_provenance.py \
    --complete "<File5>/complete" --sigma12-log <1272c771-attachment.txt> \
    --eps-check data/phaseA_epsilon_check.json --out result_provenance.csv
```

On Windows, replace `python3` with `py -3` and use `^` instead of `\` for line continuation.

## Status

Phase A is complete. Phase B (formal methodology specification) starts only after the questions in Section 16 of `initial_methodology_audit.md` are answered.
