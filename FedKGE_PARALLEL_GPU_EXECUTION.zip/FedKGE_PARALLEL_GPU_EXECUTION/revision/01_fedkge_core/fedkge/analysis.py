"""Collect run outputs into tidy tables and verify their validity (used by Phase 5a/5b/8 and selection).

A run is VALID for analysis only if:
  * status COMPLETE and final.json exists;
  * its code_hash equals the current code hash (otherwise the method changed after it ran);
  * its data_hash equals the current Phase 1 artifact hash, its partition_hash the current Phase 2 hash;
  * every selection file it depended on still has the recorded hash;
  * its tier equals the requested tier.
Invalid, failed or missing runs are REPORTED, never imputed.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .io import IntegrityError, Paths, RunDir, code_hash, read_json, sha256_file


def _flatten(prefix: str, d: Dict, out: Dict) -> None:
    for k, v in d.items():
        key = f"{prefix}{k}"
        if isinstance(v, dict):
            _flatten(key + ".", v, out)
        elif isinstance(v, list):
            continue
        else:
            out[key] = v


def load_index(paths: Paths, phase: str) -> pd.DataFrame:
    p = paths.index(phase)
    if not p.exists():
        raise IntegrityError(f"run index missing: {p}. Run the {phase.upper()} notebook first.")
    return pd.read_csv(p)


def collect(paths: Paths, phases: List[str], require_all: bool = False) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Returns (runs, problems). runs: one row per (block, name, dataset, seed) with config + results.
    problems: rows for missing / failed / stale / invalid runs (with reason)."""
    cur_code = code_hash()
    p1_hash, p2_cache, sel_cache = {}, {}, {}
    rows, problems = [], []
    for ph in phases:
        idx = load_index(paths, ph)
        for rec in idx.to_dict("records"):
            rd = RunDir(paths.run(rec["run_id"]))
            base = {k: rec[k] for k in ("phase", "block", "name", "dataset", "seed", "run_id")}
            st = rd.status()
            if st is None:
                problems.append({**base, "problem": "NOT_RUN"}); continue
            if st["status"] != "COMPLETE":
                problems.append({**base, "problem": st["status"], "detail": st.get("error", "")}); continue
            fin = read_json(rd.path / "final.json")
            cfg = read_json(rd.path / "config.json")
            if fin["code_hash"] != cur_code:
                problems.append({**base, "problem": "STALE_CODE"}); continue
            if fin["tier"] != paths.tier or cfg["tier"] != paths.tier:
                problems.append({**base, "problem": "WRONG_TIER"}); continue
            ds = fin["dataset"]
            if ds not in p1_hash:
                p1_hash[ds] = read_json(paths.p1(ds) / "manifest.json")["content_hash"]
            if fin["data_hash"] != p1_hash[ds]:
                problems.append({**base, "problem": "STALE_DATA"}); continue
            from .partition import spec_key
            pkey = (ds, spec_key(cfg["partition"]), fin["seed"])
            if pkey not in p2_cache:
                mp = paths.p2(ds) / pkey[1] / f"seed{fin['seed']}_manifest.json"
                p2_cache[pkey] = read_json(mp)["content_hash"] if mp.exists() else None
            if fin["partition_hash"] != p2_cache[pkey]:
                problems.append({**base, "problem": "STALE_PARTITION"}); continue
            sel_ok = True
            for ref, val in (cfg.get("selection_refs") or {}).items():
                fname, dotted = ref.split(".", 1)
                if fname not in sel_cache:
                    sp = paths.selection(fname)
                    sel_cache[fname] = read_json(sp) if sp.exists() else None
                from .config import get_dotted
                cur = get_dotted(sel_cache[fname], dotted, None) if sel_cache[fname] is not None else None
                if cur != val:
                    sel_ok = False
            if not sel_ok:
                problems.append({**base, "problem": "STALE_SELECTION"}); continue
            row = dict(base)
            _flatten("cfg.", {k: v for k, v in cfg.items() if k not in ("labels",)}, row)
            _flatten("", {k: v for k, v in fin.items() if k not in ("run_id", "dataset", "seed", "phase")}, row)
            for k, v in (cfg.get("labels") or {}).items():
                row[f"label.{k}"] = v
            rows.append(row)
    runs = pd.DataFrame(rows)
    probs = pd.DataFrame(problems, columns=["phase", "block", "name", "dataset", "seed", "run_id", "problem", "detail"])
    if require_all and len(probs):
        raise IntegrityError(f"{len(probs)} runs are missing/failed/stale:\n{probs.head(20).to_string()}")
    return runs, probs


def seed_table(runs: pd.DataFrame, group_cols: List[str], metric: str) -> pd.DataFrame:
    """Per-configuration summary INCLUDING every individual seed value (never only the mean)."""
    from .stats import summarize
    out = []
    for key, g in runs.groupby(group_cols, dropna=False):
        key = key if isinstance(key, tuple) else (key,)
        s = summarize(g[metric].values)
        rec = dict(zip(group_cols, key))
        rec.update({f"{metric}.mean": s["mean"], f"{metric}.sd": s["sd"], f"{metric}.ci95_low": s["ci95_low"],
                    f"{metric}.ci95_high": s["ci95_high"], "n_seeds": s["n"]})
        for sd_, v in sorted(zip(g["seed"], g[metric])):
            rec[f"{metric}.seed{sd_}"] = v
        out.append(rec)
    return pd.DataFrame(out)
