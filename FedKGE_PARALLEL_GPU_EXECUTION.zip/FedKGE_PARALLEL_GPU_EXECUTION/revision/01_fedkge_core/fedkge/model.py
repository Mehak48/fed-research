"""TransE (Bordes et al. 2013) as used throughout the pipeline.

score(h, r, t) = -|| n(e_h) + w_r - n(e_t) ||_2,  n(x) = x/||x|| if normalize else x.
The old Phase 3 normalised entities; the old Phase 4 silently dropped normalisation (one of the confounds found
in the audit). normalize=False exists ONLY for the legacy replica / DP-ladder step L1.

Parameters are held as a flat dict {'ent': (E,d), 'rel': (R,d)} of plain tensors so the same object can be
trained (non-DP autograd, or DP per-example gradients), serialised, hashed and aggregated.
"""
from __future__ import annotations

from typing import Dict

import torch
import torch.nn.functional as F

Params = Dict[str, torch.Tensor]
PARAM_ORDER = ("ent", "rel")


def init_params(n_ent: int, n_rel: int, dim: int, generator: torch.Generator, device) -> Params:
    b = 6.0 / dim ** 0.5
    ent = (torch.rand(n_ent, dim, generator=generator, device=device) * 2 - 1) * b
    rel = (torch.rand(n_rel, dim, generator=generator, device=device) * 2 - 1) * b
    return {"ent": ent, "rel": rel}


def ent_repr(x: torch.Tensor, normalize: bool) -> torch.Tensor:
    return F.normalize(x, p=2, dim=-1) if normalize else x


def score(h_e: torch.Tensor, r_e: torch.Tensor, t_e: torch.Tensor, normalize: bool) -> torch.Tensor:
    return -torch.linalg.vector_norm(ent_repr(h_e, normalize) + r_e - ent_repr(t_e, normalize), dim=-1)


def margin_loss_per_example(ph, pr, pt, nh, nt, margin: float, normalize: bool) -> torch.Tensor:
    """ph,pr,pt: (B,d) gathered positive rows; nh,nt: (B,k,d) negative head/tail rows (relation shared).
    Returns (B,) per-example loss = mean_k relu(margin - s(pos) + s(neg_k))."""
    s_pos = score(ph, pr, pt, normalize)                        # (B,)
    s_neg = score(nh, pr.unsqueeze(1), nt, normalize)           # (B,k)
    return F.relu(margin - s_pos.unsqueeze(1) + s_neg).mean(dim=1)


def flatten(p: Params) -> torch.Tensor:
    return torch.cat([p[k].reshape(-1) for k in PARAM_ORDER])


def unflatten(v: torch.Tensor, like: Params) -> Params:
    out, i = {}, 0
    for k in PARAM_ORDER:
        n = like[k].numel()
        out[k] = v[i:i + n].view_as(like[k])
        i += n
    return out


def clone(p: Params) -> Params:
    return {k: v.detach().clone() for k, v in p.items()}


def num_params(p: Params) -> int:
    return sum(v.numel() for v in p.values())
