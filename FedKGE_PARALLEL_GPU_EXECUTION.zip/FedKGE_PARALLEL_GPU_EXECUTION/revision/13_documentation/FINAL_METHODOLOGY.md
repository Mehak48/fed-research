# FedKGE — final approved methodology (execution version)

**Date:** 2026-11-05 · **Status:** frozen for execution. It consolidates the Phase B design (decisions D1–D18, `audit/phaseB/`), the Phase C implementation (`audit/phaseC/`) and the owner's decisions B2–B5 of 2026-11-04 (`13_documentation/STAGE3_APPROVAL_REGISTER_2026-11-04.md`).

**Nothing in this document is a result.** No tuning or confirmatory run has been executed. Every number below is a design value, a measured property of the data or code, or a planning estimate. Each is labelled as such.

The machine-readable versions are what the code executes:

| What | File | Frozen how |
|---|---|---|
| Base settings | `10_configs/base.yaml` | git checkpoint; SHA-256 in the frozen manifest |
| Tuning chain (Stage 3) | `10_configs/matrices/tune.yaml` | same |
| Main matrix (Stage 4) | `10_configs/matrices/confirm.yaml` (reduced profile) | same |
| Legacy replicas | `10_configs/matrices/p3.yaml`, `p4.yaml` (blocks L1–L4) | same |
| Selection rules | `10_configs/selection_rules.yaml` | same; each rule's SHA-256 is stored in its selection output |
| Gates and diagnostics | `10_configs/gates.yaml` | same |
| Hypotheses and tests | `10_configs/hypotheses.yaml` | same; SHA-256 in every analysis output |
| The approved run list | `10_configs/manifest/FROZEN_MANIFEST.json` (+ `.csv`) | rebuilt from the configs and compared at the start of every research session |

---

## 1. Research questions and pre-registered hypotheses

The study asks what correctly accounted, triple-level differential privacy costs a federated TransE model on three benchmarks, and whether trust-weighted aggregation protects it against poisoning without hurting clean utility.

| ID | Claim | Test (one-sided, paired by seed, α = 0.025, Holm within the family) | Members |
|---|---|---|---|
| **H1** | The complete method at ε\* = 4 keeps ≥ 90 % of the centralised non-private test MRR | H0: E[log(R1p / N1)] ≤ log 0.9 | 3 datasets |
| **H2** | Defence effectiveness E_a = 1 − mean(Δ_method) / mean(Δ_FedAvg) ≥ 0.35 under the complete method's DP configuration | c_s = 0.65·Δ_F,s − Δ_P,s; H0: E[c] ≤ 0. **Gate:** the attack must hurt FedAvg (one-sided lower 97.5 % bound of mean Δ_F > 0), else "not testable" (p = 1) | 3 datasets × 7 attacks = 21 |
| **H2b** | No harm (non-inferiority): the complete method's clean MRR is ≥ 95 % of DP-FedAvg's under the same DP settings | H0: E[log(R1p / DP2_ε4)] ≤ log 0.95 | 3 datasets |
| **H3** | DP at ε\* = 4 reduces the primary membership attack's advantage (A2 AUC − 0.5) by ≥ 25 % | H0: E[A_dp − 0.75·A_np] ≥ 0 vs H1: < 0. **Gate:** measurable leakage without DP (one-sided lower 97.5 % bound of mean A_np > 0) | 3 datasets |
| **HS** | The selected noise schedule s\* beats fixed σ at the same ε\* = 4 | H0: E[DP2_ε4 − DP1_ε4] ≤ 0. **Not testable** if Stage 3 selects the fixed schedule | 3 datasets |

**Descriptive questions** (paired 95 % intervals, never called significant): the federation cost (N2/N1), the privacy cost (R1p/N2), the DP-cost decomposition (DP3), heterogeneity (N3), robust baselines (R1, R4), trust without DP (R5, R5a), the schedule inside the method (R1q), integrity overhead and corruption handling (I1, I2), and the legacy replication (L0–L4).

**Non-inferiority (owner decision B5).**

- The margin is 0.95 on the ratio scale (log margin log 0.95 ≈ −0.051), fixed before any result.
- Non-inferiority is shown on a dataset only if its Holm-adjusted one-sided p ≤ 0.025. For a single member this is equivalent to the lower one-sided 97.5 % confidence bound of the geometric-mean ratio exceeding 0.95.
- **A point estimate above 0.95 alone is never evidence**, and the report says so.
- If the whole 95 % interval lies below 0.95, the report states it descriptively.

---

## 2. Data (Phase B D5; Phase C verified)

| Dataset | Source (pinned) | Licence (verified 2026-10-28) | Official splits (train / valid / test) |
|---|---|---|---|
| FB15k-237 | ConvE repository, commit `f3c0eb28…` (the Microsoft page was blocked) | Freebase-derived (CC BY 2.5); the Microsoft page states no terms; research use with attribution; no redistribution | 272,115 / 17,535 / 20,466 |
| WN18RR | ConvE repository, same commit | WordNet licence (notice required) | 86,835 / 3,034 / 3,134 |
| CoDEx-M | github.com/tsafavi/codex, commit `3132e426…` | MIT repository; Wikidata triples (CC0) | 185,584 / 10,310 / 10,311 |

**Licence gate.**

- `scripts/prepare_data.py` downloads only with `--i-confirm-licence` and an operator note, both recorded in `source_manifest.json`.
- The owner confirmed research use of all three datasets on 2026-11-02.
- The notebook asks for the confirmation again (settings cell, Step 1a) before its first download.
- Dataset files and processed artifacts are never put into a deliverable or an export.

**Integrity.**

- The fetched archives and files must match pinned SHA-256 values. These are the bytes of the owner's Colab session of 2026-11-04, re-downloaded identically on 2026-11-05.
- If they differ, nothing is written.

**Preprocessing (deterministic; `fedkge/data.py`).**

- Triples whose entities never occur in training are removed from validation and test (PyKEEN convention): FB −9 / −28, WN18RR −210 / −210, CoDEx-M 0. Some papers rank all test triples, so this is stated in the paper.
- The validation split is divided with seed 0 into V_sel (80 %, used for selection and final validation) and V_root (20 %, the FLTrust root set and MIA calibration).
- A fixed 2,000-triple subset V_es is used for periodic validation.
- Every artifact carries a content hash. Runs record it, and a changed artifact makes the dependent runs stale.

---

## 3. Clients and partitions (D4)

- **Main federation:** 10 clients. Triples are assigned by a Dirichlet distribution over relations with α = 0.1 (main setting).
- **Heterogeneity settings:** α = 0.5, 1.0 and IID. A centralised reference (one client) is also run.
- **Size rule:** every client holds ≥ 20 % of the mean client size and ≥ 1,024 triples.
  - The partition is the first draw in the seeded stream that meets the rule; draws are never re-tried for a "better" partition.
  - **WN18RR at α = 0.1** passes in only about 3 % of draws (measured on the real counts), so it is a heavily truncated Dirichlet. This is disclosed, and heterogeneity is compared through measured statistics (Table 2).
- **Legacy replicas:** the original 5-client relation-disjoint split.
- **Pairing:** a seed fixes the partition, the initialisation and the attacker placement, so every comparison is paired by seed.

---

## 4. Model and training (D13)

**Model and local training:**

- TransE, d = 100, L2-normalised entity embeddings, margin-ranking loss (margin 1).
- 64 uniformly drawn, data-independent negatives per positive.
- Adam with fresh optimiser state every round; one local epoch per round.
- Random initialisation; warm starts are refused.

**Validation, stopping and checkpoint selection:**

- Validation on V_es every 5 rounds.
- **Non-private runs** stop after 4 evaluations without improvement (R_max = 100).
- **DP runs** execute all R rounds.
- The final model is the best-validated checkpoint (post-processing). It is evaluated once on V_sel and once on the test split.

**Resolved inconsistency RC-1 (2026-11-05).**

- `confirm.yaml` capped the Stage-4 non-private references at 60 rounds. That cap was a Phase B cost-model assumption.
- Their tuning (T1C, T1F) and the approved protocol use R_max = 100 with early stopping.
- A shorter cap could under-train the non-private references and inflate H1's ratio in the proposed method's favour.
- Stage 4 now uses the tuned protocol. This changes no run count and raises the GPU upper bound by at most about 9.1 GPU-hours (171 non-private runs × 40 extra rounds × ≤ 4.8 s on a T4). Early stopping makes the real cost lower.

---

## 5. Federated protocol

1. All K clients take part in every round (no client sampling, so no amplification by subsampling is claimed).
2. Each client sends U_k = θ_k − θ^{t−1}.
3. The server verifies every update (§8), aggregates only the verified tensors and applies θ^t = θ^{t−1} + Δ^t.
4. Clients reject a broadcast that fails verification or contains a non-finite value.

---

## 6. Privacy mechanism and accounting (D2, D3, D11, D12)

**Mechanism:**

- **Privacy unit:** one training triple of one client, under **zero-out adjacency** (the triple is replaced by a null record; client sizes are public and unchanged).
- **Per-client DP-SGD:**
  - Poisson sampling, either design Q (common rate q, T = round(1/q) steps, one σ) or design A (expected batch 512, per-client σ); the design is selected in T2d.
  - Per-example clipping at C; non-finite gradients are zeroed.
  - Dense Gaussian noise N(0, σ²C²) is added once per step to the sum, normalised by the public expected batch.
  - The server adds no noise.

**Accounting:**

- RDP composition over the steps each client actually executed, converted to (ε, δ).
- **Reported: ε = max_k ε_k** (worst client) at δ = 10⁻⁶, also at 10⁻⁵, with δ × max N̂_k.
- Cross-checks: PLD (`dp_accounting`) and PRV (`prv-accountant`). The public-API RDP value must equal the run-time value.

**Calibration and schedules:**

- σ₀ is calibrated by RDP so that ε ≤ ε\* exactly over R rounds, for each schedule (fixed / linear / exponential / cosine, ρ ∈ {0.25, 0.5}).
- The executed σ trace is asserted to equal the configured schedule.
- ε\* ∈ {1, 2, 4, 8}; ε\* = 4 was declared in advance.

**Scope of the guarantee (owner decision B5).**

- Each reported ε is a **per-trained-model** guarantee.
- **The research workflow as a whole has no end-to-end DP guarantee:**
  - Stage 3 trains 99 models on the same client data and chooses hyperparameters from their validation scores.
  - Stage 4 trains further models on the same data under several configurations and seeds.
- Neither the selection nor the release of several models is in any reported ε. This is stated in the paper and in `DP_MECHANISM.md`.
- Settings selected at ε\* = 4 are reused at ε\* ∈ {1, 2, 8}. This may understate utility at those levels and never changes their ε.
- **Not covered:** entity-level or client-level privacy, the public client sizes, dataset-level properties, duplicated facts, and the server's validation data (assumed not to be client data).

---

## 7. Aggregation (D14, D15; owner decisions B3, B4)

**Baselines:**

- FedAvg, coordinate-wise median, trimmed mean (β = 0.2), Krum (f = 2), and FLTrust (500 root triples from V_root).
- Robustness parameters are set at the design attacker fraction f_design = 0.2, also in clean runs. Violated assumptions are recorded as flags.

**Proposed rule (frozen, `fedkge/trust.py`):**

- Reference: the coordinate-wise median update.
- Anomaly A_i = max(z(direction anomaly), z(magnitude anomaly)), with MAD standardisation; the magnitude is measured relative to the median norm of all updates.
- Flag: A_i > τ. History penalty e^{−λh}, λ = 0.5. Norm bound at the median norm. Weights ∝ size × trust. If every update is flagged, the median is used.
- It uses only transmitted updates and public sizes, so it is post-processing: it costs no privacy and provides none.

**B4 — variant V1 removed.**

- The size-third magnitude reference and its D15 switching trigger no longer exist. A configuration containing `aggregation.magnitude_reference` is rejected, and the column `A_v1` is forbidden in outputs.
- Benign false-positive rates per declared-size third (small / middle / large) remain a **descriptive diagnostic** (table `fpr_by_size_third`, figure F12). They never change the rule.

**τ selection (D14 with B3):**

- **Source:** the frozen-rule scores logged in the clean DP FedAvg tuning run at the selected DP settings (block TAU; predefined, tuning seed, no attack).
- **Grid:** {1.5, 2, 2.5, 3, 3.5, 4, 5}, predefined and never extended.
- **Rule:** τ\* = the smallest τ with mean benign FPR ≤ 5 %.
- **Direction check (B3):** the flag is A > τ, so along the increasing grid the benign FPR must be non-increasing, overall and in every size third. This is verified at selection time. A larger τ flags fewer updates: a lower false-positive rate, but weaker detection.
- **Fallback (B3):** if no grid τ meets the constraint, τ\* = the largest grid τ (the lowest FPR on the grid). The selection is recorded as `RULE_NOT_MET_LARGEST_GRID_TAU`, with the observed FPR and the excess over 5 %.
  - The dataset stays in every analysis.
  - Every result that uses this τ carries the label "τ rule not met (benign FPR = x %)".
  - The constraint is never reported as satisfied.

---

## 8. Integrity verification (D7)

**Protocol:**

- Every update and broadcast is serialised (header + float32 payload) and identified by `sha256-<hex>`; this is **not** an IPFS CID.
- Identifiers are sent over the authenticated channel, and the bytes go through the untrusted store.
- The receiver re-hashes. Only the tensor deserialised from verified bytes is aggregated; a mismatch drops the update for that round and is logged.

**What it guarantees:** detection of any change to the covered bytes.

**What it does not guarantee:** that content is benign. **A poisoned update hashes correctly, so this is not a poisoning defence.**

**Measured:**

- Bytes and hash / verify / store seconds per round. This operational overhead is reported separately from training time, and the hardware is named.
- In block I2, the corruption-in-transit detection rate (must be 1.0) and utility with verification on versus off.

---

## 9. Threat model and attacks (D16; `13_documentation/THREAT_MODEL.md`)

**Setting:**

- A static set of compromised, colluding clients: f = 0.2 (2 of 10), placed by seeded random draw. Attack strength s = 3.
- Under DP, attackers inherit the noise of their honest update (Gaussian, sign-flip, KG-targeted) or are norm-matched to it (ALIE, IPM, adaptive, Sybil).

**Attacks:**

- Gaussian, scaled sign-flip, ALIE, IPM.
- KG-targeted poisoning: 50 false-tail targets drawn from the attackers' own data, with 50 copies each, trained with DP.
- An adaptive attack tailored to the proposed rule, with a γ search on an 81-point grid in [0, 20].
- Sybil: 2 data-less identities.

**Metrics:**

- Damage Δ = clean − attacked test MRR. For the targeted attack, Δ is the rise in target Hits@10.
- E_a as a ratio of means.
- TPR / FPR of the flags, and the malicious weight share.

---

## 10. Membership-inference audit (D6, B5: settings preserved)

**Design (block M1, 5 seeds):**

- Each client draws an audit pool of 10 % of its training triples. Each candidate is included with probability ½; an excluded candidate becomes a null record, so the public sizes are unchanged.
- Configurations: FedAvg non-private and FedAvg + DP at ε\* ∈ {1, 4, 8}.

**Attacks:**

- A1: black-box score.
- **A2 (primary, pre-registered):** A1 standardised per relation on V_root, pooled over all clients.
- A3: white-box score change, secondary.

**Metrics:**

- AUC, TPR at FPR 1 % and 0.1 %, and the DP bound TPR ≤ e^ε·FPR + δ on every ROC.
- A one-run empirical ε lower bound (Steinke, Nasr & Jagielski 2023). Guesses are fixed at {100, 300, 1000}, each at confidence 1 − 0.05/3 (Bonferroni), and the largest bound is reported.

**Red line:** a lower bound above the accountant's ε in any DP run blocks H3 until the implementation is investigated.

---

## 11. Evaluation metrics

- **Ranking:** filtered (train + valid + test known-true triples removed), head and tail queries, realistic ties (optimistic and pessimistic also stored), micro-averaged over 2·|split| queries.
- **Reported metrics:** MRR, Hits@1/3/10, per-relation MRR, and a query-bootstrap interval (within-run only).
- **Leakage rules:** training triples are never queries; validation is used for selection only; the test split is evaluated once per run.
- **Also recorded:** runtime per component, peak GPU memory, and computed communication bytes.

---

## 12. Execution plan and budget (owner decision B2)

| Stage | Runs | Content | Measured T4 upper bound |
|---|---|---|---|
| 3 — tuning (tune tier, seed 1001) | **99** (114 cells: 15 cells re-state a winner and reuse its run) | **Stage 0 = gate G-B first (T1C)**, then T1F + T2a → T2b → T2c → T2d → T3 → TAU (τ, D10 flag) | 12.5 GPU-h (gate 1.7) |
| G-C — freeze | — | `freeze_selections.py`: append-only, refused unless G-B passed and τ exists | — |
| 4 — main (final tier, reduced profile) | **756** (726 if s\* = fixed: DP2 ≡ DP1 at ε\* = 4 and R1q ≡ R1p) | 21 blocks, run in priority order (below) | 100.5 GPU-h (91.9 measured basis + RC-1 rounds) |
| 4 — legacy replicas L1–L4 (final tier, FB15k-237) | **30** | p3 / p4 blocks R3_legacy, R3_fixed, R4_legacy, L1_legacy, L2_trainer_fixed, L3_accounting_fixed | ≤ 5.4 GPU-h (not measured) |
| L0 | evaluation only | the saved legacy model under the corrected protocol (needs the owner's checkpoint) | minutes |
| 5 — extended / sensitivity | 0 | **deferred (B2)**; `run_plan.py` refuses it | — |

**Total: 885 runs; upper bound ≈ 118 GPU-hours on a T4** (per block and dataset: `provenance/deadline_cost_model/`). These are estimates from 2-round measurements, not guarantees. Early stopping lowers the non-private cost; q = 0.02 would raise DP cost by about 12–29 %; attack crafting, the robust aggregators and the MIA audit add unmeasured cost.

**Stage-4 priority order** (so that a partial Stage 4 still answers the pre-registered hypotheses first; Phase B 07 §6, with RC-12 of 2026-11-05: M1 moved from 7 to 3, the others down by one; execution order only, no cell changed):

| Priority | Blocks | Answers | Cells |
|---|---|---|---|
| 1 | N1, N2, DP1 and DP2 at ε\* = 4, R1p | main table, H1, H2b, HS | 75 |
| 2 | R2, R2a, R3, R3a | H2 | 210 |
| 3 | M1 | H3 | 60 |
| 4 | L1–L4 | original vs revised (Table 13) | 30 |
| 5 | R1q | schedule inside the method | 15 |
| 6 | R1, R4, R5, R5a | baselines; trust without DP | 252 |
| 7 | DP1 at ε\* ∈ {1, 2, 8}, DP3, N3, I1, I2 | privacy-utility curve, DP-cost decomposition, heterogeneity, integrity | 144 |

After priority 3, every pre-registered hypothesis family (H1, H2, H2b, H3, HS) has all its members.

Within a priority, runs go dataset by dataset (in the order requested), then seed by seed. Early seeds thus give paired results for every block.

---

## 13. Selection rules (validation only, tuning seed 1001; D13)

| Step | Grid | Rule (ties within 0.002 validation MRR) |
|---|---|---|
| T1C / T1F | lr ∈ {1e-3, 3e-3, 1e-2} × B ∈ {512, 4096} | max validation MRR; ties → B = 512, then smaller lr |
| T2a | design Q: q ∈ {0.02, 0.05, 0.10} × lr ∈ {1e-3, 3e-3, 1e-2}; C = 1, R = 100, fixed σ, ε\* = 4 | ties → larger q, then smaller lr |
| T2b | C ∈ {0.25, 0.5, 1, 2, 4} | ties → smaller C |
| T2c | R ∈ {50, 100} (σ recalibrated) | ties → R = 50 |
| T2d | design A vs Q | ties → Q |
| T3 | fixed + {linear, exponential, cosine} × ρ ∈ {0.25, 0.5} | ties → fixed |
| τ | §7 | §7 (D14 + B3) |

**How selection runs:**

- Selections need the complete grid. They record the rule text, its SHA-256 and the full candidate table.
- The final tier refuses to select.
- Datasets may be tuned in different sessions. Earlier datasets' candidate tables are kept, and a rule text that changed between sessions is refused.

**Asymmetry (disclosed):** DP has more tuning cells than the non-private settings (21 vs 6). If anything, this makes the measured privacy cost look smaller.

---

## 14. Gates and diagnostics

| Gate | Rule | Effect |
|---|---|---|
| G-A | every block completes in smoke on the real subsets; schemas valid | met (Phase C; re-checked for this package) |
| **G-B — sanity gate (automatic prerequisite)** | the pre-registered T1_central configuration (centralised, non-private, fully trained) reaches ≥ ⅔ of the published TransE MRR on validation: FB15k-237 0.313 (LibKGE), WN18RR 0.228 (LibKGE), CoDEx-M 0.303 (CoDEx paper), i.e. thresholds 0.209 / 0.152 / 0.202 | **Stage 3 stops** if any requested dataset fails, and `SANITY_GATE_REPORT.md` gives the diagnostics. The ratio is never lowered and nothing is tuned towards the published value |
| G-C | selections frozen | Stage 4 refuses to start without `final/selection/FROZEN.json` |
| G-D | hypotheses and budget frozen | `hypotheses.yaml` and the manifest are part of the git checkpoint; their hashes are checked every session |
| **D10 flag (B5)** | r = best DP FedAvg validation MRR at ε\* = 4 / best non-private FedAvg validation MRR, FB15k-237, tuning runs | r < 0.25 is **flagged in every report**; nothing changes (no extra tuning, no mechanism change) |
| Environment lock | the first execution of a (tier, dataset) records device, GPU type, torch, CUDA and Python | a different environment is refused for that tier and dataset (no mixed GPUs or torch builds inside a comparison) |

---

## 15. Statistical analysis (D9; `fedkge/hypotheses.py`)

**Design:**

- **Unit:** one run, giving one test value of its selected checkpoint. Rounds are never replicates.
- **Pairing:** by seed. Both arms of every member must have exactly the pre-registered seed set; otherwise the member is reported as missing.

**Per configuration:** every per-seed value, the mean, the SD and a 95 % t-interval.

**Comparisons:**

- The paired difference or log-ratio with a 95 % t-interval, and d_z.
- One-sided paired t-tests at α = 0.025 with Holm correction over **all** pre-registered members of a family.
  - A member that is not testable, missing or invalid enters with p = 1, so the family size never shrinks.
  - A family with missing members is labelled **PROVISIONAL**.
- Exact sign-flip tests are secondary: with 5 seeds their smallest one-sided p is 1/32 > 0.025.

**Decision labels:**

- **SUPPORTED** (Holm-adjusted p ≤ α).
- **NOT SUPPORTED, inconclusive at this level.** Failing to reject H0 never establishes the opposite claim.
- **NOT TESTABLE** (with the pre-registered reason).
- **PENDING** (runs missing).
- **INVALID_MIXED_ENVIRONMENT** or **BLOCKED_RED_LINE**.
- "Holds on all datasets" requires every member to be supported.
- Results from any tier other than `final` are labelled NOT EVIDENCE.

---

## 16. Reproducibility

**Run identity and validity:**

- **Run identity:** the SHA-256 of the full semantic configuration. Each run has its own folder `<results>/<tier>/runs/<run_id>/`, and identical configurations in two blocks share one run.
- **Recorded per run:** the configuration, environment, code hash, data hash, partition hash, selection values, every per-round log, accountant, attack, integrity and MIA records, and the status.
- **Validity:** a run is used only if its code, data, partition and selections are current.

**Session safety:**

- Writes are atomic; checkpoints are written every 5 rounds through a temporary file and a rename.
- An interrupted run resumes from its checkpoint (tested: the resumed result equals an uninterrupted run on CPU).
- An unreadable checkpoint is kept aside and the run restarts from round 1.
- A failed run is retried by the next call, and its earlier traceback is kept.
- Completion is derived from the run folders; nothing is marked complete unless its folder says COMPLETE with the current code hash and `final.json` exists.

**Determinism:**

- CPU runs are bitwise reproducible (tested).
- GPU runs are not bitwise-tested: the same seed twice on one T4 matched to 4 decimals in 18 of 18 pilot configurations.

**Freezing:**

- The git commit is recorded in every run's `env.json`. The notebook refuses any code that differs from the packaged commit.

---

## 17. Changes relative to Phase B / Phase C, all made before any result

| ID | Change | Why |
|---|---|---|
| B3 | τ fallback: largest grid τ, labelled, kept in the analysis; monotonicity verified | owner decision 2026-11-04 |
| B4 | variant V1 and its D15 switch removed; size-third FPR kept as a diagnostic | owner decision 2026-11-04 (finding PC-2: V1 statistically weak with 10 clients) |
| B5 | D10 is a flag only; the H2b procedure is stated; the tuning privacy cost is disclosed as not end-to-end; MIA settings unchanged | owner decision 2026-11-04 |
| B2 | reduced profile; Stage 5 refused; priority order; frozen manifest of 885 runs | owner decision 2026-11-04 |
| RC-1 | Stage-4 non-private references use R_max = 100 (the tuned protocol) instead of a 60-round cap | removes a bias in H1's favour (§4) |
| — | gate G-B became tuning stage 0 (T1C first); same 99 runs | automatic prerequisite (approval register, safeguard 5) |
| — | the smoke-only τ placeholder (`--smoke-tau-fallback`) removed | B3 now defines the behaviour on every tier |
| — | atomic checkpoints, unreadable-checkpoint restart, retry history, session time budget, environment lock, pinned dataset hashes | session safety and integrity; the computation is unchanged |

---

## 18. What is not claimed

- No IPFS; SHA-256 integrity is not a poisoning defence.
- No client-level or entity-level DP.
- No end-to-end DP for the tuning-and-evaluation workflow.
- No bitwise GPU reproducibility.
- No external DP baseline reproduction (D17).
- Nothing from smoke, pilot or fixture outputs is a result.
- Published TransE values are a trainer check, never comparison rows.

## 19. Known open inputs

- **L0** needs the owner's original checkpoint `complete/global_transe_final.pt`. Without it, Table 13 shows L0 as pending.
- **X6** (local-only training) and **O1** (validation-triggered σ decay) are not implemented. They are optional in Phase B and outside the approved budget.
- **Inputs requested in Phase A–C and never supplied:** the professor's review, a repository link, and the owner's additional roadmap changes. Nothing was invented in their place.
