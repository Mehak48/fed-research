# Phase 1 — Data preparation
**Notebook:** `phase1_data.ipynb` · **Inputs:** none (PyKEEN downloads) · **GPU:** no · **Runtime:** ~3–20 min

Does: loads FB15k-237, WN18RR, YAGO3-10 via PyKEEN (same code for all three); validates id ranges, duplicates,
train/valid/test overlap (must be 0), unseen entities, inverse-pair statistic; splits the official validation
set 80/20 into V_sel (model selection) / V_root (server root data for later FLTrust) with a fixed split seed;
fixes the 2,000-triple early-stopping subset inside V_sel; hashes arrays + files; writes a dataset card; recomputes
the descriptive OLAP roll-ups. Smoke tier uses a 3,000-triple subset (re-indexed) per dataset.

**Outputs:** `artifacts/p1/<ds>/{triples.npz, labels.json, dataset_card.json, validation_report.json,
olap_summary.json, manifest.json}`, `reports/p1/*dataset_summary.csv`, `*_distributions.png`.
**Checks:** schema validation, zero leakage, V_sel ∩ V_root = ∅, re-hash, rebuild reproduces the content hash.
**Next:** Phase 2. Downstream runs record this `content_hash`; if it changes, every later result becomes STALE.
