#!/usr/bin/env python3
"""PHASE 11 (master, CPU, minutes) - tables, 2D/3D figures, results draft and the final export of the master store.

  python parallel/phases/phase11_report_export.py --base B [--no-export] [--l0-checkpoint path/global_transe_final.pt]

Runs scripts/build_report.py --with-figures (unchanged: partial results give partial tables and PENDING
placeholders, never invented numbers) and scripts/export_artifacts.py (no dataset files, no weights). With
--l0-checkpoint it first runs the optional L0 evaluation (scripts/legacy_l0_eval.py; evaluation only, no training).
Outputs: <master>/final/reports/, figures, and <base>/fedkge_results_export_<UTC>.zip.
"""
from __future__ import annotations

import subprocess
import sys

from _cli import layout, parser

from fedkge_parallel.common import REPO


def main(argv=None) -> int:
    ap = parser(__doc__)
    ap.add_argument("--no-export", action="store_true")
    ap.add_argument("--l0-checkpoint")
    a = ap.parse_args(argv)
    L = layout(a)
    tier = "final" if a.mode == "research" else "smoke"
    if a.l0_checkpoint:
        if subprocess.run([sys.executable, "scripts/legacy_l0_eval.py", "--checkpoint", a.l0_checkpoint, "--results",
                           str(L.master), "--tier", tier], cwd=REPO).returncode != 0:
            return 1
    if subprocess.run([sys.executable, "scripts/build_report.py", "--results", str(L.master), "--tier", tier,
                       "--with-figures"], cwd=REPO).returncode != 0:
        return 1
    if not a.no_export:
        return subprocess.run([sys.executable, "scripts/export_artifacts.py", "--results", str(L.master), "--out",
                               str(L.base)], cwd=REPO).returncode
    return 0


if __name__ == "__main__":
    sys.exit(main())
