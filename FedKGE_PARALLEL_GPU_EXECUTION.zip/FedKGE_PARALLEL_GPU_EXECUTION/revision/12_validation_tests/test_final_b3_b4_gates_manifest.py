"""Final package (2026-11-05): regression tests for owner decisions B3 (tau fallback) and B4 (V1 removed), the
pre-registered gates (G-B sanity gate, D10 flag, environment lock), the frozen manifest and the session-safe
execution (deadline, interruption and resume, atomic checkpoints, retry history).
All inputs are SYNTHETIC or hand-made tables: these tests check the implementation, never a research result."""
import json
import shutil
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from conftest import CONFIG_DIR, PKG, SCHEMA_DIR, synthetic_base_cfg
from fedkge.config import load_yaml
from fedkge.io import IntegrityError, Paths, read_json

RULES = load_yaml(CONFIG_DIR / "selection_rules.yaml")
GATES = load_yaml(CONFIG_DIR / "gates.yaml")
GRID = [1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 5.0]


def _trust_rounds(scores, thirds=None, malicious=None):
    n = len(scores)
    return pd.DataFrame({"round": np.arange(n) // 10 + 1, "client": np.arange(n) % 10,
                         "malicious": malicious if malicious is not None else np.zeros(n, bool),
                         "size_third": thirds if thirds is not None else np.arange(n) % 3, "A": scores})


def _tune_paths(tmp_path):
    return Paths(tmp_path, "tune")


# ============================================================================================== B3: tau fallback
def test_b3_rule_text_is_preregistered():
    r = RULES["tau"]
    assert r["grid"] == GRID and r["max_benign_fpr"] == 0.05 and r["source_block"] == "TAU"
    assert r["if_infeasible"] == "largest_grid_tau" and r["choose"] == "smallest_feasible"
    assert r["score"] == "A" and r["flag"] == "A > tau"
    assert "v1_trigger" not in RULES                                     # B4


def test_b3_feasible_case_picks_smallest_tau(tmp_path):
    from fedkge.selection import select_tau
    rng = np.random.default_rng(0)
    sel = select_tau({"wn18rr": _trust_rounds(rng.normal(0, 1, 2000))}, RULES, _tune_paths(tmp_path))
    t = sel["wn18rr"]["tau"]
    cand = [c for c in sel["_tau_rule"]["candidates"] if c["dataset"] == "wn18rr"]
    feas = [c["tau"] for c in cand if c["benign_fpr"] <= 0.05]
    assert t["rule_met"] is True and t["status"] == "RULE_MET" and t["aggregation"]["tau"] == min(feas)
    assert t["constraint_violation"] is None and t["benign_fpr_at_selected_tau"] <= 0.05


def test_b3_boundary_fpr_equal_to_limit_is_feasible(tmp_path):
    from fedkge.selection import select_tau
    scores = np.r_[np.full(95, 0.0), np.full(5, 1.6)]           # exactly 5 % above 1.5, none above 2.0
    sel = select_tau({"fb15k237": _trust_rounds(scores)}, RULES, _tune_paths(tmp_path))
    assert sel["fb15k237"]["tau"]["aggregation"]["tau"] == 1.5 and sel["fb15k237"]["tau"]["rule_met"]


def test_b3_no_feasible_tau_uses_largest_grid_tau_and_is_flagged(tmp_path):
    from fedkge.selection import select_tau
    scores = np.r_[np.full(80, 0.0), np.full(20, 9.0)]          # 20 % benign FPR at every grid tau
    sel = select_tau({"codex_m": _trust_rounds(scores)}, RULES, _tune_paths(tmp_path))
    t = sel["codex_m"]["tau"]
    assert t["aggregation"]["tau"] == max(GRID) == 5.0                   # never outside the predefined grid
    assert t["rule_met"] is False and t["status"] == "RULE_NOT_MET_LARGEST_GRID_TAU"
    assert t["benign_fpr_at_selected_tau"] == pytest.approx(0.2)
    assert t["constraint_violation"] == {"observed_benign_fpr": pytest.approx(0.2), "limit": 0.05,
                                         "excess": pytest.approx(0.15)}
    assert "NOT met" in t["label"] and "20.0 %" in t["label"]
    assert set(t["benign_fpr_by_size_third_at_selected_tau"]) == {"third0", "third1", "third2"}
    assert not any(c["feasible"] for c in sel["_tau_rule"]["candidates"])
    from fedkge.schemas import validate_file
    validate_file(tmp_path / "tune" / "selection" / "tuning.json", SCHEMA_DIR, "tuning_selection")


def test_b3_direction_check(tmp_path):
    from fedkge.selection import benign_fpr_table, check_tau_direction
    tab = benign_fpr_table(_trust_rounds(np.random.default_rng(1).exponential(1, 999)), GRID)
    d = check_tau_direction(tab)
    assert d["fpr_non_increasing_in_tau"] and "lower benign false-positive rate" in d["meaning"]
    assert (np.diff(tab["benign_fpr"]) <= 0).all()
    bad = tab.copy(); bad.loc[3, "benign_fpr"] = 0.9                    # an increase must be caught
    with pytest.raises(IntegrityError):
        check_tau_direction(bad)
    with pytest.raises(IntegrityError):
        check_tau_direction(tab.iloc[::-1].reset_index(drop=True))     # the grid must be increasing


def test_b3_refuses_non_finite_scores_attack_runs_and_final_tier(tmp_path):
    from fedkge.selection import select_tau
    with pytest.raises(IntegrityError, match="non-finite"):
        select_tau({"wn18rr": _trust_rounds(np.r_[np.zeros(9), np.nan])}, RULES, _tune_paths(tmp_path))
    mal = np.zeros(10, bool); mal[0] = True
    with pytest.raises(IntegrityError, match="clean"):
        select_tau({"wn18rr": _trust_rounds(np.zeros(10), malicious=mal)}, RULES, _tune_paths(tmp_path))
    with pytest.raises(IntegrityError, match="final"):
        select_tau({"wn18rr": _trust_rounds(np.zeros(10))}, RULES, Paths(tmp_path, "final"))


def test_b3_without_declared_fallback_still_stops(tmp_path):
    from fedkge.selection import select_tau
    rules = {**RULES, "tau": {k: v for k, v in RULES["tau"].items() if k != "if_infeasible"}}
    with pytest.raises(IntegrityError, match="no tau on the grid"):
        select_tau({"wn18rr": _trust_rounds(np.full(10, 9.0))}, rules, _tune_paths(tmp_path))


def test_b3_is_deterministic_and_keeps_earlier_sessions(tmp_path):
    from fedkge.selection import select_tau
    rng = np.random.default_rng(2)
    a, b = _trust_rounds(rng.normal(0, 1, 500)), _trust_rounds(np.full(100, 9.0))
    s1 = select_tau({"fb15k237": a}, RULES, Paths(tmp_path / "x", "tune"))
    s2 = select_tau({"fb15k237": a}, RULES, Paths(tmp_path / "y", "tune"))
    assert s1 == s2
    p = Paths(tmp_path / "z", "tune")
    select_tau({"fb15k237": a}, RULES, p)                                # session 1: one dataset
    sel = select_tau({"wn18rr": b}, RULES, p)                            # session 2: another dataset
    assert {c["dataset"] for c in sel["_tau_rule"]["candidates"]} == {"fb15k237", "wn18rr"}
    assert sel["fb15k237"]["tau"]["rule_met"] and not sel["wn18rr"]["tau"]["rule_met"]


def test_b3_fallback_tau_flows_into_stage4_and_is_recorded(tmp_path):
    from fedkge.runner import expand
    sel = {}
    for ds in ("fb15k237", "wn18rr", "codex_m"):
        sel[ds] = {"T1_nonprivate": {"train": {"lr": 0.001, "batch_size": 512}},
                   "T1_central": {"train": {"lr": 0.001, "batch_size": 512}},
                   "T2a": {"dp": {"q": 0.05}, "train": {"lr": 0.003}}, "T2b": {"dp": {"clip": 1.0}},
                   "T2c": {"train": {"rounds_max": 100}}, "T2d": {"dp": {"sampling": "common_rate"}},
                   "T3": {"dp": {"schedule": {"shape": "cosine", "rho": 0.5}}},
                   "tau": {"aggregation": {"tau": 5.0}, "rule_met": False, "status": "RULE_NOT_MET_LARGEST_GRID_TAU"}}
    d = tmp_path / "final" / "selection"; d.mkdir(parents=True)
    (d / "tuning.json").write_text(json.dumps(sel))
    e = expand("final", CONFIG_DIR, Paths(tmp_path, "final"), "final", ["wn18rr"], [4], ["R1p", "R3"],
               profile="reduced", matrix_name="confirm")
    assert e and all(x["cfg"]["aggregation"]["tau"] == 5.0 for x in e)
    assert all(x["cfg"]["selection_refs"]["tuning.wn18rr.tau.aggregation.tau"] == 5.0 for x in e)


# ============================================================================================== B4: V1 removed
def test_b4_no_v1_anywhere_in_configs():
    for p in CONFIG_DIR.rglob("*.yaml"):
        d = load_yaml(p)
        txt = json.dumps(d)
        assert "magnitude_reference" not in txt and "size_third" not in txt and "v1_trigger" not in txt, p


def test_b4_config_with_v1_key_is_rejected():
    from fedkge.config import ConfigError, validate
    for v in ("global", "size_third"):
        with pytest.raises(ConfigError, match="B4"):
            validate(synthetic_base_cfg(aggregation={"magnitude_reference": v}))


def test_b4_trust_rounds_schema_forbids_v1_column(tmp_path):
    import jsonschema
    from fedkge.schemas import validate_csv_columns
    spec = json.loads((SCHEMA_DIR / "trust_rounds_csv.schema.json").read_text())
    assert "A_v1" not in spec["required_columns"] and spec["forbidden_columns"] == ["A_v1"]
    cols = spec["required_columns"]
    pd.DataFrame([[0] * len(cols)], columns=cols).to_csv(tmp_path / "ok.csv", index=False)
    validate_csv_columns(tmp_path / "ok.csv", SCHEMA_DIR, "trust_rounds_csv")
    pd.DataFrame([[0] * (len(cols) + 1)], columns=cols + ["A_v1"]).to_csv(tmp_path / "bad.csv", index=False)
    with pytest.raises(jsonschema.ValidationError):
        validate_csv_columns(tmp_path / "bad.csv", SCHEMA_DIR, "trust_rounds_csv")


def test_b4_size_third_fpr_remains_a_diagnostic(tmp_path):
    from fedkge.selection import benign_fpr_table
    tab = benign_fpr_table(_trust_rounds(np.random.default_rng(3).normal(0, 1, 300)), [3.0])
    assert {"benign_fpr_third0", "benign_fpr_third1", "benign_fpr_third2", "n_obs_third0"} <= set(tab.columns)


# ============================================================================================== gates
def _t1c_runs(vals):
    rows = []
    for ds, v in vals.items():
        for lr in (0.001, 0.003, 0.01):
            for b in (512, 4096):
                rows.append({"block": "T1C", "dataset": ds, "run_id": f"r_{ds}_{lr}_{b}", "cfg.train.lr": lr,
                             "cfg.train.batch_size": b, "val.mrr": v if (lr, b) == (0.003, 512) else v - 0.01,
                             "rounds_executed": 60, "selected_round": 40, "cfg.train.rounds_max": 100,
                             "stop_reason": "early_stopping"})
    return pd.DataFrame(rows)


def _sel(dsets):
    return {ds: {"T1_central": {"train": {"lr": 0.003, "batch_size": 512}}} for ds in dsets}


def test_sanity_gate_reference_values_and_threshold():
    g = GATES["sanity_gate"]
    assert {k: v["value"] for k, v in g["published_transe_mrr"].items()} == {"fb15k237": 0.313, "wn18rr": 0.228,
                                                                               "codex_m": 0.303}
    plan = (PKG.parent / "audit" / "phaseB" / "05_privacy_utility_plan.md").read_text()
    for v in ("0.313", "0.228", "0.303"):
        assert v in plan                                              # the Phase B source of the reference values
    assert g["ratio"] == pytest.approx(2 / 3) and g["enforce_on_tiers"] == ["tune"] and g["on_failure"] == "stop"


def test_sanity_gate_pass_fail_and_report(tmp_path):
    from fedkge.gates import sanity_gate, write_gate_report
    runs = _t1c_runs({"fb15k237": 0.25, "wn18rr": 0.10})             # 0.25 >= 0.2087 passes; 0.10 < 0.152 fails
    res = sanity_gate(runs, _sel(["fb15k237", "wn18rr"]), GATES["sanity_gate"], "tune", ["fb15k237", "wn18rr"])
    assert res["enforced"] and not res["all_passed"]
    assert res["datasets"]["fb15k237"]["status"] == "PASSED" and res["datasets"]["wn18rr"]["status"] == "FAILED"
    assert res["datasets"]["fb15k237"]["threshold"] == pytest.approx(0.313 * 2 / 3)
    files = write_gate_report(res, tmp_path / "gates")
    md = files["md"].read_text()
    assert "Stage 3 has stopped" in md and "Do not lower the ratio" in md and "Recovery" in md
    ok = sanity_gate(_t1c_runs({"codex_m": 0.30}), _sel(["codex_m"]), GATES["sanity_gate"], "tune", ["codex_m"])
    write_gate_report(ok, tmp_path / "gates")                         # a later session adds a dataset
    merged = read_json(tmp_path / "gates" / "sanity_gate.json")
    assert set(merged["datasets"]) == {"fb15k237", "wn18rr", "codex_m"} and not merged["all_recorded_passed"]
    smoke = sanity_gate(runs, _sel(["wn18rr"]), GATES["sanity_gate"], "smoke", ["wn18rr"])
    assert smoke["enforced"] is False                                   # smoke: recorded, never enforced


def test_sanity_gate_missing_runs_never_pass():
    from fedkge.gates import sanity_gate
    res = sanity_gate(_t1c_runs({"fb15k237": 0.3}), _sel(["fb15k237"]), GATES["sanity_gate"], "tune",
                      ["fb15k237", "codex_m"])
    assert res["datasets"]["codex_m"]["status"] == "MISSING_RUNS_OR_SELECTION" and not res["all_passed"]


def test_d10_trigger_is_a_flag_only():
    from fedkge.gates import d10_trigger
    cfg = GATES["d10_trigger"]
    assert cfg["threshold"] == 0.25 and cfg["action"] == "flag_only" and cfg["dataset"] == "fb15k237"
    rows = [{"block": "T1F", "dataset": "fb15k237", "run_id": "np", "val.mrr": 0.20, "cfg.dp.enabled": False,
             "cfg.dp.target_epsilon": 4.0}]
    rows += [{"block": b, "dataset": "fb15k237", "run_id": f"dp{i}", "val.mrr": v, "cfg.dp.enabled": True,
              "cfg.dp.target_epsilon": 4.0} for i, (b, v) in enumerate([("T2a", 0.02), ("T3", 0.04)])]
    res = d10_trigger(pd.DataFrame(rows), cfg, "tune")
    assert res["triggered"] and res["r"] == pytest.approx(0.2) and res["numerator"]["run_id"] == "dp1"
    assert res["consequence"].startswith("none") and "nothing was changed" in res["label"]
    rows[2]["val.mrr"] = 0.06
    assert d10_trigger(pd.DataFrame(rows), cfg, "tune")["triggered"] is False
    assert d10_trigger(pd.DataFrame(rows), {**cfg, "dataset": "wn18rr"}, "tune")["status"] == "NOT_EVALUATED"


def test_environment_lock_records_then_refuses(tmp_path, monkeypatch):
    import fedkge.gates as G
    sig = {"device_type": "cuda", "gpu_name": "Tesla T4", "torch": "2.11.0+cu130", "cuda": "13.0", "python_minor": "3.13"}
    monkeypatch.setattr(G, "environment_signature", lambda device=None: dict(sig))
    p = Paths(tmp_path, "final")
    G.check_environment_lock(p, ["fb15k237", "wn18rr"], "cuda", GATES["environment_lock"])
    G.check_environment_lock(p, ["fb15k237"], "cuda", GATES["environment_lock"])             # same: fine
    sig["gpu_name"] = "NVIDIA L4"
    with pytest.raises(G.EnvironmentMismatch, match="gpu_name"):
        G.check_environment_lock(p, ["wn18rr"], "cuda", GATES["environment_lock"])
    G.check_environment_lock(p, ["codex_m"], "cuda", GATES["environment_lock"])              # a new dataset may start
    lock = read_json(tmp_path / "final" / "ENVIRONMENT_LOCK.json")
    assert lock["datasets"]["codex_m"]["signature"]["gpu_name"] == "NVIDIA L4"
    assert lock["datasets"]["fb15k237"]["signature"]["gpu_name"] == "Tesla T4"
    out = G.check_environment_lock(Paths(tmp_path, "smoke"), ["wn18rr"], "cuda", GATES["environment_lock"])
    assert out["enforced"] is False


# ============================================================================================== frozen manifest
def test_frozen_manifest_counts_equal_the_approved_budget():
    from fedkge.manifest import load_frozen
    m = load_frozen(CONFIG_DIR)
    p = m["plans"]
    assert (p["tune"]["cells"], p["tune"]["unique_runs"]) == (114, 99)
    assert (p["main"]["cells"], p["main"]["unique_runs"], p["main"]["unique_runs_if_fixed_schedule_selected"]) == \
        (756, 756, 726)
    assert (p["legacy"]["cells"], p["legacy"]["unique_runs"]) == (30, 30)
    assert m["approved_budget"]["total_runs"] == 99 + 756 + 30 == 885
    df = pd.DataFrame(m["cells"])
    assert df["cell_id"].is_unique and df["cell_key"].is_unique
    assert df[df["plan"] == "main"].groupby("priority").size().to_dict() == {1: 75, 2: 210, 3: 60, 5: 15, 6: 252,
                                                                            7: 144}
    assert set(df[df["plan"] == "legacy"]["priority"]) == {4} and set(df[df["plan"] == "tune"]["priority"]) == {0}
    assert set(df[(df["plan"] == "main") & (df["priority"] == 3)]["block"]) == {"M1"}     # RC-12: H3 before 4-7
    assert not df["block"].str.match(r"^X\d").any()                    # Stage 5 is deferred (B2)
    fixed = df[df["run_id"].notna()]
    assert set(fixed["plan"]) >= {"legacy", "tune"} and fixed["run_id"].is_unique


def test_frozen_manifest_matches_the_current_configs_and_code():
    from fedkge.manifest import verify_frozen
    verify_frozen(CONFIG_DIR)


def test_manifest_detects_a_changed_matrix(tmp_path):
    from fedkge.manifest import verify_frozen
    cfg = tmp_path / "10_configs"
    shutil.copytree(CONFIG_DIR, cfg)
    p = cfg / "matrices" / "confirm.yaml"
    p.write_text(p.read_text().replace("trimmed_mean, median, krum, fltrust]}}", "trimmed_mean, median, krum]}}", 1))
    with pytest.raises(IntegrityError):
        verify_frozen(cfg)


def test_expanded_entries_must_equal_manifest_cells(tmp_path):
    from fedkge.manifest import _placeholder_selection, check_entries_against_manifest, load_frozen
    from fedkge.runner import expand
    m = load_frozen(CONFIG_DIR)
    d = tmp_path / "final" / "selection"; d.mkdir(parents=True)
    (d / "tuning.json").write_text(json.dumps(_placeholder_selection(False)))
    e = expand("final", CONFIG_DIR, Paths(tmp_path, "final"), "final", ["fb15k237"], [4], profile="reduced",
               matrix_name="confirm")
    info = check_entries_against_manifest(e, m, "main")
    assert info["n_entries"] == 252
    with pytest.raises(IntegrityError, match="missing"):
        check_entries_against_manifest(e[:-1], m, "main")
    bogus = dict(e[0]); bogus["name"] = "not_a_cell"
    with pytest.raises(IntegrityError, match="extra"):
        check_entries_against_manifest(e + [bogus], m, "main")


def test_progress_is_derived_from_run_folders(tmp_path):
    from fedkge.io import code_hash
    from fedkge.manifest import load_frozen, progress
    m = load_frozen(CONFIG_DIR)
    leg = [c for c in m["cells"] if c["plan"] == "legacy"][:4]
    p = Paths(tmp_path, "final")
    for c, st in zip(leg, ["COMPLETE", "RUNNING", "FAILED", "COMPLETE"]):
        d = p.run(c["run_id"]); d.mkdir(parents=True)
        (d / "status.json").write_text(json.dumps({"status": st, "code_hash": code_hash()}))
    (p.run(leg[0]["run_id"]) / "final.json").write_text("{}")         # the 4th has no final.json
    df = progress(tmp_path, m, ["legacy"]).set_index("cell_id")
    got = [df.loc[c["cell_id"], "status"] for c in leg]
    assert got == ["COMPLETE", "INCOMPLETE", "FAILED", "INCOMPLETE"]
    assert (df["status"] == "NOT_STARTED").sum() == 30 - 4
    tune = progress(tmp_path, m, ["tune"])
    assert set(tune[tune["block"] == "TAU"]["status"]) == {"WAITING_FOR_SELECTIONS"}


# ============================================================================================== session safety
def test_deadline_leaves_runs_pending_never_complete(synthetic_paths):
    import time
    from fedkge.config import run_id
    from fedkge.runner import run_entries
    cfg = synthetic_base_cfg(train={"rounds_max": 2, "lr": 0.0123})
    e = [{"run_id": run_id(cfg), "block": "TEST", "dataset": "synthetic", "seed": 42, "name": "t", "cfg": cfg}]
    st = run_entries(e, synthetic_paths, "cpu", deadline=time.time() - 1)
    assert list(st["status"]) == ["PENDING"] and not synthetic_paths.run(run_id(cfg)).exists()


def test_interrupted_run_resumes_from_checkpoint_identically(synthetic_paths, monkeypatch):
    """A failure in round 7 leaves the round-5 checkpoint; the retry resumes there, keeps the earlier traceback, and
    gives exactly the result of an uninterrupted run (CPU)."""
    import fedkge.federated as F
    from fedkge.config import run_id
    over = dict(train={"rounds_max": 8, "ckpt_every": 5, "eval_every": 2, "lr": 0.0077})
    ref_cfg = synthetic_base_cfg(**over)
    ref = F.run_experiment(ref_cfg, synthetic_paths, "cpu", force=True)
    d = synthetic_paths.run(run_id(ref_cfg))
    shutil.move(str(d), str(d.with_name(d.name + "_reference")))
    real, calls = F.local_train, {"n": 0}

    def flaky(*a, **k):
        calls["n"] += 1
        if calls["n"] == 6 * 10 + 5:                                    # inside round 7 (10 clients per round)
            raise RuntimeError("simulated disconnect")
        return real(*a, **k)
    monkeypatch.setattr(F, "local_train", flaky)
    with pytest.raises(RuntimeError, match="simulated"):
        F.run_experiment(ref_cfg, synthetic_paths, "cpu")
    st = read_json(d / "status.json")
    assert st["status"] == "FAILED" and (d / "checkpoint.pt").exists() and not (d / "final.json").exists()
    monkeypatch.setattr(F, "local_train", real)
    fin = F.run_experiment(ref_cfg, synthetic_paths, "cpu")
    st = read_json(d / "status.json")
    assert st["status"] == "COMPLETE" and st["attempt"] == 2 and (d / "error_attempt1.txt").exists()
    assert "resumed from round 5" in (d / "log.txt").read_text()
    assert fin["val"]["mrr"] == ref["val"]["mrr"] and fin["test"]["mrr"] == ref["test"]["mrr"]
    assert fin["rounds_executed"] == ref["rounds_executed"] == 8


def test_atomic_checkpoint_write_keeps_the_previous_file(tmp_path, monkeypatch):
    import torch
    from fedkge.io import atomic_torch_save
    p = tmp_path / "checkpoint.pt"
    atomic_torch_save({"round": 5}, p)
    real = torch.save

    def broken(obj, f, *a, **k):
        Path(f).write_bytes(b"half")
        raise OSError("disk full")
    monkeypatch.setattr(torch, "save", broken)
    with pytest.raises(OSError):
        atomic_torch_save({"round": 10}, p)
    monkeypatch.setattr(torch, "save", real)
    assert torch.load(p, weights_only=True) == {"round": 5}
    assert sorted(x.name for x in tmp_path.iterdir()) == ["checkpoint.pt"]       # no temporary file left


def test_run_plan_refuses_stage5_and_full_profile():
    import subprocess
    import sys
    base = [sys.executable, str(PKG / "scripts" / "run_plan.py"), "--plan", "confirm", "--tier", "final",
            "--datasets", "fb15k237"]
    r = subprocess.run(base + ["--stages", "5"], capture_output=True, text=True)
    assert r.returncode == 2 and "deferred" in r.stderr
    r = subprocess.run(base + ["--profile", "full"], capture_output=True, text=True)
    assert r.returncode == 2 and "reduced" in r.stderr


def test_freeze_is_gated_append_only_and_per_dataset(tmp_path):
    """G-C: refused without gate G-B; a dataset still in Stage 3 is skipped; later datasets are appended; a frozen
    dataset can never change."""
    import subprocess
    import sys
    from fedkge.manifest import _placeholder_selection
    sel = _placeholder_selection(False)
    del sel["wn18rr"]["tau"]                                            # wn18rr: Stage 3 not finished
    del sel["codex_m"]
    (tmp_path / "tune" / "selection").mkdir(parents=True)
    (tmp_path / "tune" / "gates").mkdir(parents=True)
    sp, gp = tmp_path / "tune" / "selection" / "tuning.json", tmp_path / "tune" / "gates" / "sanity_gate.json"
    for ds in ("fb15k237", "wn18rr"):
        sel[ds]["tau"] = sel[ds].get("tau")
    sel["fb15k237"]["tau"] = {"aggregation": {"tau": 3.0}, "rule_met": True, "status": "RULE_MET", "label": "met"}
    sel["wn18rr"].pop("tau")
    sp.write_text(json.dumps(sel))
    run = lambda: subprocess.run([sys.executable, str(PKG / "scripts" / "freeze_selections.py"), "--results",
                                  str(tmp_path)], capture_output=True, text=True)
    gp.write_text(json.dumps({"datasets": {"fb15k237": {"status": "FAILED", "passed": False}}}))
    r = run()
    assert r.returncode != 0 and "gate G-B has not passed" in (r.stdout + r.stderr)
    gp.write_text(json.dumps({"datasets": {"fb15k237": {"status": "PASSED", "passed": True},
                                           "wn18rr": {"status": "PASSED", "passed": True}}}))
    r = run()
    assert r.returncode == 0, r.stdout + r.stderr
    fz = read_json(tmp_path / "final" / "selection" / "tuning.json")
    assert "fb15k237" in fz and "wn18rr" not in fz
    sel["wn18rr"]["tau"] = {"aggregation": {"tau": 5.0}, "rule_met": False, "status": "RULE_NOT_MET_LARGEST_GRID_TAU",
                            "label": "not met"}
    sp.write_text(json.dumps(sel))
    assert run().returncode == 0
    fz = read_json(tmp_path / "final" / "selection" / "tuning.json")
    assert fz["fb15k237"]["tau"]["aggregation"]["tau"] == 3.0 and fz["wn18rr"]["tau"]["aggregation"]["tau"] == 5.0
    assert read_json(tmp_path / "final" / "selection" / "FROZEN.json")["tau"]["wn18rr"]["status"].startswith("RULE_NOT")
    sel["fb15k237"]["T2a"]["dp"]["q"] = 0.1                              # a frozen value may never change
    sp.write_text(json.dumps(sel))
    r = run()
    assert r.returncode != 0 and "DIFFERENT frozen selection" in (r.stdout + r.stderr)
