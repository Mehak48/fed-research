#!/usr/bin/env python3
"""Run this worker's whole queue (phase 03's QUEUE_<worker>.json), in order, within one session budget.

  python parallel/phases/run_worker_queue.py --base B --worker W --max-hours 10.5 [--wait-minutes 0]

For each job: skipped if this worker already finished it (receipt with exit 0); skipped for now if it waits for a
release pack (the next job is tried instead); otherwise run (phase 04 / 06 / 07 logic) and bundled. Stops at the
session budget (EXIT 3: run the same command in the next session), and at an environment, manifest or contract
problem (EXIT 5 / 6 / 7: fix it first). --wait-minutes N keeps polling for releases for up to N minutes when only
waiting jobs are left (useful when the master runs in another session on the same shared folder).
"""
from __future__ import annotations

import sys
import time

from _cli import finish, layout, parser

from fedkge_parallel.common import (EXIT_BUDGET, EXIT_CONTRACT, EXIT_ENV, EXIT_FAILED, EXIT_MANIFEST, EXIT_OK,
                                    read_json, read_json_or)
from fedkge_parallel.execute import job_spec_for, run_worker_job


def main(argv=None) -> int:
    ap = parser(__doc__, worker=True, gpu=True)
    ap.add_argument("--wait-minutes", type=float, default=0.0)
    ap.add_argument("--jobs", nargs="*", help="run these jobs instead of the planned queue")
    a = ap.parse_args(argv)
    L = layout(a)
    t0 = time.time()
    qf = L.plan_dir / f"QUEUE_{a.worker}.json"
    queue = a.jobs or (read_json(qf)["jobs"] if qf.exists() else [])
    if not queue:
        print(f"no queue for {a.worker} ({qf}); run phase 03 on the master, or give --jobs"); return finish(EXIT_CONTRACT)
    receipts = L.worker(a.worker) / "parallel" / "receipts"
    failed_any = False
    while True:
        waiting = []
        for jid in queue:
            r = read_json_or(receipts / f"{jid}.json", None)
            if r and r["exit_code"] == EXIT_OK:
                continue
            left = None if a.max_hours is None else a.max_hours - (time.time() - t0) / 3600
            if left is not None and left <= 0.02:
                print("session budget used up"); return finish(EXIT_BUDGET)
            try:
                job_spec_for(L, jid)
            except SystemExit as e:
                waiting.append(jid); print(f"{jid}: not startable yet - {e}"); continue
            code = run_worker_job(L, a.worker, jid, a.device, left, a.max_runs)
            if code == EXIT_BUDGET:
                return finish(EXIT_BUDGET)
            if code in (EXIT_ENV, EXIT_MANIFEST, EXIT_CONTRACT):
                return finish(code)
            failed_any |= code == EXIT_FAILED
        if not waiting:
            return finish(EXIT_FAILED if failed_any else EXIT_OK)
        if (time.time() - t0) / 60 >= a.wait_minutes:
            print(f"jobs waiting for a release: {waiting}. Run the master steps (phase 08 + 05), then this command again.")
            return finish(EXIT_BUDGET)
        time.sleep(300)


if __name__ == "__main__":
    sys.exit(main())
