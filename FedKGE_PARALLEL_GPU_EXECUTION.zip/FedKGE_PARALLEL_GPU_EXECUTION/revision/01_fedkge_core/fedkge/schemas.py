"""JSON-schema validation of pipeline outputs against 11_experiment_schemas/*.schema.json.
Notebooks call validate_file(...) in their validation cells; the test suite validates the offline outputs."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

import jsonschema


def load_schema(schema_dir: Path, name: str) -> Dict[str, Any]:
    p = Path(schema_dir) / f"{name}.schema.json"
    if not p.exists():
        raise FileNotFoundError(f"schema missing: {p}")
    return json.loads(p.read_text())


def validate_obj(obj: Any, schema_dir: Path, name: str) -> None:
    jsonschema.validate(obj, load_schema(schema_dir, name))


def validate_file(path: Path, schema_dir: Path, name: str) -> None:
    validate_obj(json.loads(Path(path).read_text()), schema_dir, name)


def validate_rounds_csv(path: Path, schema_dir: Path, dp: bool) -> None:
    import pandas as pd
    spec = load_schema(schema_dir, "rounds_csv")
    cols = set(pd.read_csv(path).columns)
    need = set(spec["required_columns"]) | (set(spec["required_columns_dp"]) if dp else set())
    missing = need - cols
    if missing:
        raise jsonschema.ValidationError(f"{path}: missing columns {sorted(missing)}")


def validate_csv_columns(path: Path, schema_dir: Path, name: str, groups=()) -> None:
    """Column check of a CSV output against <name>.schema.json: 'required_columns' plus every listed group
    'required_columns_<group>' (Phase C: trust_rounds.csv with group 'proposed' for the proposed aggregator)."""
    import pandas as pd
    spec = load_schema(schema_dir, name)
    cols = set(pd.read_csv(path).columns)
    need = set(spec["required_columns"])
    for g in groups:
        need |= set(spec[f"required_columns_{g}"])
    missing = need - cols
    if missing:
        raise jsonschema.ValidationError(f"{path}: missing columns {sorted(missing)}")
    banned = set(spec.get("forbidden_columns", [])) & cols
    if banned:
        raise jsonschema.ValidationError(f"{path}: columns of a removed design are present: {sorted(banned)}")


def validate_run_dir(run_dir: Path, schema_dir: Path) -> list:
    """Validate every known output of one run directory. Returns the list of (file, schema) checked; raises
    jsonschema.ValidationError on the first violation. Phase C: also integrity, attack, MIA and trust outputs."""
    run_dir, checked = Path(run_dir), []
    cfg = json.loads((run_dir / "config.json").read_text())
    for fname, schema in (("config.json", "run_config"), ("final.json", "final"), ("accountant.json", "accountant"),
                          ("integrity.json", "integrity"), ("attack.json", "attack"), ("mia.json", "mia")):
        if (run_dir / fname).exists():
            validate_file(run_dir / fname, schema_dir, schema)
            checked.append((fname, schema))
    validate_rounds_csv(run_dir / "rounds.csv", schema_dir, bool(cfg["dp"]["enabled"]))
    checked.append(("rounds.csv", "rounds_csv"))
    if (run_dir / "trust_rounds.csv").exists():
        groups = ("proposed",) if cfg["aggregation"]["method"] == "proposed" else ()
        validate_csv_columns(run_dir / "trust_rounds.csv", schema_dir, "trust_rounds_csv", groups)
        checked.append(("trust_rounds.csv", "trust_rounds_csv"))
    return checked
