"""Shared fixtures. The offline pipeline fixture executes P1 -> P2 -> P3 -> P4 (all stages + DP selections) on the
synthetic dataset with the 'offline' tier (CPU, ~2-3 minutes) - the same code path the notebooks use."""
import shutil
import sys
from pathlib import Path

import pytest

PKG = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PKG / "01_fedkge_core"))
CONFIG_DIR = PKG / "10_configs"
SCHEMA_DIR = PKG / "11_experiment_schemas"


def run_offline_pipeline(root: Path):
    from fedkge.analysis import collect
    from fedkge.config import load_yaml
    from fedkge.data import build_artifact, load_artifact
    from fedkge.io import Paths
    from fedkge.partition import build_partition
    from fedkge.runner import expand, partition_specs_needed, run_entries, write_index
    from fedkge import selection as S
    paths = Paths(root, "smoke")
    build_artifact(load_yaml(CONFIG_DIR / "datasets" / "synthetic.yaml"), paths.p1("synthetic"))
    data = load_artifact(paths.p1("synthetic"))
    for spec in partition_specs_needed(CONFIG_DIR, "smoke", "offline")["synthetic"]:
        build_partition(data.train, data.num_relations, spec, 42, paths.p2("synthetic"), data.content_hash)
    rules = load_yaml(CONFIG_DIR / "selection_rules.yaml")

    def go(phase, stages):
        e = expand(phase, CONFIG_DIR, paths, "smoke", stages=stages, tier_file="offline")
        write_index(paths, phase, e)
        st = run_entries(e, paths, "cpu", stop_on_error=True)
        assert set(st["status"]) <= {"COMPLETE", "COMPLETE(existing)"}
        return e
    go("p3", [1]); go("p4", [1])
    S.select_clip(collect(paths, ["p4"])[0], rules, [42], paths)
    go("p4", [2])
    S.select_schedule(collect(paths, ["p4"])[0], rules, [42], paths)
    go("p4", [3])
    return paths


@pytest.fixture(scope="session")
def offline(tmp_path_factory):
    root = tmp_path_factory.mktemp("results")
    return run_offline_pipeline(root)


# ----------------------------------------------------------------------------------------------- Phase C fixtures
def synthetic_base_cfg(**over):
    """A fully resolved offline run config (synthetic data, tiny model) for Phase C integration tests."""
    import copy
    from fedkge.config import deep_merge, load_yaml
    base = load_yaml(CONFIG_DIR / "base.yaml")
    tier = load_yaml(CONFIG_DIR / "tiers" / "offline.yaml")
    cfg = deep_merge(base, tier["run_overrides"])
    cfg.update({"tier": "smoke", "phase": "phasec_test", "seed": 42, "block": "TEST", "name": "t"})
    cfg["dataset"] = {"name": "synthetic"}
    cfg["train"].update({"rounds_max": 3, "eval_every": 1})
    return deep_merge(cfg, over)


@pytest.fixture(scope="session")
def synthetic_paths(tmp_path_factory):
    """P1 + P2 artifacts for the synthetic dataset (Dirichlet 0.1 and IID, seed 42) in a fresh results root."""
    from fedkge.config import load_yaml
    from fedkge.data import build_artifact, load_artifact
    from fedkge.io import Paths
    from fedkge.partition import build_partition
    root = tmp_path_factory.mktemp("phasec_results")
    paths = Paths(root, "smoke")
    build_artifact(load_yaml(CONFIG_DIR / "datasets" / "synthetic.yaml"), paths.p1("synthetic"))
    data = load_artifact(paths.p1("synthetic"))
    cfg = synthetic_base_cfg()
    for spec in ({**cfg["partition"]}, {**cfg["partition"], "scheme": "iid"}):
        for seed in (42, 43):
            build_partition(data.train, data.num_relations, spec, seed, paths.p2("synthetic"), data.content_hash)
    return paths


@pytest.fixture
def run_cfg(synthetic_paths):
    """run_cfg(**overrides) -> (final, run_dir) for one synthetic run (CPU)."""
    from fedkge.config import deep_merge
    from fedkge.federated import run_experiment
    from fedkge.config import run_id

    def go(force=True, **over):
        cfg = synthetic_base_cfg(**over)
        fin = run_experiment(cfg, synthetic_paths, "cpu", force=force)
        return fin, synthetic_paths.run(run_id(cfg))
    return go


@pytest.fixture
def offline_round(run_cfg):
    import pandas as pd
    from fedkge.io import read_json

    def go(mode="hash_only", corrupt_p=0.0, **over):
        fin, d = run_cfg(integrity={"mode": mode, "corrupt_p": corrupt_p}, **over)
        return read_json(d / "integrity.json"), pd.read_csv(d / "rounds.csv"), pd.read_csv(d / "weights_rounds.csv")
    return go


@pytest.fixture
def offline_capture(run_cfg, monkeypatch):
    """Instrument one run: capture every matrix given to aggregate() and the bytes accepted by the server."""
    import fedkge.federated as F
    from fedkge.integrity import IntegrityLayer
    captured, round_blobs = [], []

    class Recording(IntegrityLayer):
        def _fetch(self, env):
            data, corrupted = super()._fetch(env)
            self._last_bytes = data                      # exactly the bytes that go through verification
            return data, corrupted

        def receive(self, env, receiver, device=None):
            got, rec = super().receive(env, receiver, device)
            if rec.accepted and receiver == "server":
                round_blobs.append((int(env.name[6:]), self._last_bytes))
            return got, rec

    real = F.aggregate

    def spy(method, U, *a, **k):
        blobs = [b for _, b in sorted(round_blobs)]
        captured.append((U.detach().clone(), blobs))
        round_blobs.clear()
        return real(method, U, *a, **k)
    monkeypatch.setattr(F, "IntegrityLayer", Recording)
    monkeypatch.setattr(F, "aggregate", spy)

    def go(**over):
        run_cfg(**over)
        return captured
    return go
