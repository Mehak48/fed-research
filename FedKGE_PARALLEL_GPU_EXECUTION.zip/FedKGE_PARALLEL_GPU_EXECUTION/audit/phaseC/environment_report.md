# Phase C — environment report

**Date:** 2026-11-02, updated 2026-11-04 with the owner's Colab GPU session · Every value here was checked or measured, unless it is marked otherwise. The 2026-11-02 version is kept in `_versions/2026-11-02/`.

## 1. Where Phase C ran

**Hardware and system:**

| Item | Value |
|---|---|
| Machine | Cloud container: 2 CPU cores, 7.8 GB RAM, **no GPU**; Linux x86_64 |
| Python | 3.13.18, in a project virtual environment (`.venv`) |
| Disk | About 22 GB free; the venv uses 5.3 GB (the CUDA runtime wheels that PyPI's torch pulls in) |

**Packages** (`revision/requirements-phaseC.txt`):

| Package | Version |
|---|---|
| torch | 2.14.1 (CUDA 13 build, used on CPU) |
| numpy | 2.5.3 |
| scipy | 1.18.1 |
| pandas | 3.0.5 |
| PyYAML | 6.0.3 |
| jsonschema | 4.26.0 |
| matplotlib | 3.11.2 |
| dp-accounting | 0.6.0 |
| prv-accountant | 0.2.0 |
| opacus | 1.6.0 (tests only) |
| pytest | 9.1.1 |

**Network:**

| Destination | Result |
|---|---|
| PyPI | works |
| download.pytorch.org | blocked, so torch came from PyPI. The install took 29 minutes |
| GitHub API | 403 |
| raw.githubusercontent.com | works; the datasets came from there |
| Microsoft's FB15k-237 page | blocked; the official zip was not fetched, the ConvE copy was used instead (§4) |

**The environment was checked before installing.** Phase A could not run the 26 PyTorch-dependent tests here. After the install they run, and every one passes.

## 2. What could and could not run here

| Work | Status here |
|---|---|
| Unit, integration, regression, reproducibility, failure-path and PyTorch tests | ran (`test_report.md`) |
| Privacy-accounting validation (96 points × 5 methods) | ran twice, 0 failed checks |
| Dataset download, after the owner's licence confirmation | ran |
| Artifacts, partition audit, acceptance rates | ran on the full data and on the smoke subsets |
| Smoke runs on the real data (11 profiles × 3 datasets) | ran: 33 of 33 complete |
| Every block in smoke on the real data (tuning chain + all 28 confirmatory blocks) | ran: 421 runs, 0 failures (gate G-A) |
| Final test suite | 131 passed on 2026-11-02; **133 passed, 0 failed, 0 errors, 0 skipped** on the final code (2026-11-04, after fix PC-6) |
| Legacy replica blocks L1–L4 in smoke (real FB15k-237 subset) | ran on 2026-11-04: 6 of 6 complete |
| L0 (legacy checkpoint under the corrected protocol) | ran |
| Measured pilot on the full data | ran **on CPU** (`pilot_plan.md` §2). Upper-bound timings |
| GPU smoke and GPU pilot | ran on the **owner's Colab T4** on 2026-11-04 (§3) |
| Tuning (Stage 3), confirmatory runs (Stage 4) | **not possible here.** One private FedAvg round on FB15k-237 takes about 45–80 s on these 2 cores, so one 100-round private run takes about 1.3–2.3 hours. The reduced core plan would take about 870 CPU-hours |

## 3. The owner's GPU environment: free Google Colab (stated 2026-11-02; measured 2026-11-04)

**Measured in the session of 2026-11-04** (`results/phaseC/colab/session_20261104T163226Z/`):

| Item | Value |
|---|---|
| GPU | **Tesla T4** (a 16 GB card). Peak allocated memory per run: 0.2–1.35 GB |
| torch / CUDA | **2.11.0+cu130 / 13.0**: Colab's preinstalled build, not reinstalled |
| Python | **3.13.16** |
| Other packages | Pinned (`requirements-colab.txt`); the exact list is `colab_pip_freeze.txt` |
| Host memory per run | 1.5–1.8 GB peak RSS |
| Session | Started 16:32:26Z, packaged 16:55:53Z (about 24 minutes, including one extra pilot run). No disconnect |
| Code | Kit zip SHA-256 `4fb27cf8…`, verified by the notebook; core code hash `94105bac…`, the same as the local runs of 2026-11-02 |
| Data | Downloaded on Colab with the recorded licence note. Split counts equal the official counts. Every P1 content hash and P2 partition hash equals the local build |

**General conditions (not measured):**

| Item | Detail |
|---|---|
| GPU type | Not guaranteed; Colab may assign none when its unpublished quota is exhausted |
| Session limits | Free sessions last up to about 12 hours and disconnect after idling. Daily GPU time varies and is not published |
| Storage | Google Drive; Colab's local disk is wiped at disconnect. All results must be written to Drive (the kit does this) |

**Consequences for the plan:**

- All runs that are compared with each other must use one environment (GPU type and torch version), recorded with them. Mixing Colab torch versions or GPU types inside a block would add an uncontrolled factor.
- **Colab can update its image during a multi-week campaign.** The Stage 3 kit will record the environment at the start of every session and refuse to continue a dataset's stage in a different one.
- **The run identity does not include the device.** A CPU run and a GPU run of one configuration share a `run_id`, so CPU and GPU results must live in separate results roots (`remaining_blockers.md` B16).
- The code hash in every run (`code_hash`) identifies the exact core code. The Colab kit also checks the SHA-256 of the code zip before it runs anything.

## 4. Datasets: sources, licences, verification (measured 2026-11-02)

**The licence check:**

- The owner confirmed research use of all three datasets on 2026-11-02, in an in-app answer: "Yes, all three".
- She was shown the terms first.
- Her confirmation is stored in every `source_manifest.json` (`operator_note`).
- Dataset files live outside the repository (`data_cache/`) and are never put into any deliverable.

**Sources and licences:**

| Dataset | Source (pinned) | Licence found | Official split counts | Downloaded counts |
|---|---|---|---|---|
| FB15k-237 | ConvE repo `f3c0eb28…` `FB15k-237.tar.gz` | Microsoft page states none. Freebase-derived (Freebase dumps CC BY 2.5, attribution). ClueWeb mentions not used | 272,115 / 17,535 / 20,466 | **identical** |
| WN18RR | ConvE repo `f3c0eb28…` `WN18RR.tar.gz` | WordNet licence (notice kept); repo code MIT | 86,835 / 3,034 / 3,134 | **identical** |
| CoDEx-M | CoDEx repo `3132e426…` `data/triples/codex-m/*.txt` | Repo MIT; triples from Wikidata (CC0) | 185,584 / 10,310 / 10,311 | **identical** |

**Measured statistics after loading:**

- The loader uses PyKEEN-identical ids: the vocabulary is the training split.
- Evaluation triples with entities unseen in training are dropped and counted.

| Dataset | Entities (train / all splits) | Relations | Valid kept (dropped) | Test kept (dropped) | Duplicates and split overlaps | Test triples whose reverse pair is in train | Relations with < 10 train triples |
|---|---|---|---|---|---|---|---|
| FB15k-237 | 14,505 / 14,541 | 237 | 17,526 (9) | 20,438 (28) | 0 | 0.0 % | 0 |
| WN18RR | 40,559 / 40,943 | 11 | 2,824 (210) | 2,924 (210) | 0 | 37.4 % | 0 |
| CoDEx-M | 17,050 / 17,050 | 51 | 10,310 (0) | 10,311 (0) | 0 | 3.5 % | 6 |

**Notes:**

- **FB15k-237 counts** equal PyKEEN's published statistics (14,505 entities; 17,526 / 20,438 evaluation triples).
- **WN18RR evaluation choice:**
  - WN18RR loses 210 validation and 210 test triples (6.7 %) because they contain entities never seen in training.
  - Some papers evaluate all 3,134 test triples instead, giving unseen entities random embeddings.
  - The choice changes absolute MRR comparisons with prior work and must be stated in the paper.
- **WN18RR reverse pairs:** the 37.4 % comes from WN18RR's symmetric relations. It is a known property of the benchmark, not a leak.
- **No benchmark split was altered.** V_sel / V_root are a fixed 80 / 20 split of the official validation set (seed 0).

## 5. Partition feasibility on the real relation counts (gate G15 resolved)

**The rule:** every client must get ≥ max(1024, 20 % of the mean client size) triples. The table gives the acceptance rate over 2,000 fresh Dirichlet draws per (dataset, α), measured on the full training splits.

| Dataset | α = 0.1 | α = 0.5 | α = 1.0 | Attempts used for the accepted seed-1001 partition (α = 0.1) |
|---|---|---|---|---|
| FB15k-237 | 100 % | 100 % | 100 % | 1 |
| WN18RR | **3.1 %** | 72.5 % | 97.3 % | 6 |
| CoDEx-M | 67.1 % | 100 % | 100 % | 1 |

**WN18RR at α = 0.1:**

- **It is feasible**, so the pre-approved fallback (relax the size rule to 10 % for that dataset) is **not** triggered.
- **But it is a heavily truncated Dirichlet:** only about 3 % of draws qualify. The Phase B planning value was 3.75 %, estimated from unverified counts.
- **This must be stated wherever WN18RR α = 0.1 results appear.**
- **Compare heterogeneity across datasets with the measured statistics** (`partition_audit_*.csv`: size Gini, largest share, Jensen–Shannon divergence), not with α alone.

## 6. How to set up the environment again

**Local (Linux, Python 3.13):**

```bash
python3.13 -m venv .venv && . .venv/bin/activate
pip install -r revision/requirements-phaseC.txt
cd revision && python scripts/run_tests.py --name local_check
```

**Free Colab (the owner's GPU):**

- Use `revision/colab/phaseC_pilot_colab.ipynb` together with `fedkge_code_phaseC.zip`. Its first cell explains the steps.
- It checks the code fingerprint and installs the pinned packages.
- It runs the tests, downloads the data with the recorded confirmation, runs a GPU smoke test, then runs the pilot.
- Finally it writes one results zip to Drive.

## 7. Known environment risks

- **The GPU code path has now executed:** 9 GPU smoke runs and 2 × 18 pilot runs on a T4, with 0 failures.
- **The torch version differs:** 2.11.0 on Colab, 2.14.1 here. The tests passed on Colab too (130 + 1 expected skip). Results from different environments are never mixed inside one comparison.
- **GPU determinism is not bitwise-tested.** Same seed twice on the T4 gave identical logged values to 4 decimals. CUDA's deterministic mode is not switched on (`remaining_blockers.md` B17).
- **A free Colab session can end without warning.** Results go straight to Drive, and every script resumes or reruns safely.
