"""FIXTURE results for SOFTWARE CHECKS of the analysis, table, figure and draft code - NEVER RESULTS.

The owner's final directive (section 6) asks that the reporting and figure code be verified against clearly labelled
fixture data. This module builds such a fixture: the real Stage-4 and legacy cells (expanded from the configs with
placeholder selections), each given RANDOM metric values drawn from a fixed seed. The fixture is labelled
'fixture' everywhere: tier name, file-name prefix FIXTURE_SYNTHETIC_NOT_RESULTS_, a banner on every table and a
watermark on every figure. Some cells are deliberately left out so that PENDING / MISSING_RUNS paths are exercised.
The fixture is built in memory and written only to an output folder chosen by the caller; it can never enter a results
root (it has no run folders, no status files and no code hash).
"""
from __future__ import annotations

import hashlib
import json
import tempfile
from pathlib import Path
from typing import Dict, Optional

import numpy as np
import pandas as pd

from .analysis import _flatten
from .config import load_yaml

FIXTURE_TIER = "fixture"
NOTE = "FIXTURE: random numbers for a software check - not results"
BASE_MRR = {"N1": 0.30, "N2": 0.26, "N3": 0.27, "DP1": 0.12, "DP2": 0.13, "DP3": 0.20, "R1": 0.12, "R1p": 0.125,
            "R1q": 0.12, "R2": 0.08, "R2a": 0.09, "R3": 0.11, "R3a": 0.10, "R4": 0.10, "R5": 0.24, "R5a": 0.22,
            "I1": 0.20, "I2": 0.12, "M1": 0.12, "R3_legacy": 0.20, "R3_fixed": 0.21, "R4_legacy": 0.01,
            "L1_legacy": 0.01, "L2_trainer_fixed": 0.03, "L3_accounting_fixed": 0.04}


def _stable(rid: str) -> int:
    return int(hashlib.sha256(rid.encode()).hexdigest()[:8], 16)


class FixtureContext:
    """Same attributes as context.ResultsContext, filled with labelled random numbers."""

    def __init__(self, config_dir: Path, project_root: Optional[Path] = None, seed: int = 20261105,
                 drop: Optional[Dict] = None):
        from .manifest import _expand_plan, _placeholder_selection, load_frozen
        self.tier, self.config_dir = FIXTURE_TIER, Path(config_dir)
        self.project_root = Path(project_root) if project_root else self.config_dir.parents[1]
        self.root = Path("<fixture: in memory, not a results root>")
        self.hyp = load_yaml(self.config_dir / "hypotheses.yaml")
        rng = np.random.default_rng(seed)
        drop = drop if drop is not None else {"M1": ["codex_m"]}      # exercise MISSING_RUNS on purpose
        rows = []
        with tempfile.TemporaryDirectory() as tmp:
            for tier in ("tune", "final"):
                d = Path(tmp) / tier / "selection"; d.mkdir(parents=True)
                (d / "tuning.json").write_text(json.dumps(_placeholder_selection(False)))
            entries = _expand_plan("main", self.config_dir, Path(tmp), False) + \
                _expand_plan("legacy", self.config_dir, Path(tmp), False)
        seen = set()
        for e in entries:
            if e["run_id"] in seen or e["dataset"] in drop.get(e["block"], []):
                continue
            seen.add(e["run_id"])
            cfg = e["cfg"]
            row = {"phase": e["phase"], "block": e["block"], "name": e["name"], "dataset": e["dataset"],
                   "seed": e["seed"], "run_id": "FIXTURE_" + e["run_id"]}
            _flatten("cfg.", {k: v for k, v in cfg.items() if k != "labels"}, row)
            dp = bool(cfg["dp"]["enabled"]) and cfg["dp"].get("mode") != "no_noise"
            eps_t = float(cfg["dp"]["target_epsilon"]) if dp else None
            base = BASE_MRR.get(e["block"], 0.1) * (1.0 if not dp else min(1.6, 0.7 + 0.12 * eps_t))
            mrr = float(max(0.002, base * (1 + rng.normal(0, 0.05)) + 0.004 * (e["seed"] % 7)))
            row.update({"test.mrr": mrr, "test.hits@1": mrr * 0.6, "test.hits@3": mrr * 1.1, "test.hits@10": mrr * 1.6,
                        "val.mrr": mrr * 1.02, "rounds_executed": 100 if dp else 45, "selected_round": 95 if dp else 30,
                        "runtime.total_s": float(rng.uniform(300, 700)), "runtime.per_round_s": float(rng.uniform(3, 6)),
                        "runtime.device": "cuda", "runtime.integrity_s": float(rng.uniform(40, 90)),
                        "runtime.local_training_s": float(rng.uniform(200, 500)),
                        "runtime.gpu_peak_allocated_mb": float(rng.uniform(200, 1300)),
                        "communication.bytes_up_total": 5.9e6 * 10 * 100,
                        "anomaly_scores.benign_fpr_at_cfg_tau": float(rng.uniform(0.0, 0.08)),
                        "targeted.target_hits@10": float(rng.uniform(0, 0.05))})
            for k in ("0", "1", "2"):
                row[f"anomaly_scores.benign_fpr_at_cfg_tau_by_size_third.{k}"] = float(rng.uniform(0, 0.1))
            if dp:
                row.update({"privacy.eps": eps_t * float(rng.uniform(0.97, 1.0)), "privacy.delta": 1e-6,
                            "privacy.eps_at.1e-05": eps_t * 0.85, "privacy.eps_pld": eps_t * 0.93,
                            "privacy.eps_prv_upper": eps_t * 0.94, "privacy.sigma0_worst": 3.0,
                            "privacy.q_worst": 0.05, "privacy.rounds_executed": 100, "privacy.budget_ok": True,
                            "privacy.sampling_design": cfg["dp"].get("sampling"), "privacy.clip": cfg["dp"].get("clip"),
                            "privacy.adjacency": "zero-out (fixture)", "privacy.delta_times_largest_size": 0.04})
            atk = cfg["attack"]["type"]
            if atk != "none":
                hit = 0.6 if cfg["aggregation"]["method"] == "proposed" else 0.0
                row.update({"attack.mean_tpr": hit + float(rng.uniform(0, 0.3)), "attack.mean_fpr": float(rng.uniform(0, 0.06)),
                            "attack.mean_malicious_weight_share": float(rng.uniform(0.0, 0.2))})
                if atk == "targeted":
                    row["targeted.target_hits@10"] = float(rng.uniform(0.2, 0.6)) * (0.5 if hit else 1.0)
            if e["block"] == "M1":
                auc = 0.5 + (0.08 if not dp else 0.01 * eps_t) + float(rng.normal(0, 0.005))
                row.update({"mia.auc": auc, "mia.tpr_at_fpr_1pct": 0.02, "mia.tpr_at_fpr_0_1pct": 0.002,
                            "mia.eps_lower_bound": 0.3 if dp else 1.0,
                            "mia.lower_bound_exceeds_accountant": False if dp else None})
            if e["block"] == "I2":
                row.update({"integrity.n_corrupted": 40.0, "integrity.n_rejected": 40.0 if
                            cfg["integrity"]["mode"] == "hash_only" else 0.0, "integrity.n_corrupted_and_consumed":
                            0.0 if cfg["integrity"]["mode"] == "hash_only" else 40.0,
                            "integrity.detection_rate": 1.0 if cfg["integrity"]["mode"] == "hash_only" else 0.0})
            if e["block"] in ("R3_legacy", "R3_fixed", "R4_legacy"):
                row["test_legacy_protocol.mrr"] = mrr * 1.3
            rows.append(row)
        self.runs = pd.DataFrame(rows)
        self.problems = pd.DataFrame(columns=["phase", "block", "name", "dataset", "seed", "run_id", "problem", "detail"])
        sel = _placeholder_selection(False)
        for ds in sel:
            sel[ds]["tau"] = {"aggregation": {"tau": 3.0}, "rule_met": ds != "codex_m",
                              "status": "RULE_MET" if ds != "codex_m" else "RULE_NOT_MET_LARGEST_GRID_TAU",
                              "benign_fpr_at_selected_tau": 0.04 if ds != "codex_m" else 0.07,
                              "label": "FIXTURE " + ("tau rule met" if ds != "codex_m" else "tau rule NOT met")}
        self.selection = sel
        self.frozen = {"note": NOTE}
        self.sanity_gate = {"datasets": {ds: {"status": "PASSED", "passed": True, "selected_val_mrr": 0.3,
                                              "threshold": 0.2} for ds in ("fb15k237", "wn18rr", "codex_m")}}
        self.d10 = {"status": "NOT_TRIGGERED", "label": "FIXTURE D10 label", "triggered": False}
        self.env_lock = {"tune": None, "final": None}
        self.l0 = None
        self.provenance_csv = self.project_root / "audit" / "result_provenance.csv"
        self.manifest = load_frozen(self.config_dir)
        self.progress = None
        self.missing_indexes = []
        self._rng = np.random.default_rng(seed + 1)

    def env_of(self, rid: str) -> Dict:
        return {"gpu": "FIXTURE-GPU", "torch": "fixture", "cuda": "fixture"}

    def rounds_of(self, rid: str) -> pd.DataFrame:
        r = np.arange(1, 41)
        rng = np.random.default_rng(_stable(rid))
        val = np.where(r % 5 == 0, 0.2 * (1 - np.exp(-r / 12)) + rng.normal(0, 0.003, len(r)), np.nan)
        return pd.DataFrame({"round": r, "val_es_mrr": val, "t_local_s": rng.uniform(3, 4, len(r)),
                             "t_agg_s": rng.uniform(0.05, 0.1, len(r)), "t_integrity_s": rng.uniform(0.5, 0.9, len(r)),
                             "integrity_bytes": 1.2e8, "mean_client_loss": np.exp(-r / 20)})

    def mia_scores_of(self, rid: str) -> pd.DataFrame:
        rng = np.random.default_rng(_stable(rid))
        m = rng.random(2000) < 0.5
        return pd.DataFrame({"member": m.astype(int), "A2": rng.normal(0, 1, 2000) + 0.15 * m})

    def card_of(self, ds: str) -> Optional[Dict]:
        return None

    def partition_stats(self):
        return []

    def summary(self) -> Dict:
        return {"tier": FIXTURE_TIER, "note": NOTE, "n_runs": int(len(self.runs))}
