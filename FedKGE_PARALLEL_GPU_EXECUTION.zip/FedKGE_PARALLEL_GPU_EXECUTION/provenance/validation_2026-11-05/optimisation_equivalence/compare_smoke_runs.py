"""Compare two smoke-tier executions run by run (final.json numeric fields except timings; integrity.json counts).
Software check: smoke outputs are not evidence. python -I compare_smoke_runs.py <runs_old> <runs_new> <out.json>"""
import json, sys
from pathlib import Path
a, b, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
skip = ("time", "second", "wall", "utc", "duration", "elapsed", "speed", "throughput", "_s", "overhead", "hash_s", "verify_s", "store_s")
def flat(d, pre=""):
    o = {}
    for k, v in d.items():
        if isinstance(v, dict): o.update(flat(v, pre + k + "."))
        elif isinstance(v, (int, float)) and not isinstance(v, bool): o[pre + k] = v
    return o
ra = {p.name for p in a.iterdir() if (p / "final.json").exists()}; rb = {p.name for p in b.iterdir() if (p / "final.json").exists()}
res = {"runs_old": len(ra), "runs_new": len(rb), "common": len(ra & rb), "bit_identical_runs": 0, "differing_runs": {},
       "integrity_runs_compared": 0, "integrity_counts_identical": 0}
for r in sorted(ra & rb):
    fa = flat(json.load(open(a / r / "final.json"))); fb = flat(json.load(open(b / r / "final.json")))
    diff = {k: (fa[k], fb[k]) for k in fa.keys() & fb.keys() if not any(s in k.lower() for s in skip) and fa[k] != fb[k] and not (fa[k] != fa[k] and fb[k] != fb[k])}   # NaN == NaN
    cfg = json.load(open(a / r / "config.json"))
    if diff:
        rel = max(abs(x - y) / max(abs(x), 1e-12) for x, y in diff.values())
        res["differing_runs"][r] = {"block": cfg.get("block"), "federated": cfg["partition"]["scheme"] != "centralized",
                                   "integrity_mode": cfg["integrity"]["mode"], "n_fields": len(diff), "max_rel_diff": rel}
    else:
        res["bit_identical_runs"] += 1
    ia, ib = a / r / "integrity.json", b / r / "integrity.json"
    if ia.exists() and ib.exists():
        res["integrity_runs_compared"] += 1
        ka = {k: v for k, v in json.load(open(ia)).items() if not k.startswith("mean_") or k == "mean_bytes_per_round"}
        kb = {k: v for k, v in json.load(open(ib)).items() if not k.startswith("mean_") or k == "mean_bytes_per_round"}
        res["integrity_counts_identical"] += int(ka == kb)
d = res["differing_runs"]
res["differing_blocks"] = sorted({v["block"] for v in d.values()})
res["differing_runs_with_integrity_transport"] = sum(v["integrity_mode"] != "off" for v in d.values())
res["max_rel_diff"] = max((v["max_rel_diff"] for v in d.values()), default=0.0)
out.write_text(json.dumps(res, indent=1))
print(json.dumps({k: v for k, v in res.items() if k != "differing_runs"}, indent=1))
print({r: (v["block"], v["integrity_mode"], f"{v['max_rel_diff']:.1e}") for r, v in list(d.items())[:30]})
