Code cells extracted as plain text from the owner's ORIGINAL notebooks (phase3_updated.ipynb = the non-private
FedAvg run, MRR 0.2858; phase4_ready_1.ipynb = the DP run, MRR 0.009). Unmodified code text, for checking the
gap analysis in HANDOFF_PHASE_C.md section 5.6. The original notebooks themselves are the owner's files.
