# Benign false-positive rate by client-size third (diagnostic, decision B4)

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| dataset | runs | n | benign FPR third 0 (small) | benign FPR third 1 (middle) | benign FPR third 2 (large) | benign FPR overall |
|---|---|---|---|---|---|---|
| FB15k-237 | complete method, clean (tau*) | 1 | 0.000 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0.000 (n=1) |
| FB15k-237 | DP-FedAvg clean, scores at its configured tau | 1 | 0.000 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0.000 (n=1) |
| WN18RR | complete method, clean (tau*) | 1 | 0.000 (n=1) | 0.000 (n=1) | 0.111 (n=1) | 0.033 (n=1) |
| WN18RR | DP-FedAvg clean, scores at its configured tau | 1 | 0.000 (n=1) | 0.000 (n=1) | 0.111 (n=1) | 0.033 (n=1) |
| CoDEx-M | complete method, clean (tau*) | 1 | 0.000 (n=1) | 0.000 (n=1) | 0.000 (n=1) | 0.000 (n=1) |
| CoDEx-M | DP-FedAvg clean, scores at its configured tau | 1 | 0.083 (n=1) | 0.111 (n=1) | 0.000 (n=1) | 0.067 (n=1) |
