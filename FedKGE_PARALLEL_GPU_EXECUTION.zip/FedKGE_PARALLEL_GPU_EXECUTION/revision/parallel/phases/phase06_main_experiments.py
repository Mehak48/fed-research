#!/usr/bin/env python3
"""PHASE 06 (GPU worker) - one shard of the Stage-4 confirmatory experiments of one dataset and priority.

  python parallel/phases/phase06_main_experiments.py --base B --worker W --job M-codex_m-p2-1of4 --max-hours 10

Needs the master's release pack for the dataset (frozen selections + the job's explicit run ids), installed
automatically from <base>/exchange/packs/. The worker re-expands the frozen matrix and refuses to run if any of its
cells maps to a different run id than the master's (exit 7). Runs execute in the pre-registered priority order.
Outputs: COMPLETE run folders in <base>/workers/<W>/results/final/runs/, a result bundle in the outbox.
Success: EXIT 0 (EXIT 3 = session budget: run the same command again). Next: master phase 08 (import)."""
from __future__ import annotations

import sys

from _cli import finish, layout, parser

from fedkge_parallel.common import EXIT_CONTRACT
from fedkge_parallel.execute import job_spec_for, run_worker_job

KINDS = ['MAIN']


def main(argv=None) -> int:
    ap = parser(__doc__, worker=True, gpu=True)
    ap.add_argument("--job", required=True, help="a job id from the plan (see QUEUE_<worker>.md)")
    a = ap.parse_args(argv)
    L = layout(a)
    spec = job_spec_for(L, a.job)
    if spec["kind"] not in KINDS:
        print(f"STOP: {a.job} is a {spec['kind']} job; this entry point runs {KINDS}")
        return finish(EXIT_CONTRACT)
    return finish(run_worker_job(L, a.worker, a.job, a.device, a.max_hours, a.max_runs))


if __name__ == "__main__":
    sys.exit(main())
