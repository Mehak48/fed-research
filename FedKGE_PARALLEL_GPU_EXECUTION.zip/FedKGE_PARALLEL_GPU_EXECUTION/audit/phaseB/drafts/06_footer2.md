
## 5. Required tables (master prompt §17) → blocks

Every table is generated from saved run records. None is typed by hand.

| # | Table | Source blocks / artifacts |
|---|---|---|
| 1 | Dataset statistics | Phase D dataset cards and validation reports (no training) |
| 2 | Client partition statistics | Phase D partition artifacts, every α × every seed |
| 3 | Main results by dataset | N1 (centralised), N2 (FedAvg), DP2 at ε* = 4 (the DP baseline with the selected schedule; equals DP1 if s* = fixed), R1p (complete method); with provenance labels |
| 4 | Baseline comparison | N1, N2, DP1/DP2, R1, R4, X6 |
| 5 | Ablation study | R1p, R5, R2/R2a, R1q, I1/I2, DP3 |
| 6 | DP privacy accounting | `accountant.json` of every DP run (DP1, DP1h, DP2, DP2h, R*, X*, L3/L4, M1) |
| 7 | Privacy/utility Pareto comparison | DP1, DP2, X1, X7a, N2/N3 (ε = ∞), M1 (if H3) |
| 8 | Threshold sweeps | T2a–T2d, T3 (selection tables), X2, X2a, X3, X1 |
| 9 | Attack and defence evaluation | R1–R5, R2a, R3a, X4, X4a, X5, X7b |
| 10 | Integrity overhead | integrity logs of all runs; I1; I2 |
| 11 | Runtime and communication cost | runtime and communication fields of all runs |
| 12 | Statistical uncertainty | per-seed values, 95 % intervals, d_z, and the Holm-adjusted one-sided tests of every pre-registered family (H1, H2, H2b, H3, HS) |
| 13 | Original vs revised on FB15k-237 | historical values (`result_provenance.csv`, labelled *Reported*), L0–L4 (*Reproduced*), N2, DP1/DP2 and R1p on FB15k-237 (*Newly measured*) |
| 14 | Completion and failure status | run index: planned (this matrix) vs COMPLETE / FAILED / STALE / NOT_RUN, with failure reasons |

## 6. Figure families (master prompt §15) → blocks

| Family | Surface or plot | Axes (all values measured or calculated) | Blocks |
|---|---|---|---|
| A. Dataset comparison | one surface per dataset: test MRR over (ε, α) | ε = calculated worst-client ε; α ∈ {0.1, 0.5, 1.0} with IID as its own category | DP1, X1, N2/N3 |
| B. Privacy/utility | MRR over (ε, schedule), plus a 2D frontier with seed CIs | ε calculated, not σ | DP1, DP2, X7a |
| C. Threshold sensitivity | MRR, and degradation relative to FedAvg, over (τ, f) under ALIE; τ curve under the adaptive attack | τ in MAD units; f ∈ {0.1, 0.2, 0.3} | X2, X2a, X4, R2, R3 |
| D. Baseline comparison | bars or points with CIs; original (*Reported*) vs replica (*Reproduced*) vs revised (*Newly measured*) on FB15k-237; the same revised comparison on the other two datasets | categorical | L0–L4, N1, N2, DP2, R1p, R1, R4 |
| E. Ablations | grouped 2D panels, or 3D bars over (component set × ε) | categorical × ε (**no continuous surface over categories**) | R1p, R5, R2, DP3, X7a, X7b |

Rules for every figure:
- missing cells are shown as missing, with no interpolation;
- seed aggregation is stated;
- descriptive (3-seed) results are labelled as such;
- PNG + PDF + SVG output;
- the plotting script is saved next to the figure;
- a 2D view is added where it is clearer.

## 7. Completion, failure and validity rules

- **Validity.** A run counts only if its code, data, partition and selection hashes are current (the revision's `analysis.collect`). Stale runs are archived and rerun, never mixed in.
- **Smoke and dev runs** are watermarked and rejected by the table builders.
- **Failed runs** keep their traceback (`error.txt`) and appear in Table 14. Nothing is filled in for a missing or failed run.
- **Selections** refuse to run on incomplete grids, and record the rule text, its SHA-256 and the full candidate table.
- **Before Stage 4 starts:**
  1. all selections for the dataset exist;
  2. the decision sheet (02) is approved;
  3. the hypotheses (03 §13) are frozen. Their file hash is recorded in the run configs.
