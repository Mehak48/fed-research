#!/usr/bin/env python3
"""Phase 1 + Phase 2 artifacts with a partition audit (Phase C sections 6 and 10).

  python scripts/build_artifacts.py --tier smoke --datasets fb15k237 wn18rr codex_m --data-dir ../data_cache \
         --seeds 42 1001 --alphas 0.1 0.5 1.0 --iid --central [--accept-draws 2000]

For every (dataset, partition spec, seed): coverage (each training triple exactly once), no empty client, minimum
size, deterministic re-derivation, hash bound to the Phase 1 data hash, attempts. For every (dataset, alpha): the
acceptance rate of the minimum-size rule estimated from fresh Dirichlet draws on the REAL relation counts (resolves
G15 for WN18RR, whose counts were unverified in Phase B). Nothing is retried until a favourable partition appears:
the accepted partition is the first one that satisfies the pre-declared rule in the seeded stream.
"""
from __future__ import annotations

import argparse
import json
import sys
import time

import numpy as np
import pandas as pd

from _common import CONFIG_DIR, Manifest, results_root
from fedkge.config import deep_merge, load_yaml
from fedkge.data import build_artifact, load_artifact
from fedkge.io import Paths
from fedkge.partition import assign, build_partition, canonical_spec, load_partition


def acceptance_rate(train: np.ndarray, spec: dict, draws: int, seed: int = 12345) -> dict:
    n, alpha = int(spec["n_clients"]), float(spec["alpha"])
    N = len(train)
    m = int(max(spec.get("min_client_abs", 0), spec.get("min_client_frac", 0.0) * N / n))
    rels, counts = np.unique(train[:, 1], return_counts=True)
    rng = np.random.default_rng(seed)
    ok, ginis, maxshare = 0, [], []
    for _ in range(draws):
        sizes = np.zeros(n, dtype=np.int64)
        for c in counts:
            p = rng.dirichlet(np.full(n, alpha))
            cuts = (np.cumsum(p)[:-1] * c).astype(int)
            sizes += np.diff(np.concatenate([[0], cuts, [c]]))
        if sizes.min() >= m:
            ok += 1
            s = np.sort(sizes)
            ginis.append(float((2 * np.arange(1, n + 1) - n - 1).dot(s) / (n * s.sum())))
            maxshare.append(float(s.max() / s.sum()))
    return {"alpha": alpha, "draws": draws, "min_size": m, "accept_rate": ok / draws,
            "gini_median_accepted": float(np.median(ginis)) if ginis else None,
            "max_share_median_accepted": float(np.median(maxshare)) if maxshare else None}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results"); ap.add_argument("--tier", default="smoke")
    ap.add_argument("--datasets", nargs="+", required=True); ap.add_argument("--data-dir", required=True)
    ap.add_argument("--seeds", nargs="+", type=int, default=[42])
    ap.add_argument("--alphas", nargs="*", type=float, default=[0.1])
    ap.add_argument("--iid", action="store_true"); ap.add_argument("--central", action="store_true")
    ap.add_argument("--accept-draws", type=int, default=0)
    ap.add_argument("--no-subset", action="store_true", help="smoke tier: use the full dataset instead of the subset")
    ap.add_argument("--tier-file", help="tier settings file (e.g. 'offline' for the synthetic KG); default = --tier")
    a = ap.parse_args(argv)
    root = results_root(a.results)
    paths = Paths(root, a.tier)
    man = Manifest(root, f"artifacts_{a.tier}")
    tier = load_yaml(CONFIG_DIR / "tiers" / f"{a.tier_file or a.tier}.yaml")
    base = load_yaml(CONFIG_DIR / "base.yaml")
    audit_rows, acc_rows = [], []
    try:
        for ds in a.datasets:
            ds_cfg = load_yaml(CONFIG_DIR / "datasets" / f"{ds}.yaml")
            subset = None if a.no_subset else tier.get("subset")
            t0 = time.time()
            m1 = build_artifact(ds_cfg, paths.p1(ds), subset=subset, data_dir=a.data_dir)
            data = load_artifact(paths.p1(ds))
            man.output(paths.p1(ds))
            print(f"{ds}: P1 built in {time.time() - t0:.1f}s ({len(data.train)} train, {data.num_entities} entities)")
            part = deep_merge(base["partition"], tier.get("run_overrides", {}).get("partition", {}))
            specs = [{**part, "scheme": "dirichlet_relation", "alpha": al} for al in a.alphas]
            if a.iid:
                specs.append({**part, "scheme": "iid"})
            if a.central:
                specs.append({"scheme": "centralized", "n_clients": 1})
            for spec in specs:
                cs = canonical_spec(spec)
                for seed in a.seeds:
                    t1 = time.time()
                    pm = build_partition(data.train, data.num_relations, cs, seed, paths.p2(ds), data.content_hash)
                    p = load_partition(paths.p2(ds), cs, seed, data.content_hash)
                    again = assign(data.train, cs, seed)
                    sizes = np.bincount(p["client"], minlength=int(cs["n_clients"]))
                    audit_rows.append({
                        "dataset": ds, "scheme": cs["scheme"], "alpha": cs.get("alpha"), "seed": seed,
                        "n_train": len(data.train), "coverage_ok": bool(len(p["client"]) == len(data.train)
                                                                        and p["client"].min() >= 0),
                        "no_empty_client": bool(sizes.min() > 0), "min_size_rule": p["stats"]["min_size"],
                        "min_size_ok": bool(sizes.min() >= p["stats"]["min_size"]),
                        "deterministic": bool(np.array_equal(again["client"], p["client"])),
                        "hash_bound_to_p1": pm["data_hash"] == data.content_hash, "attempts": p["stats"]["attempts"],
                        **{k: p["stats"]["summary"][k] for k in ("size_gini", "size_max_share", "size_max_min_ratio",
                                                                  "mean_relation_js", "mean_pairwise_entity_jaccard")},
                        "seconds": time.time() - t1})
                if cs["scheme"] == "dirichlet_relation" and a.accept_draws:
                    acc_rows.append({"dataset": ds, **acceptance_rate(data.train, cs, a.accept_draws)})
        aud = pd.DataFrame(audit_rows)
        stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())      # never overwrite an earlier audit
        out = root / a.tier / f"partition_audit_{stamp}.csv"
        aud.to_csv(out, index=False); man.output(out)
        if acc_rows:
            o2 = root / a.tier / f"partition_acceptance_{stamp}.csv"
            pd.DataFrame(acc_rows).to_csv(o2, index=False); man.output(o2)
        bad = aud[~(aud["coverage_ok"] & aud["no_empty_client"] & aud["min_size_ok"] & aud["deterministic"]
                    & aud["hash_bound_to_p1"])]
        man.close("COMPLETE" if bad.empty else "AUDIT_FAILED", n_partitions=len(aud), n_failed=len(bad))
        print(aud.to_string(index=False))
        if acc_rows:
            print(pd.DataFrame(acc_rows).to_string(index=False))
        return 0 if bad.empty else 1
    except Exception as e:
        man.close("FAILED", error=repr(e))
        raise


if __name__ == "__main__":
    sys.exit(main())
