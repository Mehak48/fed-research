# ===== CELL 1 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 1 — Environment Setup (Opacus + dependencies)
# ═══════════════════════════════════════════════════════════════════
import subprocess, sys

def pip_q(pkg, label=None):
    label = label or pkg
    r = subprocess.run([sys.executable,"-m","pip","install","-q",pkg],
                       capture_output=True, text=True)
    print(f"{'✅' if r.returncode==0 else '❌'} {label}")

# Remove flwr if it conflicts
subprocess.run([sys.executable,"-m","pip","uninstall","-y","flwr","ray"],
               capture_output=True)

for pkg, lbl in [
    ("opacus>=1.4.0,<2.0.0","opacus"),
    ("pykeen>=1.10,<2.0","pykeen"),
    ("torch>=2.0","torch"),
    ("matplotlib>=3.7","matplotlib"),
    ("seaborn>=0.12","seaborn"),
    ("plotly>=5.15","plotly"),
    ("pandas>=2.0","pandas"),
    ("numpy>=1.24","numpy"),
    ("scipy>=1.10","scipy"),
]:
    pip_q(pkg, lbl)

import opacus, torch
print(f"\n✅ Opacus {opacus.__version__} | PyTorch {torch.__version__}")
print(f"✅ CUDA: {torch.cuda.is_available()}")

# ===== CELL 2 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 2 — Imports & Configuration
# ═══════════════════════════════════════════════════════════════════
import os, json, time, warnings, copy, math
from pathlib import Path
from datetime import datetime
from collections import defaultdict

import numpy as np
import pandas as pd
import scipy.stats as stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import seaborn as sns
from mpl_toolkits.mplot3d import Axes3D
import plotly.graph_objects as go
from plotly.subplots import make_subplots

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

from opacus import PrivacyEngine
from opacus.utils.batch_memory_manager import BatchMemoryManager
from opacus.accountants.utils import get_noise_multiplier

warnings.filterwarnings("ignore")

ROOT      = Path("checkpoints")
P4_DIR    = ROOT / "phase4"
GRAPH_DIR = P4_DIR / "graphs"
MODEL_DIR = P4_DIR / "models"
for d in [P4_DIR, GRAPH_DIR, MODEL_DIR]:
    d.mkdir(parents=True, exist_ok=True)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

plt.rcParams.update({
    "figure.dpi":150,"savefig.dpi":300,"font.family":"DejaVu Sans",
    "axes.titlesize":13,"axes.labelsize":11,"xtick.labelsize":9,
    "ytick.labelsize":9,"legend.fontsize":9,"figure.facecolor":"white",
    "axes.facecolor":"#f8f9fa","axes.grid":True,"grid.alpha":0.4,
})

def style_table(df, caption=""):
    return (df.style.set_caption(caption)
              .set_table_styles([
                  {"selector":"caption","props":[("font-weight","bold"),("font-size","13px"),
                   ("text-align","left"),("padding","6px 0")]},
                  {"selector":"th","props":[("background-color","#e63946"),("color","white"),
                   ("font-weight","bold"),("text-align","center"),("padding","8px 12px")]},
                  {"selector":"td","props":[("text-align","center"),("padding","6px 12px")]},
                  {"selector":"tr:nth-child(even)","props":[("background-color","#ffe8d6")]},
              ]).hide(axis="index"))

# ── ADP Configuration (Table 4) ───────────────────────────────────
ADP_CFG = {
    "target_epsilon":     15.0,
    "target_delta":       1e-5,
    "max_grad_norm":      1.0,
    "schedule_type":      "fixed",          # exponential | cosine | linear
    "sigma_initial":      1.0,
    "sigma_final":        1.0,
    "fl_rounds":          20,
    "virtual_batch_size": 256,
    "max_physical_batch": 64,
    "accountant":         "rdp",
}

# ── Base KGE config (inherited from Phase 3) ─────────────────────
KGE_CFG = {
    "embedding_dim": 100,
    "margin":        1.0,
    "lr":            0.001,
    "n_clients":     5,
    "neg_samples":   64,
    "seed":          42,
}
torch.manual_seed(KGE_CFG["seed"])
np.random.seed(KGE_CFG["seed"])

print("✅ Phase 4 configuration loaded.")
print("\nADP Configuration (Table 4):")
for k,v in ADP_CFG.items(): print(f"   {k:22s}: {v}")

# ===== CELL 3 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 3 — Load Phase 3 Results & Dataset
# ═══════════════════════════════════════════════════════════════════
with open("phase3_results.json") as f:
    phase3 = json.load(f)

print("✅ phase3_results.json loaded.")
print(f"   Phase 3 final MRR    : {phase3['final_metrics']['mrr']:.4f}")
print(f"   Phase 3 final Hits@10: {phase3['final_metrics']['hits@10']:.4f}")

from pykeen.datasets import FB15k237
print("⏳ Loading FB15k-237 …")
dataset       = FB15k237()
train_triples = dataset.training.mapped_triples.numpy()
valid_triples = dataset.validation.mapped_triples.numpy()
test_triples  = dataset.testing.mapped_triples.numpy()

entity_to_id   = dataset.entity_to_id
relation_to_id = dataset.relation_to_id
id_to_entity   = {v:k for k,v in entity_to_id.items()}
id_to_relation = {v:k for k,v in relation_to_id.items()}

NUM_ENTITIES  = phase3["config"]["n_clients"] and len(entity_to_id)
NUM_RELATIONS = len(relation_to_id)
NUM_ENTITIES  = len(entity_to_id)
N_TRAIN       = len(train_triples)
all_triples   = np.vstack([train_triples, valid_triples, test_triples])

print(f"✅ Dataset loaded. {NUM_ENTITIES:,} entities, {NUM_RELATIONS:,} relations.")

# ===== CELL 4 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 4 — TransE Model & Dataset (Opacus-compatible)
# Opacus requires: no in-place ops, per-sample gradients via hooks
# ═══════════════════════════════════════════════════════════════════

class TransEDP(nn.Module):
    """TransE wrapped for Opacus — no inplace ops, no shared params in forward."""
    def __init__(self, n_entities, n_relations, dim, margin=1.0):
        super().__init__()
        self.dim     = dim
        self.margin  = margin
        self.ent_emb = nn.Embedding(n_entities,  dim)
        self.rel_emb = nn.Embedding(n_relations, dim)
        nn.init.uniform_(self.ent_emb.weight, -6/dim**0.5, 6/dim**0.5)
        nn.init.uniform_(self.rel_emb.weight, -6/dim**0.5, 6/dim**0.5)

    def forward(self, heads, rels, tails, neg_heads, neg_rels, neg_tails):
        h  = self.ent_emb(heads)
        r  = self.rel_emb(rels)
        t  = self.ent_emb(tails)
        nh = self.ent_emb(neg_heads)
        nr = self.rel_emb(neg_rels)
        nt = self.ent_emb(neg_tails)
        pos_score = -torch.norm(h + r - t,   p=2, dim=-1)
        neg_score = -torch.norm(nh + nr - nt, p=2, dim=-1)
        loss = F.relu(self.margin - pos_score + neg_score).mean()
        return loss

    def score(self, heads, rels, tails):
        h = self.ent_emb(heads)
        r = self.rel_emb(rels)
        t = self.ent_emb(tails)
        return -torch.norm(h + r - t, p=2, dim=-1)


class KGETupleDataset(Dataset):
    """Returns 6-tuples (pos_h, pos_r, pos_t, neg_h, neg_r, neg_t) for Opacus."""
    def __init__(self, triples, n_entities, n_neg=5):
        self.triples    = torch.tensor(triples, dtype=torch.long)
        self.n_entities = n_entities
        self.n_neg      = n_neg

    def __len__(self): return len(self.triples)

    def __getitem__(self, idx):
        h, r, t = self.triples[idx]
        neg_h = torch.randint(0, self.n_entities, (1,)).item() if torch.rand(1)>0.5 else h.item()
        neg_t = t.item() if torch.rand(1)>0.5 else torch.randint(0, self.n_entities, (1,)).item()
        return (h.item(), r.item(), t.item(), neg_h, r.item(), neg_t)


def partition_relation_cluster(triples, n_clients):
    all_rels = np.unique(triples[:,1])
    chunks   = np.array_split(all_rels, n_clients)
    return {cid: triples[np.isin(triples[:,1], chunk)] for cid, chunk in enumerate(chunks)}

partitions = partition_relation_cluster(train_triples, KGE_CFG["n_clients"])
print("✅ TransEDP model and dataset ready.")
for cid, part in partitions.items():
    print(f"   Client-{cid}: {len(part):,} triples")

# ===== CELL 5 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 5 — Adaptive Noise Schedule
# Three schedule types: exponential | cosine | linear
# ═══════════════════════════════════════════════════════════════════

class AdaptiveNoiseScheduler:
    """
    Deterministic noise multiplier decay schedule.
    Replaces GAN-based noise estimation (Peng et al. 2021).
    """
    def __init__(self, sigma_0, sigma_T, T, schedule_type="exponential"):
        self.sigma_0     = sigma_0
        self.sigma_T     = sigma_T
        self.T           = T
        self.schedule    = schedule_type
        self._log        = []

    def get_sigma(self, rnd):
        """Return noise multiplier σ for round rnd (1-indexed)."""
        t = rnd - 1  # 0-indexed
        if self.schedule == "exponential":
            if self.T > 1:
                decay = (self.sigma_T / self.sigma_0) ** (t / (self.T-1))
            else:
                decay = 1.0
            sigma = self.sigma_0 * decay
        elif self.schedule == "cosine":
            sigma = self.sigma_T + 0.5*(self.sigma_0 - self.sigma_T) * (
                1 + math.cos(math.pi * t / max(self.T-1, 1)))
        else:  # linear
            sigma = self.sigma_0 - (self.sigma_0 - self.sigma_T) * t / max(self.T-1, 1)
        return max(float(sigma), self.sigma_T)

    def log_round(self, rnd, sigma, epsilon, loss, round_time):
        self._log.append({
            "round": rnd, "sigma": sigma, "epsilon": epsilon,
            "loss": loss, "time": round_time,
        })

    def export(self):
        return self._log


# ── Preview schedule for 5 rounds ─────────────────────────────────
scheduler = AdaptiveNoiseScheduler(
    ADP_CFG["sigma_initial"], ADP_CFG["sigma_final"],
    ADP_CFG["fl_rounds"], ADP_CFG["schedule_type"]
)

schedule_df = pd.DataFrame([
    {"Round": r, "σ (noise multiplier)": round(scheduler.get_sigma(r),4),
     "Schedule": ADP_CFG["schedule_type"]}
    for r in range(1, ADP_CFG["fl_rounds"]+1)
])
display(style_table(schedule_df, f"Table — Noise Schedule ({ADP_CFG['schedule_type'].title()}, 5 rounds)"))

# ===== CELL 6 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 6 — Federated Training with Adaptive DP (Opacus)
# DPModelWrapper: wraps TransEDP with PrivacyEngine per round
# ═══════════════════════════════════════════════════════════════════

def get_params(model):
    return {k: v.detach().cpu().numpy().copy() for k,v in model.state_dict().items()}

def set_params(model, params):
    model.load_state_dict({k: torch.tensor(v) for k,v in params.items()})

def fedavg(client_params, client_weights):
    total_w = sum(client_weights)
    keys    = client_params[0].keys()
    return {k: sum(w/total_w * p[k] for p,w in zip(client_params, client_weights))
            for k in keys}

def evaluate_mrr(model, test_triples, all_triples, n_ent, device, max_eval=200):
    model.eval()
    known = defaultdict(set)
    for h,r,t in all_triples:
        known[(int(h),int(r))].add(int(t))
    mrr = hits1 = hits3 = hits10 = 0.0
    n   = min(max_eval, len(test_triples))
    subset = test_triples[np.random.choice(len(test_triples), n, replace=False)]
    with torch.no_grad():
        for h,r,t in subset:
            h,r,t  = int(h),int(r),int(t)
            h_t    = torch.tensor([h]*n_ent, dtype=torch.long).to(device)
            r_t    = torch.tensor([r]*n_ent, dtype=torch.long).to(device)
            t_t    = torch.arange(n_ent, dtype=torch.long).to(device)
            scores = model.score(h_t, r_t, t_t).cpu().numpy()
            for t2 in known[(h,r)]:
                if t2 != t: scores[t2] = -1e9
            rank  = int(np.sum(scores > scores[t])) + 1
            mrr  += 1/rank; hits1 += rank<=1; hits3 += rank<=3; hits10 += rank<=10
    return {"mrr":round(mrr/n,4),"hits@1":round(hits1/n,4),
            "hits@3":round(hits3/n,4),"hits@10":round(hits10/n,4)}


print("⏳ Starting Adaptive DP Federated Training …")
print(f"   Schedule: {ADP_CFG['schedule_type']} | σ₀={ADP_CFG['sigma_initial']} → σ_T={ADP_CFG['sigma_final']}")
print(f"   Rounds: {ADP_CFG['fl_rounds']} | Clients: {KGE_CFG['n_clients']} | ε_target={ADP_CFG['target_epsilon']}\n")

global_model = TransEDP(NUM_ENTITIES, NUM_RELATIONS,
                        KGE_CFG["embedding_dim"], KGE_CFG["margin"]).to(DEVICE)
global_params = get_params(global_model)

# ── Warm-start: load Phase 3 checkpoint ─────────────────────
import glob
_p3_candidates = [
    "checkpoints/phase3/models/global_transe_final.pt",
    "global_transe_final.pt",
]
_p3_found = next((p for p in _p3_candidates if os.path.exists(p)), None)
if _p3_found is None:
    # last resort: search recursively
    _hits = glob.glob("**/global_transe_final.pt", recursive=True)
    _p3_found = _hits[0] if _hits else None
if _p3_found:
    _state = torch.load(_p3_found, map_location=DEVICE)
    global_model.load_state_dict(_state)
    print(f"✅ Warm-start loaded: {_p3_found}")
else:
    print("⚠ Phase 3 checkpoint NOT found — training from random init")
    print("  Searched:", _p3_candidates)

scheduler = AdaptiveNoiseScheduler(
    ADP_CFG["sigma_initial"], ADP_CFG["sigma_final"],
    ADP_CFG["fl_rounds"], ADP_CFG["schedule_type"]
)

adp_history = {
    "round":[], "sigma":[], "cumulative_epsilon":[],
    "avg_loss":[], "mrr":[], "hits@1":[], "hits@3":[], "hits@10":[],
    "client_losses":[], "client_epsilons":[],
}

cumulative_epsilon = 0.0
t_adp = time.time()

for rnd in range(1, ADP_CFG["fl_rounds"]+1):
    sigma       = scheduler.get_sigma(rnd)
    t_round     = time.time()
    print(f"  ── Round {rnd}/{ADP_CFG['fl_rounds']} | σ={sigma:.4f} ──")

    client_params_list  = []
    client_weights_list = []
    round_losses        = []
    round_eps           = []

    for cid in range(KGE_CFG["n_clients"]):
        local_triples = partitions[cid]
        if len(local_triples) < ADP_CFG["max_physical_batch"]:
            print(f"     Client-{cid}: skipped (too few triples)")
            continue

        local_model = TransEDP(NUM_ENTITIES, NUM_RELATIONS,
                               KGE_CFG["embedding_dim"], KGE_CFG["margin"]).to(DEVICE)
        set_params(local_model, global_params)
        local_model.train()

        dataset_c = KGETupleDataset(local_triples, NUM_ENTITIES, KGE_CFG["neg_samples"])
        loader    = DataLoader(dataset_c, batch_size=ADP_CFG["virtual_batch_size"],
                               shuffle=True, drop_last=True)

        optimizer = torch.optim.Adam(local_model.parameters(), lr=KGE_CFG["lr"])
        privacy_engine = PrivacyEngine(accountant=ADP_CFG["accountant"])

        # Attach Opacus
        local_model, optimizer, loader = privacy_engine.make_private(
            module=local_model,
            optimizer=optimizer,
            data_loader=loader,
            noise_multiplier=sigma,
            max_grad_norm=ADP_CFG["max_grad_norm"],
        )

        # Train with BatchMemoryManager
        total_loss = 0.0
        n_batches  = 0
        with BatchMemoryManager(
            data_loader=loader,
            max_physical_batch_size=ADP_CFG["max_physical_batch"],
            optimizer=optimizer,
        ) as mem_loader:
            for batch in mem_loader:
                ph,pr,pt,nh,nr,nt = [torch.tensor(x, dtype=torch.long).to(DEVICE) for x in batch]
                optimizer.zero_grad()
                loss = local_model(ph, pr, pt, nh, nr, nt)
                loss.backward()
                optimizer.step()
                total_loss += loss.item()
                n_batches  += 1

        avg_loss = total_loss / max(n_batches, 1)
        # Get epsilon from accountant
        try:
            eps = privacy_engine.get_epsilon(delta=ADP_CFG["target_delta"])
        except Exception:
            eps = sigma * 0.5   # fallback estimate

        # Strip Opacus module prefix before extracting params
        raw_params = {}
        for k,v in local_model.state_dict().items():
            clean_k = k.replace("_module.","")
            raw_params[clean_k] = v.detach().cpu().numpy().copy()

        client_params_list.append(raw_params)
        client_weights_list.append(len(local_triples))
        round_losses.append(avg_loss)
        round_eps.append(eps)
        print(f"     Client-{cid}: loss={avg_loss:.4f}, ε={eps:.4f}")

    if not client_params_list:
        print("     ⚠️  No clients in this round. Skipping aggregation.")
        continue

    # FedAvg aggregation
    global_params = fedavg(client_params_list, client_weights_list)

    # Create clean model for evaluation
    eval_model = TransEDP(NUM_ENTITIES, NUM_RELATIONS,
                          KGE_CFG["embedding_dim"], KGE_CFG["margin"]).to(DEVICE)
    eval_model.load_state_dict({k: torch.tensor(v) for k,v in global_params.items()})

    eval_metrics = evaluate_mrr(eval_model, test_triples, all_triples,
                                 NUM_ENTITIES, DEVICE, max_eval=150)
    avg_loss  = float(np.mean(round_losses))
    avg_eps   = float(np.mean(round_eps))
    cumulative_epsilon += avg_eps
    round_time = time.time() - t_round

    scheduler.log_round(rnd, sigma, avg_eps, avg_loss, round_time)
    adp_history["round"].append(rnd)
    adp_history["sigma"].append(sigma)
    adp_history["cumulative_epsilon"].append(cumulative_epsilon)
    adp_history["avg_loss"].append(avg_loss)
    adp_history["mrr"].append(eval_metrics["mrr"])
    adp_history["hits@1"].append(eval_metrics["hits@1"])
    adp_history["hits@3"].append(eval_metrics["hits@3"])
    adp_history["hits@10"].append(eval_metrics["hits@10"])
    adp_history["client_losses"].append(round_losses)
    adp_history["client_epsilons"].append(round_eps)

    print(f"     → Loss={avg_loss:.4f} | ε_rnd={avg_eps:.3f} | "
          f"ε_cum={cumulative_epsilon:.3f} | MRR={eval_metrics['mrr']:.4f} | "
          f"H@10={eval_metrics['hits@10']:.4f} | {round_time:.1f}s")

    # Budget check
    if cumulative_epsilon > ADP_CFG["target_epsilon"]:
        print(f"⚠️  ε budget exceeded ({cumulative_epsilon:.3f} > {ADP_CFG['target_epsilon']}). Stopping.")
        break

    # Save checkpoint
    torch.save(global_params, MODEL_DIR / f"dp_global_rnd{rnd}.pt")

adp_time = time.time() - t_adp
print(f"\n✅ ADP simulation complete in {adp_time:.1f}s | Final ε_cum={cumulative_epsilon:.4f}")

# ===== CELL 7 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 7 — ADP Training Results Table
# ═══════════════════════════════════════════════════════════════════
adp_df = pd.DataFrame({
    "Round":    adp_history["round"],
    "σ (noise)":  [f"{s:.4f}" for s in adp_history["sigma"]],
    "ε (round)":  [f"{e:.4f}" for e in [
        adp_history["client_epsilons"][i][0] if adp_history["client_epsilons"][i] else 0.0
        for i in range(len(adp_history["round"]))]],
    "ε (cum)":    [f"{e:.4f}" for e in adp_history["cumulative_epsilon"]],
    "Avg Loss":   [f"{l:.4f}" for l in adp_history["avg_loss"]],
    "MRR":        [f"{m:.4f}" for m in adp_history["mrr"]],
    "Hits@10":    [f"{h:.4f}" for h in adp_history["hits@10"]],
})
display(style_table(adp_df, "Table — Phase 4 ADP Training History"))

# Comparison vs Phase 3 baseline
p3_mrr   = phase3["final_metrics"]["mrr"]
p4_mrr   = adp_history["mrr"][-1] if adp_history["mrr"] else 0.0
delta_pct= (p4_mrr - p3_mrr) / max(p3_mrr, 1e-9) * 100

comp_df = pd.DataFrame([
    ("Phase 3 (No DP)",         f"{p3_mrr:.4f}",  "—"),
    ("Phase 4 (ADP)",           f"{p4_mrr:.4f}",  f"{delta_pct:+.2f}%"),
], columns=["Setting","MRR","ΔvPhase3"])
display(style_table(comp_df, "Table — Privacy-Utility Trade-off Comparison"))
print(f"\nMRR delta vs baseline: {delta_pct:+.2f}%")

# ===== CELL 8 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 8 — Figure: Noise Schedule & Privacy Accounting
# ═══════════════════════════════════════════════════════════════════
rounds = adp_history["round"]

fig, axes = plt.subplots(2, 2, figsize=(16, 10))
fig.suptitle("Phase 4 — Adaptive Differential Privacy Tracking", fontsize=15, fontweight="bold")

# σ decay
ax = axes[0,0]
all_rounds = list(range(1, ADP_CFG["fl_rounds"]+1))
all_sigmas = [scheduler.get_sigma(r) for r in all_rounds]
ax.plot(all_rounds, all_sigmas, "o-", color="#e63946", lw=2, ms=8, label="σ schedule")
ax.fill_between(all_rounds, all_sigmas, alpha=0.15, color="#e63946")
ax.axhline(ADP_CFG["sigma_final"], ls="--", color="gray", lw=1, label=f"σ_final={ADP_CFG['sigma_final']}")
ax.axhline(ADP_CFG["sigma_initial"], ls=":", color="gray", lw=1, label=f"σ_initial={ADP_CFG['sigma_initial']}")
ax.set_xlabel("FL Round"); ax.set_ylabel("Noise Multiplier σ")
ax.set_title(f"Adaptive Noise Schedule ({ADP_CFG['schedule_type'].title()})")
ax.legend()
for r, s in zip(all_rounds, all_sigmas):
    ax.annotate(f"{s:.3f}", (r, s), textcoords="offset points", xytext=(0,8),
                ha="center", fontsize=8)

# Cumulative epsilon
ax = axes[0,1]
if rounds:
    ax.plot(rounds, adp_history["cumulative_epsilon"], "s-", color="#457b9d", lw=2, ms=8)
    ax.axhline(ADP_CFG["target_epsilon"], ls="--", color="#e63946", lw=1.5,
               label=f"ε_target={ADP_CFG['target_epsilon']}")
    ax.fill_between(rounds, adp_history["cumulative_epsilon"], alpha=0.15, color="#457b9d")
ax.set_xlabel("FL Round"); ax.set_ylabel("Cumulative ε")
ax.set_title("Privacy Budget Consumption (RDP Accounting)")
ax.legend()

# Loss comparison
ax = axes[1,0]
p3_losses = phase3["training_history"]["avg_loss"]
p3_rounds = phase3["training_history"]["round"]
ax.plot(p3_rounds, p3_losses, "o-", color="#2d6a4f", lw=2, ms=7, label="Phase 3 (No DP)")
if rounds:
    ax.plot(rounds, adp_history["avg_loss"], "s-", color="#e63946", lw=2, ms=7, label="Phase 4 (ADP)")
ax.set_xlabel("FL Round"); ax.set_ylabel("Avg Training Loss")
ax.set_title("Training Loss: Phase 3 vs Phase 4 (ADP)")
ax.legend()

# MRR comparison
ax = axes[1,1]
p3_mrr_hist = phase3["training_history"]["mrr"]
ax.plot(p3_rounds, p3_mrr_hist, "o-", color="#2d6a4f", lw=2, ms=7, label="Phase 3 (No DP)")
if rounds:
    ax.plot(rounds, adp_history["mrr"], "s-", color="#e63946", lw=2, ms=7, label="Phase 4 (ADP)")
ax.set_xlabel("FL Round"); ax.set_ylabel("MRR (Filtered)")
ax.set_title("Link Prediction MRR: Phase 3 vs Phase 4")
ax.legend()

plt.tight_layout()
p = GRAPH_DIR / "fig12_adp_training.png"
fig.savefig(p, dpi=300, bbox_inches="tight")
plt.show()
print(f"✅ Figure 12 saved → {p}")

# ===== CELL 9 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 9 — 3D Privacy-Utility Plot: ε × σ × MRR
# ═══════════════════════════════════════════════════════════════════
if rounds and len(rounds) >= 2:
    sigmas   = adp_history["sigma"]
    eps_cum  = adp_history["cumulative_epsilon"]
    mrr_vals = adp_history["mrr"]
    loss_vals= adp_history["avg_loss"]

    fig = plt.figure(figsize=(14, 10))
    ax  = fig.add_subplot(111, projection="3d")
    sc  = ax.scatter(sigmas, eps_cum, mrr_vals,
                     c=loss_vals, cmap="plasma",
                     s=200, alpha=0.9, edgecolors="white", linewidth=0.5)
    plt.colorbar(sc, ax=ax, label="Training Loss", pad=0.1, shrink=0.55)
    # Draw trajectory
    ax.plot(sigmas, eps_cum, mrr_vals, "k--", lw=1.5, alpha=0.5)
    for rnd, s, e, m in zip(rounds, sigmas, eps_cum, mrr_vals):
        ax.text(s, e, m, f"R{rnd}", fontsize=9, fontweight="bold")
    ax.set_xlabel("Noise Multiplier σ", labelpad=10)
    ax.set_ylabel("Cumulative ε",       labelpad=10)
    ax.set_zlabel("MRR",               labelpad=10)
    ax.set_title("3D Privacy-Utility Trajectory\nσ × ε_cum × MRR | colour = loss",
                 fontsize=12, fontweight="bold")
    ax.view_init(elev=20, azim=45)

    p = GRAPH_DIR / "fig13_3d_privacy_utility.png"
    fig.savefig(p, dpi=300, bbox_inches="tight")
    plt.show()
    print(f"✅ Figure 13 (3D privacy-utility) saved → {p}")
else:
    print("⚠️  Insufficient rounds for 3D plot. At least 2 rounds required.")

# ===== CELL 10 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 10 — Figure 6 Reproduction: 3D KG Cube Scatter (from Methodology §3.6.G)
# ═══════════════════════════════════════════════════════════════════
from collections import defaultdict as _dd

print("⏳ Building cube sample for 3D scatter …")
_cube_dict = _dd(int)
_rel_freq  = _dd(int)
_ent_deg   = _dd(int)

for h,r,t in train_triples:
    h,r,t = int(h),int(r),int(t)
    _cube_dict[(h,r,t)] += 1
    _rel_freq[r] += 1
    _ent_deg[h]  += 1
    _ent_deg[t]  += 1

# Top-25 relations
top25_rel = sorted(_rel_freq.items(), key=lambda x:-x[1])[:25]
top25_ids = {r for r,_ in top25_rel}

_rows = []
for (h,r,t), cnt in _cube_dict.items():
    if r in top25_ids:
        h_d  = max(_ent_deg.get(h,1),1)
        t_d  = max(_ent_deg.get(t,1),1)
        wt   = cnt / (h_d*t_d)**0.5
        _rows.append((h, r, t, cnt, wt))

_df = pd.DataFrame(_rows, columns=["head","relation","tail","count","weight"])
sample = _df.sample(min(2000, len(_df)), random_state=42)

fig = plt.figure(figsize=(14,10))
ax  = fig.add_subplot(111, projection="3d")
sc  = ax.scatter(sample["head"], sample["relation"], sample["tail"],
                 c=sample["weight"], cmap="plasma", s=8, alpha=0.7, edgecolors="none")
plt.colorbar(sc, ax=ax, label="Weighted Score", pad=0.1, shrink=0.55)
ax.set_xlabel("Head Entity Index (Dim 1)", labelpad=10)
ax.set_ylabel("Relation Index (Dim 2)",    labelpad=10)
ax.set_zlabel("Tail Entity Index (Dim 3)", labelpad=10)
ax.set_title("3D Knowledge Graph Cube — Scatter Plot\nTop-25 Relations | Color = Weighted Score",
             fontsize=12, fontweight="bold")
ax.view_init(elev=20, azim=45)

p = GRAPH_DIR / "fig6_3d_kg_cube_scatter.png"
fig.savefig(p, dpi=300, bbox_inches="tight")
plt.show()
print(f"✅ Figure 6 (3D KG cube scatter) saved → {p}")

# ===== CELL 11 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 11 — Noise Schedule Comparison: Exponential vs Cosine vs Linear
# ═══════════════════════════════════════════════════════════════════
fig, ax = plt.subplots(figsize=(12, 6))
all_rounds = list(range(1, ADP_CFG["fl_rounds"]+1))
colors = {"exponential":"#e63946","cosine":"#457b9d","linear":"#2d6a4f"}

for sched_type, color in colors.items():
    sched = AdaptiveNoiseScheduler(
        ADP_CFG["sigma_initial"], ADP_CFG["sigma_final"],
        ADP_CFG["fl_rounds"], sched_type
    )
    sigmas = [sched.get_sigma(r) for r in all_rounds]
    ax.plot(all_rounds, sigmas, "o-", color=color, lw=2.5, ms=8,
            label=sched_type.capitalize())
    for r, s in zip(all_rounds, sigmas):
        ax.annotate(f"{s:.3f}", (r, s), textcoords="offset points",
                    xytext=(0,8), ha="center", fontsize=7, color=color)

ax.axhline(ADP_CFG["sigma_final"],   ls="--", color="gray", lw=1, alpha=0.7)
ax.axhline(ADP_CFG["sigma_initial"], ls=":",  color="gray", lw=1, alpha=0.7)
ax.set_xlabel("FL Round", fontsize=12)
ax.set_ylabel("Noise Multiplier σ", fontsize=12)
ax.set_title("Adaptive Noise Schedule Comparison\n"
             "Exponential vs Cosine vs Linear Decay (σ₀=2.0 → σ_T=0.5)",
             fontsize=13, fontweight="bold")
ax.legend(fontsize=11)
ax.annotate("ADP: concentrates noise in early rounds\n(where impact on learning is minimal)",
            xy=(1, ADP_CFG["sigma_initial"]*0.95), fontsize=9,
            bbox=dict(boxstyle="round",fc="white",ec="#e63946",alpha=0.8))

plt.tight_layout()
p = GRAPH_DIR / "fig14_schedule_comparison.png"
fig.savefig(p, dpi=300, bbox_inches="tight")
plt.show()
print(f"✅ Figure 14 saved → {p}")

# ===== CELL 12 =====
# ═══════════════════════════════════════════════════════════════════
# CELL 12 — Export Phase 4 Results Artifact
# ═══════════════════════════════════════════════════════════════════
schedule_log = scheduler.export()

graph_paths = {
    "fig12_adp_training":      str(GRAPH_DIR / "fig12_adp_training.png"),
    "fig13_3d_privacy_utility":str(GRAPH_DIR / "fig13_3d_privacy_utility.png"),
    "fig6_3d_kg_cube":         str(GRAPH_DIR / "fig6_3d_kg_cube_scatter.png"),
    "fig14_schedule_comparison":str(GRAPH_DIR / "fig14_schedule_comparison.png"),
}

phase4_results = {
    "phase":              4,
    "timestamp":          datetime.now().isoformat(),
    "adp_config":         {k: (float(v) if isinstance(v, (int,float)) else v)
                           for k,v in ADP_CFG.items()},
    "kge_config":         KGE_CFG,
    "adp_time_sec":       float(adp_time),
    "final_epsilon":      float(cumulative_epsilon),
    "epsilon_budget":     float(ADP_CFG["target_epsilon"]),
    "budget_remaining":   float(ADP_CFG["target_epsilon"] - cumulative_epsilon),
    "schedule_log":       schedule_log,
    "training_history":   adp_history,
    "final_metrics": {
        "mrr":     adp_history["mrr"][-1] if adp_history["mrr"] else 0.0,
        "hits@1":  adp_history["hits@1"][-1] if adp_history["hits@1"] else 0.0,
        "hits@3":  adp_history["hits@3"][-1] if adp_history["hits@3"] else 0.0,
        "hits@10": adp_history["hits@10"][-1] if adp_history["hits@10"] else 0.0,
        "avg_loss":adp_history["avg_loss"][-1] if adp_history["avg_loss"] else 0.0,
    },
    "phase3_baseline":    phase3["final_metrics"],
    "graph_paths":        graph_paths,
}

with open("phase4_results.json","w") as f:
    json.dump(phase4_results, f, indent=2)

print("✅ phase4_results.json written.")
summary_df = pd.DataFrame([
    ("ADP Schedule",          ADP_CFG["schedule_type"].capitalize()),
    ("σ₀ → σ_T",              f"{ADP_CFG['sigma_initial']} → {ADP_CFG['sigma_final']}"),
    ("Target ε",              f"{ADP_CFG['target_epsilon']:.1f}"),
    ("Consumed ε",            f"{cumulative_epsilon:.4f}"),
    ("Budget Remaining",      f"{ADP_CFG['target_epsilon']-cumulative_epsilon:.4f}"),
    ("Final MRR (ADP)",       f"{phase4_results['final_metrics']['mrr']:.4f}"),
    ("Phase 3 MRR (No DP)",   f"{phase3['final_metrics']['mrr']:.4f}"),
    ("MRR Δ",                 f"{phase4_results['final_metrics']['mrr'] - phase3['final_metrics']['mrr']:+.4f}"),
    ("Sim Time (s)",          f"{adp_time:.1f}"),
], columns=["Metric","Value"])
display(style_table(summary_df, "Phase 4 — Final Adaptive DP Summary"))
print("\n✅ Phase 4 complete. Load phase4_results.json in Phase 5.")
