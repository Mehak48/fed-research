#!/usr/bin/env python3
"""PHASE 04 (GPU worker) - Stage-3 tuning jobs, including the mandatory accuracy sanity gate G-B.

  python parallel/phases/phase04_tuning.py --base B --worker W --job T-fb15k237-chain --max-hours 10
  python parallel/phases/phase04_tuning.py --base B --worker W --job T-wn18rr-s2-1of2 --max-hours 10   (stage mode)

T-<ds>-chain = scripts/run_plan.py --plan tune --datasets <ds> in this worker's root: stage 0 (T1C), gate G-B (a
failure stops the chain, exit 4), stages 1-6 with the pre-registered selection after each stage. The master later
re-derives every selection from the imported runs and must obtain exactly the same values before it freezes.
T-<ds>-s<k>-<i>of<n> = one shard of tuning stage k; stage k >= 1 needs the master's release pack (selections of the
earlier stages; for k = 1 the gate G-B result PASSED).
Inputs : phase 01-02 done in this environment; the plan (phase 03); a release pack when the job needs one.
Outputs: COMPLETE run folders in <base>/workers/<W>/results/tune/runs/, a result bundle in <base>/exchange/outbox/.
Success: EXIT 0. Rerun the same command after EXIT 3 (session budget) or a disconnect: finished runs are reused, an
interrupted run resumes from its checkpoint. Next: the master imports the bundle and runs phase 05."""
from __future__ import annotations

import sys

from _cli import finish, layout, parser

from fedkge_parallel.common import EXIT_CONTRACT
from fedkge_parallel.execute import job_spec_for, run_worker_job

KINDS = ['TUNECHAIN', 'TUNESTAGE']


def main(argv=None) -> int:
    ap = parser(__doc__, worker=True, gpu=True)
    ap.add_argument("--job", required=True, help="a job id from the plan (see QUEUE_<worker>.md)")
    a = ap.parse_args(argv)
    L = layout(a)
    spec = job_spec_for(L, a.job)
    if spec["kind"] not in KINDS:
        print(f"STOP: {a.job} is a {spec['kind']} job; this entry point runs {KINDS}")
        return finish(EXIT_CONTRACT)
    return finish(run_worker_job(L, a.worker, a.job, a.device, a.max_hours, a.max_runs))


if __name__ == "__main__":
    sys.exit(main())
