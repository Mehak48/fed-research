#!/usr/bin/env python3
"""Render the Markdown tables of 06_experiment_matrix.md from experiment_matrix.csv, and write the threshold
inventory (master prompt 12) as CSV + Markdown. Keeps the document and the machine-readable files identical.
[Calculated - Phase B planning]; nothing is executed.
"""
from __future__ import annotations

import argparse
import csv
import sys

THRESHOLDS = [
    # parameter, kind, where, legacy value, revision value, handling, grid, selection rule, justification, reported in
    ("Trust anomaly threshold tau", "threshold (detection)", "revision trust.py; legacy TrustScorer",
     "0.15 on a loss-consistency score (legacy, not comparable)", "3.0 MAD units",
     "calibrated + sensitivity", "{1.5, 2, 2.5, 3, 3.5, 4, 5}",
     "smallest tau with mean benign FPR <= 5 % in clean DP FedAvg runs, tuning seed; selected after the D15 variant is fixed (D14)",
     "a detection threshold is set by its false-positive rate, not by attack outcomes", "Tables 8-9; X2, X2a"),
    ("History penalty lambda", "hyperparameter of the trust rule", "revision trust.py", "0.5 (legacy, loss-based)",
     "0.5", "fixed a priori + sensitivity", "{0, 0.25, 0.5, 1.0}", "none (fixed)",
     "kept from the paper's equation; not tuned to avoid over-fitting the defence", "Table 8; X3"),
    ("Norm bound (median norm)", "threshold (derived, data-adaptive)", "revision trust.py", "-", "on",
     "fixed design element", "on", "none", "standard robust step", "03 section 8.3"),
    ("Clipping norm C", "threshold (per-example gradient norm)", "revision dp.py", "1.0", "1.0 (swept 0.25-4)",
     "swept + selected", "{0.25, 0.5, 1, 2, 4}", "highest validation MRR at eps*=4, tuning seed; ties -> smaller C",
     "main DP utility lever; clipping fraction logged", "Table 8; T2b"),
    ("Privacy budget eps*", "operating point", "revision accountant/config", "15 (naive sum, invalid)", "4 (+1,2,8)",
     "pre-declared + full curve", "{1, 2, 4, 8} + non-private", "not selected (eps*=4 declared a priori)",
     "master prompt 7: no selection for attractive graphs", "Tables 6-7; DP1, DP2"),
    ("delta", "operating point", "revision", "1e-5", "1e-6 (+1e-5 reported)", "fixed a priori", "-", "-",
     "delta x largest client size ~0.04 (FB15k-237), ~0.025 (WN18RR); YAGO3-10 would need 1e-7", "Table 6"),
    ("Noise multiplier sigma", "derived", "revision accountant", "1.0 / 1.2 fixed", "calibrated per eps*",
     "derived by calibration", "-", "smallest sigma meeting eps* (RDP)", "not a free parameter", "Table 6"),
    ("Noise schedule shape / rho", "hyperparameter (DP)", "revision accountant", "fixed (claimed adaptive)",
     "fixed; {linear, exponential, cosine} x rho {0.25, 0.5}", "swept + selected", "6 schedules + fixed",
     "highest validation MRR at eps*=4, tuning seed; ties -> fixed", "tests the 'adaptive DP' claim (HS)",
     "Tables 5, 8; T3, DP2"),
    ("Sampling rate q / expected batch B", "hyperparameter (DP)", "revision accountant/dp", "B=256 (Opacus)",
     "B=512 fixed (design A)", "swept + selected", "q {0.02, 0.05, 0.10} (design Q); design A vs Q in T2d",
     "highest validation MRR; ties -> larger q; design ties -> Q (D11)",
     "main legitimate DP lever (MJ-17)", "Table 8; T2a, T2d"),
    ("Learning rate", "hyperparameter", "revision base.yaml", "1e-3", "1e-3", "swept + selected (DP and non-private)",
     "{1e-3, 3e-3, 1e-2}", "highest validation MRR; ties -> smaller", "symmetric tuning (MJ-19)", "Table 8; T1, T2a"),
    ("Rounds R", "hyperparameter", "revision base.yaml", "50 (P3) / 20 planned, 16 run (P4)", "100",
     "swept (DP) / early stopping (non-private)", "{50, 100}", "validation MRR; ties -> 50", "eps depends on R",
     "Table 8; T2c"),
    ("Early-stopping patience", "threshold (stopping)", "revision base.yaml", "none (last round)", "4 evaluations x 5 rounds",
     "fixed a priori", "-", "-", "non-private only; DP runs execute all R rounds (G6)", "final.json"),
    ("Dirichlet alpha", "non-IID concentration (not a threshold)", "revision partition", "relation-disjoint (ID order)",
     "{0.1, 1.0}", "all levels reported (not selected)", "{0.1, 0.5, 1.0} + IID", "none",
     "master prompt 9", "Tables 2-3, 7; N3, X1"),
    ("Minimum client size", "threshold (feasibility)", "revision partition", "-", ">= 20 % of mean and >= 1024",
     "fixed a priori + documented fallback", "fallback 10 % of mean (one dataset only)", "-",
     "avoids degenerate clients; truncation documented", "Table 2"),
    ("Trimmed-mean beta", "threshold (robust baseline)", "revision aggregators", "-", "0.2",
     "design value 0.2, or the true attacker fraction if larger (X4, f = 0.3)", "-", "-",
     "satisfies the baseline's assumption; also used in clean runs", "Table 9"),
    ("Krum f", "threshold (robust baseline)", "revision aggregators", "-", "true f (min 1)",
     "design value 2, or the true attacker count if larger", "-", "-",
     "favourable to the baseline; n > 2f+2 checked", "Table 9"),
    ("FLTrust root size", "baseline parameter", "revision base.yaml", "-", "500 from V_root", "fixed a priori", "-", "-",
     "server root data size (Cao et al. 2021 use small root sets)", "Table 9"),
    ("Attacker fraction f", "attack budget (not a threshold)", "revision attacks", "5/10/20 % (1 attacker of 5)",
     "0.2 main", "main + sensitivity", "{0.1, 0.2, 0.3}", "-", "threat-model budget", "Table 9; X4"),
    ("Attack strength s", "attack budget", "revision base.yaml", "POISON_SCALE 2.0 (simulation)", "3.0",
     "fixed a priori", "-", "-", "revision default set before any result (MN-19)", "attack.json"),
    ("Adaptive attacker margin / gamma grid", "attacker threshold", "revision attacks", "-", "0.05; [0, 20] x 81",
     "fixed a priori", "-", "-", "standard AGR-tailored search", "attack.json"),
    ("Target success cut-off k", "metric threshold", "revision evaluate", "-", "Hits@10", "fixed a priori", "-", "-",
     "conventional top-10", "Table 9"),
    ("MIA decision threshold", "metric threshold", "revision mia", "-", "swept (ROC)", "swept implicitly", "ROC",
     "-", "AUC and TPR at fixed FPR avoid choosing one threshold", "Tables 6-7 (if H3)"),
    ("One-run audit guess count", "audit parameter", "Phase B design", "-", "-", "fixed a priori",
     "{100, 300, 1000} guesses (proposed)",
     "largest lower bound over the three, each at confidence 1 - 0.05/3 (Bonferroni)",
     "choosing the count after seeing scores would inflate the bound", "Tables 6-7 (if H3); M1"),
    ("MIA audit pool size", "audit parameter", "Phase B design", "-", "-", "fixed a priori",
     "10 % of each client's training triples; inclusion probability 1/2 (proposed)", "-",
     "about 5 % of training data withheld in expectation", "Tables 6-7 (if H3); M1"),
    ("Integrity tamper probability", "experiment factor", "Phase B design", "-", "-", "experiment factor",
     "{0.01, 0.1}", "-", "corruption-in-transit model", "Table 10; I2"),
    ("Selection tie tolerance", "selection rule threshold", "revision selection_rules.yaml", "-", "0.0",
     "fixed a priori", "0.002 MRR (proposed)", "-", "avoids choosing on noise; stated before use", "selection files"),
]


def md(s):
    return str(s).replace("|", "/")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--matrix", required=True)
    ap.add_argument("--out-matrix-md", required=True)
    ap.add_argument("--out-threshold-csv", required=True)
    ap.add_argument("--out-threshold-md", required=True)
    a = ap.parse_args(argv)
    rows = list(csv.DictReader(open(a.matrix)))
    lines = ["| Block | Stage | Tier | Datasets | Cells / dataset | Seeds (full → reduced) | Runs (full → reduced) | "
             "Factors | Answers | Tables |", "|---|---|---|---|---|---|---|---|---|---|"]
    for r in rows:
        red = r["reduced_seed_set"]
        seeds = r["seed_set"] if red == r["seed_set"] else f'{r["seed_set"]} → {red}'
        cells = r["cells_per_dataset"] if r["reduced_cells"] == r["cells_per_dataset"] else \
            f'{r["cells_per_dataset"]} → {r["reduced_cells"]}'
        runs = r["runs_total"] if r["runs_total"] == r["reduced_runs_total"] else \
            f'{r["runs_total"]} → {r["reduced_runs_total"]}'
        lines.append("| " + " | ".join(md(x) for x in (r["block"], r["stage"], r["tier"], r["datasets"], cells, seeds,
                                                     runs, r["factors"], r["answers"], r["tables"])) + " |")
    open(a.out_matrix_md, "w").write("\n".join(lines) + "\n")
    hdr = ["parameter", "kind", "where", "legacy_value", "revision_value", "handling", "grid", "selection_rule",
           "justification", "reported_in"]
    with open(a.out_threshold_csv, "w", newline="") as f:
        w = csv.writer(f); w.writerow(hdr); w.writerows(THRESHOLDS)
    tl = ["| Parameter | Kind | Legacy → revision | Handling | Grid | Selection rule | Reported in |",
          "|---|---|---|---|---|---|---|"]
    for t in THRESHOLDS:
        tl.append("| " + " | ".join(md(x) for x in (t[0], t[1], f"{t[3]} → {t[4]}", t[5], t[6], t[7], t[9])) + " |")
    open(a.out_threshold_md, "w").write("\n".join(tl) + "\n")
    print(len(rows), "blocks;", len(THRESHOLDS), "threshold-inventory rows")
    return 0


if __name__ == "__main__":
    sys.exit(main())
