"""Shared paths, imports of the unchanged core, atomic file helpers and exit codes."""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, Iterable, Optional

REPO = Path(__file__).resolve().parents[2]                  # .../revision
for _p in (REPO / "01_fedkge_core", REPO / "scripts"):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from fedkge.io import (IntegrityError, Paths, RunDir, code_hash, read_json, sha256_file, utc_now,  # noqa: E402
                       write_csv, write_json)

CONFIG_DIR = REPO / "10_configs"
DATASETS = ("fb15k237", "wn18rr", "codex_m")
RESEARCH_TIERS = ("tune", "final")
BUNDLE_SCHEMA = 1
PACK_SCHEMA = 1

# exit codes: identical meaning to scripts/run_plan.py, plus 7 for a violated input contract
EXIT_OK, EXIT_FAILED, EXIT_BUDGET, EXIT_GATE, EXIT_ENV, EXIT_MANIFEST, EXIT_CONTRACT = 0, 1, 3, 4, 5, 6, 7
EXIT_TEXT = {0: "COMPLETE", 1: "RUN FAILURES", 3: "PAUSED (session budget) - run the same command again",
             4: "GATE G-B FAILED", 5: "ENVIRONMENT MISMATCH", 6: "MANIFEST MISMATCH", 7: "INPUT CONTRACT VIOLATED"}


def tiers_for(mode: str) -> Dict[str, str]:
    """Tier of each plan. 'research' = the approved study; 'smoke'/'dev' = software checks (never evidence)."""
    if mode == "research":
        return {"tune": "tune", "main": "final", "legacy": "final"}
    if mode in ("smoke", "dev"):
        return {"tune": mode, "main": mode, "legacy": mode}
    raise ValueError(f"unknown mode {mode!r}")


def mode_of_tier(tier: str) -> str:
    return "research" if tier in RESEARCH_TIERS else tier


class Layout:
    """One shared folder (e.g. MyDrive/FedKGE) seen by every environment, or copied between them by hand.

    <base>/master/results            the master store: the ONLY results root that is analysed
    <base>/workers/<name>/results    one private results root per worker (never written by anyone else)
    <base>/exchange/registry         worker registrations (phase 00)
    <base>/exchange/plan             the job plan and the per-worker queues (phase 03)
    <base>/exchange/outbox           result bundles, worker -> master (zip + .sha256 sidecar)
    <base>/exchange/packs            release packs, master -> workers (zip + .sha256 sidecar)
    """

    def __init__(self, base: str | Path):
        self.base = Path(base).expanduser().resolve()

    @property
    def master(self) -> Path: return self.base / "master" / "results"
    def worker(self, name: str) -> Path: return self.base / "workers" / safe_name(name) / "results"
    @property
    def exchange(self) -> Path: return self.base / "exchange"
    @property
    def registry(self) -> Path: return self.exchange / "registry"
    @property
    def plan_dir(self) -> Path: return self.exchange / "plan"
    @property
    def outbox(self) -> Path: return self.exchange / "outbox"
    @property
    def packs(self) -> Path: return self.exchange / "packs"
    @property
    def plan_file(self) -> Path: return self.plan_dir / "PLAN.json"

    def ensure(self) -> "Layout":
        for d in (self.master, self.registry, self.plan_dir, self.outbox, self.packs):
            d.mkdir(parents=True, exist_ok=True)
        return self


def safe_name(name: str) -> str:
    ok = "".join(c if (c.isalnum() or c in "-_.") else "_" for c in str(name))
    if not ok or ok.startswith("."):
        raise ValueError(f"invalid name {name!r}")
    return ok


def stamp() -> str:
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def canonical_hash(obj: Any) -> str:
    return sha256_bytes(json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode())


def atomic_write_bytes(path: Path, data: bytes) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def atomic_write_text(path: Path, text: str) -> None:
    atomic_write_bytes(path, text.encode())


def atomic_write_json(path: Path, obj: Any) -> None:
    atomic_write_text(path, json.dumps(obj, indent=1, sort_keys=True, default=str) + "\n")


def atomic_replace_dir(src: Path, dst: Path) -> None:
    """Move a fully written directory into place (same filesystem): readers see all of it or nothing."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        raise FileExistsError(dst)
    os.replace(src, dst)


def tree_hashes(root: Path, include) -> Dict[str, str]:
    out = {}
    for p in sorted(Path(root).rglob("*")):
        if p.is_file() and include(p):
            out[str(p.relative_to(root)).replace(os.sep, "/")] = sha256_file(p)
    return out


class JobLog:
    """Timestamped console + file log of one phase invocation."""

    def __init__(self, path: Optional[Path]):
        self.path = Path(path) if path else None
        if self.path:
            self.path.parent.mkdir(parents=True, exist_ok=True)

    def __call__(self, *msg: Any) -> None:
        line = f"[{_dt.datetime.now(_dt.timezone.utc).strftime('%H:%M:%S')}] " + " ".join(str(m) for m in msg)
        print(line, flush=True)
        if self.path:
            with open(self.path, "a") as fh:
                fh.write(line + "\n")


def copy_file(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def read_json_or(path: Path, default: Any) -> Any:
    return read_json(path) if Path(path).exists() else default


def frozen_manifest() -> Dict:
    """The frozen manifest after verify_frozen (configs + core code unchanged since the freeze)."""
    from fedkge.manifest import verify_frozen
    return verify_frozen(CONFIG_DIR)


def environment_signature(device: Optional[str]) -> Dict:
    """The environment-lock signature (fields of 10_configs/gates.yaml), computed by the core."""
    from fedkge.config import load_yaml
    from fedkge.gates import environment_signature as _sig
    fields = load_yaml(CONFIG_DIR / "gates.yaml")["environment_lock"]["fields"]
    sig = _sig(device)
    return {k: sig[k] for k in fields}


def signature_key(sig: Dict) -> str:
    return " | ".join(f"{k}={sig.get(k)}" for k in sorted(sig))


__all__ = ["REPO", "CONFIG_DIR", "DATASETS", "RESEARCH_TIERS", "Layout", "Paths", "RunDir", "IntegrityError",
           "read_json", "write_json", "write_csv", "sha256_file", "code_hash", "utc_now", "tiers_for",
           "mode_of_tier", "atomic_write_bytes", "atomic_write_json", "atomic_write_text", "atomic_replace_dir",
           "canonical_hash", "sha256_bytes", "stamp", "safe_name", "tree_hashes", "JobLog", "copy_file",
           "read_json_or", "frozen_manifest", "environment_signature", "signature_key"] + \
          [n for n in dir() if n.startswith("EXIT_")] + ["Iterable"]
