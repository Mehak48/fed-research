# Table 8 — Stage 3 selection (T2c); validation only

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| dataset | train.rounds_max | val_mrr_mean | chosen | tied_within_tolerance |
|---|---|---|---|---|
| codex_m | 50 | 0.002018 | True | True |
| codex_m | 100 | 0.002015 | False | True |
| fb15k237 | 50 | 0.002599 | True | True |
| fb15k237 | 100 | 0.002598 | False | True |
| wn18rr | 50 | 0.0008418 | True | True |
| wn18rr | 100 | 0.0008412 | False | True |
