#!/usr/bin/env python3
"""Compile the recorded experiments into the paper material (Tables 1-14, MIA and size-third diagnostics, privacy and
robustness summary, compute accounting, reproducibility record, figure manifest and a results draft with marked
placeholders for everything that does not exist yet).

  python scripts/build_report.py --tier final [--results R] [--with-figures]   -> <R>/final/reports/ (+ figures/)
  python scripts/build_report.py --tier smoke --with-figures                   -> watermarked software check
  python scripts/build_report.py --fixture --out DIR --with-figures             -> FIXTURE software check

Safe to run at any time: partial results give partial tables and PENDING placeholders, never invented numbers.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from _common import Manifest, git_commit
from analyze_results import make_context


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results"); ap.add_argument("--tier", default="final", choices=["final", "smoke"])
    ap.add_argument("--fixture", action="store_true"); ap.add_argument("--out")
    ap.add_argument("--with-figures", action="store_true")
    a = ap.parse_args(argv)
    if a.fixture and not a.out:
        ap.error("--fixture needs --out (fixture outputs never go into a results root)")
    from fedkge.reporting import run_analysis, run_figures, run_report
    ctx = make_context(a)
    base = Path(a.out) if a.out else ctx.paths.base
    hyp = run_analysis(ctx, base / "analysis")
    fm = run_figures(ctx, hyp, base / "figures") if a.with_figures else None
    idx = run_report(ctx, hyp, base / "reports", fm, extra_record={"git_commit": git_commit()})
    print(json.dumps({"reports": str(base / "reports"), "draft": idx["draft"], "figures": str(fm) if fm else None},
                     indent=1))
    if not a.fixture:
        man = Manifest(ctx.root, f"report_{a.tier}"); man.output(base / "reports"); man.close("COMPLETE")
    return 0


if __name__ == "__main__":
    sys.exit(main())
