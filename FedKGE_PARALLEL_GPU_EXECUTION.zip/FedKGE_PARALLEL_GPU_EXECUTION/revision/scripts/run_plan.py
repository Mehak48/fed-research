#!/usr/bin/env python3
"""Runs the approved experiment schedule in its pre-registered order (Phase B 06; decisions D13-D14, B2-B5).

  Stage 3 - tuning chain (tune tier, tuning seed 1001; validation metrics only):
    python scripts/run_plan.py --plan tune --tier tune --datasets fb15k237 wn18rr codex_m --device cuda [--max-hours 10]
  freeze the selections (gate G-C), then Stage 4 in priority order (final tier, reduced profile):
    python scripts/freeze_selections.py
    python scripts/run_plan.py --plan confirm --tier final --datasets fb15k237 wn18rr codex_m --device cuda \
           [--priorities 1 2] [--max-hours 10]
  software check of every block on the real smoke subsets (gate G-A; NEVER evidence):
    python scripts/run_plan.py --plan tune --tier smoke --datasets fb15k237 wn18rr codex_m
    python scripts/run_plan.py --plan confirm --tier smoke --datasets fb15k237 wn18rr codex_m

Tuning stages (selections after every stage; nothing is re-drawn or re-run to obtain a better result):
  0  T1C (centralised non-private, fully trained) -> select T1_central -> GATE G-B (10_configs/gates.yaml). On the
     tune tier a failure STOPS Stage 3 here and writes <tier>/gates/SANITY_GATE_REPORT.md.
  1  T1F, T2a -> T1_nonprivate, T2a     2  T2b -> T2b     3  T2c -> T2c     4  T2d -> T2d     5  T3 -> T3
  6  TAU (the T3 winner, reused) -> tau rule D14 with the pre-declared fallback B3 -> D10 utility flag (B5)
Stage 4 runs the reduced profile only (B2); Stage 5 is deferred (B2) and refused here.

Safety: the frozen manifest is checked first (configs and core code unchanged since the freeze), the environment of
every (tier, dataset) is locked on the tune and final tiers (B13, B16), every expanded entry must be a manifest
cell, runs are executed in priority order, no new run starts after --max-hours / --max-runs (the rest is PENDING,
never COMPLETE), and PROGRESS.md / PROGRESS_cells.csv in the results root are rebuilt from the run folders.
Exit codes: 0 complete, 1 run failures, 3 stopped by the session budget (rerun to continue), 4 gate G-B failed,
5 environment mismatch, 6 manifest mismatch.
"""
from __future__ import annotations

import argparse
import json
import sys
import time

import pandas as pd

from _common import CONFIG_DIR, Manifest, results_root
from fedkge.analysis import collect
from fedkge.config import load_yaml
from fedkge.data import load_artifact
from fedkge.gates import (EnvironmentMismatch, check_environment_lock, d10_trigger, sanity_gate,
                          write_gate_report)
from fedkge.io import IntegrityError, Paths, read_json, write_json
from fedkge.manifest import check_entries_against_manifest, resolve, verify_frozen, write_progress
from fedkge.partition import build_partition, load_partition
from fedkge.runner import expand, partitions_needed, run_entries, write_index
from fedkge.selection import select_rule, select_tau

TUNE_RULES = {0: ["T1_central"], 1: ["T1_nonprivate", "T2a"], 2: ["T2b"], 3: ["T2c"], 4: ["T2d"], 5: ["T3"],
              6: ["tau"]}
RESEARCH_TIERS = ("tune", "final")


class BudgetStop(Exception):
    """The session budget (--max-hours / --max-runs) was reached; the remaining runs are PENDING."""


class GateStop(Exception):
    """Gate G-B failed on a tier that enforces it."""


def ensure_partitions(entries, paths: Paths, man: Manifest) -> int:
    """Build the partitions the expanded runs need and that do not exist yet. Returns the number built."""
    built, data = 0, {}
    for need in partitions_needed(entries):
        ds = need["dataset"]
        if ds not in data:
            try:
                data[ds] = load_artifact(paths.p1(ds))
            except Exception as e:
                raise SystemExit(f"Phase 1 artifact for {ds} is missing at {paths.p1(ds)} ({e!r}); "
                                 f"run scripts/build_artifacts.py --tier {paths.tier} first")
        d = data[ds]
        try:
            load_partition(paths.p2(ds), need["spec"], need["seed"], d.content_hash)
        except IntegrityError:
            build_partition(d.train, d.num_relations, need["spec"], need["seed"], paths.p2(ds), d.content_hash)
            built += 1
            man.output(paths.p2(ds))
    return built


def order_entries(entries, datasets):
    """Priority, then dataset (in the order requested), then seed, then matrix order (stable)."""
    rank = {d: i for i, d in enumerate(datasets)}
    return sorted(entries, key=lambda e: (int(e.get("priority", 0)), rank.get(e["dataset"], 99), int(e["seed"])))


def run_stage(phase, matrix, tier, tier_file, paths, datasets, stages, profile, device, man, frozen, plan_name,
              priorities=None, deadline=None, max_runs=None) -> pd.DataFrame:
    entries = expand(phase, CONFIG_DIR, paths, tier, datasets, stages, tier_file=tier_file, profile=profile,
                     matrix_name=matrix)
    if not entries:
        print(f"stages {stages}: no runs"); return pd.DataFrame()
    if frozen is not None:                         # research tiers: exactly the approved cells, nothing else
        info = check_entries_against_manifest(entries, frozen, plan_name, require_all=(plan_name == "main"))
        man.rec.setdefault("manifest_checks", []).append({**info, "stages": stages})
    nb = ensure_partitions(entries, paths, man)
    write_index(paths, phase, entries)             # the full index, so progress can resolve every cell
    if frozen is not None and plan_name == "main":
        write_json(paths.base / "manifest" / "resolved_main.json", {"cells": resolve(entries, frozen, "main")})
    todo = [e for e in entries if priorities is None or int(e.get("priority", 0)) in priorities]
    todo = order_entries(todo, datasets)
    n_unique = len({e["run_id"] for e in todo})
    print(f"\n##### {matrix} stages {stages}{' priorities ' + str(priorities) if priorities else ''}: {len(todo)} "
          f"entries, {n_unique} unique runs, {nb} partitions built")
    st = run_entries(todo, paths, device, deadline=deadline, max_runs=max_runs)
    if len(st):
        pr = {e["run_id"]: e.get("priority", 0) for e in todo}
        st["stages"] = str(stages); st["priority"] = st["run_id"].map(pr)
    failed = st[st["status"].astype(str).str.startswith("FAILED")] if len(st) else st
    if len(failed):
        raise SystemExit(f"stages {stages}: {len(failed)} run(s) failed; nothing is selected or continued:\n"
                         f"{failed.to_string()}")
    if len(st) and (st["status"] == "PENDING").any():
        raise BudgetStop(f"session budget reached: {int((st['status'] == 'PENDING').sum())} run(s) of stages "
                         f"{stages} not started; rerun the same command to continue")
    return st


def tune_select(stage, paths, rules, gates, seeds, datasets, man) -> dict:
    runs, probs = collect(paths, ["tune"])
    if len(probs):
        stage_blocks = set()
        for name in TUNE_RULES[stage]:
            stage_blocks |= set(rules[name].get("blocks", [])) if name != "tau" else {rules["tau"]["source_block"]}
        bad = probs[probs["block"].isin(stage_blocks) & probs["dataset"].isin(datasets)]
        if len(bad):
            raise SystemExit(f"stage {stage}: candidate runs are missing/stale; selection refused:\n{bad.to_string()}")
    runs = runs[runs["dataset"].isin(datasets)] if len(runs) else runs
    out = {}
    if stage < 6:
        for name in TUNE_RULES[stage]:
            sel = select_rule(runs, name, rules, seeds, paths)
            out[name] = {ds: sel[ds][name] for ds in datasets if ds in sel and name in sel[ds]}
        if stage == 0:                                                     # gate G-B, automatic prerequisite
            res = sanity_gate(runs, read_json(paths.selection("tuning")), gates["sanity_gate"], paths.tier, datasets)
            files = write_gate_report(res, paths.base / "gates")
            man.output(files["json"]); man.output(files["md"])
            out["sanity_gate"] = {ds: d.get("status") for ds, d in res["datasets"].items()}
            print(files["md"].read_text())
            if res["enforced"] and not res["all_passed"]:
                raise GateStop(f"gate G-B failed: {out['sanity_gate']}; Stage 3 stopped. Diagnostic report: "
                               f"{files['md']}")
            if not res["all_passed"]:
                man.warn(f"gate G-B not passed on the {paths.tier} tier (not enforced here): {out['sanity_gate']}")
        return out
    # stage 6: tau (D14) with the pre-declared fallback (B3) from the clean TAU run's logged scores
    src = runs[runs["block"] == rules["tau"]["source_block"]]
    trust_by_ds = {}
    for ds, g in src.groupby("dataset"):
        trust_by_ds[ds] = pd.concat([pd.read_csv(paths.run(rid) / "trust_rounds.csv") for rid in g["run_id"]],
                                    ignore_index=True)
    sel = select_tau(trust_by_ds, rules, paths)
    out["tau"] = {ds: {"tau": sel[ds]["tau"]["aggregation"]["tau"], "status": sel[ds]["tau"]["status"],
                       "benign_fpr": sel[ds]["tau"]["benign_fpr_at_selected_tau"]} for ds in trust_by_ds}
    for ds, t in out["tau"].items():
        if t["status"] != "RULE_MET":
            man.warn(f"tau rule NOT met on {ds}: largest grid tau {t['tau']} used, benign FPR {t['benign_fpr']:.3f} "
                     f"> {rules['tau']['max_benign_fpr']} (owner decision B3; labelled in every report)")
    d10 = d10_trigger(runs, gates["d10_trigger"], paths.tier)
    if d10.get("status") != "NOT_EVALUATED" or not (paths.base / "gates" / "d10_trigger.json").exists():
        write_json(paths.base / "gates" / "d10_trigger.json", d10)
    out["d10_trigger"] = d10.get("label", d10.get("status"))
    if d10.get("triggered"):
        man.warn(d10["label"])
    return out


def require_frozen_selections(paths: Paths, datasets) -> None:
    """Stage 4 needs the Stage-3 selections frozen by scripts/freeze_selections.py (gate G-C) for every dataset."""
    fz = paths.base / "selection" / "FROZEN.json"
    if not paths.selection("tuning").exists() or not fz.exists():
        raise SystemExit(f"no frozen selections in {paths.base / 'selection'}: complete Stage 3 and run "
                         "scripts/freeze_selections.py first (gate G-C)")
    sel = read_json(paths.selection("tuning"))
    missing = [ds for ds in datasets if ds not in sel or "tau" not in sel[ds]]
    if missing:
        raise SystemExit(f"frozen selections lack datasets {missing}: finish their Stage 3 and freeze again")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--plan", required=True, choices=["tune", "confirm"])
    ap.add_argument("--results"); ap.add_argument("--tier", required=True, choices=["smoke", "dev", "tune", "final"])
    ap.add_argument("--tier-file", help="tier settings file (default = --tier)")
    ap.add_argument("--datasets", nargs="+", required=True)
    ap.add_argument("--stages", nargs="*", type=int, help="tune: default 0-6 in order; confirm: default 4")
    ap.add_argument("--profile", choices=["reduced", "full"], default="reduced",
                    help="confirm plan only; the approved budget (B2) is the reduced profile")
    ap.add_argument("--priorities", nargs="*", type=int, help="confirm plan: run only these execution priorities "
                    "(1-7; 4 = legacy replicas, run by scripts/run_legacy_blocks.py)")
    ap.add_argument("--max-hours", type=float, help="start no new run after this many hours (session limits)")
    ap.add_argument("--max-runs", type=int, help="start at most this many new runs")
    ap.add_argument("--device")
    a = ap.parse_args(argv)
    if a.plan == "tune" and a.tier == "final":
        ap.error("the tuning chain never runs on the final tier (D13)")
    if a.plan == "confirm" and a.tier == "tune":
        ap.error("the confirmatory matrix runs on the final tier (or smoke/dev for software checks)")
    if a.plan == "confirm" and a.stages and any(s != 4 for s in a.stages):
        ap.error("Stage 5 is deferred by owner decision B2; only stage 4 is run")
    if a.plan == "confirm" and a.tier == "final" and a.profile != "reduced":
        ap.error("the approved budget (owner decision B2) is the reduced profile")
    root = results_root(a.results)
    paths = Paths(root, a.tier)
    man = Manifest(root, f"plan_{a.plan}_{a.tier}")
    rules = load_yaml(CONFIG_DIR / "selection_rules.yaml")
    gates = load_yaml(CONFIG_DIR / "gates.yaml")
    tier_cfg = load_yaml(CONFIG_DIR / "tiers" / f"{a.tier_file or a.tier}.yaml")
    deadline = time.time() + 3600 * a.max_hours if a.max_hours else None
    t0 = time.time()
    statuses, selections = [], {}
    frozen = None
    try:
        if a.tier in RESEARCH_TIERS:
            try:
                frozen = verify_frozen(CONFIG_DIR)
            except IntegrityError as e:
                man.close("MANIFEST_MISMATCH", reason=str(e)); print(f"STOP: {e}"); return 6
            try:
                env = check_environment_lock(paths, a.datasets, a.device, gates["environment_lock"],
                                             session_note=f"run_plan {a.plan}")
                man.rec["environment_lock"] = env
            except EnvironmentMismatch as e:
                man.close("ENVIRONMENT_MISMATCH", reason=str(e)); print(f"STOP: {e}"); return 5
        if a.plan == "tune":
            seeds = list(tier_cfg["seeds"])
            if a.tier == "tune" and seeds != list(rules["tuning_seeds"]):
                raise SystemExit(f"tune tier seeds {seeds} differ from the pre-registered tuning seeds "
                                 f"{rules['tuning_seeds']}")
            for s in (a.stages if a.stages else sorted(TUNE_RULES)):
                statuses.append(run_stage("tune", "tune", a.tier, a.tier_file, paths, a.datasets, [s], "full",
                                          a.device, man, frozen, "tune", deadline=deadline, max_runs=a.max_runs))
                selections[s] = tune_select(s, paths, rules, gates, seeds, a.datasets, man)
                print(f"stage {s} selections: {json.dumps(selections[s], default=str)}")
        else:
            if a.tier == "final":
                require_frozen_selections(paths, a.datasets)
            statuses.append(run_stage("final", "confirm", a.tier, a.tier_file, paths, a.datasets, [4], a.profile,
                                      a.device, man, frozen, "main", priorities=a.priorities, deadline=deadline,
                                      max_runs=a.max_runs))
    except GateStop as e:
        _finish(root, frozen, man, statuses, "GATE_G-B_FAILED", reason=str(e), seconds=time.time() - t0)
        print(f"STOP: {e}"); return 4
    except BudgetStop as e:
        _finish(root, frozen, man, statuses, "PARTIAL_SESSION_BUDGET", reason=str(e), seconds=time.time() - t0)
        print(f"PAUSED: {e}"); return 3
    except SystemExit as e:
        _finish(root, frozen, man, statuses, "STOPPED", reason=str(e), seconds=time.time() - t0)
        raise
    st = pd.concat(statuses, ignore_index=True) if statuses else pd.DataFrame()
    stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    out = root / a.tier / f"plan_{a.plan}_status_{stamp}.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    st.to_csv(out, index=False); man.output(out)
    if selections:
        man.output(paths.selection("tuning"))
    _finish(root, frozen, man, statuses, "COMPLETE", n_runs=int(len(st)), seconds=time.time() - t0,
            status_counts=st["status"].value_counts().to_dict() if len(st) else {}, selections=selections)
    print(st["status"].value_counts().to_string() if len(st) else "no runs")
    return 0


def _finish(root, frozen, man, statuses, status, **extra):
    if frozen is not None:
        try:
            extra["progress"] = write_progress(root, frozen)
        except Exception as e:                   # progress is a view; never let it hide the stage's own outcome
            man.warn(f"progress view not written: {e!r}")
    man.close(status, **extra)


if __name__ == "__main__":
    sys.exit(main())
