"""The frozen experiment manifest and manifest-based completion tracking (final package, owner decision B2).

WHAT IS FROZEN. Every approved cell of the research schedule, built from 10_configs only (no results):
  tune    Stage 3 tuning chain, tune tier, tuning seed 1001: 114 cells = 99 unique runs (15 cells re-state the
          previous stage's winner and reuse its run by construction)
  main    Stage 4 confirmatory matrix, final tier, reduced profile: 756 cells = 756 unique runs (726 if Stage 3
          selects the fixed noise schedule, because DP2 then equals DP1 at eps* = 4 and R1q equals R1p; HS is then
          'not testable', as pre-registered)
  legacy  L1-L4 legacy replicas (p3 / p4 blocks, FB15k-237, S5): 30 cells = 30 runs
  Stage 5 is deferred (B2) and is not part of the manifest.
Each cell has a stable cell_id (from plan, block, dataset, seed and grid point), its priority, the hypotheses or
tables it feeds, and its output folder pattern <results>/<tier>/runs/<run_id>/. Cells whose configuration does not
depend on a Stage-3 selection carry their run_id already; the others are resolved after freeze_selections.

WHY CELLS, NOT ONLY RUN IDS. A run_id is the hash of the complete configuration, so it exists only once the Stage-3
selections are frozen. The manifest therefore freezes the cells; resolve() maps each cell to exactly one run_id with
the frozen selections, and execution refuses any expanded entry that is not a manifest cell (and the reverse).

COMPLETION TRACKING. progress() derives the status of every cell from the run folders themselves (status.json,
final.json and the current code hash), never from a separate ledger, so a disconnected session can neither erase a
completed run nor make an incomplete one look complete. Its outputs are written atomically.
"""
from __future__ import annotations

import copy
import hashlib
import json
import tempfile
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd

from .config import get_dotted, load_yaml, run_id, validate
from .io import IntegrityError, Paths, RunDir, code_hash, read_json, utc_now, write_csv, write_json

MANIFEST_VERSION = 1
DATASETS = ["fb15k237", "wn18rr", "codex_m"]
LEGACY_BLOCKS = {"p3": ["R3_legacy", "R3_fixed"],
                 "p4": ["R4_legacy", "L1_legacy", "L2_trainer_fixed", "L3_accounting_fixed"]}
LEGACY_NAME = {"R3_legacy": "L1", "R3_fixed": "L2", "R4_legacy": "L3", "L1_legacy": "L4a (legacy mechanism)",
               "L2_trainer_fixed": "L4b (trainer fixed)", "L3_accounting_fixed": "L4c (formal accounting)"}
APPROVED = {"tune": {"cells": 114, "unique_runs": 99}, "main": {"cells": 756, "unique_runs": 756},
            "legacy": {"cells": 30, "unique_runs": 30}}
REUSE_BLOCKS = {"T2b0": "T2a winner", "T2c0": "T2b winner", "T2d0": "T2c winner", "T30": "T2d winner",
                "TAU": "T3 winner (the complete-method DP configuration with FedAvg, clean)"}
# what each block is for (Phase B 06 sections 2-5; 03 section 13). 'H*' = pre-registered hypothesis families.
ROLES = {
    "T1C": "Stage 3: centralised non-private settings; gate G-B (sanity)", "T1F": "Stage 3: FedAvg non-private settings",
    "T2a": "Stage 3: q x lr", "T2b": "Stage 3: clip", "T2b0": "Stage 3: clip C = 1 (reuse)", "T2c": "Stage 3: R = 50",
    "T2c0": "Stage 3: R = 100 (reuse)", "T2d": "Stage 3: design A", "T2d0": "Stage 3: design Q (reuse)",
    "T3": "Stage 3: noise schedules", "T30": "Stage 3: fixed schedule (reuse)", "TAU": "Stage 3: tau rule source (reuse)",
    "N1": "H1 denominator; Tables 3-4", "N2": "federation cost; Tables 3-5", "N3": "heterogeneity (descriptive)",
    "DP1": "HS fixed arm (eps* = 4); privacy-utility curve", "DP2": "H2 / H2b clean FedAvg reference; HS s* arm",
    "DP3": "DP-cost decomposition (descriptive)", "R1": "robust baselines, clean (descriptive)",
    "R1p": "H1 numerator; H2 / H2b complete method, clean", "R1q": "schedule ablation inside the method (descriptive)",
    "R2": "H2 FedAvg under attack", "R2a": "H2 FedAvg, adaptive attack", "R3": "H2 complete method under attack",
    "R3a": "H2 complete method, adaptive attack", "R4": "robust baselines under attack (descriptive)",
    "R5": "trust without DP (descriptive)", "R5a": "trust without DP, adaptive (descriptive)",
    "I1": "integrity overhead (descriptive)", "I2": "corruption in transit, verification on vs off (descriptive)",
    "M1": "H3 membership-inference audit", "R3_legacy": "L1 legacy replica (Table 13)",
    "R3_fixed": "L2 legacy replica (Table 13)", "R4_legacy": "L3 legacy replica (Table 13)",
    "L1_legacy": "L4 ladder (Table 13)", "L2_trainer_fixed": "L4 ladder (Table 13)",
    "L3_accounting_fixed": "L4 ladder (Table 13)"}
PRIORITY_LEGACY = 4


def _sub(obj, ds: str):
    if isinstance(obj, dict):
        return {k: _sub(v, ds) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_sub(v, ds) for v in obj]
    return obj.replace("{dataset}", ds) if isinstance(obj, str) else obj


def cell_key(plan: str, block: str, dataset: str, seed: int, name: str) -> str:
    return f"{plan}|{block}|{dataset}|s{int(seed)}|{name}"


def cell_id(key: str) -> str:
    return "C" + hashlib.sha256(key.encode()).hexdigest()[:12]


def _canonical_hash(obj) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()


def _file_hashes(config_dir: Path) -> Dict[str, str]:
    out = {}
    for p in sorted(Path(config_dir).rglob("*.yaml")):
        if "manifest" in p.relative_to(config_dir).parts:
            continue
        out[str(p.relative_to(config_dir))] = hashlib.sha256(p.read_bytes()).hexdigest()
    return out


def _placeholder_selection(schedule_fixed: bool) -> Dict:
    """Placeholder selections used ONLY to count unique runs while building the manifest (never written to a
    results root, never used by a run)."""
    sch = {"shape": "fixed", "rho": 1.0} if schedule_fixed else {"shape": "cosine", "rho": 0.5}
    return {ds: {"T1_nonprivate": {"train": {"lr": 0.001, "batch_size": 512}},
                 "T1_central": {"train": {"lr": 0.001, "batch_size": 512}},
                 "T2a": {"dp": {"q": 0.05}, "train": {"lr": 0.003}}, "T2b": {"dp": {"clip": 1.0}},
                 "T2c": {"train": {"rounds_max": 100}}, "T2d": {"dp": {"sampling": "common_rate"}},
                 "T3": {"dp": {"schedule": sch}}, "tau": {"aggregation": {"tau": 3.0}}} for ds in DATASETS}


def _expand_plan(plan: str, config_dir: Path, base: Path, symbolic: bool) -> List[Dict]:
    from .runner import expand
    if plan == "tune":
        return expand("tune", config_dir, Paths(base, "tune"), "tune", DATASETS, symbolic=symbolic,
                      profile="full", matrix_name="tune")
    if plan == "main":
        return expand("final", config_dir, Paths(base, "final"), "final", DATASETS, [4], symbolic=symbolic,
                      profile="reduced", matrix_name="confirm")
    if plan == "legacy":
        out = []
        for phase, blocks in LEGACY_BLOCKS.items():
            out += expand(phase, config_dir, Paths(base, "final"), "final", ["fb15k237"], None, blocks,
                          symbolic=symbolic)
        return out
    raise ValueError(plan)


def _unique_runs_with(plan: str, config_dir: Path, schedule_fixed: bool) -> int:
    with tempfile.TemporaryDirectory() as tmp:
        for tier in ("tune", "final"):
            d = Path(tmp) / tier / "selection"
            d.mkdir(parents=True)
            (d / "tuning.json").write_text(json.dumps(_placeholder_selection(schedule_fixed)))
        return len({e["run_id"] for e in _expand_plan(plan, config_dir, Path(tmp), symbolic=False)})


def build_manifest(config_dir: Path) -> Dict:
    """Build the manifest from the configs (deterministic; no results, no selections)."""
    config_dir = Path(config_dir)
    hyp = config_dir / "hypotheses.yaml"
    cells, plans = [], {}
    with tempfile.TemporaryDirectory() as tmp:
        for plan in ("tune", "main", "legacy"):
            entries = _expand_plan(plan, config_dir, Path(tmp), symbolic=True)
            tier = "tune" if plan == "tune" else "final"
            for e in entries:
                key = cell_key(plan, e["block"], e["dataset"], e["seed"], e["name"])
                rid = None
                if not e["placeholders"]:                      # fully determined now: freeze its run identity too
                    rid = run_id(validate(copy.deepcopy(e["cfg"])))
                prio = 0 if plan == "tune" else (PRIORITY_LEGACY if plan == "legacy" else int(e["priority"]))
                if plan == "main" and prio not in range(1, 8):
                    raise IntegrityError(f"{key}: Stage-4 cell without an execution priority 1-7")
                cells.append({
                    "cell_id": cell_id(key), "cell_key": key, "plan": plan, "tier": tier, "phase": e["phase"],
                    "stage": int(e["stage"]) if plan != "legacy" else 4, "priority": prio, "block": e["block"],
                    "phase_b_block": LEGACY_NAME.get(e["block"], e["block"]), "dataset": e["dataset"],
                    "seed": int(e["seed"]), "name": e["name"], "grid_point": _sub(e["grid_point"], e["dataset"]),
                    "role": ROLES.get(e["block"], ""),
                    "reuses": REUSE_BLOCKS.get(e["block"]) if plan == "tune" else None,
                    "coincides_if_fixed_schedule": {"DP2": "DP1 at eps* = 4", "R1q": "R1p"}.get(e["block"])
                    if plan == "main" else None,
                    "depends_on_selections": e["placeholders"], "run_id": rid,
                    "output": f"<results>/{tier}/runs/{rid or '<run_id resolved after freeze_selections>'}/"})
            plans[plan] = {"tier": tier, "cells": len(entries)}
    keys = [c["cell_key"] for c in cells]
    if len(set(keys)) != len(keys) or len({c["cell_id"] for c in cells}) != len(cells):
        raise IntegrityError("manifest cell keys / ids are not unique")
    plans["tune"].update({"unique_runs": plans["tune"]["cells"] - sum(1 for c in cells if c["plan"] == "tune"
                                                                      and c["reuses"]),
                          "unique_runs_check": _unique_runs_with("tune", config_dir, False)})
    plans["main"].update({"unique_runs": _unique_runs_with("main", config_dir, False),
                          "unique_runs_if_fixed_schedule_selected": _unique_runs_with("main", config_dir, True),
                          "profile": "reduced", "stages": [4]})
    plans["legacy"].update({"unique_runs": _unique_runs_with("legacy", config_dir, False)})
    for plan, want in APPROVED.items():
        got = {"cells": plans[plan]["cells"], "unique_runs": plans[plan]["unique_runs"]}
        if got != want:
            raise IntegrityError(f"manifest {plan}: {got} differs from the approved budget {want} (owner decision B2)")
    if plans["tune"]["unique_runs_check"] != plans["tune"]["unique_runs"]:
        raise IntegrityError("tuning reuse cells do not reuse runs as declared")
    body = {
        "manifest_version": MANIFEST_VERSION,
        "approved_budget": {"stage3_tuning_runs": 99, "stage4_main_runs": 756, "legacy_replication_runs": 30,
                            "total_runs": 885, "stage5": "deferred (owner decision B2)"},
        "plans": plans,
        "priority_order": {"0": "Stage 3 tuning (stage 0 = gate G-B first)",
                           "1": "N1, N2, DP1 and DP2 at eps* = 4, R1p (main table, H1, H2b, HS)",
                           "2": "R2, R2a, R3, R3a (H2)", "3": "M1 (H3)", "4": "legacy replicas L1-L4 (Table 13)",
                           "5": "R1q (schedule inside the method)", "6": "R1, R4, R5, R5a (baselines, trust without DP)",
                           "7": "DP1 at eps* in {1, 2, 8}, DP3, N3, I1, I2"},
        "not_in_manifest": {"L0": "evaluation only of the saved legacy model (scripts/legacy_l0_eval.py); needs the "
                                  "owner's original checkpoint complete/global_transe_final.pt",
                            "Stage 5": "deferred (B2)", "X6, O1": "not implemented (Phase C B10)"},
        "config_sha256": _file_hashes(config_dir),
        "hypotheses_sha256": hashlib.sha256(hyp.read_bytes()).hexdigest() if hyp.exists() else None,
        "core_code_hash": code_hash(),
        "cells": cells}
    body["content_sha256"] = _canonical_hash(body)
    return body


def write_manifest(man: Dict, out_dir: Path) -> Dict[str, Path]:
    """FROZEN_MANIFEST.json (+ .csv view, + .sha256 of the JSON file)."""
    out_dir = Path(out_dir)
    jp = out_dir / "FROZEN_MANIFEST.json"
    write_json(jp, {**man, "built_utc": utc_now()})
    cols = ["cell_id", "plan", "tier", "stage", "priority", "block", "phase_b_block", "dataset", "seed", "name",
            "role", "reuses", "coincides_if_fixed_schedule", "run_id", "cell_key"]
    write_csv(out_dir / "FROZEN_MANIFEST.csv", pd.DataFrame(man["cells"])[cols])
    (out_dir / "FROZEN_MANIFEST.sha256").write_text(
        f"{hashlib.sha256(jp.read_bytes()).hexdigest()}  FROZEN_MANIFEST.json\n"
        f"content_sha256 {man['content_sha256']}\n")
    return {"json": jp, "csv": out_dir / "FROZEN_MANIFEST.csv"}


def load_frozen(config_dir: Path) -> Dict:
    p = Path(config_dir) / "manifest" / "FROZEN_MANIFEST.json"
    if not p.exists():
        raise IntegrityError(f"frozen manifest missing: {p} (scripts/build_manifest.py --write)")
    return read_json(p)


def verify_frozen(config_dir: Path) -> Dict:
    """Rebuild the manifest from the current configs and code and compare it with the frozen file. Any change to a
    matrix, a rule, the hypotheses or the core code after the freeze is reported here."""
    frozen = load_frozen(config_dir)
    now = build_manifest(config_dir)
    if now["content_sha256"] != frozen["content_sha256"]:
        diff = [k for k in now if k not in ("content_sha256", "built_utc") and now.get(k) != frozen.get(k)]
        raise IntegrityError("the configs or the core code differ from the frozen manifest (changed: "
                             f"{diff}); the approved schedule must not change silently. If the change is intended "
                             "and approved, rebuild with scripts/build_manifest.py --write and commit it.")
    return frozen


# ------------------------------------------------------------------------------------------------ execution side
def check_entries_against_manifest(entries: List[Dict], manifest: Dict, plan: str, require_all: bool = True) -> Dict:
    """Every expanded entry must be a manifest cell of `plan`; with require_all, every manifest cell of the requested
    datasets must be expanded. Fixed run_ids in the manifest must equal the expanded ones."""
    cells = {c["cell_key"]: c for c in manifest["cells"] if c["plan"] == plan}
    seen, extra, wrong_rid = set(), [], []
    for e in entries:
        k = cell_key(plan, e["block"], e["dataset"], e["seed"], e["name"])
        c = cells.get(k)
        if c is None:
            extra.append(k); continue
        seen.add(k)
        if c["run_id"] is not None and c["run_id"] != e["run_id"]:
            wrong_rid.append((k, c["run_id"], e["run_id"]))
    dsets = {e["dataset"] for e in entries}
    missing = [k for k, c in cells.items() if c["dataset"] in dsets and k not in seen] if require_all else []
    if extra or wrong_rid or missing:
        raise IntegrityError(f"expanded {plan} entries do not match the frozen manifest: {len(extra)} extra "
                             f"{extra[:3]}, {len(missing)} missing {missing[:3]}, {len(wrong_rid)} with a different "
                             f"run_id {wrong_rid[:2]}")
    return {"plan": plan, "n_entries": len(entries), "n_unique_runs": len({e['run_id'] for e in entries})}


def resolve(entries: List[Dict], manifest: Dict, plan: str) -> List[Dict]:
    """Cell -> run_id map for one plan after selections exist (written by the run scripts)."""
    out = []
    for e in entries:
        k = cell_key(plan, e["block"], e["dataset"], e["seed"], e["name"])
        out.append({"cell_id": cell_id(k), "cell_key": k, "run_id": e["run_id"], "priority": e.get("priority"),
                    "block": e["block"], "dataset": e["dataset"], "seed": e["seed"]})
    return out


def _index_lookup(paths: Paths) -> Dict[str, str]:
    m = {}
    idx = paths.base / "index"
    if idx.exists():
        for p in sorted(idx.glob("*_runs_index.csv")):
            df = pd.read_csv(p)
            for r in df.to_dict("records"):
                m[f"{r['block']}|{r['dataset']}|s{int(r['seed'])}|{r['name']}"] = r["run_id"]
    return m


def cell_status(paths: Paths, rid: Optional[str]) -> Dict:
    if rid is None:
        return {"status": "WAITING_FOR_SELECTIONS"}
    rd = RunDir(paths.run(rid))
    st = rd.status()
    if st is None:
        return {"status": "NOT_STARTED"}
    if st["status"] == "COMPLETE":
        if st.get("code_hash") != code_hash():
            return {"status": "STALE_CODE", "attempt": st.get("attempt")}
        if not (rd.path / "final.json").exists():
            return {"status": "INCOMPLETE", "detail": "status COMPLETE but final.json missing", "attempt": st.get("attempt")}
        return {"status": "COMPLETE", "attempt": st.get("attempt"), "time_utc": st.get("time_utc")}
    if st["status"] == "RUNNING":
        ck = rd.path / "checkpoint.pt"
        return {"status": "INCOMPLETE", "detail": "interrupted or running" + (" (checkpoint present)" if ck.exists()
                                                                               else ""), "attempt": st.get("attempt")}
    return {"status": st["status"], "detail": str(st.get("error", ""))[:300], "attempt": st.get("attempt")}


def progress(results_root: Path, manifest: Dict, plans: Optional[List[str]] = None) -> pd.DataFrame:
    """Status of every manifest cell, derived from the run folders (the only source of truth)."""
    rows, lookups = [], {}
    for c in manifest["cells"]:
        if plans and c["plan"] not in plans:
            continue
        paths = Paths(results_root, c["tier"])
        if c["tier"] not in lookups:
            lookups[c["tier"]] = _index_lookup(paths)
        rid = c["run_id"] or lookups[c["tier"]].get(c["cell_key"].split("|", 1)[1])
        rows.append({"cell_id": c["cell_id"], "plan": c["plan"], "priority": c["priority"], "stage": c["stage"],
                     "block": c["block"], "dataset": c["dataset"], "seed": c["seed"], "name": c["name"],
                     "run_id": rid, **cell_status(paths, rid)})
    return pd.DataFrame(rows)


def write_progress(results_root: Path, manifest: Dict) -> Dict:
    df = progress(results_root, manifest)
    root = Path(results_root)
    write_csv(root / "PROGRESS_cells.csv", df)
    uniq = df.dropna(subset=["run_id"]).drop_duplicates(subset=["plan", "run_id"])
    summ = {"updated_utc": utc_now(), "note": "derived from the run folders; a cell is COMPLETE only if its run folder "
                                              "says COMPLETE with the current code hash and final.json exists",
            "cells_by_plan_status": {p: g["status"].value_counts().to_dict() for p, g in df.groupby("plan")},
            "unique_runs_by_plan_status": {p: g["status"].value_counts().to_dict() for p, g in uniq.groupby("plan")},
            "main_by_priority": {int(k): g["status"].value_counts().to_dict()
                                 for k, g in df[df["plan"] == "main"].groupby("priority")},
            "approved_budget": manifest["approved_budget"]}
    write_json(root / "PROGRESS.json", summ)
    lines = ["# Research progress (derived from the run folders)", "", f"Updated {summ['updated_utc']}.", "",
             "| Plan | Cells | Unique runs COMPLETE | Unique runs total (resolved) | Status of cells |",
             "|---|---|---|---|---|"]
    for p, g in df.groupby("plan"):
        u = uniq[uniq["plan"] == p]
        lines.append(f"| {p} | {len(g)} | {int((u['status'] == 'COMPLETE').sum())} | {len(u)} | "
                     + ", ".join(f"{k} {v}" for k, v in g["status"].value_counts().items()) + " |")
    lines += ["", "Stage 4 by priority:", "", "| Priority | Cells | Status |", "|---|---|---|"]
    for k, g in df[df["plan"] == "main"].groupby("priority"):
        lines.append(f"| {k} | {len(g)} | " + ", ".join(f"{a} {b}" for a, b in g["status"].value_counts().items()) + " |")
    (root / "PROGRESS.md").write_text("\n".join(lines) + "\n")
    return summ
