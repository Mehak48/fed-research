#!/usr/bin/env python3
"""Runs the legacy-replica blocks of the Phase B plan (06_experiment_matrix.md: L1-L4, FB15k-237 only), Stage-4
execution priority 4 (owner decision B2; RC-12). 30 runs on the final tier (6 blocks x the 5 confirmatory seeds).

The blocks live in the p3 / p4 matrices, not in matrices/confirm.yaml:

  Phase B   matrix block                     what it isolates
  L1        p3 R3_legacy                     exact old Phase 3 (5 relation-disjoint clients; legacy protocol)
  L2        p3 R3_fixed                      old 5-client partition, corrected trainer and evaluation
  L3        p4 R4_legacy                     exact old Phase 4 (sigma = 1, B = 256, naive-sum stop)
  L4        p4 L1_legacy, L2_trainer_fixed,  ladder on the main partition: legacy mechanism -> trainer fixed
            L3_accounting_fixed              -> formal RDP accounting
  (L0 is evaluation only: scripts/legacy_l0_eval.py, needs the owner's original checkpoint)

  software check on the real smoke subsets (gate G-A; NEVER evidence):
    python scripts/run_legacy_blocks.py --tier smoke
  Stage 4, priority 4 (final tier):
    python scripts/run_legacy_blocks.py --tier final --device cuda [--max-hours 10]

These runs need no Stage-3 selection; on the final tier they are checked against the frozen manifest (their run ids
are frozen there) and the environment lock. Completed runs are reused; nothing is re-run for a better result.
Exit codes as scripts/run_plan.py (0 complete, 1 failures, 3 session budget, 5 environment, 6 manifest).
"""
from __future__ import annotations

import argparse
import time

from _common import CONFIG_DIR, Manifest, results_root
from fedkge.config import load_yaml
from fedkge.gates import EnvironmentMismatch, check_environment_lock
from fedkge.io import IntegrityError, Paths
from fedkge.manifest import LEGACY_BLOCKS, LEGACY_NAME, check_entries_against_manifest, verify_frozen, write_progress
from fedkge.runner import expand, run_entries, write_index
from run_plan import ensure_partitions


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", help="results root (default: FEDKGE_RESULTS or revision/results/phaseC)")
    ap.add_argument("--tier", required=True, choices=["smoke", "final"])
    ap.add_argument("--tier-file", help="tier settings file (default: --tier)")
    ap.add_argument("--device", default=None)
    ap.add_argument("--max-runs", type=int, help="start at most this many new runs (session limits)")
    ap.add_argument("--max-hours", type=float, help="start no new run after this many hours (session limits)")
    a = ap.parse_args(argv)
    root = results_root(a.results)
    paths = Paths(root, a.tier)
    man = Manifest(root, f"legacy_blocks_{a.tier}")
    frozen = None
    if a.tier == "final":
        try:
            frozen = verify_frozen(CONFIG_DIR)
            man.rec["environment_lock"] = check_environment_lock(
                paths, ["fb15k237"], a.device, load_yaml(CONFIG_DIR / "gates.yaml")["environment_lock"],
                session_note="run_legacy_blocks")
        except IntegrityError as e:
            man.close("MANIFEST_MISMATCH", reason=str(e)); print(f"STOP: {e}"); return 6
        except EnvironmentMismatch as e:
            man.close("ENVIRONMENT_MISMATCH", reason=str(e)); print(f"STOP: {e}"); return 5
    entries = []
    for phase, blocks in LEGACY_BLOCKS.items():
        es = expand(phase, CONFIG_DIR, paths, a.tier, ["fb15k237"], None, blocks, tier_file=a.tier_file)
        missing = sorted(set(blocks) - {e["block"] for e in es})
        if missing:
            man.close("FAILED", error=f"blocks not found in {phase}.yaml: {missing}")
            raise SystemExit(f"blocks not found in {phase}.yaml: {missing}")
        write_index(paths, phase, es)
        entries += es
    if frozen is not None:
        man.rec["manifest_check"] = check_entries_against_manifest(entries, frozen, "legacy", require_all=True)
    built = ensure_partitions(entries, paths, man)
    entries = sorted(entries, key=lambda e: int(e["seed"]))           # seed-major: early pairs for every block
    print(f"{len(entries)} entries ({len({e['run_id'] for e in entries})} unique runs); {built} partitions built")
    t0 = time.time()
    deadline = t0 + 3600 * a.max_hours if a.max_hours else None
    st = run_entries(entries, paths, a.device, max_runs=a.max_runs, deadline=deadline)
    st["phase_b_block"] = st["block"].map(LEGACY_NAME)
    out = root / a.tier / f"legacy_blocks_status_{time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())}.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    st.to_csv(out, index=False)
    man.output(out)
    print(st[["block", "phase_b_block", "status"]].to_string(index=False))
    failed = int(st["status"].astype(str).str.startswith("FAILED").sum())
    pending = int((st["status"] == "PENDING").sum())
    if frozen is not None:
        man.rec["progress"] = write_progress(root, frozen)
    man.close("COMPLETE" if not failed and not pending else ("SOME_FAILED" if failed else "PARTIAL_SESSION_BUDGET"),
              n_runs=len(st), n_failed=failed, n_pending=pending, seconds=time.time() - t0)
    return 1 if failed else (3 if pending else 0)


if __name__ == "__main__":
    raise SystemExit(main())
