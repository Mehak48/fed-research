# Phase C — measured pilot and staged plan

**Date:** 2026-11-02 · **Gate:** G-B (`audit/phaseB/07_compute_feasibility.md` §8).

The pilot's MRR values are **not** results: runs stop after 2 rounds and are flagged `partial_run`.

## 1. What the pilot measures and how

- **Script:** `scripts/pilot.py`.
- **Configurations:** 6 per dataset, each run on the **full** dataset for 2 rounds with the real configuration: true σ and q, steps, clipping, dense noise, integrity, trust.

| Label | Configuration | Planned rounds R |
|---|---|---|
| `np_central` | Non-private, centralised | 60 |
| `np_fed` | Non-private FedAvg, 10 clients, α = 0.1 | 60 |
| `dp_fedA_B512` | DP-FedAvg, design A (expected batch 512, per-client σ) | 100 |
| `dp_fed_q0.10` / `dp_fed_q0.02` | DP-FedAvg, design Q at the ends of the q grid | 100 |
| `complete_q0.10` | Proposed aggregation + hash-only integrity + DP | 100 |

**Measurement rules:**

- **One subprocess per run,** so peak memory belongs to that run. CPU uses peak RSS; CUDA uses peak allocated memory.
- **Storage** is the size of the run directory, with the final weights kept.
- **Per-run hours** = (R × seconds per round + R/5 validation passes + final evaluation) / 3600. This is an upper bound: every run executes R rounds, while non-private runs may stop early.
- **Plan-level hours:**
  - every **unique** run of the tuning matrix and of the confirmatory matrix is expanded exactly as the runner expands it, with placeholder selections (q = 0.05, R = 100, design Q, τ = 3);
  - each run gets the measured cost of its class;
  - design Q at q = 0.05 is interpolated with cost(q) = a + b/q through the q = 0.10 and q = 0.02 measurements;
  - the proposed method adds its measured overhead over DP-FedAvg.
- **Not in the estimate** (listed with counts in the output):
  - attack crafting;
  - robust aggregators other than the proposed one;
  - the MIA audit;
  - legacy replicas.

  Each is expected to be small next to training, but none is measured.

## 2. Measured on this machine (CPU, 2 cores; full real data; 2 rounds per run; 2026-11-02) — upper bounds, not GPU timings

| Dataset | Configuration | Params | Local s/round | Aggregation s/round | Integrity s/round | **Total s/round** | Validation pass s | Final evaluation s | **Per-run hours (upper)** | Peak RSS (GB) | Run directory (MB) | Note |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| fb15k237 | np_central | 1,474,200 | 48.5 | 0.00 | 0.03 | **48.5** | 0.82 | 13.8 | **0.82** | 1.1 | 5.9 |  |
| fb15k237 | np_fed | 1,474,200 | 78.3 | 0.02 | 0.18 | **78.5** | 0.83 | 14.2 | **1.32** | 1.3 | 5.9 | overlapped a test run; superseded |
| fb15k237 | dp_fedA_B512 | 1,474,200 | 45.1 | 0.01 | 0.18 | **45.3** | 0.74 | 12.6 | **1.27** | 1.4 | 6.0 |  |
| fb15k237 | dp_fed_q0.10 | 1,474,200 | 74.5 | 0.02 | 0.20 | **74.7** | 0.66 | 11.9 | **2.08** | 1.9 | 6.0 |  |
| fb15k237 | dp_fed_q0.02 | 1,474,200 | 47.9 | 0.01 | 0.19 | **48.1** | 0.74 | 13.6 | **1.34** | 1.4 | 6.0 |  |
| fb15k237 | complete_q0.10 | 1,474,200 | 78.0 | 0.21 | 0.22 | **78.4** | 0.73 | 12.3 | **2.19** | 1.9 | 6.0 |  |
| wn18rr | np_central | 4,057,000 | 18.1 | 0.01 | 0.07 | **18.2** | 1.08 | 3.8 | **0.31** | 1.3 | 16.2 |  |
| wn18rr | np_fed | 4,057,000 | 18.3 | 0.10 | 0.58 | **19.0** | 1.48 | 2.8 | **0.32** | 2.2 | 16.2 |  |
| wn18rr | dp_fedA_B512 | 4,057,000 | 19.8 | 0.06 | 0.56 | **20.4** | 1.17 | 2.8 | **0.57** | 2.0 | 16.3 |  |
| wn18rr | dp_fed_q0.10 | 4,057,000 | 26.6 | 0.06 | 0.57 | **27.2** | 1.19 | 3.0 | **0.76** | 2.2 | 16.3 |  |
| wn18rr | dp_fed_q0.02 | 4,057,000 | 32.9 | 0.05 | 0.58 | **33.5** | 1.25 | 3.6 | **0.94** | 2.0 | 16.3 |  |
| wn18rr | complete_q0.10 | 4,057,000 | 25.6 | 0.57 | 0.58 | **26.8** | 1.18 | 3.1 | **0.75** | 2.1 | 16.3 |  |
| codex_m | np_central | 1,710,100 | 31.7 | 0.00 | 0.03 | **31.7** | 1.22 | 11.3 | **0.54** | 1.0 | 6.9 |  |
| codex_m | np_fed | 1,710,100 | 31.6 | 0.02 | 0.20 | **31.8** | 1.18 | 10.5 | **0.54** | 1.3 | 6.9 |  |
| codex_m | dp_fedA_B512 | 1,710,100 | 30.9 | 0.02 | 0.20 | **31.1** | 1.07 | 10.2 | **0.87** | 1.4 | 6.9 |  |
| codex_m | dp_fed_q0.10 | 1,710,100 | 48.3 | 0.02 | 0.25 | **48.5** | 1.20 | 11.2 | **1.36** | 2.0 | 6.9 |  |
| codex_m | dp_fed_q0.02 | 1,710,100 | 35.6 | 0.02 | 0.20 | **35.8** | 1.26 | 11.5 | **1.00** | 1.4 | 6.9 |  |
| codex_m | complete_q0.10 | 1,710,100 | 47.3 | 0.29 | 0.26 | **47.9** | 1.13 | 11.1 | **1.34** | 1.9 | 6.9 |  |
| fb15k237 | np_fed | 1,474,200 | 45.5 | 0.02 | 0.18 | **45.7** | 0.67 | 13.4 | **0.77** | 1.3 | 5.9 | clean re-measurement (used) |

**Notes on the measurements:**

- **Completeness:** all 18 runs plus 1 re-measurement completed, with 0 failures.
  - Files: `results/phaseC/pilot/pilot_measurements_20261102T130753Z.csv` and `…T133807Z.csv`.
  - Manifests: `manifests/*_pilot*.json`.
  - Per-run logs: `logs/pilot_*`.
- **FB15k-237 `np_fed`:**
  - The first measurement (78.5 s/round) overlapped a test-suite run on the same 2 cores.
  - The clean re-measurement gives 45.7 s/round. The extrapolation uses the clean value, and both files are kept.
- **Where the time goes:**
  - Local training dominates.
  - Aggregation takes ≤ 0.6 s per round.
  - Integrity (hash and verify 20 objects per round) takes 0.03–0.6 s per round.
- **The proposed method plus hash-only integrity** costs at most about 5 % more than DP-FedAvg at q = 0.10: FB15k-237 +3.7 s/round; WN18RR and CoDEx-M within measurement noise.
- **Effect of the sampling rate.** Here, q = 0.10 (10 large steps) is *slower* than q = 0.02 (50 small steps) on FB15k-237 and CoDEx-M, where big per-example batches are memory-bound. It is faster on WN18RR, where dense noise on 4.06 M parameters per step dominates. A GPU may behave differently, which is why both ends of the q grid are measured.
- **Memory:** peak RSS is 1.1–2.2 GB per run, which fits free Colab's RAM. GPU memory will be measured on Colab.
- **Storage:**
  - A run directory is about the model weights plus about 0.1 MB of records: FB15k-237 6.0 MB, WN18RR 16.3 MB, CoDEx-M 6.9 MB (with weights).
  - Planned kept weights: 150 models in the reduced plan, ≈ 50 × (5.9 + 16.2 + 6.8) MB ≈ 1.45 GB. This matches Phase B's 1.46 GB.
  - Records for the reduced plan: about 0.1–0.2 GB.
- **Privacy:** ε after 2 of 100 planned rounds is 0.54–0.68, with σ calibrated so that ε(R = 100) ≤ 4. This is an accountant check, not a result.
- **WN18RR parameters:** 4,057,000 = (40,559 training entities + 11 relations) × 100. Phase B assumed 40,943 entities.

## 3. Plan-level extrapolation from the CPU measurements (upper bounds)

| Plan | Stage | Unique runs | CPU-hours (upper bound) |
|---|---|---|---|
| Tuning chain (tune tier, seed 1001) | 1 (T1C, T1F, T2a) | 63 | 67.1 |
| Tuning chain (tune tier, seed 1001) | 2 (T2b) | 12 | 15.9 |
| Tuning chain (tune tier, seed 1001) | 3 (T2c) | 3 | 2.0 |
| Tuning chain (tune tier, seed 1001) | 4 (T2d) | 3 | 2.7 |
| Tuning chain (tune tier, seed 1001) | 5 (T3) | 18 | 23.8 |
| | **Total** (TAU reuses the T3 winner: 0 new runs) | **99** | **111.6** |
| Confirmatory, **reduced** profile | 4 (core blocks + M1) | 756 | 874.0 |
| Confirmatory, **reduced** profile | 5 (extended, deferrable) | 423 | 582.5 |
| Confirmatory, full profile | 4 (core blocks + M1) | 1,404 | 1,676.6 |
| Confirmatory, full profile | 5 (extended, deferrable) | 585 | 800.2 |

**How to read this table:**

- Runs shared by several blocks are counted once.
- Every run is assumed to execute rounds_max (an upper bound).
- In the reduced plan, the *extra* cost is not measured for:
  - attack crafting (714 attack runs);
  - robust aggregators other than the proposed one (180 runs);
  - the MIA audit (60 runs).

  Their training cost **is** included.

**Per run, compared with Phase B's GPU estimates** (`audit/phaseB/data/per_run_time_estimate.csv`):

- This CPU takes **1.4–3.9×** the Phase B *HIGH* GPU estimate.
- It takes **7–42×** the *LOW* estimate.
- Example: FB15k-237 DP-FedAvg needs 81–125 CPU-minutes per 100-round run, against 3.1–33.3 GPU-minutes estimated.

**What this means:**

**This 2-core CPU cannot run the plan:**

- the tuning chain alone is up to about 112 CPU-hours;
- the reduced core (Stage 4) is up to about 874 CPU-hours.

**On a GPU it depends on the speed-up, which the Colab pilot measures:**

| T4 speed-up over this CPU | Tuning | Reduced core (Stage 4) | Stage 5 (extended) | Per-run times vs Phase B |
|---|---|---|---|---|
| 10× | ≈ 11 GPU-hours | ≈ 87 GPU-hours | +58 | inside Phase B's range |
| 30× | ≈ 4 GPU-hours | ≈ 29 GPU-hours | +19 | — |
| ≈ 4× or more | — | — | — | every run at or below the HIGH estimate |
| ≈ 40× | — | — | — | runs reach the LOW estimate |

**No GPU number is claimed until it is measured.**

## 4. The GPU pilot on free Colab (next action, owner)

1. Upload `fedkge_code_phaseC.zip` to `MyDrive/fedkge_phaseC/`.
2. Open `phaseC_pilot_colab.ipynb` in Colab and select `Runtime → Change runtime type → T4 GPU`.
3. Use `Runtime → Run all`. Expect about 45–75 minutes. The notebook:
   - checks the code's SHA-256;
   - installs the pinned packages;
   - runs the test suite (expected: all pass, 1 skipped);
   - downloads the data with the recorded licence confirmation;
   - runs 9 GPU smoke runs;
   - runs the pilot;
   - writes `colab_pilot_results_<UTC>.zip` to the same Drive folder.
4. Send that zip back. Nothing in it is a result for the paper.

**The kit was dry-run end to end on this CPU** (WN18RR only; the Drive mount, pip install and the CUDA device were replaced). It took 6.5 minutes and produced a 0.1 MB results zip. **The GPU path itself is still untested**, which is why the kit runs the GPU smoke before the pilot.

## 5. Decisions after the GPU pilot (gate G-B → stage plan)

- **Refit the cost model** with the GPU numbers. Then choose:
  - the profile: reduced (recommended);
  - which optional parts to defer (`remaining_blockers.md` B2).
- **Answer B3–B5** before Stage 3.

**Stage order (unchanged from Phase B, with run counts from the implemented matrices):**

| Stage | What | Runs (reduced profile, three datasets) |
|---|---|---|
| 3 | Tuning chain T1 → T2a → T2b → T2c → T2d → T3 → τ (tuning seed 1001; validation only) | 99 (Phase B); the implemented chain reuses winners automatically |
| — | `freeze_selections.py` (hash recorded); hypotheses frozen (gate G-D) | — |
| 4 | Core confirmatory blocks (N, DP, R, I, M1; 5–10 seeds) | 727 + 60 (M1) |
| 5 | Extended / sensitivity (X blocks) | 432 (deferrable) |
