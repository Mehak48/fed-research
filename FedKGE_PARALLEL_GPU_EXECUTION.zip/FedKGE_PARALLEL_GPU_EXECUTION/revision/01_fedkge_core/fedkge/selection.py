"""Pre-registered selection rules (10_configs/selection_rules.yaml). Selection uses VALIDATION metrics only
(val.mrr = full V_sel, filtered, realistic ties); test metrics are never read here.
Phase C (decision D13): selections are made on the TUNE tier (tuning seed 1001) only; the final tier refuses to
select. The generic select_rule implements the Phase B tuning chain T1, T2a-T2d, T3; select_tau implements D14
(benign-FPR rule on logged anomaly scores) with the owner's pre-declared response B3 to infeasibility.
Owner decision B4 (2026-11-04): variant V1 and the D15 trigger are removed; per-size-third benign FPRs are diagnostics.

Every selection writes RESULTS_ROOT/<tier>/selection/<name>.json containing: the rule text and its SHA-256,
the complete candidate table (every grid point, every seed), the chosen value per dataset, and whether the
rule's constraint was satisfied. Downstream runs record the SHA-256 of the selection file they used; if the
file changes, those runs become STALE_SELECTION and must be rerun.
Selections require the COMPLETE candidate grid (all points x all seeds). Partial grids => failure.
"""
from __future__ import annotations

import hashlib
from typing import Dict, List

import numpy as np
import pandas as pd

from .io import IntegrityError, Paths, read_json, write_json
from .stats import summarize

VAL = "val.mrr"


def rule_hash(rules: Dict) -> str:
    import json
    return hashlib.sha256(json.dumps(rules, sort_keys=True).encode()).hexdigest()


def _complete(df: pd.DataFrame, by: List[str], seeds: List[int], label: str) -> None:
    for key, g in df.groupby(by):
        missing = set(seeds) - set(g["seed"])
        if missing:
            raise IntegrityError(f"{label}: candidate {key} missing seeds {sorted(missing)}; selection refused")


def _argmax_tie(means: Dict, tol: float, prefer) -> object:
    best = max(means.values())
    tied = [k for k, v in means.items() if best - v <= tol]
    return prefer(tied)


def _load_or_new(paths: Paths, name: str) -> Dict:
    p = paths.selection(name)
    return read_json(p) if p.exists() else {}


def _merge_rule_record(sel: Dict, key: str, rule: Dict, new_rows: List[Dict], datasets, **extra) -> None:
    """Keep the candidate tables of datasets selected in earlier sessions (one dataset per session is allowed); the
    rows of the datasets selected now replace their older rows. A rule whose text changed between sessions is refused
    (a selection made under another rule text would be silently mixed)."""
    old = sel.get(key) or {}
    if old and old.get("rule_sha256") not in (None, rule_hash(rule)):
        raise IntegrityError(f"{key}: the rule text changed since an earlier selection (hash {old.get('rule_sha256')} "
                             f"-> {rule_hash(rule)}); selections under different rule texts cannot be mixed")
    keep = [r for r in old.get("candidates", []) if r.get("dataset") not in set(datasets)]
    sel[key] = {**{k: v for k, v in old.items() if k not in ("candidates",)}, "rule": rule,
                "rule_sha256": rule_hash(rule), **extra, "candidates": keep + list(new_rows)}


def _refuse_final(paths: Paths) -> None:
    """Decision D13: confirmatory (final-tier) runs never re-select. Selections are made on the tuning tier."""
    if paths.tier == "final":
        raise IntegrityError("selection on the final tier is forbidden (D13): select on the tune tier only")


def _nest(flat: Dict[str, object]) -> Dict:
    out: Dict = {}
    for k, v in flat.items():
        d = out
        parts = k.split(".")
        for p in parts[:-1]:
            d = d.setdefault(p, {})
        d[parts[-1]] = v
    return out


def _prefer(tied: List[tuple], keys: List[str], tie_break: List) -> tuple:
    """tie_break: list of [key, 'min'|'max'] or [key, 'prefer', value]; applied in order (lexicographic)."""
    cand = list(tied)
    for tb in tie_break:
        k = keys.index(tb[0])
        if tb[1] == "min":
            best = min(c[k] for c in cand); cand = [c for c in cand if c[k] == best]
        elif tb[1] == "max":
            best = max(c[k] for c in cand); cand = [c for c in cand if c[k] == best]
        elif tb[1] == "prefer":
            pref = [c for c in cand if c[k] == tb[2]]
            cand = pref or cand
        if len(cand) == 1:
            break
    return sorted(cand, key=lambda c: tuple(str(x) for x in c))[0]


def select_rule(runs: pd.DataFrame, rule_name: str, rules: Dict, seeds: List[int], paths: Paths) -> Dict:
    """Generic pre-registered selection (Phase B 05 section 6): maximise mean VALIDATION MRR over the tuning seeds
    among the candidates of the rule's blocks; ties within tie_tolerance broken by the rule's tie_break order.
    Writes selection/tuning.json: {dataset: {rule_name: {nested cfg keys: value}}} + the full candidate table."""
    _refuse_final(paths)
    r = rules[rule_name]
    keys = list(r["keys"])
    df = runs[runs["block"].isin(r["blocks"])]
    if df.empty:
        raise IntegrityError(f"{rule_name}: no candidate runs in blocks {r['blocks']}")
    bad_seeds = set(df["seed"]) - set(seeds)
    if bad_seeds:
        raise IntegrityError(f"{rule_name}: candidate runs use seeds {sorted(bad_seeds)} outside the tuning seeds")
    sel = _load_or_new(paths, "tuning")
    cand_rows = []
    for ds, g in df.groupby("dataset"):
        cols = [f"cfg.{k}" for k in keys]
        missing_cols = [c for c in cols if c not in g.columns]
        if missing_cols:
            raise IntegrityError(f"{rule_name}/{ds}: runs lack config columns {missing_cols}")
        g = g.copy()
        for c in cols:
            g[c] = g[c].astype(object)
        _complete(g, cols, seeds, f"{rule_name}/{ds}")
        if r.get("grid"):
            have = {tuple(x) for x in g[cols].itertuples(index=False, name=None)}
            want = {tuple(x) for x in r["grid"]}
            if not want <= have:
                raise IntegrityError(f"{rule_name}/{ds}: incomplete grid, missing {sorted(want - have)}")
        means = {tuple(k if isinstance(k, tuple) else (k,)): summarize(gg[VAL])["mean"] for k, gg in g.groupby(cols)}
        best = max(means.values())
        tied = [k for k, v in means.items() if best - v <= float(r["tie_tolerance"])]
        chosen = _prefer(tied, keys, r.get("tie_break", []))
        sel.setdefault(ds, {})[rule_name] = _nest(dict(zip(keys, chosen)))
        cand_rows += [{"dataset": ds, **dict(zip(keys, k)), "val_mrr_mean": m, "chosen": k == chosen,
                       "tied_within_tolerance": k in tied} for k, m in means.items()]
    _merge_rule_record(sel, f"_{rule_name}_rule", r, cand_rows, sorted(set(df["dataset"])), seeds=list(seeds))
    write_json(paths.selection("tuning"), sel)
    return sel


def benign_fpr_table(trust_rounds: pd.DataFrame, taus: List[float], score_col: str = "A") -> pd.DataFrame:
    """Mean benign false-positive rate of the flag score > tau over all rounds and benign identities, overall and by
    declared-size third (diagnostic only, decision B4). Uses logged scores only (no extra training). Fails loudly on
    missing or non-finite scores instead of letting NaN silently count as 'not flagged'."""
    if score_col not in trust_rounds.columns:
        raise IntegrityError(f"trust_rounds has no column {score_col!r}")
    ben = trust_rounds[~trust_rounds["malicious"].astype(bool)]
    if ben.empty:
        raise IntegrityError("no benign anomaly-score observations; the tau rule cannot be applied")
    scores = pd.to_numeric(ben[score_col], errors="coerce").to_numpy(float)
    if not np.isfinite(scores).all():
        raise IntegrityError(f"{int((~np.isfinite(scores)).sum())} non-finite anomaly scores; the tau rule cannot "
                             "be applied (report the run, never impute)")
    rows = []
    for t in taus:
        flag = scores > float(t)
        rec = {"tau": float(t), "benign_fpr": float(flag.mean()), "n_benign_obs": int(len(flag)),
               "n_flagged": int(flag.sum())}
        for third, gg in ben.assign(flag=flag).groupby("size_third"):
            rec[f"benign_fpr_third{int(third)}"] = float(gg["flag"].mean())
            rec[f"n_obs_third{int(third)}"] = int(len(gg))
        rows.append(rec)
    return pd.DataFrame(rows)


def check_tau_direction(tab: pd.DataFrame) -> Dict:
    """B3 prerequisite (approval register 2026-11-04: 'validate the score/threshold monotonicity before choosing the
    fallback'). The flag is A > tau, so along a strictly increasing grid the benign FPR must be non-increasing, overall
    and within every size third. Then the LARGEST grid tau is the least-violating choice on the grid (lowest benign
    FPR) and also the least sensitive detector (fewest flags). Raises if the grid or the table contradicts this."""
    taus = tab["tau"].to_numpy(float)
    if len(taus) < 2 or not (np.diff(taus) > 0).all():
        raise IntegrityError(f"the tau grid must be strictly increasing with >= 2 values: {taus.tolist()}")
    cols = ["benign_fpr"] + sorted(c for c in tab.columns if c.startswith("benign_fpr_third"))
    for c in cols:
        if (np.diff(tab[c].to_numpy(float)) > 1e-15).any():
            raise IntegrityError(f"benign FPR ({c}) increases with tau: the flag direction is not 'A > tau'")
    return {"flag": "A > tau", "fpr_non_increasing_in_tau": True, "checked_columns": cols,
            "meaning": "larger tau = fewer flags = lower benign false-positive rate and weaker detection"}


def select_tau(trust_rounds_by_ds: Dict[str, pd.DataFrame], rules: Dict, paths: Paths) -> Dict:
    """D14 + B3. tau* = the smallest grid tau whose mean benign FPR <= max_benign_fpr in the clean DP FedAvg tuning
    run (block TAU, frozen-rule score A). If no grid tau meets the constraint, the owner's pre-declared response B3
    applies: tau* = the largest predefined grid tau, recorded with status RULE_NOT_MET and its observed benign FPR.
    The grid is never extended; attack runs are never used; the constraint is never reported as met when it is not."""
    _refuse_final(paths)
    r = rules["tau"]
    if r.get("score", "A") != "A" or r.get("flag", "A > tau") != "A > tau":
        raise IntegrityError("the tau rule must use the frozen score A with the flag 'A > tau'")
    if r.get("choose", "smallest_feasible") != "smallest_feasible":
        raise IntegrityError("the tau rule must choose the smallest feasible tau (D14)")
    grid = [float(x) for x in r["grid"]]
    lim = float(r["max_benign_fpr"])
    fallback_rule = r.get("if_infeasible")
    sel = _load_or_new(paths, "tuning")
    rows = []
    for ds, tr in sorted(trust_rounds_by_ds.items()):
        if tr["malicious"].astype(bool).any():
            raise IntegrityError(f"tau/{ds}: the calibration run contains malicious identities; tau is calibrated on "
                                 "the clean TAU run only")
        tab = benign_fpr_table(tr, grid, "A")
        direction = check_tau_direction(tab)
        ok = tab[tab["benign_fpr"] <= lim]
        if len(ok):
            tau, rule_met, status = float(ok["tau"].min()), True, "RULE_MET"
        elif fallback_rule == "largest_grid_tau":
            tau, rule_met, status = float(tab["tau"].max()), False, "RULE_NOT_MET_LARGEST_GRID_TAU"
        else:
            raise IntegrityError(f"tau/{ds}: no tau on the grid meets benign FPR <= {lim} and the rule declares no "
                                 "fallback (never extend the grid after seeing data)")
        at = tab[tab["tau"] == tau].iloc[0]
        fpr_sel = float(at["benign_fpr"])
        sel.setdefault(ds, {})["tau"] = {
            "aggregation": {"tau": tau},
            "rule_met": rule_met, "status": status, "max_benign_fpr": lim,
            "benign_fpr_at_selected_tau": fpr_sel,
            "constraint_violation": None if rule_met else {"observed_benign_fpr": fpr_sel, "limit": lim,
                                                           "excess": fpr_sel - lim},
            "benign_fpr_by_size_third_at_selected_tau": {k.replace("benign_fpr_", ""): float(at[k])
                                                         for k in at.index if str(k).startswith("benign_fpr_third")},
            "n_benign_observations": int(at["n_benign_obs"]),
            "direction": direction,
            "label": ("tau rule met" if rule_met else
                      f"tau rule NOT met (benign FPR = {100 * fpr_sel:.1f} % > {100 * lim:.0f} % at the largest "
                      f"grid tau {tau:g}; owner decision B3)"),
        }
        rows += [{"dataset": ds, "score": "A", **rec, "feasible": bool(rec["benign_fpr"] <= lim),
                  "chosen": rec["tau"] == tau} for rec in tab.to_dict("records")]
    _merge_rule_record(sel, "_tau_rule", r, rows, sorted(trust_rounds_by_ds))
    write_json(paths.selection("tuning"), sel)
    return sel


def select_clip(runs: pd.DataFrame, rules: Dict, seeds: List[int], paths: Paths) -> Dict:
    _refuse_final(paths)
    r = rules["clip"]
    df = runs[runs["block"] == r["block"]]
    if df.empty:
        raise IntegrityError("no clip-sweep runs found")
    sel = _load_or_new(paths, "dp_selection")
    cand_rows = []
    for ds, g in df.groupby("dataset"):
        _complete(g, ["cfg.dp.clip"], seeds, f"clip/{ds}")
        means = {c: summarize(gg[VAL])["mean"] for c, gg in g.groupby("cfg.dp.clip")}
        chosen = _argmax_tie(means, float(r["tie_tolerance"]), min)
        sel.setdefault(ds, {})["clip"] = float(chosen)
        cand_rows += [{"dataset": ds, "clip": c, "val_mrr_mean": m, "chosen": c == chosen} for c, m in means.items()]
    sel["_clip_rule"] = {"rule": r, "rule_sha256": rule_hash(r), "candidates": cand_rows}
    write_json(paths.selection("dp_selection"), sel)
    return sel


def select_schedule(runs: pd.DataFrame, rules: Dict, seeds: List[int], paths: Paths) -> Dict:
    _refuse_final(paths)
    r = rules["schedule"]
    sel = _load_or_new(paths, "dp_selection")
    cand_rows = []
    for ds in sorted(set(runs["dataset"])):
        if ds not in sel or "clip" not in sel[ds]:
            raise IntegrityError(f"schedule selection needs the clip selection for {ds} first")
        fixed = runs[(runs["block"] == rules["clip"]["block"]) & (runs["dataset"] == ds) &
                     (runs["cfg.dp.clip"] == sel[ds]["clip"])]
        sch = runs[(runs["block"] == r["block"]) & (runs["dataset"] == ds)]
        g = pd.concat([fixed, sch])
        if sch.empty:
            raise IntegrityError(f"no schedule-sweep runs for {ds}")
        _complete(g, ["cfg.dp.schedule.shape", "cfg.dp.schedule.rho"], seeds, f"schedule/{ds}")
        means = {(s, float(rho)): summarize(gg[VAL])["mean"]
                 for (s, rho), gg in g.groupby(["cfg.dp.schedule.shape", "cfg.dp.schedule.rho"])}
        prefer = lambda tied: ("fixed", 1.0) if ("fixed", 1.0) in tied else sorted(tied)[0]
        chosen = _argmax_tie(means, float(r["tie_tolerance"]), prefer)
        sel[ds]["schedule_shape"], sel[ds]["schedule_rho"] = chosen[0], float(chosen[1])
        cand_rows += [{"dataset": ds, "shape": k[0], "rho": k[1], "val_mrr_mean": m, "chosen": k == chosen}
                      for k, m in means.items()]
    sel["_schedule_rule"] = {"rule": r, "rule_sha256": rule_hash(r), "candidates": cand_rows}
    write_json(paths.selection("dp_selection"), sel)
    return sel
