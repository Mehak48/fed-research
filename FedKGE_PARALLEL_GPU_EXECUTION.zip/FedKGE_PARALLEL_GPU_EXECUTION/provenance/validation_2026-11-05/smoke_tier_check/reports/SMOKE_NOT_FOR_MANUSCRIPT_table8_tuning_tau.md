# Table 8 — Stage 3 selection (tau); validation only

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| dataset | score | tau | benign_fpr | n_benign_obs | n_flagged | benign_fpr_third0 | n_obs_third0 | benign_fpr_third1 | n_obs_third1 | benign_fpr_third2 | n_obs_third2 | feasible | chosen |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| codex_m | A | 1.5 | 0.2 | 30 | 6 | 0.25 | 12 | 0.3333 | 9 | 0 | 9 | False | False |
| codex_m | A | 2 | 0.1667 | 30 | 5 | 0.25 | 12 | 0.2222 | 9 | 0 | 9 | False | False |
| codex_m | A | 2.5 | 0.1 | 30 | 3 | 0.08333 | 12 | 0.2222 | 9 | 0 | 9 | False | False |
| codex_m | A | 3 | 0.06667 | 30 | 2 | 0.08333 | 12 | 0.1111 | 9 | 0 | 9 | False | False |
| codex_m | A | 3.5 | 0.06667 | 30 | 2 | 0.08333 | 12 | 0.1111 | 9 | 0 | 9 | False | False |
| codex_m | A | 4 | 0.06667 | 30 | 2 | 0.08333 | 12 | 0.1111 | 9 | 0 | 9 | False | False |
| codex_m | A | 5 | 0 | 30 | 0 | 0 | 12 | 0 | 9 | 0 | 9 | True | True |
| fb15k237 | A | 1.5 | 0.1 | 30 | 3 | 0 | 12 | 0.3333 | 9 | 0 | 9 | False | False |
| fb15k237 | A | 2 | 0 | 30 | 0 | 0 | 12 | 0 | 9 | 0 | 9 | True | True |
| fb15k237 | A | 2.5 | 0 | 30 | 0 | 0 | 12 | 0 | 9 | 0 | 9 | True | False |
| fb15k237 | A | 3 | 0 | 30 | 0 | 0 | 12 | 0 | 9 | 0 | 9 | True | False |
| fb15k237 | A | 3.5 | 0 | 30 | 0 | 0 | 12 | 0 | 9 | 0 | 9 | True | False |
| fb15k237 | A | 4 | 0 | 30 | 0 | 0 | 12 | 0 | 9 | 0 | 9 | True | False |
| fb15k237 | A | 5 | 0 | 30 | 0 | 0 | 12 | 0 | 9 | 0 | 9 | True | False |
| wn18rr | A | 1.5 | 0.2667 | 30 | 8 | 0.25 | 12 | 0.1111 | 9 | 0.4444 | 9 | False | False |
| wn18rr | A | 2 | 0.1667 | 30 | 5 | 0.1667 | 12 | 0.1111 | 9 | 0.2222 | 9 | False | False |
| wn18rr | A | 2.5 | 0.1 | 30 | 3 | 0.08333 | 12 | 0 | 9 | 0.2222 | 9 | False | False |
| wn18rr | A | 3 | 0.03333 | 30 | 1 | 0 | 12 | 0 | 9 | 0.1111 | 9 | True | True |
| wn18rr | A | 3.5 | 0.03333 | 30 | 1 | 0 | 12 | 0 | 9 | 0.1111 | 9 | True | False |
| wn18rr | A | 4 | 0.03333 | 30 | 1 | 0 | 12 | 0 | 9 | 0.1111 | 9 | True | False |
| wn18rr | A | 5 | 0.03333 | 30 | 1 | 0 | 12 | 0 | 9 | 0.1111 | 9 | True | False |
