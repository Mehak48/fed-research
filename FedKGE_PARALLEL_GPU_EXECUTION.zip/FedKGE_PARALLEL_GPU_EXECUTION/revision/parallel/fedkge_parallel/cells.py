"""The approved cells and their GPU-hour estimates.

Research mode: exactly the cells of the frozen manifest (10_configs/manifest/FROZEN_MANIFEST.json), verified against
the configs and the core code first. Software-check mode (smoke/dev tiers): the same matrices expanded for that tier,
exactly as scripts/run_plan.py and scripts/run_legacy_blocks.py expand them.
"""
from __future__ import annotations

import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd

from .common import CONFIG_DIR, DATASETS, REPO, Paths, frozen_manifest, tiers_for

REUSE_BLOCKS = ("T2b0", "T2c0", "T2d0", "T30", "TAU")        # re-state an earlier winner: no new run
COST_TABLE = REPO / "parallel" / "cost_table_T4_upper.csv"
CHECK_TIER_HOURS_PER_RUN = 0.002                                # software-check tiers: placeholder for ordering only


@dataclass(frozen=True)
class Cell:
    cell_key: str
    plan: str            # tune | main | legacy
    tier: str
    phase: str           # tune | final | p3 | p4 (the config 'phase' field, part of the run identity)
    stage: int
    priority: int
    block: str
    dataset: str
    seed: int
    name: str
    run_id: Optional[str]          # known before the Stage-3 selections only for cells that do not depend on them
    reuse: bool                    # re-states an earlier stage's winner (same configuration, same run)
    coincides_if_fixed: Optional[str]

    def to_dict(self) -> Dict:
        return asdict(self)


def expand_plan(plan: str, tier: str, paths: Paths, datasets: List[str], stages: Optional[List[int]] = None,
                symbolic: bool = False) -> List[Dict]:
    """Expand one plan exactly as the sequential entry points do (same function, same arguments)."""
    from fedkge.manifest import LEGACY_BLOCKS
    from fedkge.runner import expand
    if plan == "tune":
        return expand("tune", CONFIG_DIR, paths, tier, list(datasets), stages, profile="full", matrix_name="tune",
                      symbolic=symbolic)
    if plan == "main":
        return expand("final", CONFIG_DIR, paths, tier, list(datasets), [4], profile="reduced", matrix_name="confirm",
                      symbolic=symbolic)
    if plan == "legacy":
        out = []
        for phase, blocks in LEGACY_BLOCKS.items():
            out += expand(phase, CONFIG_DIR, paths, tier, ["fb15k237"], None, blocks, symbolic=symbolic)
        return out
    raise ValueError(plan)


def entry_cell_key(plan: str, e: Dict) -> str:
    from fedkge.manifest import cell_key
    return cell_key(plan, e["block"], e["dataset"], e["seed"], e["name"])


def approved_cells(mode: str = "research") -> List[Cell]:
    if mode == "research":
        man = frozen_manifest()
        return [Cell(c["cell_key"], c["plan"], c["tier"], c["phase"], int(c["stage"]), int(c["priority"]), c["block"],
                     c["dataset"], int(c["seed"]), c["name"], c["run_id"],
                     bool(c.get("reuses")) or c["block"] in REUSE_BLOCKS, c.get("coincides_if_fixed_schedule"))
                for c in man["cells"]]
    tiers = tiers_for(mode)
    cells: List[Cell] = []
    with tempfile.TemporaryDirectory() as tmp:          # no selections exist here: placeholders stay unresolved
        for plan in ("tune", "main", "legacy"):
            tier = tiers[plan]
            paths = Paths(tmp, tier)
            sym = expand_plan(plan, tier, paths, list(DATASETS), symbolic=True)
            fixed = {}
            for e in sym:
                if not e["placeholders"]:
                    fixed.setdefault((e["phase"], e["block"]), []).append(e)
            rid = {}
            for e in expand_plan(plan, tier, paths, list(DATASETS), stages=[0, 1] if plan == "tune" else None) \
                    if plan != "main" else []:
                rid[entry_cell_key(plan, e)] = e["run_id"]
            for e in sym:
                k = entry_cell_key(plan, e)
                cells.append(Cell(k, plan, tier, e["phase"], int(e["stage"]), int(e.get("priority", 0)), e["block"],
                                  e["dataset"], int(e["seed"]), e["name"],
                                  rid.get(k) if not e["placeholders"] else None, e["block"] in REUSE_BLOCKS, None))
    return cells


def load_cost_table() -> Dict:
    t = pd.read_csv(COST_TABLE)
    return {(r.plan, r.block, r.dataset): float(r.hours_per_run) for r in t.itertuples()}


def cell_hours(c: Cell, table: Optional[Dict] = None) -> float:
    """Estimated GPU-hours (T4 upper bound) of the NEW run a cell causes; 0 for cells that reuse a run."""
    if c.reuse:
        return 0.0
    if c.tier not in ("tune", "final"):
        return CHECK_TIER_HOURS_PER_RUN
    table = table if table is not None else load_cost_table()
    key = (c.plan, c.block, c.dataset)
    if key not in table:
        raise KeyError(f"no cost estimate for {key}; rebuild parallel/cost_table_T4_upper.csv")
    return table[key]
