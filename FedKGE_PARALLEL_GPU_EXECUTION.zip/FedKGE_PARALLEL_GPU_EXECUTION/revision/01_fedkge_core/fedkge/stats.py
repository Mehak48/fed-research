"""Statistics across seeds (n = 5 by design) - explicit about what n = 5 can and cannot support.

Per configuration: all per-seed values, mean, SD (ddof=1), 95% t-interval (t_{0.975, n-1}).
Paired comparison (same seed => same partition, initialisation and attacker placement):
  differences d_s = x_s(A) - x_s(B); mean difference with 95% t-CI; effect size d_z = mean(d)/sd(d);
  paired t-test (assumes approximately normal differences; Shapiro-Wilk p reported, low power at n=5);
  exact sign-flip permutation test over all 2^n sign patterns (distribution-free).
  LIMITATION: with n = 5 the smallest attainable two-sided p of any exact sign/sign-flip/Wilcoxon test is
  2/32 = 0.0625 (one-sided 1/32 = 0.031), so they can never reach the one-sided 0.025 level of the pre-registered
  tests. Effect sizes with CIs are the primary evidence; p-values are secondary and Holm-corrected within each
  pre-registered family (Phase B 03 section 13: H1, H2 (21 members), H2b, H3, HS; one-sided, alpha = 0.025).
Never: tests over rounds of one run (rounds are neither independent nor paired) - the old notebook did this.
"""
from __future__ import annotations

import itertools
from typing import Dict, List, Optional, Sequence

import numpy as np
from scipy import stats as st

MIN_EXACT_P_N5 = 2 / 32


def summarize(values: Sequence[float]) -> Dict:
    x = np.asarray(values, dtype=float)
    n = len(x)
    if n == 0:
        raise ValueError("no values to summarise")
    if np.isnan(x).any():
        raise ValueError("NaN in values to summarise; a failed/missing run must be handled explicitly")
    mean = float(x.mean())
    sd = float(x.std(ddof=1)) if n > 1 else float("nan")
    half = float(st.t.ppf(0.975, n - 1) * sd / np.sqrt(n)) if n > 1 else float("nan")
    return {"n": n, "mean": mean, "sd": sd, "ci95_low": mean - half, "ci95_high": mean + half,
            "min": float(x.min()), "max": float(x.max()), "values": x.tolist()}


def exact_signflip_p(d: np.ndarray) -> float:
    d = np.asarray(d, float)
    obs = abs(d.mean())
    n = len(d)
    cnt = 0
    for signs in itertools.product([1, -1], repeat=n):
        if abs((d * np.array(signs)).mean()) >= obs - 1e-15:
            cnt += 1
    return cnt / 2 ** n


def paired(a: Sequence[float], b: Sequence[float], seeds_a: Sequence[int], seeds_b: Sequence[int]) -> Dict:
    """a vs b paired by seed. Requires identical seed sets (fail loudly otherwise)."""
    da, db = dict(zip(seeds_a, a)), dict(zip(seeds_b, b))
    if set(da) != set(db):
        raise ValueError(f"paired comparison needs identical seed sets: {sorted(da)} vs {sorted(db)}")
    seeds = sorted(da)
    d = np.array([da[s] - db[s] for s in seeds], float)
    n = len(d)
    sd = d.std(ddof=1)
    half = st.t.ppf(0.975, n - 1) * sd / np.sqrt(n)
    t_p = float(st.ttest_rel([da[s] for s in seeds], [db[s] for s in seeds]).pvalue) if sd > 0 else float("nan")
    return {"n_pairs": n, "seeds": seeds, "diffs": d.tolist(), "mean_diff": float(d.mean()),
            "ci95_low": float(d.mean() - half), "ci95_high": float(d.mean() + half),
            "d_z": float(d.mean() / sd) if sd > 0 else float("nan"),
            "p_paired_t": t_p, "p_exact_signflip": exact_signflip_p(d),
            "shapiro_p": float(st.shapiro(d).pvalue) if n >= 3 and sd > 0 else float("nan"),
            "min_attainable_exact_p": 2 / 2 ** n,
            "n_positive": int((d > 0).sum()), "n_negative": int((d < 0).sum())}


def holm(pvals: List[float]) -> List[float]:
    p = np.asarray(pvals, float)
    order = np.argsort(p)
    m = len(p)
    adj = np.empty(m)
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, min(1.0, (m - rank) * p[i]))
        adj[i] = running
    return adj.tolist()


def _aligned(a: Dict[int, float], b: Dict[int, float]):
    if set(a) != set(b):
        raise ValueError(f"paired comparison needs identical seed sets: {sorted(a)} vs {sorted(b)}")
    seeds = sorted(a)
    return seeds, np.array([a[s] for s in seeds], float), np.array([b[s] for s in seeds], float)


def one_sided_t(d: np.ndarray, alternative: str) -> Dict:
    """One-sided one-sample t-test of mean(d) against 0 ('greater' or 'less'), with the one-sided 97.5 % bound."""
    d = np.asarray(d, float)
    n = len(d)
    if n < 2:
        raise ValueError("a t-test needs at least 2 paired seeds")
    sd = d.std(ddof=1)
    if sd == 0:
        p = 0.0 if ((alternative == "greater" and d.mean() > 0) or (alternative == "less" and d.mean() < 0)) else 1.0
        return {"n": n, "mean": float(d.mean()), "sd": 0.0, "t": float("inf") if p == 0.0 else float("nan"),
                "p_one_sided": p, "bound_97_5": float(d.mean())}
    t = d.mean() / (sd / np.sqrt(n))
    p = float(st.t.sf(t, n - 1)) if alternative == "greater" else float(st.t.cdf(t, n - 1))
    half = st.t.ppf(0.975, n - 1) * sd / np.sqrt(n)
    bound = d.mean() - half if alternative == "greater" else d.mean() + half
    return {"n": n, "mean": float(d.mean()), "sd": float(sd), "t": float(t), "p_one_sided": p,
            "bound_97_5": float(bound)}


def log_ratio_test(x: Dict[int, float], y: Dict[int, float], threshold: float) -> Dict:
    """H1 / H2b form: H0 E[log(x/y)] <= log(threshold) vs H1 > (one-sided paired t on per-seed log-ratios).
    Reports the geometric-mean ratio with its 95 % interval."""
    seeds, a, b = _aligned(x, y)
    if (a <= 0).any() or (b <= 0).any():
        raise ValueError("log-ratio test needs strictly positive values")
    lr = np.log(a / b)
    res = one_sided_t(lr - np.log(threshold), "greater")
    n = len(lr); sd = lr.std(ddof=1)
    half = st.t.ppf(0.975, n - 1) * sd / np.sqrt(n) if n > 1 else float("nan")
    res.update({"seeds": seeds, "ratio_geo_mean": float(np.exp(lr.mean())),
                "ratio_ci95": [float(np.exp(lr.mean() - half)), float(np.exp(lr.mean() + half))],
                "threshold": threshold})
    return res


def robustness_contrast(delta_fedavg: Dict[int, float], delta_method: Dict[int, float], keep: float = 0.65) -> Dict:
    """H2 member: effectiveness E = 1 - mean(Delta_method)/mean(Delta_FedAvg) (a ratio of means) >= 1 - keep.
    Testability gate: the attack must be effective against FedAvg (one-sided lower 97.5 % bound of
    mean(Delta_FedAvg) > 0); otherwise the member is 'not testable' and enters Holm with p = 1.
    Test: c_s = keep * Delta_F,s - Delta_P,s, H0 E[c] <= 0."""
    seeds, dF, dP = _aligned(delta_fedavg, delta_method)
    gate = one_sided_t(dF, "greater")
    out = {"seeds": seeds, "mean_delta_fedavg": float(dF.mean()), "mean_delta_method": float(dP.mean()),
           "E_ratio_of_means": float(1 - dP.mean() / dF.mean()) if dF.mean() != 0 else float("nan"),
           "attack_effective_bound_97_5": gate["bound_97_5"]}
    if not gate["bound_97_5"] > 0:
        out.update({"testable": False, "p_one_sided": 1.0})
        return out
    c = keep * dF - dP
    res = one_sided_t(c, "greater")
    out.update({"testable": True, "p_one_sided": res["p_one_sided"], "contrast_mean": res["mean"],
                "contrast_bound_97_5": res["bound_97_5"]})
    return out


def holm_family(members: Dict[str, Optional[float]], alpha: float = 0.025) -> Dict[str, Dict]:
    """Holm correction over a FIXED, pre-registered family. A member that is missing or not testable must be
    passed with p = 1 (or None, treated as 1), so the family size cannot shrink after seeing the data."""
    names = list(members)
    p = [1.0 if members[k] is None or not np.isfinite(members[k]) else float(members[k]) for k in names]
    adj = holm(p)
    return {k: {"p": p[i], "p_holm": adj[i], "reject": bool(adj[i] <= alpha)} for i, k in enumerate(names)}


def pareto_front(eps: Sequence[float], util: Sequence[float]) -> List[bool]:
    """Non-dominated points: lower epsilon is better, higher utility is better."""
    e, u = np.asarray(eps, float), np.asarray(util, float)
    out = []
    for i in range(len(e)):
        dominated = np.any((e <= e[i]) & (u >= u[i]) & ((e < e[i]) | (u > u[i])))
        out.append(not dominated)
    return out
