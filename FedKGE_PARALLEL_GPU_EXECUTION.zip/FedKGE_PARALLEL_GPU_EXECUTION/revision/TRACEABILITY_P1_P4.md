# Requirements traceability — Phases 1–4

| Requirement | Implementation | Notebook | Experiment | Output | Validation test | Manuscript evidence |
|---|---|---|---|---|---|---|
| 3 datasets, one parameterised pipeline | `data.py`, `datasets/*.yaml`, `runner.expand` | P1–P4 | all blocks × {fb15k237, wn18rr, yago310} | `artifacts/p1/<ds>`, `runs/*` | `test_artifact_hash_reproducible`, pipeline tests | dataset table (`reports/p1`) |
| Dataset validation, mappings, V_sel/V_root, hashes, cards | `data.validate_splits/build_artifact` | P1 | — | `dataset_card.json`, `validation_report.json`, `manifest.json` | `test_validation_detects_leakage_and_bad_ids`, schema checks | data section |
| IID, Dirichlet 1.0/0.1, legacy split (FB only), deterministic + stats | `partition.py`, `runner.partition_specs_needed` | P2 | all partitions × 5 seeds | `artifacts/p2/*`, `reports/p2/*` | `test_partition_*`, `test_legacy_partition_is_relation_disjoint` | heterogeneity table; Client-0 (**manuscript-dependent**) |
| Corrected FL trainer (d100, margin 1, L2 norm, Adam 1e-3, B512, 64 correct negatives, 10 clients, 1 epoch) | `base.yaml`, `train.py`, `sampling.py`, `federated.py` | P3 | P3_iid, P3_dir | `runs/p3_*/final.json` | `test_correct_negatives_*`, `test_config_guards` | main non-DP table |
| Full filtered head+tail realistic evaluation; no test selection | `evaluate.py`, `federated.py` (best V_sel checkpoint, test once) | P3/P4 | all | `final.json → val, test` | `test_filtered_head_tail_realistic_matches_bruteforce`, `test_ties_are_not_optimistic`, `test_selections_use_validation_only_and_full_grid` | every MRR in the paper |
| Centralised baseline measured | block `P3_central` | P3 | P3_central | `reports/p3/p3_fl_gap_paired.csv` | linter (no 0.0940) | replaces 3.04× claim |
| Legacy replicas isolated | blocks `R3_legacy`, `R4_legacy`, `L1_legacy`; `neg_mode` legacy; `evaluate_legacy` | P3/P4 | R3/R4/L1 | `*legacy_replica.csv` | `test_legacy_p4_bug_is_reproduced`, `test_reproduces_old_per_round_log` | old-vs-new explanation |
| 5 seeds, per-seed values, mean/SD/CI, paired stats, effect size | `stats.py`, `analysis.seed_table`, `reports.py` | P3/P4 | all | every report CSV (`*.seedS` columns) | pipeline report test | all tables |
| Example-level client DP-SGD, clipping, Gaussian noise | `dp.py` | P4 | L1–L3, 4B–4D | `accountant.json` | `test_matches_opacus`, `test_matches_bruteforce_*`, `test_noise_is_dense_and_scaled` | DP method section |
| Formal RDP, PLD cross-check, worst-client ε, δ = 1e-6, heterogeneous σ_t, full trace, no fallback | `accountant.py`, `federated.py` | P4 | all DP blocks | `accountant.json`, `final.json → privacy` | `test_epsilon_recomputed_independently`, `test_rdp_vs_pld_crosscheck`, `test_calibration_meets_target_tightly`, linter | privacy guarantee statement |
| No warm start | `config.validate` | P3/P4 | — | `config.json` | `test_config_guards` | method section |
| DP ladder L1→L4 | `p4.yaml` (L1, L2, L3, 4B@C_sel = L4a, selected schedule = L4b), `reports.table_ladder` | P4 | ladder blocks | `p4_dp_ladder*.csv` | `test_reports_are_built_and_watermarked` | decomposition table |
| Clip / schedule / regime sweeps with full grids + pre-registered validation-only selection | `p4.yaml`, `selection.py`, `selection_rules.yaml` | P4 | 4B, 4C, 4D | `dp_selection.json`, `p4_clip_grid.csv`, `p4_schedule_grid.csv`, `p4_privacy_utility.csv` | `test_selections_use_validation_only_and_full_grid` | threshold/sensitivity figures |
| Per-run machine-readable outputs (dataset, seed, clients, partition, config, rounds, DP params, clip, schedule, ε, δ, MRR, Hits, per-round, runtime, config hash, provenance) | `federated.py`, `io.environment` | P3/P4 | all | `final.json`, `rounds.csv`, `accountant.json`, `env.json` | `test_all_outputs_match_schemas` | reproducibility appendix |
| Strict dependency chain + automatic invalidation, fail on missing input | `io.py`, `analysis.collect`, `partition.load_partition`, `data.load_artifact` | all | — | `status.json`, `stale/` | `test_stale_code_is_detected`, `test_missing_upstream_fails_without_fallback`, `test_partition_artifact_hash_and_upstream_check` | — |
| Tiers never leak into final tables | tier folders, `collect` tier check, filename prefixes | all | — | `*_NOT_FOR_MANUSCRIPT_*` | `test_reports_are_built_and_watermarked` | — |
| Resume / checkpoint | `federated.py`, `runner.run_entries` | P3/P4 | — | `checkpoint.pt` | `test_resume_after_interruption` | — |
| MI isolated, disabled | `mia.py`, `base.yaml mia.enabled: false` | (P4 optional) | — | `final.json → mia` if enabled | — | **manuscript-dependent (H3)** |

**Not implementable from the supplied artifacts yet:** Client-0 74.26 % comparison, round-count inconsistency check
against the paper, related-work values — all need the manuscript/review.
