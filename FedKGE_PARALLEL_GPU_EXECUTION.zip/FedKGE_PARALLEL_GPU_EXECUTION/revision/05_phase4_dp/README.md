# Phase 4 — Formal DP and adaptive-DP investigation
**Notebook:** `phase4_dp.ipynb` · **Inputs:** P1, P2, **complete P3** · **GPU:** yes · **Runs:** ≈305 (final)

Stages inside one notebook: (1) ladder L1/L2/L3 + old-P4 replica R4 + clip sweep 4B → **pre-registered clip
selection** → (2) schedule sweep 4C at ε* = 4 → **pre-registered schedule selection** → (3) privacy regimes 4D.
Selections read validation MRR only and refuse partial grids. See `13_documentation/DP_MECHANISM.md`,
`THRESHOLDS.md`, `EXECUTION_PLAN.md`.

**Extra per DP run:** `accountant.json` = mechanism, privacy unit, δ, C, mode, schedule, per-client (n, q, steps,
σ₀, ε at every δ), worst client, σ schedule per client, ε trace per round per client, orders, PLD cross-check,
`budget_ok`, `schedule_verified`, and for legacy rows the naive sum. `final.json → privacy` summarises it;
`rounds.csv` has ε_max/ε_min, mean σ, clip fraction, gradient-norm median per round.
**Reports:** `reports/p4/{p4_dp_ladder, p4_dp_ladder_paired_steps, p4_clip_grid, p4_schedule_grid,
p4_privacy_utility, p4_legacy_replica, p4_all_runs}.csv`; `selection/dp_selection.json`.
**Rule:** report measured degradation as is; a schedule "helps" only if the paired gain at equal ε* has a CI above 0.
**MI:** module present, disabled (`mia.enabled: false`) until the manuscript confirms H3.
