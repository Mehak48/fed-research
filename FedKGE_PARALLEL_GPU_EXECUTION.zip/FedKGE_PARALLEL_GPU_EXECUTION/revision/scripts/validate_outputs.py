#!/usr/bin/env python3
"""Schema validation of a whole results tier (Phase C, gate G-A "schemas valid").

  python scripts/validate_outputs.py --tier smoke            [--results R]

Checks every Phase 1 artifact (dataset card, manifest, split validation report), every Phase 2 partition
(manifest, statistics), every run directory (config, final, accountant, integrity, attack, MIA, rounds.csv,
trust_rounds.csv), every run index and the tuning selection, against 11_experiment_schemas/. Directories under
'_superseded/' and 'stale/' are kept for the record and are not validated. Writes
test_reports/schema_validation_<tier>_<UTC>.json and exits 1 if anything fails.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import jsonschema

from _common import REPO, SCHEMA_DIR, Manifest, results_root
from fedkge.schemas import validate_csv_columns, validate_file, validate_run_dir


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results"); ap.add_argument("--tier", required=True)
    a = ap.parse_args(argv)
    root = results_root(a.results)
    base = root / a.tier
    man = Manifest(root, f"validate_outputs_{a.tier}")
    checked, failures = [], []

    def check(label, fn):
        try:
            fn()
            checked.append(label)
        except (jsonschema.ValidationError, FileNotFoundError, KeyError, ValueError) as e:
            failures.append({"item": label, "error": str(e)[:500]})

    p1 = base / "artifacts" / "p1"
    for d in sorted(p1.glob("*")) if p1.exists() else []:
        for fname, schema in (("dataset_card.json", "dataset_card"), ("manifest.json", "p1_manifest"),
                              ("validation_report.json", "validation_report")):
            check(f"p1/{d.name}/{fname}", lambda d=d, f=fname, s=schema: validate_file(d / f, SCHEMA_DIR, s))
    p2 = base / "artifacts" / "p2"
    for mp in sorted(p2.glob("*/*/seed*_manifest.json")) if p2.exists() else []:
        rel = mp.relative_to(p2)
        check(f"p2/{rel}", lambda mp=mp: validate_file(mp, SCHEMA_DIR, "partition_manifest"))
        sp = mp.with_name(mp.name.replace("_manifest.json", "_stats.json"))
        check(f"p2/{sp.relative_to(p2)}", lambda sp=sp: validate_file(sp, SCHEMA_DIR, "partition_stats"))
    n_runs = 0
    for rd in sorted((base / "runs").glob("*")) if (base / "runs").exists() else []:
        if not (rd / "final.json").exists():
            continue                                   # failed or running runs are reported by the runner, not here
        n_runs += 1
        check(f"runs/{rd.name}", lambda rd=rd: validate_run_dir(rd, SCHEMA_DIR))
    for ip in sorted((base / "index").glob("*.csv")) if (base / "index").exists() else []:
        check(f"index/{ip.name}", lambda ip=ip: validate_csv_columns(ip, SCHEMA_DIR, "runs_index"))
    sel = base / "selection" / "tuning.json"
    if sel.exists():
        check("selection/tuning.json", lambda: validate_file(sel, SCHEMA_DIR, "tuning_selection"))
    stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    out = root / "test_reports" / f"schema_validation_{a.tier}_{stamp}.json"
    rep = {"tier": a.tier, "results": str(base), "schema_dir": str(SCHEMA_DIR.relative_to(REPO)),
           "n_items_checked": len(checked), "n_run_dirs": n_runs, "n_failures": len(failures), "failures": failures,
           "checked": checked}
    out.write_text(json.dumps(rep, indent=2)); man.output(out)
    man.close("COMPLETE" if not failures else "SCHEMA_FAILURES", n_checked=len(checked), n_failures=len(failures))
    print(json.dumps({k: rep[k] for k in ("tier", "n_items_checked", "n_run_dirs", "n_failures")}, indent=1))
    for f in failures[:20]:
        print("FAIL", f["item"], "-", f["error"][:200])
    return 0 if not failures else 1


if __name__ == "__main__":
    sys.exit(main())
