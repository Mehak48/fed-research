# Validation of the parallel execution layer (2026-11-07)

Software checks only: CPU, smoke tier on real data subsets, synthetic registries. **Nothing here is research evidence.**

| File | What it is |
|---|---|
| `test_report_parallel.txt` | `pytest revision/parallel/tests` (plan, exchange, CLI) |
| `test_report_core.txt` | the unchanged core suite `revision/12_validation_tests`, re-run after adding the layer |
| `e2e_result_stage.json`, `e2e_result_chain.json` | sequential entry points vs the parallel phases with 3 concurrent workers (`revision/parallel/tests/e2e_smoke_equivalence.py`), in both tuning modes |
| `e2e_validation_report_*.md` | the master store's validation report at the end of each end-to-end run |
| `notebook_harness_*.json` | cell-by-cell execution of the two parallel notebooks (smoke mode, CPU, local folder) |
| `PLAN_EXAMPLES.md` | example schedules for 1-4 GPUs (estimates from the T4 upper bounds) |
