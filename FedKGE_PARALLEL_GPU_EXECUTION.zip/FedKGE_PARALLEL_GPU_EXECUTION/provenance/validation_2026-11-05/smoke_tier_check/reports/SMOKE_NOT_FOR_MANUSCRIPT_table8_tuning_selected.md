# Table 8 — Stage 3 selection (selected); validation only

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| dataset | T1_central (lr, B) | T1_nonprivate (lr, B) | q*, lr* | C* | R* | design | s* | tau* | tau rule | benign FPR at tau* | tau label |
|---|---|---|---|---|---|---|---|---|---|---|---|
| FB15k-237 | {"lr": 0.01, "batch_size": 512} | {"lr": 0.001, "batch_size": 512} | {"dp": {"q": 0.1}, "train": {"lr": 0.001}} | {"dp": {"clip": 0.25}} | {"train": {"rounds_max": 50}} | {"dp": {"sampling": "common_rate"}} | {"dp": {"schedule": {"shape": "fixed", "rho": 1.0}}} | 2 | RULE_MET | 0 | tau rule met |
| WN18RR | {"lr": 0.01, "batch_size": 512} | {"lr": 0.001, "batch_size": 512} | {"dp": {"q": 0.1}, "train": {"lr": 0.001}} | {"dp": {"clip": 0.25}} | {"train": {"rounds_max": 50}} | {"dp": {"sampling": "common_rate"}} | {"dp": {"schedule": {"shape": "fixed", "rho": 1.0}}} | 3 | RULE_MET | 0.03333 | tau rule met |
| CoDEx-M | {"lr": 0.01, "batch_size": 512} | {"lr": 0.01, "batch_size": 512} | {"dp": {"q": 0.1}, "train": {"lr": 0.001}} | {"dp": {"clip": 0.25}} | {"train": {"rounds_max": 50}} | {"dp": {"sampling": "common_rate"}} | {"dp": {"schedule": {"shape": "fixed", "rho": 1.0}}} | 5 | RULE_MET | 0 | tau rule met |
