#!/usr/bin/env python3
"""PHASE 08 (master, CPU) - import every verified result bundle from <base>/exchange/outbox into the master store.

  python parallel/phases/phase08_import_results.py --base B

Safe to run at any time and as often as you like: a bundle still being written or synced (no sidecar, or bytes that
differ from it) is left for later; an imported bundle is never imported twice (IMPORT_LEDGER.json); a refused bundle
is re-examined on the next call (e.g. after phase 02 on the master). Every run is validated before it is moved into
place atomically (fedkge_parallel/store.py lists the checks). Nothing is deleted, nothing is overwritten.
Outputs: <master>/<tier>/runs/<run_id>/, indexes, ENVIRONMENT_LOCK.json, parallel/IMPORT_LEDGER.json, PROGRESS.md.
Next: phase 05 (selections and releases), phase 09 (validation), phase 10-11 (analysis, report).
"""
from __future__ import annotations

import sys

from _cli import finish, layout, parser

from fedkge_parallel.common import EXIT_CONTRACT, EXIT_OK, frozen_manifest
from fedkge_parallel.store import Master


def main(argv=None) -> int:
    ap = parser(__doc__)
    a = ap.parse_args(argv)
    L = layout(a)
    m = Master(L, a.mode)
    s = m.import_all()
    for r in s["imported"]:
        print(f"{r['bundle']}: {r['status']} - {len(r['imported'])} new run(s), {len(r['identical_already_present'])} "
              f"identical, {len(r['conflicts'])} conflict(s), {len(r['refused_runs'])} refused run(s)")
        for rid, why in list(r["refused_runs"].items())[:10]:
            print(f"   refused {rid}: {why}")
    for r in s["refused"]:
        print(f"{r['bundle']}: REFUSED - {r['reason']}")
    print(f"{s['skipped_known']} bundle(s) already imported; not yet verifiable: {s['not_yet_verifiable'] or 'none'}")
    if a.mode == "research":
        from fedkge.manifest import write_progress
        write_progress(m.root, frozen_manifest())
    return finish(EXIT_CONTRACT if s["refused"] else EXIT_OK)


if __name__ == "__main__":
    sys.exit(main())
