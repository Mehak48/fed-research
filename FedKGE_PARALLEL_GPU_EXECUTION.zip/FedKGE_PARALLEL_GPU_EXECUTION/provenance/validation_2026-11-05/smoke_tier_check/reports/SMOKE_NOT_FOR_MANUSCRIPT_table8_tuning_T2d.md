# Table 8 — Stage 3 selection (T2d); validation only

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| dataset | dp.sampling | val_mrr_mean | chosen | tied_within_tolerance |
|---|---|---|---|---|
| codex_m | common_rate | 0.002018 | True | True |
| codex_m | fixed_batch | 0.00201 | False | True |
| fb15k237 | common_rate | 0.002599 | True | True |
| fb15k237 | fixed_batch | 0.002599 | False | True |
| wn18rr | common_rate | 0.0008418 | True | True |
| wn18rr | fixed_batch | 0.0008528 | False | True |
