# FedKGE revision — implementation package (Phase C)

A federated TransE pipeline:

- triple-level DP per client (zero-out adjacency);
- trust-weighted aggregation and robust baselines;
- poisoning attacks;
- SHA-256 integrity verification in the data path. This is **not** a poisoning defence, and there is **no IPFS**.

It runs on three benchmarks: FB15k-237, WN18RR and CoDEx-M.

**Specification:** `../audit/phaseB/` (decisions D1–D18). **Phase C status:** `../audit/phaseC/`.

> **Nothing produced so far is a scientific result.** Smoke and pilot runs are software checks. The tuning (Stage 3) and confirmatory (Stage 4) runs have not started.

## Layout

```
01_fedkge_core/fedkge/   the package (all science; its code hash is recorded in every run)
10_configs/              base.yaml, datasets/, tiers/ (smoke, smoke_synthetic, dev, pilot, tune, final),
                         matrices/ (tune.yaml = Stage 3, confirm.yaml = Stages 4-5, p3/p4 = legacy replicas),
                         selection_rules.yaml (pre-registered)
11_experiment_schemas/   JSON schemas for every output
12_validation_tests/     pytest suite (legacy + test_phaseC_*)
13_documentation/        DP_MECHANISM.md, THREAT_MODEL.md, theory, thresholds (some pages still describe the
                         original package)
scripts/                 Phase C entry points (below)
colab/                   phaseC_pilot_colab.ipynb (free-Colab GPU pilot kit)
02_ … 09_                original Colab notebooks for Phases 1-4 (kept; superseded by scripts/)
```

## Setup

```bash
python3.13 -m venv ../.venv && . ../.venv/bin/activate
pip install -r requirements-phaseC.txt      # exact versions; on Colab/Kaggle keep the platform torch (requirements-colab.txt)
```

Results go to `results/phaseC/`. To change this, pass `--results DIR` or set `FEDKGE_RESULTS`. The folder contains:

| Folder | Contents |
|---|---|
| `logs/` | Step logs |
| `manifests/` | One execution manifest per step: command, code version, start and end times, outputs, warnings |
| `test_reports/` | Test and schema reports |
| `privacy_accounting/` | Accounting validation |
| `smoke/`, `pilot/`, `tune/`, `final/` | Per tier: `artifacts/p1`, `artifacts/p2`, `runs/<run_id>/`, `index/`, `selection/` |
| `configs/`, `checkpoints/` | Reserved |

**Every run directory holds:**

- `config.json`, `env.json`, `status.json`;
- `rounds.csv`, `weights_rounds.csv`, `trust_rounds.csv`;
- `final.json`;
- `accountant.json` (DP runs), `attack.json`, `integrity.json`, `mia.json` + `mia_scores.csv`, as applicable.

## Commands, in the required order

**1. Tests** (unit, integration, regression, reproducibility, failure paths, PyTorch):

```bash
python scripts/run_tests.py --name <label>          # → results/phaseC/test_reports/summary_<label>.json
```

**2. Privacy-accounting validation** (96 operating points, five methods):

```bash
python scripts/check_privacy_accounting.py          # → results/phaseC/privacy_accounting/accounting_validation_<UTC>.csv
```

**3. Datasets.** Licence-gated; nothing is downloaded without `--i-confirm-licence` and the owner's note:

```bash
python scripts/prepare_data.py --dataset codex_m --data-dir ../data_cache                 # prints source and terms
python scripts/prepare_data.py --dataset codex_m --data-dir ../data_cache --i-confirm-licence --operator-note "..."
```

**4. Artifacts and partition audit** (acceptance rates on the real relation counts):

```bash
python scripts/build_artifacts.py --tier smoke --datasets fb15k237 wn18rr codex_m --data-dir ../data_cache \
       --seeds 42 --alphas 0.1 --iid --central --accept-draws 2000
python scripts/build_artifacts.py --tier pilot --datasets fb15k237 wn18rr codex_m --data-dir ../data_cache \
       --seeds 1001 --alphas 0.1 0.5 1.0 --iid --central --accept-draws 2000
```

**5. Small runs.** Non-private and private smoke, one per dataset:

```bash
python scripts/small_run.py --dataset fb15k237 --tier smoke --rounds 3 \
       --profiles np_central np_fed np_fed_iid dp_q dp_a complete attack_alie attack_targeted integrity_corrupt mia dp3_no_noise
```

**6. Every block in smoke** (gate G-A). In smoke only, a failed τ rule can be bridged by a recorded placeholder:

```bash
python scripts/run_plan.py --plan tune --tier smoke --datasets fb15k237 wn18rr codex_m --smoke-tau-fallback 3.0
python scripts/run_plan.py --plan confirm --tier smoke --profile reduced --datasets fb15k237 wn18rr codex_m
python scripts/validate_outputs.py --tier smoke     # schema check of everything in results/phaseC/smoke
```

**7. L0.** The saved legacy model, re-evaluated under the corrected protocol (read-only):

```bash
python scripts/legacy_l0_eval.py --checkpoint /path/to/complete/global_transe_final.pt --tier pilot
```

**8. Measured pilot** (gate G-B). On a GPU: `colab/phaseC_pilot_colab.ipynb`. Locally:

```bash
python scripts/pilot.py --datasets fb15k237 wn18rr codex_m --rounds 2 [--device cuda]
```

**Not before the owner approves the pilot, the budget and the open decisions** (`../audit/phaseC/remaining_blockers.md`):

```bash
python scripts/run_plan.py --plan tune --tier tune --datasets fb15k237 wn18rr codex_m --device cuda      # Stage 3
python scripts/freeze_selections.py
python scripts/run_plan.py --plan confirm --tier final --profile reduced --datasets fb15k237 wn18rr codex_m --device cuda
```

## Rules the code enforces

- **Validation-only selection.** The final tier refuses to select.
- **Synthetic data** is refused in the tune and final tiers.
- **Warm starts** are rejected.
- **Stale runs** are archived, never deleted. A changed code hash, data, partition or selection marks dependent runs stale.
- **Historical files** are never written; a regression test re-hashes them.

## Original package (Phases 1–4 notebooks)

`MASTER_EXECUTION_ORDER.md` and `13_documentation/COLAB_RUNBOOK.md` describe the original notebook workflow. The notebooks still work with the legacy matrices `p3` and `p4`. The Phase C scripts above supersede them for the revised study.
