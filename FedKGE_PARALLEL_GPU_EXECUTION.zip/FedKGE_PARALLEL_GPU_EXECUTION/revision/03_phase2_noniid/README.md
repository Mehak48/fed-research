# Phase 2 — Non-IID partitioning and analysis
**Notebook:** `phase2_noniid.ipynb` · **Inputs:** Phase 1 artifacts · **GPU:** no · **Runtime:** ~1–10 min

Builds exactly the partitions required by `10_configs/matrices/p3.yaml` and `p4.yaml` (derived automatically) for
every tier seed: IID (10 clients), Dirichlet-over-relations α = 1.0 and α = 0.1 (10 clients; α = 0.1 = main),
centralised (1 client), and the legacy relation-disjoint 5-client split **for FB15k-237 only (reproduction)**.
Dirichlet partitions are re-drawn from the same seeded generator until every client has ≥ 20 % of the mean size
and ≥ 1,024 triples (attempts logged).

**Outputs:** `artifacts/p2/<ds>/<spec>/seed<S>{.npz,_stats.json,_manifest.json}`, `reports/p2/*partition_stats*.csv`,
`*client_stats.csv`, `*client_share_curves.png`.
**Checks:** schemas; full coverage; min size; legacy relation-disjointness; re-derivation reproduces the partition;
each partition bound to the current Phase 1 hash.
**Manuscript-dependent:** Client-0 74.26 % comparison (needs manuscript).
