#!/usr/bin/env python3
"""Writes RUN_COMPLETE_FEDKGE_RESEARCH.ipynb (the primary Colab notebook) next to revision/.

  python colab/make_notebook.py --commit <git commit> --manifest-sha <content sha256> --code-hash <core code hash>

The notebook lives OUTSIDE the git repository on purpose: it carries the expected commit, so it cannot be inside the
commit it checks. Maintainer tool; the operator never runs this.

Structure (owner directive of 2026-11-05): Steps 1-9 in order. The mandatory path starts no smoke test, pilot,
benchmark or CPU test-suite training; the only preliminary training is the mandatory accuracy sanity gate (Step 3).
The CPU test suite stays available as an opt-in appendix cell (RUN_CPU_CHECKS).
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

MD, CODE = "markdown", "code"

CELLS = [
(MD, r"""# FedKGE — complete executable methodology

**The whole approved study in one notebook** (owner decisions D1–D18, B2–B5), on FB15k-237, WN18RR and CoDEx-M:

| Step | What | Runs | T4 upper bound* |
|---|---|---|---|
| 1 | Environment setup (no training) | — | minutes |
| 2 | Datasets: licence, download, checksums, deterministic preprocessing (only what is missing) | — | minutes, first session only |
| 3 | **Mandatory accuracy sanity gate** (G-B) | 18 | ≈ 1.7 GPU-h |
| 4 | Pre-registered tuning (Stage 3), then the selections are frozen (G-C) | 81 more (99 in total) | ≈ 10.8 GPU-h |
| 5 | Main experiments (Stage 4), priority order 1 → 7 | 756 | ≈ 100.5 GPU-h |
| 6 | Original-paper replications L1–L4 (priority 4 of Step 5) + optional L0 | 30 | ≈ 5.4 GPU-h |
| | **Total** | **885** | **≈ 118 GPU-h** |
| 7 | Statistical analysis | — | minutes |
| 8 | Figures, tables, results draft | — | minutes |
| 9 | Export | — | minutes |

\* Upper bounds from the owner's measured Phase C T4 pilot, not measurements of complete runs (`DEADLINE_PLAN.md`). Stage 5 is deferred (B2).

**The notebook starts no smoke test, pilot or benchmark.** The only preliminary training is the mandatory accuracy sanity gate (Step 3). The CPU test suite is an optional appendix cell (off by default).

**How to use it**

1. `Runtime → Change runtime type → T4 GPU`.
2. Put `FedKGE_PARALLEL_GPU_EXECUTION.zip` (unchanged) into `MyDrive/FedKGE/`.
3. Edit **only the settings cell (Step 1a)**: the licence confirmation and your note, once.
4. **Every session:** run Step 1 and Step 2 (a few minutes; nothing is downloaded or preprocessed twice), then continue with the first step that is not COMPLETE.
5. Every step is safe to run again. A completed run is never executed again, an interrupted run continues from its last checkpoint, and nothing that finished is overwritten.
6. **PAUSED (session budget)** means the time budget of this session is used up. Next session: Step 1 → Step 2 → the same step again.
7. Run **one session at a time** on this Drive folder.

**What is kept where:** every run folder, selection, log and report is on your Drive (`MyDrive/FedKGE/results/`). A disconnect loses at most the run in progress, which resumes from its last checkpoint. The code is unpacked fresh each session and checked against its git commit."""),
(MD, r"""## Step 1 — Environment setup
Settings, runtime check, Drive, package verification, pinned dependencies and the frozen run manifest. No training.

### 1a. Settings — the only cell to edit"""),
(CODE, r"""DRIVE_ROOT = "/content/drive/MyDrive/FedKGE"                    # your Drive folder (results and data stay here)
PACKAGE_ZIP = "FedKGE_PARALLEL_GPU_EXECUTION.zip"      # the package zip, uploaded into DRIVE_ROOT
DATASETS = ["fb15k237", "wn18rr", "codex_m"]                    # the three approved benchmarks (keep all three)
MAX_HOURS_THIS_SESSION = 10.5   # no NEW run starts after this many hours (free sessions end after ~12 h)

# Dataset licences: Step 2 prints each dataset's source, licence terms and citation. Set True only after reading them.
LICENCE_CONFIRMED = {"fb15k237": False, "wn18rr": False, "codex_m": False}
LICENCE_NOTE = ""   # who confirmed, when and for what, e.g. "Mehak Ramzan, 2026-11-10: research use, attribution, no redistribution"

# Optional: run the CPU test suite in the appendix cell (about 3-5 minutes; not part of the research path)
RUN_CPU_CHECKS = False

# ===================== fixed by the package (do not edit) =====================
EXPECTED_GIT_COMMIT = "__EXPECTED_GIT_COMMIT__"
EXPECTED_MANIFEST_CONTENT_SHA256 = "__EXPECTED_MANIFEST_SHA__"
EXPECTED_CORE_CODE_HASH = "__EXPECTED_CODE_HASH__"
TUNE_TIER, FINAL_TIER, DEVICE, REQUIRE_GPU = "tune", "final", "cuda", True
PINNED = {"numpy": "2.5.3", "scipy": "1.18.1", "pandas": "3.0.5", "PyYAML": "6.0.3", "jsonschema": "4.26.0",
          "matplotlib": "3.11.2", "dp-accounting": "0.6.0", "prv-accountant": "0.2.0", "opacus": "1.6.0",
          "pytest": "9.1.1"}
print("settings loaded")"""),
(MD, r"""### 1b. Runtime check
Stops if the runtime cannot run the study: no GPU, a Python version outside 3.10–3.13, or a torch build that is too old. Colab's own CUDA build of PyTorch is kept (never reinstalled) and recorded in every run."""),
(CODE, r"""import os, sys, json, time, shutil, hashlib, zipfile, subprocess, pathlib, re, platform
SESSION_T0 = time.time()
print("Python", sys.version.split()[0], "|", platform.platform())
assert (3, 10) <= sys.version_info[:2] <= (3, 13), (
    f"Python {sys.version.split()[0]} is outside the tested range 3.10-3.13: the pinned packages may not install. "
    "Use a standard Colab runtime.")
import torch
print("torch", torch.__version__, "| CUDA build", torch.version.cuda, "| GPU available", torch.cuda.is_available())
major, minor = (int(x) for x in torch.__version__.split("+")[0].split(".")[:2])
assert (major, minor) >= (2, 4), f"torch {torch.__version__} is too old (need >= 2.4)"
if REQUIRE_GPU:
    assert torch.cuda.is_available(), ("No GPU. Runtime > Change runtime type > T4 GPU, then run from Step 1 again. "
                                       "Free Colab sometimes assigns no GPU: wait and reconnect.")
    GPU_NAME = torch.cuda.get_device_name(0)
    print("GPU:", GPU_NAME, "| memory", round(torch.cuda.get_device_properties(0).total_memory / 1e9, 1), "GB")
    if "T4" not in GPU_NAME:
        print("NOTE: the measured budget assumes a Tesla T4. Another GPU type is fine for a dataset that has not "
              "started yet, but the environment lock refuses to mix GPU types inside one dataset's stage.")
else:
    GPU_NAME = None
    print("CPU mode (software check only)")

def sh(*args, cwd=None, check=True, quiet=False, log=None):
    # run a command; quiet=True prints only run headers, results, warnings and errors (the full output goes to log)
    print("$", " ".join(str(a) for a in args), flush=True)
    p = subprocess.Popen([str(a) for a in args], cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    keep = re.compile(r"(=== \[|DONE |#####|selections:|STOP|PAUSED|WARNING|FAILED|Traceback|Error|error|PASSED|"
                      r"frozen|EXPORT|MANIFEST|gate|tau|D10|COMPLETE|PENDING|wrote|\| )")
    lines = []
    fh = open(log, "a") if log else None
    for line in p.stdout:
        lines.append(line)
        if fh: fh.write(line)
        if not quiet or keep.search(line):
            print(line, end="", flush=True)
    p.wait()
    if fh: fh.close()
    if check and p.returncode != 0:
        raise RuntimeError(f"command failed with exit code {p.returncode}: {' '.join(map(str, args))}")
    return subprocess.CompletedProcess(args, p.returncode, "".join(lines), "")

def hours_left():
    return max(0.0, MAX_HOURS_THIS_SESSION - (time.time() - SESSION_T0) / 3600)

def paused_msg(step):
    return f"PAUSED (session budget): next session run Step 1 and Step 2, then Step {step} again"
"""),
(MD, r"""### 1c. Mount Drive, unpack the package, verify it
The code is unpacked to the Colab disk every session and must be exactly the committed, frozen version: same git commit and no modified file."""),
(CODE, r"""try:
    from google.colab import drive
    drive.mount("/content/drive")
except ImportError:
    print("not on Colab: no Drive mount (software check)")
ROOT = pathlib.Path(DRIVE_ROOT); ROOT.mkdir(parents=True, exist_ok=True)
zp = ROOT / PACKAGE_ZIP
assert zp.exists(), f"Upload {PACKAGE_ZIP} into {ROOT} first"
WORK = pathlib.Path(os.environ.get("FEDKGE_WORK", "/content/fedkge_pkg"))
shutil.rmtree(WORK, ignore_errors=True); WORK.mkdir(parents=True)
with zipfile.ZipFile(zp) as z:
    bad = [n for n in z.namelist() if n.startswith("/") or ".." in n.split("/")]
    assert not bad, f"unsafe paths in the zip: {bad[:3]}"
    z.extractall(WORK)
PKG = next(WORK.glob("*/revision")).parent
REPO = PKG / "revision"
GIT = ["git", "-c", "safe.directory=*", "-c", "core.fileMode=false"]   # zip extraction drops file modes
head = subprocess.run(GIT + ["rev-parse", "HEAD"], cwd=REPO, capture_output=True, text=True).stdout.strip()
dirty = subprocess.run(GIT + ["status", "--porcelain"], cwd=REPO, capture_output=True, text=True).stdout.strip()
print("git commit:", head)
assert head == EXPECTED_GIT_COMMIT, f"the code is commit {head}, expected {EXPECTED_GIT_COMMIT}: wrong or changed zip"
assert not dirty, f"files differ from the committed version:\n{dirty[:500]}"
RESULTS = ROOT / "results"; DATA = ROOT / "data_cache"; LOGS = RESULTS / "logs"
for d in (RESULTS, DATA, LOGS): d.mkdir(parents=True, exist_ok=True)
os.environ["FEDKGE_RESULTS"] = str(RESULTS)
SESSION_LOG = LOGS / f"notebook_session_{time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())}.log"
print("package:", PKG.name, "| results:", RESULTS, "| data:", DATA, "| session log:", SESSION_LOG)"""),
(MD, r"""### 1d. Pinned dependencies, frozen manifest, environment record
Everything except torch is pinned to the versions the test suite passed with; any mismatch stops the notebook. The core code hash and the frozen run manifest must match the package. The environment (GPU type, torch, CUDA, Python) is recorded; the stage scripts refuse to mix environments inside one dataset's comparison."""),
(CODE, r"""sh(sys.executable, "-m", "pip", "install", "-q", *[f"{k}=={v}" for k, v in PINNED.items()], log=SESSION_LOG)
import importlib.metadata as md
wrong = {k: md.version(k) for k in PINNED if md.version(k) != PINNED[k]}
assert not wrong, f"installed versions differ from the pins: {wrong} - restart the runtime (Runtime > Restart) and run from Step 1"
(RESULTS / "colab_pip_freeze_latest.txt").write_text(sh(sys.executable, "-m", "pip", "freeze", quiet=True).stdout)
def py(code):      # run a snippet in a fresh interpreter (the notebook kernel never imports the project or its pins)
    return sh(sys.executable, "-c", "import sys, json; sys.path.insert(0, '01_fedkge_core'); " + code, cwd=REPO,
              quiet=True).stdout.strip().splitlines()[-1]
ch = py("from fedkge.io import code_hash; print(code_hash())")
assert ch == EXPECTED_CORE_CODE_HASH, f"core code hash {ch} != {EXPECTED_CORE_CODE_HASH}"
sh(sys.executable, "scripts/build_manifest.py", "--check", cwd=REPO)
man = json.loads((REPO / "10_configs" / "manifest" / "FROZEN_MANIFEST.json").read_text())
assert man["content_sha256"] == EXPECTED_MANIFEST_CONTENT_SHA256, "frozen manifest differs from the package's"
print("pinned versions OK; frozen manifest OK:", json.dumps(man["approved_budget"]))
SIG = json.loads(py(f"from fedkge.gates import environment_signature; print(json.dumps(environment_signature('{DEVICE}')))"))
print("environment signature:", SIG)
(RESULTS / "sessions").mkdir(exist_ok=True)
(RESULTS / "sessions" / f"{time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())}.json").write_text(json.dumps(
    {"git_commit": head, "signature": SIG, "gpu": GPU_NAME, "python": sys.version, "started_utc": time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}, indent=1))
sh(sys.executable, "scripts/status.py", "--results", RESULTS, cwd=REPO, check=False)
print("STEP 1 COMPLETE")"""),
(MD, r"""## Step 2 — Datasets: licence, download, integrity, deterministic preprocessing
Each dataset's source, licence terms and citation are printed first. Nothing is downloaded unless you confirmed that dataset in Step 1a and wrote a note. The downloaded bytes must equal the pinned SHA-256 values. **Data already on Drive and preprocessed artifacts that verify are reused, never rebuilt.** Dataset files stay on your Drive and never enter an export."""),
(CODE, r"""for ds in DATASETS:
    if (DATA / ds / "source_manifest.json").exists():
        m = json.loads((DATA / ds / "source_manifest.json").read_text())
        assert m.get("pinned_sha256_match", False) and not m.get("UNPINNED"), f"{ds}: data on Drive are not the pinned bytes"
        print(f"{ds}: already on Drive, pinned checksums OK (confirmed: {m['operator_note'][:80]}...)"); continue
    sh(sys.executable, "scripts/prepare_data.py", "--dataset", ds, "--data-dir", DATA, cwd=REPO, check=False)
    if not LICENCE_CONFIRMED.get(ds) or not LICENCE_NOTE.strip():
        raise SystemExit(f"{ds}: read the terms above, then set LICENCE_CONFIRMED['{ds}'] = True and LICENCE_NOTE in Step 1a")
    sh(sys.executable, "scripts/prepare_data.py", "--dataset", ds, "--data-dir", DATA, "--i-confirm-licence",
       "--operator-note", LICENCE_NOTE + f" (Colab session {head[:12]})", cwd=REPO)
for tier, seeds in ((TUNE_TIER, ["1001"]), (FINAL_TIER, ["42", "123", "256", "512", "1024"])):
    todo = []
    for ds in DATASETS:
        p1 = RESULTS / tier / "artifacts" / "p1" / ds
        ok = (p1 / "manifest.json").exists() and py(
            f"from fedkge.data import load_artifact\ntry:\n    load_artifact('{p1}'); print('OK')\nexcept Exception as e:\n    print('BAD')") == "OK"
        if ok: print(f"{tier}/{ds}: preprocessed artifact present and verified (reused)")
        else: todo.append(ds)
    if todo:       # deterministic preprocessing: identical bytes every time, bound to the dataset hash
        sh(sys.executable, "scripts/build_artifacts.py", "--results", RESULTS, "--tier", tier, "--datasets", *todo,
           "--data-dir", DATA, "--seeds", *seeds, "--alphas", "0.1", "--central", cwd=REPO, quiet=True, log=SESSION_LOG)
print("STEP 2 COMPLETE: datasets ready; partitions for the other settings are built on demand, deterministically, "
      "by the step that needs them")"""),
(MD, r"""## Step 3 — Mandatory accuracy sanity gate (G-B)
Trains the centralised non-private TransE (6 settings × 3 datasets, fully trained with early stopping) and checks that the selected setting reaches ⅔ of the published TransE validation MRR. **If the gate fails, this step stops with a diagnostic report and the main workflow does not continue.** The thresholds are never lowered. These 18 runs are part of the 99 tuning runs, so nothing is trained twice."""),
(CODE, r"""p = sh(sys.executable, "scripts/run_plan.py", "--results", RESULTS, "--plan", "tune", "--tier", TUNE_TIER, "--stages", "0",
       "--datasets", *DATASETS, "--device", DEVICE, "--max-hours", f"{hours_left():.3f}", cwd=REPO, check=False,
       quiet=True, log=SESSION_LOG)
rep = RESULTS / TUNE_TIER / "gates" / "SANITY_GATE_REPORT.md"
if rep.exists(): print(rep.read_text())
gp = RESULTS / TUNE_TIER / "gates" / "sanity_gate.json"
gate = json.loads(gp.read_text()) if gp.exists() else {}
if p.returncode == 3: print(paused_msg(3))
elif p.returncode == 4: raise SystemExit("GATE G-B FAILED: the main workflow stops here. Follow the recovery steps in the report above.")
elif p.returncode != 0: raise SystemExit(f"Step 3 stopped (exit {p.returncode}); see the output and {SESSION_LOG}")
else:
    st = {ds: (gate.get("datasets", {}).get(ds) or {}).get("status") for ds in DATASETS}
    print("gate G-B:", st, "" if gate.get("enforced") else "(software-check tier: recorded, not enforced)")
    print("STEP 3 COMPLETE")"""),
(MD, r"""## Step 4 — Pre-registered hyperparameter tuning (Stage 3), then freeze the selections (G-C)
Tuning stages 1–6 in order, selection on validation data only after every stage. Stage 6 selects τ with the pre-declared fallback (B3) and records the D10 utility flag (B5). When the tuning is complete, the selections are frozen automatically: after this, the Stage-3 choices cannot change. Re-run this cell until it prints STEP 4 COMPLETE."""),
(CODE, r"""p = sh(sys.executable, "scripts/run_plan.py", "--results", RESULTS, "--plan", "tune", "--tier", TUNE_TIER,
       "--datasets", *DATASETS, "--device", DEVICE, "--max-hours", f"{hours_left():.3f}", cwd=REPO, check=False,
       quiet=True, log=SESSION_LOG)
if p.returncode == 3: print(paused_msg(4))
elif p.returncode == 4: raise SystemExit("GATE G-B FAILED: see Step 3")
elif p.returncode != 0: raise SystemExit(f"Step 4 stopped (exit {p.returncode}); see the output and {SESSION_LOG}")
else:
    sel = json.loads((RESULTS / TUNE_TIER / "selection" / "tuning.json").read_text())
    for ds in DATASETS:
        t = sel[ds]["tau"]; print(f"{ds}: tau* = {t['aggregation']['tau']} - {t['label']}")
    d10 = RESULTS / TUNE_TIER / "gates" / "d10_trigger.json"
    if d10.exists(): print("D10:", json.loads(d10.read_text()).get("label"))
    if FINAL_TIER == "final":       # gate G-C: freeze (append-only; refused if the sanity gate did not pass)
        sh(sys.executable, "scripts/freeze_selections.py", "--results", RESULTS, cwd=REPO)
    else:
        print("software-check mode: the check tier reads its own selections; nothing to freeze")
    print("STEP 4 COMPLETE")"""),
(MD, r"""## Step 5 — Main research experiments (Stage 4), essential hypotheses first
756 runs, in priority order. After priority 3, all five pre-registered hypothesis families can be decided:

| Priority | Blocks | Answers | Runs | T4 upper bound |
|---|---|---|---|---|
| 1 | N1, N2, DP1 at ε = 4, DP2, R1p | main table; H1, H2b, HS | 75 | ≈ 9.4 GPU-h |
| 2 | R2, R2a, R3, R3a | H2 (robustness under attack) | 210 | ≈ 28.4 GPU-h |
| 3 | M1 | H3 (membership-inference audit) | 60 | ≈ 8.0 GPU-h |
| 4 | **original-paper replications L1–L4** (Step 6) | Table 13 | 30 | ≈ 5.4 GPU-h |
| 5 | R1q | schedule inside the method (descriptive) | 15 | ≈ 2.0 GPU-h |
| 6 | R1, R4, R5, R5a | other robust baselines, trust without DP | 252 | ≈ 33.6 GPU-h |
| 7 | DP1 at ε ∈ {1, 2, 8}, DP3, N3, I1, I2 | privacy–utility curve, DP-cost decomposition, heterogeneity, integrity | 144 | ≈ 19.1 GPU-h |

The replications run inside this loop at priority 4. Re-run this cell every session until it prints STEP 5 COMPLETE. Completed runs are skipped automatically and never repeated."""),
(CODE, r"""status = "COMPLETE"
for prio in [1, 2, 3, 4, 5, 6, 7]:
    if hours_left() <= 0.05:
        status = "PAUSED"; break
    if prio == 4:
        if "fb15k237" not in DATASETS:
            print("priority 4 (replications, FB15k-237 only): skipped because fb15k237 is not in DATASETS"); continue
        args = ["scripts/run_legacy_blocks.py", "--results", RESULTS, "--tier", FINAL_TIER]
    else:
        args = ["scripts/run_plan.py", "--results", RESULTS, "--plan", "confirm", "--tier", FINAL_TIER,
                "--datasets", *DATASETS, "--priorities", str(prio)]
    print(f"\n########## priority {prio} ##########")
    p = sh(sys.executable, *args, "--device", DEVICE, "--max-hours", f"{hours_left():.3f}", cwd=REPO, check=False,
           quiet=True, log=SESSION_LOG)
    if p.returncode == 3: status = "PAUSED"; break
    if p.returncode != 0: raise SystemExit(f"priority {prio} stopped (exit {p.returncode}); run the status cell (appendix A) to see failed runs")
print(paused_msg(5) if status == "PAUSED" else "STEP 5 COMPLETE")
sh(sys.executable, "scripts/status.py", "--results", RESULTS, cwd=REPO, check=False)"""),
(MD, r"""## Step 6 — Original-paper replications (L0–L4)
L1–L4 (30 FB15k-237 runs, corrected evaluation) run at priority 4 of Step 5. This cell shows their status and runs any that are still missing. Completed runs are skipped, so nothing runs twice.

**L0** re-evaluates your saved original model (evaluation only, no training). It needs `complete/global_transe_final.pt` uploaded as `MyDrive/FedKGE/global_transe_final.pt`. Without the file, L0 stays PENDING in Table 13."""),
(CODE, r"""if "fb15k237" in DATASETS:
    p = sh(sys.executable, "scripts/run_legacy_blocks.py", "--results", RESULTS, "--tier", FINAL_TIER, "--device", DEVICE,
           "--max-hours", f"{hours_left():.3f}", cwd=REPO, check=False, quiet=True, log=SESSION_LOG)
    if p.returncode == 3: print(paused_msg(6))
    elif p.returncode != 0: raise SystemExit(f"Step 6 stopped (exit {p.returncode}); run the status cell (appendix A)")
    else: print("replications L1-L4 COMPLETE")
else:
    print("replications L1-L4 use FB15k-237, which is not in DATASETS")
ck = ROOT / "global_transe_final.pt"
if ck.exists():
    sh(sys.executable, "scripts/legacy_l0_eval.py", "--checkpoint", ck, "--results", RESULTS, "--tier", FINAL_TIER, cwd=REPO)
else:
    print(f"L0 skipped: {ck} not found (optional; Table 13 shows L0 as PENDING)")"""),
(MD, r"""## Step 7 — Statistical analysis
Paired-seed design. For each pre-registered hypothesis: one-sided paired t-tests, Holm correction over the fixed family, confidence intervals, effect sizes, and the non-inferiority test with its margin (H2b: the lower confidence bound decides, never the point estimate). Uses only COMPLETE runs of the current code. Missing members count as not supported (p = 1) and the family is labelled PROVISIONAL until it is complete. Safe to run at any time."""),
(CODE, r"""sh(sys.executable, "scripts/analyze_results.py", "--results", RESULTS, "--tier", FINAL_TIER, cwd=REPO, quiet=True, log=SESSION_LOG)
tab = next((RESULTS / FINAL_TIER / "analysis").glob("*table12_hypotheses.md"), None)
print(tab.read_text() if tab else "no hypothesis table yet")
print("STEP 7 COMPLETE")"""),
(MD, r"""## Step 8 — Figures, tables and the results draft
Builds the paper material from the same records: Tables 1–14 (CSV, Markdown, LaTeX), the MIA and size-group false-positive diagnostics, the privacy and robustness summary, compute and resource accounting, the reproducibility record, the 2D and 3D figures (PNG 300 dpi + PDF, each with its data table) and `RESULTS_DRAFT.md`. Everything not yet computed is shown as **⟦PENDING: …⟧** and is never filled in."""),
(CODE, r"""sh(sys.executable, "scripts/build_report.py", "--results", RESULTS, "--tier", FINAL_TIER, "--with-figures", cwd=REPO,
   quiet=True, log=SESSION_LOG)
draft = next((RESULTS / FINAL_TIER / "reports").glob("*RESULTS_DRAFT.md"))
print(draft.read_text()[:6000])
print("STEP 8 COMPLETE")"""),
(MD, r"""## Step 9 — Final export
One zip on your Drive with every run record, analysis, figure, table, log, configuration hash and reproducibility record (no dataset files, no checkpoints, no model weights)."""),
(CODE, r"""sh(sys.executable, "scripts/export_artifacts.py", "--results", RESULTS, "--out", ROOT, cwd=REPO)
print("STEP 9 COMPLETE")"""),
(MD, r"""## Appendix A — Status and recovery
Every run's status is derived from its folder on Drive. **INCOMPLETE** = interrupted; it resumes from its checkpoint when its step runs again. **FAILED** = an error (the traceback is in the run folder); the step retries it and keeps the earlier traceback. Nothing is ever deleted."""),
(CODE, r"""sh(sys.executable, "scripts/status.py", "--results", RESULTS, "--show-failed", cwd=REPO, check=False)"""),
(MD, r"""## Appendix B — Optional CPU code checks
The automated test suite (CPU, synthetic data, about 3–5 minutes). Not part of the research path and never started automatically. Set `RUN_CPU_CHECKS = True` in Step 1a to run it, for example after a Colab update or before sending a bug report."""),
(CODE, r"""if RUN_CPU_CHECKS:
    p = sh(sys.executable, "scripts/run_tests.py", "--results", RESULTS, "--name", "colab_check", cwd=REPO, check=False,
           quiet=True, log=SESSION_LOG)
    counts = json.loads((RESULTS / "test_reports" / "summary_colab_check.json").read_text())["counts"]
    print("TEST COUNTS:", counts)
    assert not counts["failed"] and not counts["error"], "tests failed in this environment: send the test report"
else:
    print("CPU checks not requested (RUN_CPU_CHECKS = False)")"""),
]


def build(commit: str, manifest_sha: str, code_hash: str) -> dict:
    cells = []
    for kind, src in CELLS:
        src = src.replace("__EXPECTED_GIT_COMMIT__", commit).replace("__EXPECTED_MANIFEST_SHA__", manifest_sha) \
                 .replace("__EXPECTED_CODE_HASH__", code_hash)
        c = {"cell_type": kind, "metadata": {}, "source": src.splitlines(keepends=True)}
        if kind == CODE:
            c.update({"execution_count": None, "outputs": []})
        cells.append(c)
    return {"cells": cells, "metadata": {"accelerator": "GPU", "colab": {"provenance": []},
                                         "kernelspec": {"display_name": "Python 3", "name": "python3"},
                                         "language_info": {"name": "python"}}, "nbformat": 4, "nbformat_minor": 5}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--commit", required=True); ap.add_argument("--manifest-sha", required=True)
    ap.add_argument("--code-hash", required=True)
    ap.add_argument("--out", default=str(Path(__file__).resolve().parents[2] / "RUN_COMPLETE_FEDKGE_RESEARCH.ipynb"))
    a = ap.parse_args()
    nb = build(a.commit, a.manifest_sha, a.code_hash)
    for i, c in enumerate(nb["cells"]):
        c["id"] = f"cell-{i:02d}"
    Path(a.out).write_text(json.dumps(nb, indent=1, ensure_ascii=False) + "\n")
    print("wrote", a.out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
