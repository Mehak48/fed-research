"""One object that loads everything the analysis, figure and report steps read from a results root (final package).

ResultsContext(results_root, tier) gathers: the valid runs and the problem list of the tier (analysis.collect over the
confirmatory and legacy indexes), the frozen selections and FROZEN.json, the Stage-3 gate outputs, the manifest
progress, dataset cards, partition statistics, and lazy per-run loaders (env.json, rounds.csv, mia_scores.csv).
Only recorded files are read. A missing file is reported as missing, never replaced.
"""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd

from .analysis import collect
from .config import load_yaml
from .io import IntegrityError, Paths, read_json

PHASES_BY_TIER = {"final": ["final", "p3", "p4"], "smoke": ["final", "p3", "p4"], "tune": ["tune"]}


def _maybe_json(p: Path) -> Optional[Dict]:
    try:
        return read_json(p) if Path(p).exists() else None
    except Exception:
        return None


class ResultsContext:
    def __init__(self, results_root, tier: str, config_dir: Path, project_root: Optional[Path] = None):
        self.root, self.tier = Path(results_root), tier
        self.paths = Paths(self.root, tier)
        self.config_dir = Path(config_dir)
        self.project_root = Path(project_root) if project_root else self.config_dir.parents[1]
        self.hyp = load_yaml(self.config_dir / "hypotheses.yaml")
        frames, probs, self.missing_indexes = [], [], []
        for ph in PHASES_BY_TIER.get(tier, ["final"]):
            try:
                r, p = collect(self.paths, [ph])
                frames.append(r); probs.append(p)
            except IntegrityError as e:
                self.missing_indexes.append(f"{ph}: {e}")
        self.runs = pd.concat([f for f in frames if len(f)], ignore_index=True) if any(len(f) for f in frames) \
            else pd.DataFrame()
        self.problems = pd.concat(probs, ignore_index=True) if probs else pd.DataFrame()
        sel_tier = "final" if tier == "final" else tier
        self.selection = _maybe_json(Paths(self.root, sel_tier).selection("tuning")) or {}
        self.frozen = _maybe_json(Paths(self.root, sel_tier).base / "selection" / "FROZEN.json")
        gate_tier = "tune" if tier == "final" else tier
        self.sanity_gate = _maybe_json(Paths(self.root, gate_tier).base / "gates" / "sanity_gate.json")
        self.d10 = _maybe_json(Paths(self.root, gate_tier).base / "gates" / "d10_trigger.json")
        self.env_lock = {t: _maybe_json(Paths(self.root, t).base / "ENVIRONMENT_LOCK.json") for t in ("tune", "final")}
        self.l0 = _maybe_json(self.paths.base / "L0_legacy_checkpoint_eval.json")
        self.provenance_csv = self.project_root / "audit" / "result_provenance.csv"
        self.progress = None
        try:
            from .manifest import load_frozen, progress
            self.manifest = load_frozen(self.config_dir)
            if tier in ("tune", "final"):
                self.progress = progress(self.root, self.manifest)
        except IntegrityError:
            self.manifest = None

    # ---------------------------------------------------------------- lazy per-run loaders
    @lru_cache(maxsize=None)
    def env_of(self, rid: str) -> Optional[Dict]:
        return _maybe_json(self.paths.run(rid) / "env.json")

    @lru_cache(maxsize=None)
    def rounds_of(self, rid: str) -> Optional[pd.DataFrame]:
        p = self.paths.run(rid) / "rounds.csv"
        return pd.read_csv(p) if p.exists() else None

    @lru_cache(maxsize=None)
    def mia_scores_of(self, rid: str) -> Optional[pd.DataFrame]:
        p = self.paths.run(rid) / "mia_scores.csv"
        return pd.read_csv(p) if p.exists() else None

    def card_of(self, ds: str) -> Optional[Dict]:
        return _maybe_json(self.paths.p1(ds) / "dataset_card.json")

    def partition_stats(self) -> List[Dict]:
        rows = []
        p2 = self.paths.base / "artifacts" / "p2"
        for sp in sorted(p2.glob("*/*/seed*_stats.json")) if p2.exists() else []:
            d = _maybe_json(sp)
            if not d:
                continue
            s = d["summary"]
            rows.append({"dataset": sp.parts[-3], "partition": sp.parts[-2], "seed": int(sp.stem.split("_")[0][4:]),
                         "n_clients": s["n_clients"], "size_gini": s["size_gini"], "size_max_share": s["size_max_share"],
                         "mean_relation_js": s["mean_relation_js"],
                         "mean_pairwise_entity_jaccard": s["mean_pairwise_entity_jaccard"],
                         "attempts": d.get("attempts"), "min_size": d.get("min_size")})
        return rows

    def summary(self) -> Dict:
        return {"tier": self.tier, "results_root": str(self.root), "n_valid_runs": int(len(self.runs)),
                "n_problem_rows": int(len(self.problems)), "missing_indexes": self.missing_indexes,
                "problems_by_kind": self.problems["problem"].value_counts().to_dict() if len(self.problems) else {}}
