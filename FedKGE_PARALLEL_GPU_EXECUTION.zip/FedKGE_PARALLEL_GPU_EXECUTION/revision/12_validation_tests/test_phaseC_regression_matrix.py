"""Phase C - regression (historical artifacts untouched; outputs never written into historical locations) and
experiment-matrix consistency (tuning chain reuses the previous winner's run; Stage 4/5 run counts equal the Phase B
plan in audit/phaseB/data/experiment_matrix.csv)."""
import csv
import hashlib
import json
from pathlib import Path

import pytest

from conftest import CONFIG_DIR, PKG

PROJECT = PKG.parent                       # .../fedkge_project
UPLOADS = Path("/mnt/user-data/uploads")
INVENTORY = PROJECT / "audit" / "data" / "artifact_inventory.csv"
PHASEB_MATRIX = PROJECT / "audit" / "phaseB" / "data" / "experiment_matrix.csv"


def _sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for ch in iter(lambda: f.read(1 << 20), b""):
            h.update(ch)
    return h.hexdigest()


def test_historical_artifacts_unchanged():
    if not INVENTORY.exists() or not UPLOADS.exists():
        pytest.skip("Phase A inventory or the original uploads are not present in this environment")
    rows = [r for r in csv.DictReader(open(INVENTORY)) if r["group"] == "UPLOADS"]
    checked = 0
    for r in rows:
        p = UPLOADS / r["path"]
        if p.exists() and r["path"].endswith((".zip", ".ipynb", ".json", ".pdf", ".docx")):
            assert _sha(p) == r["sha256"], f"historical artifact changed: {r['path']}"
            checked += 1
    assert checked >= 10


def test_results_root_is_not_a_historical_location():
    from fedkge.io import Paths
    p = Paths(PROJECT / "results" / "phaseC", "smoke")
    for hist in ("complete", "files", "orignial on one data set"):
        assert hist not in p.base.parts


def _fake_selection(tmp, tier):
    sel = {}
    for ds in ("fb15k237", "wn18rr", "codex_m"):
        sel[ds] = {"T1_nonprivate": {"train": {"lr": 0.001, "batch_size": 512}},
                   "T1_central": {"train": {"lr": 0.001, "batch_size": 512}},
                   "T2a": {"dp": {"q": 0.05}, "train": {"lr": 0.003}},
                   "T2b": {"dp": {"clip": 1.0}}, "T2c": {"train": {"rounds_max": 100}},
                   "T2d": {"dp": {"sampling": "common_rate"}},
                   "T3": {"dp": {"schedule": {"shape": "cosine", "rho": 0.5}}},
                   "tau": {"aggregation": {"tau": 3.0}}}
    d = tmp / tier / "selection"
    d.mkdir(parents=True, exist_ok=True)
    (d / "tuning.json").write_text(json.dumps(sel))


def test_tuning_chain_reuses_previous_winner(tmp_path):
    from fedkge.io import Paths
    from fedkge.runner import expand
    _fake_selection(tmp_path, "tune")
    e = expand("tune", CONFIG_DIR, Paths(tmp_path, "tune"), "tune")
    by = {}
    for x in e:
        by.setdefault((x["block"], x["dataset"]), []).append(x)
    for ds in ("fb15k237", "wn18rr", "codex_m"):
        t2a = {(x["cfg"]["dp"]["q"], x["cfg"]["train"]["lr"]): x["run_id"] for x in by[("T2a", ds)]}
        assert by[("T2b0", ds)][0]["run_id"] == t2a[(0.05, 0.003)]          # no new run for the C = 1 point
        assert len(by[("T3", ds)]) == 6 and len(by[("T2a", ds)]) == 9 and len(by[("T1F", ds)]) == 6
        t3 = {(x["cfg"]["dp"]["schedule"]["shape"], x["cfg"]["dp"]["schedule"]["rho"]): x["run_id"] for x in by[("T3", ds)]}
        assert by[("TAU", ds)][0]["run_id"] == t3[("cosine", 0.5)]          # tau source = the T3 winner


@pytest.mark.parametrize("profile,col", [("full", "runs_total"), ("reduced", "reduced_runs_total")])
def test_confirmatory_matrix_matches_phaseB_plan(tmp_path, profile, col):
    if not PHASEB_MATRIX.exists():
        pytest.skip("Phase B experiment matrix not present")
    from fedkge.io import Paths
    from fedkge.runner import expand
    _fake_selection(tmp_path, "final")
    e = expand("final", CONFIG_DIR, Paths(tmp_path, "final"), "final", profile=profile, matrix_name="confirm")
    seen, new_by_block = set(), {}
    for x in e:                                                       # count NEW unique runs in matrix order
        if x["run_id"] not in seen:
            seen.add(x["run_id"])
            new_by_block[x["block"]] = new_by_block.get(x["block"], 0) + 1
    plan = {r["block"]: int(r[col]) for r in csv.DictReader(open(PHASEB_MATRIX))}
    for blk, n in new_by_block.items():
        assert plan[blk] == n, f"{blk}: matrix gives {n} new runs, Phase B plan says {plan[blk]}"
    for blk in ("N1", "N2", "DP1", "DP2", "R1p", "R2", "R3", "M1", "I2"):
        assert blk in new_by_block
    # final weights are kept for exactly the runs Phase B planned (07_compute_feasibility.md: 225 full / 150 reduced)
    keep = {x["run_id"] for x in e if x["cfg"]["train"]["keep_final_weights"]}
    assert len(keep) == {"full": 225, "reduced": 150}[profile]
    by_run = {}
    for x in e:
        by_run.setdefault(x["run_id"], set()).add(x["cfg"]["train"]["keep_final_weights"])
    assert all(len(v) == 1 for v in by_run.values())          # one setting per shared run


def test_output_only_option_does_not_change_run_identity():
    from fedkge.config import run_id
    from conftest import synthetic_base_cfg
    a = synthetic_base_cfg(train={"keep_final_weights": False})
    b = synthetic_base_cfg(train={"keep_final_weights": True})
    c = synthetic_base_cfg(train={"keep_final_weights": False, "lr": 0.5})
    assert run_id(a) == run_id(b) != run_id(c)
