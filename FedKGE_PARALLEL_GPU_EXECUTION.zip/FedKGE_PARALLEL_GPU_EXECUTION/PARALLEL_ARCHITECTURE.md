# Parallel GPU execution: architecture, dependency graph, schedule

This document explains how the frozen FedKGE study is split into **independent jobs that can run at the same time on different GPU environments**, and what stays sequential. It also covers how results travel between environments, and what the speed-up can and cannot be.

> **In one sentence.** Nothing in the methodology changed. The same 885 runs are executed by the same unchanged code, and they are only grouped into jobs. The jobs run in separate results folders and exchange nothing but checked files. A master folder puts them back together, after checking each run as strictly as the sequential pipeline would.

The practical step-by-step guide is `PARALLEL_EXECUTION_GUIDE.md`. The proof that nothing changed is `PARALLEL_METHODOLOGY_PRESERVATION.md`.

---

## 1. Audit of the existing implementation (what was already there)

The package delivered on 2026-11-05 (commit `e55400b`, uploaded unchanged: SHA-256 `487511d8…`) already had most of the machinery a parallel layout needs:

| Existing mechanism | Where | Why it matters for parallel execution |
|---|---|---|
| **Run identity = SHA-256 of the full configuration** | `fedkge/config.py: run_id` | The same cell gives the same run id on every machine, so results from different workers can be merged without ambiguity |
| **One folder per run, status written last, atomic checkpoints** | `fedkge/federated.py`, `fedkge/io.py: RunDir` | A run is either COMPLETE or not, and a copy of a COMPLETE folder is self-contained |
| **Resume** from the last checkpoint; optimizer, accountant, trust state and RNG states are inside it | `fedkge/federated.py` | A job that is cut off by a session limit continues the *same* experiment |
| **Frozen manifest** of the 900 approved cells (885 unique runs; 855 if the fixed schedule is selected) | `10_configs/manifest/`, `fedkge/manifest.py` | Jobs are defined over these cells, so nothing can be added or dropped |
| **Validity checks** (code, tier, data, partition and selection hashes) | `fedkge/analysis.py: collect` | The master re-uses them, and stale runs are never analysed |
| **Environment lock per (tier, dataset)** (GPU name, torch, CUDA, Python) | `fedkge/gates.py`, `10_configs/gates.yaml` | **This is the main parallelism constraint** (section 4) |
| **Per-dataset sessions** (Stage 3, gate and freeze can run one dataset at a time) | `scripts/run_plan.py`, `freeze_selections.py` | Datasets are independent pipelines |

What it did **not** have:
- a job graph;
- a way for several environments to work at the same time without sharing one results folder. The old rule was "one session at a time per results folder", because Drive syncs with a delay;
- a validated merge;
- a planner for unequal GPUs.

That is what the new `revision/parallel/` layer adds.

---

## 2. What each computational component is (dependency analysis)

The table follows the questions of the task. "T4-h" are the owner's measured T4 pilot **upper bounds** (2-round measurements extrapolated; `parallel/cost_table_T4_upper.csv`). They are not timings of complete runs.

| Component | What it computes | Inputs | Depends on | GPU/CPU | Outputs | Consumers | Split further? | Cost |
|---|---|---|---|---|---|---|---|---|
| Datasets | licence-gated download, pinned SHA-256 check | network, licence note | — | CPU | `data_cache/<ds>` | artifacts | per dataset | minutes |
| Phase-1/2 artifacts | deterministic preprocessing; base partitions | data | datasets | CPU | `<tier>/artifacts/p1, p2` | every run | per dataset | minutes |
| **Gate G-B** (tune stage 0, T1C) | centralised TransE, 6 settings, fully trained; T1_central selection; ≥ ⅔ of published MRR | artifacts | — | GPU | 6 runs per dataset; `gates/sanity_gate.json` | stage 1 (barrier) | the 6 runs are independent | 0.42–0.69 T4-h per dataset |
| Tune stage 1 (T1F, T2a) | non-private FedAvg grid; q × lr grid at ε\*=4 | artifacts | **gate passed** (pre-registered order: "before any further tuning") | GPU | 15 runs per dataset | T2a selection | runs independent | ≈ 2.1–2.3 T4-h |
| Tune stages 2–5 (T2b, T2c, T2d, T3) | clip, R, sampling design, schedule | previous selection | previous stage's selection | GPU | 4 + 1 + 1 + 6 new runs | next stage | runs inside a stage independent | ≈ 0.07–0.84 T4-h per stage |
| Tune stage 6 (TAU) | τ rule with fallback B3, D10 flag | T3 winner's logged anomaly scores (no new run) | stage 5 | CPU | τ\* per dataset | freeze | — | seconds |
| **Freeze G-C** | append-only per dataset | selections, gate passed | stage 6 of that dataset | CPU | `final/selection/FROZEN.json` | all Stage-4 runs of that dataset | per dataset | seconds |
| Stage 4 (main), 252 cells per dataset | N1–N3, DP1–DP3, R1–R5a, I1, I2, M1 | frozen selections of **its** dataset | freeze of its dataset only | GPU | final runs | analysis | **every run independent** | ≈ 33–35 T4-h per dataset |
| Legacy L1–L4 (30 runs, FB15k-237) | original-study replications | artifacts | **nothing** (frozen run ids, no selection) | GPU | final runs | Table 13 | every run independent | 5.4 T4-h |
| L0 (optional) | evaluation of your saved original model | your checkpoint | — | CPU/GPU | Table 13 row | report | — | minutes |
| Analysis | paired tests, Holm, CIs, non-inferiority | COMPLETE runs | runs of each family | CPU | analysis tables | report | per family, partial allowed | minutes |
| Report / export | tables, 2D/3D figures, draft; export zip | analysis | analysis | CPU | reports, zip | you | — | minutes |

**Inside a run nothing is parallelised.** The federated rounds of one run stay strictly sequential. Round t+1 needs the global model, the trust state (flag counts) and the accountant state of round t. Parallelism is only *between* runs.

---

## 3. The phases and executables

| Phase | Executable (`revision/parallel/phases/`) | Where | GPU/CPU |
|---|---|---|---|
| 00 | `phase00_register_worker.py` | every environment | CPU (checks the GPU) |
| 01 | `phase01_prepare_data.py` | every environment | CPU |
| 02 | `phase02_build_artifacts.py` | every environment + master | CPU |
| 03 | `phase03_plan_jobs.py` | master | CPU |
| 04 | `phase04_tuning.py` (gate G-B + Stage 3; chain or stage shards) | GPU worker | GPU |
| 05 | `phase05_select_freeze_release.py` | master | CPU |
| 06 | `phase06_main_experiments.py` (Stage-4 shards) | GPU worker | GPU |
| 07 | `phase07_replications.py` (L1–L4 shards) | GPU worker | GPU |
| 08 | `phase08_import_results.py` | master | CPU |
| 09 | `phase09_validate.py` (the automated validation tool) | master | CPU |
| 10 | `phase10_analysis.py` | master | CPU |
| 11 | `phase11_report_export.py` | master | CPU |
| — | `run_worker_queue.py` (a worker's whole queue) · `master_cycle.py` (08 → 05 → 09) | worker / master | — |

Shared modules (`revision/parallel/fedkge_parallel/`):
- `cells` holds the approved cells and the cost estimates;
- `jobs` builds the job graph and materialises run ids;
- `schedule` does the environment-lock-aware assignment, the simulated timeline, the waves and the critical path;
- `execute` runs one job in one worker root;
- `bundles` handles atomic bundles and packs;
- `store` is the master: validated import, the cross-worker lock, selection replay and freeze;
- `master_flow` runs the dependency-driven master steps;
- `validate` checks completeness and compatibility.

**No methodology is duplicated.** Every run is executed by `fedkge.runner.run_entries` on entries from `fedkge.runner.expand`, called with the same arguments as `scripts/run_plan.py`. A tuning chain *is* `scripts/run_plan.py --plan tune --datasets <ds>`. Every selection is `run_plan.tune_select`, and the freeze is `scripts/freeze_selections.py`.

### Jobs

| Job id | Kind | Cells | Dependencies |
|---|---|---|---|
| `T-<ds>-chain` | TUNECHAIN (default mode) | all 38 tuning cells of a dataset (33 runs) | — |
| `T-<ds>-s<k>-<i>of<n>` | TUNESTAGE (stage mode) | a shard of the new runs of tuning stage k | `SEL-<ds>-s<k-1>` (k ≥ 1; k = 1 needs the gate) |
| `SEL-<ds>-chain` / `SEL-<ds>-s<k>` | SELECT (master) | — | the dataset's tuning jobs (of that stage) |
| `M-<ds>-p<p>-<i>of<n>` | MAIN | a shard of the Stage-4 cells of one dataset and priority | `SEL-<ds>-chain` or `SEL-<ds>-s5` (the freeze of **that** dataset) |
| `L-fb15k237-<i>of<n>` | LEGACY | a shard of the 30 legacy cells | — |
| `ANALYSE` | master | — | every MAIN and LEGACY job (partial analyses may run earlier) |

The shard sizes follow the number of workers you register: each job aims at about 3 T4-hours, so it fits in one session and results flow back often. The job definitions are frozen at the first `phase03` call and are never changed afterwards. Re-planning only changes *who* runs a job that has not started.

---

## 4. The one hard constraint: one environment per (tier, dataset)

The pre-registered environment lock (`10_configs/gates.yaml`, scope `[tier, dataset]`) requires every run of one (tier, dataset) group to come from **one** environment signature: same GPU name, torch build, CUDA version and Python minor version. The analysis declares a hypothesis member INVALID if its runs mix environments (`fedkge/hypotheses.py`).

Consequences, stated plainly:
- **Workers with identical signatures form one class.** The jobs of a group can be spread over all workers of its class: two Colab T4 sessions with the same torch build, or two identical GPUs on one machine.
- **Different GPU types, or the same GPU with another torch build, are different classes.** A group then runs on one class only, so FB15k-237's whole Stage 4 (≈ 40 T4-h with the replications) cannot be split between a T4 and an L4.
- The tune group and the final group of one dataset may use different classes. The lock is per tier.
- The master enforces the lock **across** workers: it keeps one `ENVIRONMENT_LOCK.json` per tier for the merged store, and it refuses a bundle whose signature differs from the one recorded for that group.
- A Colab runtime update that changes torch creates a new class for the groups that have not started. A group that has started must finish on its recorded class, or be restarted as a whole (`EXECUTION_GUIDE.md`, "Environment changed").

---

## 5. Dependency graph

```mermaid
flowchart LR
  subgraph EVERY_ENVIRONMENT["every environment (CPU)"]
    P00[00 register] --> P01[01 datasets] --> P02[02 artifacts]
  end
  P02 --> P03[03 plan - master]
  P03 --> TFB[T-fb15k237-chain<br/>gate G-B + Stage 3]
  P03 --> TWN[T-wn18rr-chain]
  P03 --> TCX[T-codex_m-chain]
  P03 --> LEG[L-fb15k237-* legacy L1-L4]
  TFB --> SFB[SEL-fb15k237: replay, gate, tau, D10, freeze]
  TWN --> SWN[SEL-wn18rr ...]
  TCX --> SCX[SEL-codex_m ...]
  SFB --> MFB[M-fb15k237-p1..p7 shards]
  SWN --> MWN[M-wn18rr-p1..p7 shards]
  SCX --> MCX[M-codex_m-p1..p7 shards]
  MFB --> AN[ANALYSE: validate, tests, report]
  MWN --> AN
  MCX --> AN
  LEG --> AN
```

In text, with `→` meaning "must finish first":
- `P00 → P01 → P02` in each environment, then `P03` on the master.
- `T-<ds>-chain → SEL-<ds>-chain → M-<ds>-*`, independently for each of the three datasets.
- `L-fb15k237-*` runs at any time after P02/P03.
- All `M-*` and `L-*` jobs `→ ANALYSE`.

In **stage mode** each chain becomes:

`T-<ds>-s0-* → SEL-<ds>-s0 (gate) → T-<ds>-s1-* → SEL-<ds>-s1 → … → T-<ds>-s5-* → SEL-<ds>-s5 (τ, D10, freeze) → M-<ds>-*`

**Independent branches (eligible to run at the same moment):**
- the three datasets' tuning;
- the legacy replications;
- every Stage-4 shard, against every other Stage-4 shard of any dataset whose selections are frozen;
- import, validation and partial analysis on the master while GPU jobs run.

**No artificial dependency was introduced.** In particular:
- datasets never wait for each other;
- Stage 4 of a dataset starts as soon as *its own* freeze exists;
- the legacy runs no longer wait for priority 3 (that order was only a deadline choice: RC-12).

**Deliberately kept dependency (a methodology rule, not an execution need):** tune stage 1 does not depend on stage 0 *computationally*. Their run ids are fixed in advance. The pre-registered protocol still says the gate must pass "before any further tuning" (Section III-K.4; `run_plan.py` stops Stage 3 for a failing dataset), so stage 1 is released only after `SEL-<ds>-s0` shows PASSED. In chain mode this happens inside the chain itself.

---

## 6. Why each kind of parallelism is scientifically valid

| Level | Valid? | Why |
|---|---|---|
| **Dataset** | yes | Every selection rule groups by dataset (`fedkge.selection.select_rule`). The gate, τ and D10 are per dataset, and the freeze is append-only per dataset. Hypothesis members are per dataset. No quantity of one dataset enters another dataset's runs |
| **Seed** | yes, in the same environment class | Each run derives all its randomness from its own seed through `SeedSequence` (partition, initialisation, sampling, noise, attacks). Paired comparisons need the same seed, partition and evaluation protocol, and these depend on the configuration, not on the worker. GPU non-determinism exists on one worker too; the lock keeps the environment equal |
| **Algorithm / attack / block** | yes, inside Stage 4 | Stage-4 runs share inputs (frozen selections, partitions, data) and never each other's outputs. Runs of the *same* configuration are deduplicated: the fixed-schedule case DP2 = DP1 at ε\* = 4, R1q = R1p. Each such run is executed by exactly one job (`jobs.materialize`) |
| **Tuning stages** | no between stages, yes inside a stage | Stage k+1's grid is centred on stage k's winner (placeholders `${sel:…}`), and τ needs the final DP settings. Inside a stage the candidates are independent, and the selection waits for all of them (`select_stage` refuses until every candidate is imported) |
| **Rounds inside a run** | **no, never** | Round t+1 needs the model, the trust history and the accountant of round t. The sequential FL loop is untouched |
| **Evaluation** | inside the run, as before | Best-checkpoint selection on V_es is part of the run. Nothing is re-evaluated outside the run, and no test-set result informs any selection or stopping decision |
| **Statistical analysis** | partial analyses yes | `analyze_results.py` reads only COMPLETE current runs. Missing members enter with p = 1 and the family is PROVISIONAL. A family's verdict is final only when all its members are complete (Holm uses the fixed family size) |
| **Accountant** | per run, unchanged | ε is computed from the steps a client actually executed in that run. Parallel execution of other runs cannot affect it |

**Leakage and selection safety:**
- Tuning uses only the tune tier (seed 1001) and validation metrics.
- The master re-derives every selection from the imported tune runs and, in chain mode, requires it to equal the worker's.
- Stage-4 workers cannot select anything. They run explicit run ids whose configurations were fixed by the frozen selections.
- The test split is read only by the runs' final evaluation, as before.

---

## 7. Artifact system and contracts

```
<BASE>/                                   one shared folder (Drive), or copied by hand
├── FedKGE_PARALLEL_GPU_EXECUTION.zip     the package (unchanged, commit-verified in every session)
├── data_cache/                           this environment's datasets (never exchanged)
├── master/results/                       THE store that is analysed
│   ├── tune/ final/                      runs/<run_id>/, index/, selection/, gates/, artifacts/, ENVIRONMENT_LOCK.json
│   ├── PROGRESS.md / PROGRESS_cells.csv  derived from the run folders
│   └── parallel/                         IMPORT_LEDGER.json, steps/SEL-*.json, worker_records/, VALIDATION_REPORT.*
├── workers/<name>/results/               one private results root per worker (written only by that worker)
│   └── parallel/receipts/, logs/
└── exchange/
    ├── registry/worker_<name>.json       phase 00
    ├── plan/PLAN.json, PLAN.md, jobs/<job>.json, QUEUE_<worker>.md|json     phase 03 (+ released specs)
    ├── outbox/<job>__<worker>__<UTC>.zip + .zip.sha256                         result bundles (worker → master)
    └── packs/release_<tier>_<ds>_<label>__<UTC>.zip + .zip.sha256              release packs (master → workers)
```

**Atomic writes everywhere:**
- A zip is written as `.part`, fsynced and renamed, and its `.sha256` sidecar is written last.
- A run folder enters the master store by `os.replace` of a fully written temporary folder.
- JSON records are written to a temp file and renamed.
- Readers ignore anything without a matching sidecar, so a file that is half-synced on Drive is never used.
- File names contain the job, the worker and a UTC stamp, so concurrent workers never write the same file.

### Input and output contracts

| Unit | Input contract (checked before anything runs) | Output contract |
|---|---|---|
| Worker job (04/06/07) | package commit, core code hash and frozen manifest verified; environment lock of the worker root; P1/P2 artifacts present and verifying; the job spec (plan) and, if `requires_release`, the newest verified release pack containing it, installed under the append-only rule; the worker's own expansion of the job's cells must give **exactly** the master's run ids (else exit 7) | COMPLETE run folders in the worker root; `parallel/receipts/<job>.json`; a result bundle with `BUNDLE.json`: job, worker, environment signature, code hash, frozen-manifest hash, data hash, selection-file hashes, and per-run file SHA-256 |
| Master import (08) | bundle sidecar and member hashes; code hash; frozen manifest; data hash = master's P1; environment signature = master's lock for (tier, dataset); per run: COMPLETE with current code, tier and dataset match, `run_id(config.json)` = folder name, partition hash = master's, selection values = master's | master run folders, merged indexes, `ENVIRONMENT_LOCK.json`, `IMPORT_LEDGER.json`, quarantined conflicts in `<tier>/parallel_conflicts/` |
| Master selection (05) | every candidate run of the stage COMPLETE in the master; chain mode: the worker's selection must equal the master's replay | `tune/selection/tuning.json`, gate and D10 files, `final/selection/FROZEN.json`, `steps/SEL-*.json`, a release pack with the materialised specs (explicit run ids; a shared run assigned once; runs already complete skipped) |
| Validation (09) | the master store | `VALIDATION_REPORT.md/json`, `VALIDATION_CELLS.csv`, `RERUN_LIST.csv` (job + planned worker of every missing cell); exit 0 / 2 / 1 |

Each run folder already carries the metadata the task asks for:
- `config.json`: dataset, block (= experiment), algorithm, seed, privacy settings and selection references;
- `final.json`: config hash, code hash, data hash, partition hash and status;
- `env.json`: the code version (git commit) and the environment;
- `status.json`: the execution status and attempt.

Bundles add the job, the worker and the input artifact hashes.

---

## 8. Execution sequence

### Scheduling table

| Phase | Executable File | GPU/CPU | Dependencies | Can Run Parallel With | Required Inputs | Produced Outputs | Next Phase |
|---|---|---|---|---|---|---|---|
| 00 register | `phase00_register_worker.py` | CPU | — | everything | package zip | `registry/worker_<n>.json` | 01; 03 (master) |
| 01 datasets | `phase01_prepare_data.py` | CPU | 00 in the same environment | 01/02 elsewhere; any GPU job of another environment | licence confirmation, network | `data_cache/<ds>` | 02 |
| 02 artifacts | `phase02_build_artifacts.py` | CPU | 01 in the same environment | the same elsewhere | data | `<root>/<tier>/artifacts`, `ARTIFACT_HASHES.json` | 04, 07 (worker); 08 (master) |
| 03 plan | `phase03_plan_jobs.py` | CPU (master) | 00 of every GPU worker | 01/02 anywhere | registry, frozen manifest | `PLAN.json/md`, `jobs/`, `QUEUE_*` | 04, 07 |
| 04 tuning | `phase04_tuning.py` | **GPU** | 02 + 03; stage mode: release from 05 for stage ≥ 1 | 04 of other datasets, 07, 06 of datasets already frozen | job spec (+ pack) | tune runs, bundle | 08 → 05 |
| 05 select/freeze | `phase05_select_freeze_release.py` | CPU (master) | 08 of the dataset's tuning runs | every GPU job | master tune runs | selections, gate, τ, D10, `FROZEN.json`, release packs | 04 (next stage) or 06 |
| 06 main | `phase06_main_experiments.py` | **GPU** | 05 freeze of **its** dataset | every other 06 shard, 04 of other datasets, 07 | release pack | final runs, bundle | 08 |
| 07 legacy | `phase07_replications.py` | **GPU** | 02 + 03 | everything | job spec | final runs, bundle | 08 |
| 08 import | `phase08_import_results.py` | CPU (master) | any bundle | every GPU job | bundles | master runs, ledger, lock, progress | 05, 09 |
| 09 validate | `phase09_validate.py` | CPU (master) | 08 | every GPU job | master store | validation report, rerun list | 10, or reruns |
| 10 analysis | `phase10_analysis.py` | CPU (master) | 08 (partial allowed) | GPU jobs | master store | analysis tables | 11 |
| 11 report/export | `phase11_report_export.py` | CPU (master) | 10 | — | master store | reports, figures, export zip | — |

**A. Must execute first:** 00 → 01 → 02 in every environment, and 03 on the master.

**B. Can run simultaneously:**
- the three tuning chains;
- the legacy shards;
- any Stage-4 shards of frozen datasets, with each other;
- the master cycle, at any time.

**C. Depend on earlier results:**
- SEL needs the tuning runs of its dataset (stage);
- Stage 4 needs its dataset's freeze;
- the analysis needs COMPLETE runs.

**D. Start immediately when an artifact appears:**
- `M-<ds>-*` start the moment the release pack of `<ds>` appears; they do not wait for other datasets;
- in stage mode, `T-<ds>-s<k+1>-*` start the moment `SEL-<ds>-s<k>` publishes its pack;
- a partial analysis can start the moment a family's blocks are complete.

**E. Must wait for everything:** only the final `ANALYSE`/report/export.

### Waves (default chain mode)

- **Wave 0, setup:** phases 00–02 in every environment and 03 on the master (CPU, minutes).
- **Wave 1, start at once:**
  - `T-fb15k237-chain`, `T-wn18rr-chain` and `T-codex_m-chain`, one worker each, ≈ 3.9–4.5 T4-h;
  - `L-fb15k237-*` on the FB15k-237 final class.
- **Wave 2, per dataset:** as soon as a chain bundle arrives, the master cycle runs `SEL-<ds>-chain` (minutes):
  - it replays and verifies the selections, checks gate G-B, τ and D10;
  - it freezes the dataset and releases its Stage 4.
- **Wave 3, per dataset, without waiting for the others:** the `M-<ds>-p<p>-*` shards. Each worker runs them in priority order 1, 2, 3, 5, 6, 7, so every pre-registered hypothesis is decided before the descriptive blocks:
  - H1, H2b and HS after priority 1 of all three datasets;
  - H2 after priority 2;
  - H3 after priority 3.
- **Wave 4:** import, validation and partial analyses run continually; the final analysis, report and export come last.

Stage mode has 14 dependency waves:
- the 6 tuning stages, each followed by a master step;
- Stage 4;
- the analysis.

---

## 9. Time estimates and the critical path (estimates, not measurements)

From `parallel/tools/plan_examples.py` (output: `revision/parallel/PLAN_EXAMPLES.md`). All runtimes are the T4 upper bounds; the hand-over time is your manual delay per master step.

| GPUs (identical class) | Tuning mode | Est. completion | Critical path | Busy workers on average |
|---|---|---|---|---|
| 1 T4 | chain | **≈ 119 h** | 8.0 h | 1.00 |
| 2 T4 | chain | **≈ 60 h** | 8.0 h | 1.99 |
| 3 T4 | chain | **≈ 40 h** | 8.0 h | 2.97 |
| 4 T4 | chain | **≈ 30 h** | 8.0 h | 3.96 |
| 4 T4 | stage (0.25 h hand-overs) | ≈ 30 h | 6.2 h | 3.93 |
| 4 T4 | stage (1 h hand-overs) | ≈ 34 h | 11.4 h | 3.46 |

- **Total work:** 885 runs, ≈ 118.9 T4-hours (upper bound; `DEADLINE_PLAN.md` gives 118.3 with per-row instead of per-block maxima for tuning).
- **Critical path (chain mode):** `T-fb15k237-chain` (≈ 4.5 h) → `SEL-fb15k237-chain` → the longest FB15k-237 Stage-4 shard (≈ 3 h) → `ANALYSE` ≈ **8 h**. The study cannot finish faster than this however many GPUs you have, unless the jobs are cut smaller (`--target-job-hours`) or stage mode is used with many workers.
- **Maximum useful parallelism:**
  - ≈ 4 workers during tuning in chain mode (3 chains + legacy);
  - up to ≈ 80 shard jobs in Stage 4.
- **Unequal environments cost efficiency:** with one T4 plus one T4 running a different torch build, the estimate is ≈ 70 h instead of ≈ 60 h for two identical T4s, because a dataset's Stage 4 cannot be split across classes.
- **GPU memory:** the measured pilot peak was ≤ 1.4 GB (27 GPU runs, including DP). Any GPU with ≥ 8 GB is comfortably enough. Memory is not a scheduling constraint here.
- **Bottlenecks:** the dense DP noise per optimizer step (`T_k·P`, Section III-M); integrity hashing is 12–52 % of a federated round; and, above all, the manual hand-over delays. CPU and RAM needs are small (a few GB of RAM). Storage is about 1.5 GB for the kept final weights, plus a few hundred MB of records.
- **Artifact sizes:**
  - a Stage-4 shard bundle is tens of MB, more when it holds final weights (5.9–16.2 MB per weight file, depending on the dataset);
  - a release pack is a few kB.

**No speed-up is guaranteed.**
- These figures assume that the GPUs are available when needed and that sessions are not interrupted.
- After the first runs, re-plan with `phase03 --measured`, which replaces the estimates by the measured run times.
- With one GPU, the parallel layer gives **no** speed-up. Use the single notebook (`RUN_COMPLETE_FEDKGE_RESEARCH.ipynb`) instead.

---

## 10. Checkpointing and failure recovery

| Situation | What happens |
|---|---|
| Session ends mid-run | The run's atomic checkpoint (every 5 rounds) holds the model, optimizer, accountant, trust state and RNG states. The same job command resumes the **same** run (same run id, same configuration) |
| Job paused by the budget | EXIT 3. The receipt and a partial bundle hold whatever is COMPLETE. Running the same command later continues |
| A run fails | It is retried on the next call, and the earlier traceback is kept as `error_attempt<k>.txt`. The bundle never includes it |
| Bundle half-written or half-synced | It is invisible to the master until its sidecar matches |
| Same run executed twice (operator error) | The first imported copy is kept; the second is quarantined in `parallel_conflicts/` and reported by phase 09 |
| Worker on the wrong environment | It stops before running (lock, exit 5), or the master refuses the bundle (lock across workers) |
| Pack and worker disagree on a selection | The pack is refused (exit 7); nothing runs |
| A job is never marked complete | A receipt with exit 0 is written only when every run of the job is COMPLETE |

---

## 11. Final integration

The master store is an ordinary results root, so the unchanged `scripts/analyze_results.py` and `scripts/build_report.py` run on it (phases 10–11) with all their protections:
- only COMPLETE current runs are used;
- PENDING placeholders stay PENDING;
- every member is checked for environment homogeneity;
- Holm uses the fixed family size;
- MRR, Hits@1/3/10, privacy, robustness and integrity metrics are reported as before.

Phase 09 adds the cross-worker view on top:
- completeness against all 900 approved cells;
- which job and which planned worker must (re)run each missing cell;
- mixed environments, missing output files, quarantined duplicates, unfrozen datasets with Stage-4 runs, and bundles not yet imported.
