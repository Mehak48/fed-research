"""Assigning jobs to the GPU workers you actually have, and estimating the timeline.

THE ONE HARD CONSTRAINT: the environment lock (10_configs/gates.yaml, scope [tier, dataset]; fedkge.gates). All runs
of one (tier, dataset) group must come from ONE environment signature: the same GPU name, torch build, CUDA version
and Python minor version. Two Colab T4 sessions with the same torch build are one environment class; a T4 and an
L4, or a Colab T4 and a T4 with another torch build, are two classes. A group is therefore assigned to one class, and
its jobs are spread only over the workers of that class. Different groups may use different classes.

Everything here is an ESTIMATE: durations are the T4 upper bounds of parallel/cost_table_T4_upper.csv divided by the
speed factor you give each worker (1.0 = Tesla T4); master steps cost the sync overhead you give (default 0.25 h,
i.e. moving a bundle or a pack by hand). Measured run times replace the estimates once runs exist (measured_hours).
"""
from __future__ import annotations

import itertools
from typing import Dict, List, Optional, Tuple

from .jobs import Job, topo_order, waves

PRIO_ORDER = {"TUNECHAIN": 0, "TUNESTAGE": 0, "LEGACY": 2, "MAIN": 1}


def job_rank(j: Job) -> Tuple:
    """Order among jobs that could start at the same moment: tuning first (it gates Stage 4), then Stage-4 priorities
    in the pre-registered order 1, 2, 3, (4 = legacy), 5, 6, 7."""
    if j.kind in ("TUNECHAIN", "TUNESTAGE"):
        return (0, j.stage or 0, j.dataset or "", j.shard)
    if j.kind == "LEGACY":
        return (1, 4, "", j.shard)
    return (1, j.priority or 9, j.dataset or "", j.shard)


def classes_of(workers: List[Dict]) -> Dict[str, List[Dict]]:
    out: Dict[str, List[Dict]] = {}
    for w in workers:
        out.setdefault(w["env_class"], []).append(w)
    return out


def simulate(jobs: List[Job], workers: List[Dict], assignment: Dict[str, str], durations: Optional[Dict] = None
             ) -> Dict:
    """Greedy list scheduling (earliest possible start first, ties by job_rank). Master steps run on the master as soon
    as their dependencies finish. Returns finish times, per-worker queues and the makespan (hours)."""
    by = {j.job_id: j for j in jobs}
    wclass = classes_of(workers)
    avail = {w["name"]: 0.0 for w in workers}
    speed = {w["name"]: float(w.get("speed", 1.0)) for w in workers}
    finish: Dict[str, float] = {}
    start: Dict[str, float] = {}
    where: Dict[str, str] = {}
    pending = set(by)
    queues: Dict[str, List[str]] = {w["name"]: [] for w in workers}

    def dur(j: Job, w: Optional[str]) -> float:
        base = durations.get(j.job_id, j.est_hours) if durations else j.est_hours
        return base / speed[w] if w else base

    while pending:
        progressed = True
        while progressed:
            progressed = False
            for k in sorted(pending):
                j = by[k]
                if not j.is_worker and all(d in finish for d in j.deps):
                    start[k] = max((finish[d] for d in j.deps), default=0.0)
                    finish[k] = start[k] + dur(j, None)
                    where[k] = "master"
                    pending.discard(k); progressed = True
        best = None
        for k in pending:
            j = by[k]
            if not j.is_worker or not all(d in finish for d in j.deps):
                continue
            ready = max((finish[d] for d in j.deps), default=0.0)
            cls = assignment.get(j.env_group)
            for w in wclass.get(cls, []):
                s = max(ready, avail[w["name"]])
                key = (s, job_rank(j), w["name"])
                if best is None or key < best[0]:
                    best = (key, k, w["name"])
        if best is None:
            if pending:
                stuck = sorted(pending)[:5]
                raise ValueError(f"no worker can run {stuck} (environment group not assigned to any worker class)")
            break
        (s, _, wn), k, _ = best[0], best[1], best[2]
        start[k] = s
        finish[k] = s + dur(by[k], wn)
        avail[wn] = finish[k]
        where[k] = wn
        queues[wn].append(k)
        pending.discard(k)
    return {"finish": finish, "start": start, "where": where, "queues": queues,
            "makespan": max(finish.values(), default=0.0)}


def best_assignment(jobs: List[Job], workers: List[Dict], fixed: Optional[Dict[str, str]] = None,
                    durations: Optional[Dict] = None) -> Tuple[Dict[str, str], Dict]:
    """Try every assignment of environment groups to environment classes (at most 800; otherwise a greedy one) and
    keep the shortest simulated makespan. `fixed` pins groups that already started in a class (their lock exists)."""
    groups = sorted({j.env_group for j in jobs if j.is_worker})
    classes = sorted(classes_of(workers))
    if not classes:
        raise ValueError("no workers registered")
    fixed = dict(fixed or {})
    free = [g for g in groups if g not in fixed]
    best = None
    if len(classes) ** len(free) <= 800:
        for combo in itertools.product(classes, repeat=len(free)):
            a = {**fixed, **dict(zip(free, combo))}
            sim = simulate(jobs, workers, a, durations)
            key = (round(sim["makespan"], 6), len(set(a.values())) * -1)
            if best is None or key < best[0]:
                best = (key, a, sim)
    else:
        a = dict(fixed)
        cap = {c: sum(float(w.get("speed", 1.0)) for w in classes_of(workers)[c]) for c in classes}
        load = {c: 0.0 for c in classes}
        size = {g: sum(j.est_hours for j in jobs if j.env_group == g) for g in free}
        for g in sorted(free, key=lambda g: -size[g]):
            c = min(classes, key=lambda c: (load[c] + size[g]) / cap[c])
            a[g] = c; load[c] += size[g]
        best = (None, a, simulate(jobs, workers, a, durations))
    return best[1], best[2]


def critical_path(jobs: List[Job], workers: List[Dict], assignment: Dict[str, str],
                  durations: Optional[Dict] = None) -> Dict:
    """Longest dependency chain with unlimited workers of each class (fastest worker of the assigned class): the
    minimum possible completion time under the estimates."""
    by = {j.job_id: j for j in jobs}
    fastest = {}
    for c, ws in classes_of(workers).items():
        fastest[c] = max(float(w.get("speed", 1.0)) for w in ws)
    length: Dict[str, float] = {}
    prev: Dict[str, Optional[str]] = {}
    for k in topo_order(jobs):
        j = by[k]
        base = durations.get(k, j.est_hours) if durations else j.est_hours
        d = base / fastest.get(assignment.get(j.env_group), 1.0) if j.is_worker else base
        best_dep = max(j.deps, key=lambda x: length[x], default=None)
        length[k] = d + (length[best_dep] if best_dep else 0.0)
        prev[k] = best_dep
    end = max(length, key=length.get)
    path = [end]
    while prev[path[-1]]:
        path.append(prev[path[-1]])
    return {"hours": length[end], "path": list(reversed(path))}


def plan_summary(jobs: List[Job], workers: List[Dict], durations: Optional[Dict] = None,
                 fixed: Optional[Dict[str, str]] = None) -> Dict:
    assignment, sim = best_assignment(jobs, workers, fixed, durations)
    cp = critical_path(jobs, workers, assignment, durations)
    total = sum(j.est_hours for j in jobs if j.is_worker)
    cap = sum(float(w.get("speed", 1.0)) for w in workers)
    return {"assignment": assignment, "makespan_hours": sim["makespan"], "critical_path": cp,
            "total_gpu_hours_T4": total, "lower_bound_hours": max(cp["hours"], total / cap),
            "queues": sim["queues"], "start": sim["start"], "finish": sim["finish"], "where": sim["where"],
            "waves": waves(jobs)}
