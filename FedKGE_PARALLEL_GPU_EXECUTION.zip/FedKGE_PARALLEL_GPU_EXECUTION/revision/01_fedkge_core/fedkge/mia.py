"""OPTIONAL membership-inference AUDIT (Phase B decision D6; block M1 only; disabled by default).

Design (fixes MJ-15: the revision compared training triples with official TEST triples, which FB15k-237 builds
differently from its training set, so the audit measured that construction difference as well as memorisation):
  * before training, each client draws an audit pool from its OWN training triples (pool_fraction of them);
  * each candidate is included in training independently with probability 1/2; excluded candidates are
    replaced by null records, so the client's public size is unchanged (the audit targets exactly the zero-out
    guarantee that the accountant certifies);
  * members and non-members therefore come from the same distribution.

Attacks (scores: higher = "member")
  A1  model user, black-box : TransE plausibility f(h,r,t) on the final (selected) global model
  A2  relation-calibrated    : A1 standardised per relation with the mean/sd of V_root triples of that relation
      (PRIMARY, pre-registered; pooled over all clients)   (relations with < 5 V_root triples use global stats)
  A3  server, white-box      : f_{theta_k}(x) - f_{theta_start}(x) between client k's last local model and the
      global model it started from (own candidates of client k only)

Metrics: ROC-AUC, TPR at FPR = 1 % and 0.1 %, best balanced accuracy, and an EMPIRICAL LOWER BOUND on epsilon
from the one-run audit of Steinke, Nasr & Jagielski (2023, Prop. 5.1 / Thm 5.2):
  guess 'member' on the r/2 highest scores, 'non-member' on the r/2 lowest, abstain on the rest; v = #correct.
  If the mechanism is (eps, delta)-DP: P[V >= v] <= beta + alpha * 2 m delta, with W* ~ Bin(r, e^eps/(1+e^eps)),
  beta = P[W* >= v], alpha = max_{i>=1} (P[W* >= v-i] - beta)/i, m = number of candidates.
  The reported bound is the largest eps rejected at level (1-confidence)/len(guesses) (Bonferroni over the
  pre-declared guess counts). It is a lower bound under these attacks, NOT a guarantee; if it ever exceeds the
  accountant's epsilon the implementation is presumed wrong.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import torch
from scipy.stats import binom, rankdata

from .model import Params, score


@torch.no_grad()
def _scores(params: Params, trip: np.ndarray, normalize: bool, device) -> np.ndarray:
    T = torch.as_tensor(trip, device=device, dtype=torch.long)
    out = []
    for b in range(0, len(T), 8192):
        x = T[b:b + 8192]
        out.append(score(params["ent"][x[:, 0]], params["rel"][x[:, 1]], params["ent"][x[:, 2]], normalize).cpu())
    return torch.cat(out).numpy() if out else np.zeros(0)


def roc_metrics(s: np.ndarray, y: np.ndarray) -> Dict:
    ok = np.isfinite(s)
    s, y = s[ok], y[ok].astype(bool)
    n1, n0 = int(y.sum()), int((~y).sum())
    if n1 == 0 or n0 == 0:
        return {"auc": float("nan"), "tpr_at_fpr_1pct": float("nan"), "tpr_at_fpr_0_1pct": float("nan"),
                "fpr_resolvable_1pct": False, "fpr_resolvable_0_1pct": False,
                "balanced_acc_best_threshold": float("nan"), "n_members": n1, "n_nonmembers": n0}
    ranks = rankdata(s)
    auc = (ranks[y].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)
    order = np.argsort(-s, kind="stable")
    tp = np.cumsum(y[order]) / n1
    fp = np.cumsum(~y[order]) / n0

    def tpr_at(f):
        return float(tp[fp <= f].max()) if np.any(fp <= f) else 0.0
    # an FPR target f is only resolvable with at least 1/f non-members (otherwise TPR@f is TPR at FPR = 0)
    return {"auc": float(auc), "tpr_at_fpr_1pct": tpr_at(0.01), "tpr_at_fpr_0_1pct": tpr_at(0.001),
            "fpr_resolvable_1pct": n0 >= 100, "fpr_resolvable_0_1pct": n0 >= 1000,
            # in-sample: the threshold is chosen on the same candidates (optimistic; descriptive only)
            "balanced_acc_best_threshold": float(np.max(0.5 * (tp + (1 - fp)))), "n_members": n1, "n_nonmembers": n0}


def _bound_terms(eps: float, r: int, v: int) -> Tuple[float, float]:
    p = np.exp(eps) / (1 + np.exp(eps))
    beta = float(binom.sf(v - 1, r, p))                       # P[W* >= v]
    if v <= 0:
        return beta, 0.0
    i = np.arange(1, v + 1)
    tail = binom.sf(v - i - 1, r, p)                          # P[W* >= v - i]
    alpha = float(np.max((tail - beta) / i))
    return beta, max(alpha, 0.0)


def one_run_eps_lower_bound(s: np.ndarray, member: np.ndarray, r: int, delta: float, level: float,
                            eps_max: float = 50.0, step: float = 0.005) -> Dict:
    """Largest eps such that every eps' <= eps is rejected (first crossing on a fine grid; conservative)."""
    ok = np.isfinite(s)
    s, member = s[ok], member[ok].astype(bool)
    m = len(s)
    r = int(min(r, m - (m % 2)))
    if r < 2:
        return {"r": r, "correct": 0, "eps_lb": 0.0, "m": m}
    order = np.argsort(-s, kind="stable")
    k = r // 2
    correct = int(member[order[:k]].sum() + (~member[order[-k:]]).sum())
    lb = 0.0
    for eps in np.arange(0.0, eps_max + step, step):
        beta, alpha = _bound_terms(float(eps), r, correct)
        if beta + alpha * 2 * m * delta <= level:
            lb = float(eps)
        else:
            break
    return {"r": r, "correct": correct, "accuracy": correct / r, "eps_lb": lb, "m": m}


def run_audit(final_params: Params, cand: np.ndarray, member: np.ndarray, client: np.ndarray, vroot: np.ndarray,
              normalize: bool, device, last_local: Dict[int, torch.Tensor], last_start: Optional[torch.Tensor],
              like: Params, eps_dp: Optional[float], delta: float, guesses: Sequence[int] = (100, 300, 1000),
              confidence: float = 0.95, inclusion_p: float = 0.5) -> Tuple[Dict, pd.DataFrame]:
    from .model import unflatten
    s1 = _scores(final_params, cand, normalize, device)
    # A2: per-relation calibration on server-held V_root
    sv = _scores(final_params, vroot, normalize, device)
    mu_g, sd_g = float(np.mean(sv)), float(np.std(sv) + 1e-12)
    s2 = np.empty_like(s1)
    for r in np.unique(cand[:, 1]):
        sel = cand[:, 1] == r
        vr = sv[vroot[:, 1] == r]
        mu, sd = (float(vr.mean()), float(vr.std() + 1e-12)) if len(vr) >= 5 else (mu_g, sd_g)
        s2[sel] = (s1[sel] - mu) / sd
    # A3: white-box, own candidates of each client
    s3 = np.full(len(cand), np.nan)
    if last_start is not None and last_local:
        base = unflatten(last_start, like)
        sb = _scores(base, cand, normalize, device)
        for c, u in last_local.items():
            sel = client == c
            if sel.any():
                th = unflatten(last_start + u, like)
                s3[sel] = _scores(th, cand[sel], normalize, device) - sb[sel]
    level = (1 - confidence) / max(len(guesses), 1)
    res: Dict = {"primary_attack": "A2", "n_candidates": int(len(cand)), "n_members": int(member.sum()),
                 "inclusion_p": inclusion_p, "eps_accountant": eps_dp, "delta": delta,
                 "bonferroni_level_per_guess_count": level, "attacks": {}}
    for name, s in (("A1", s1), ("A2", s2), ("A3", s3)):
        m = roc_metrics(s, member)
        if abs(inclusion_p - 0.5) < 1e-12:
            lbs = [one_run_eps_lower_bound(s, member, int(r), delta, level) for r in guesses]
            m["one_run"] = lbs
            m["eps_lower_bound"] = max(x["eps_lb"] for x in lbs)
        else:
            m["one_run"], m["eps_lower_bound"] = [], None     # theorem stated for inclusion probability 1/2
        res["attacks"][name] = m
    p = res["attacks"]["A2"]
    res.update({"auc": p["auc"], "tpr_at_fpr_1pct": p["tpr_at_fpr_1pct"], "tpr_at_fpr_0_1pct": p["tpr_at_fpr_0_1pct"],
                "fpr_resolvable_0_1pct": p["fpr_resolvable_0_1pct"], "eps_lower_bound": p["eps_lower_bound"]})
    if eps_dp is not None:
        worst = max((a["eps_lower_bound"] or 0.0) for a in res["attacks"].values())
        # Red line (Phase B 05 section 10): recorded loudly; analysis refuses the run until it is investigated.
        # Not raised, because the bound is a 95 % statement and a run must keep its evidence for the investigation.
        res["lower_bound_exceeds_accountant"] = bool(worst > eps_dp + 1e-9)
        res["max_lower_bound_over_attacks"] = worst
    scores = pd.DataFrame({"client": client, "member": member.astype(int), "h": cand[:, 0], "r": cand[:, 1],
                           "t": cand[:, 2], "A1": s1, "A2": s2, "A3": s3})
    return res, scores
