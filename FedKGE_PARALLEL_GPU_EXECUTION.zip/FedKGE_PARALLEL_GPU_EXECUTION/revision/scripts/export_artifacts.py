#!/usr/bin/env python3
"""Final artifact export: one zip of a results root for the paper and for archiving.

  python scripts/export_artifacts.py [--results R] [--out DIR] [--include-weights] [--include-mia-scores]

Included: every run's records (config, env, status, final, accountant, attack, integrity, mia summary, rounds,
weights_rounds, trust_rounds, per-relation MRR, logs, error files), indexes, selections, gate outputs, environment
locks, manifests, progress views, analysis, figures and reports, plus EXPORT_MANIFEST.json with the SHA-256 of every
file. Excluded by default: dataset copies and processed dataset artifacts (triples.npz, labels.json - never
redistributed), checkpoints (*.pt; final weights only with --include-weights), integrity object stores, temporary
files, and mia_scores.csv (per-candidate triple ids; --include-mia-scores to keep them).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
import zipfile
from pathlib import Path

from _common import Manifest, git_commit, results_root

NEVER = {"triples.npz", "labels.json", "train.txt", "valid.txt", "test.txt"}


def keep(p: Path, a) -> bool:
    if p.name in NEVER or p.suffix in (".npz", ".tmp") or "integrity_store" in p.parts:
        return False
    if p.suffix == ".pt":
        return a.include_weights and p.name == "final_weights.pt"
    if p.name == "mia_scores.csv":
        return a.include_mia_scores
    return True


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results"); ap.add_argument("--out")
    ap.add_argument("--include-weights", action="store_true"); ap.add_argument("--include-mia-scores", action="store_true")
    a = ap.parse_args(argv)
    root = results_root(a.results)
    out_dir = Path(a.out) if a.out else root.parent
    stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    zp = out_dir / f"fedkge_results_export_{stamp}.zip"
    man = Manifest(root, "export_artifacts")
    files, skipped = {}, 0
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if not p.is_file():
                continue
            if not keep(p, a):
                skipped += 1; continue
            rel = p.relative_to(root.parent)
            z.write(p, rel)
            files[str(rel)] = hashlib.sha256(p.read_bytes()).hexdigest()
        meta = {"created_utc": stamp, "results_root": str(root), "git_commit": git_commit(), "n_files": len(files),
                "n_skipped": skipped, "excluded": "dataset files and artifacts, checkpoints, integrity stores, temp "
                "files" + ("" if a.include_mia_scores else ", mia_scores.csv"), "files_sha256": files}
        z.writestr(f"{root.name}/EXPORT_MANIFEST.json", json.dumps(meta, indent=1))
    man.output(zp); man.close("COMPLETE", n_files=len(files), zip=str(zp))
    print(f"EXPORT: {zp} ({zp.stat().st_size / 1e6:.1f} MB, {len(files)} files, {skipped} excluded)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
