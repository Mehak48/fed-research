# Gate G-B — fully trained accuracy sanity check (smoke tier)

Evaluated 2026-11-05T02:41:02.558989Z · rule SHA-256 `2badc6ca89e237d0…` · enforced on this tier: **False**

Pass rule: validation MRR of the pre-registered T1_central configuration (centralised, non-private, fully trained) ≥ 0.6667 × the published TransE MRR. The published values are a trainer check only, never a target.

| Dataset | Status | Selected val MRR | Threshold | Published (source) | Candidates at R_max |
|---|---|---|---|---|---|
| fb15k237 | **FAILED** | 0.1015 | 0.2087 | 0.313 (LibKGE results table, github.com/uma-pi1/kge) | 0 of 6 |
| wn18rr | **FAILED** | 0.0083 | 0.1520 | 0.228 (LibKGE results table, github.com/uma-pi1/kge) | 0 of 6 |
| codex_m | **FAILED** | 0.0747 | 0.2020 | 0.303 (Safavi & Koutra 2020 (EMNLP), CoDEx paper, arXiv 2009.07810) | 0 of 6 |

## Result: the gate did NOT pass

This tier does not enforce the gate (software check only); nothing here is evidence.

Recovery (EXECUTION_GUIDE.md, 'Sanity gate failed'):
1. Keep every T1C run folder; nothing is deleted.
2. Read each candidate's `log.txt` and `rounds.csv`: does the validation MRR still rise at the last evaluation (candidates at R_max > 0 means possible under-training)? Is the loss finite and falling?
3. Check the data: `artifacts/p1/<dataset>/validation_report.json` must say ok, split counts must equal the official counts.
4. Send this report, `sanity_gate.json` and the T1C run folders to the maintainer for a trainer investigation. The study cannot claim a working baseline until the cause is found and fixed, and any fix changes the code hash, so every earlier run is re-executed.
