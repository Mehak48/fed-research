# 06 — Baseline, ablation and threshold-sweep matrix (Phase B, item 6)

**Status:** design draft. Nothing has run.
- Machine-readable: `data/experiment_matrix.csv` (one row per block), `drafts/experiment_matrix_draft.yaml` (input for Phase C) and `data/threshold_inventory.csv`.
- Run counts and costs come from `scripts/phaseB_experiment_matrix.py`. The tables below are generated from the same CSV.
- **Naming:** blocks are P2.x, T, L, N, DP, R, I, M, X, O. The DP blocks are DP1, DP1h, DP2, DP2h and DP3; "D1–D18" always means a *decision* (`02`).

## 1. Structure

| Stage | Purpose | Seeds | Evidence? |
|---|---|---|---|
| 0 | Unit and integration tests, including the 26 PyTorch tests not yet run | – | no (software check) |
| 1 | Smoke: every block on 3,000-triple subsets, 3 rounds | 42 | **no**, watermarked `NOT_FOR_MANUSCRIPT` |
| 2 | Pilot / dev gate: timings, sanity, first DP look | 1001 | no |
| 3 | Tuning and selection on **validation only**, under pre-registered rules | 1001 | no (selection only) |
| 4 | Confirmatory core, with selections frozen | S5 for every block that carries a hypothesis test; S10 for the headline blocks in the full profile; S3 for blocks labelled descriptive | **yes** (hypothesis blocks); descriptive otherwise |
| 5 | Extended / sensitivity, labelled as such; optional O1 | S3 (O1: S5) | descriptive only (no pre-registered hypothesis) |

**Profiles** (D18):
- **reduced (recommended first):** every hypothesis block at 5 seeds (S5); descriptive blocks at 3 seeds (S3); smaller sensitivity grids; the S10x extension blocks (DP1h, DP2h) dropped.
- **full:** the headline hypothesis blocks at 10 seeds (S10); larger grids.

**Run totals** (three datasets with CoDEx-M; `data/run_counts.csv`):

| Tier | Full profile | Reduced profile |
|---|---|---|
| Core, Stages 2–4 | 1,485 runs | 837 runs |
| MIA audit M1 (only if D6 keeps H3; 5 seeds in both profiles) | 60 | 60 |
| Extended (Stage 5) | 594 | 432 |
| Optional (O1) | 15 | 15 |

**The complete method** (`03` §0) is the whole pipeline with every component active:
- DP at ε* = 4 with the sampling design (D11), sampling rate q*, clip C*, learning rate lr*, rounds R* and noise schedule s* selected in Stage 3;
- the proposed trust aggregation (`03` §8.3; variant V1 only if its D15 trigger fires) with the selected τ*;
- integrity verification in the data path (`03` §9).

Every robustness block uses the complete method's DP configuration and changes **only** the aggregator or the attack, so the comparisons are clean ablations.

## 2. Baselines vs ablations (master prompt §13)

**Baselines** are different methods or references, compared with the complete method:

| # (master prompt §13) | Comparison | Block(s) |
|---|---|---|
| 1 | Centralised non-private KGE reference | N1 |
| 2 | Federated non-private KGE (FedAvg) | N2 (α = 0.1), N3 (α = 0.5, 1.0, IID) |
| 3 | Federated KGE with DP, without trust (standard DP-SGD + FedAvg; **the DP baseline**) | DP1 (fixed σ), DP2 (selected schedule s*; equals DP1 if s* = fixed) |
| 8 | Alternative aggregation: trimmed mean, median, Krum, FLTrust | R1 (clean), R4 (attacks) |
| 9 | External DP baseline | none reproducible (D17); O1 is a DP-Flames-*inspired* policy, labelled "not a reproduction" |
| – | Local-only training (value of federating) | X6 |
| – | The original method (historical) | L0–L4 (FB15k-237 only) |

**Ablations** remove one component *from the complete method*:

| # (master prompt §13) | Remove | Block(s) | Note |
|---|---|---|---|
| 4 | DP (keep trust) | R5, R5a | the trust rule without DP, clean and attacked |
| 5 | — (the complete method itself) | R1p (clean), R3/R3a (attacked) | |
| 6 | Integrity verification | I1 (off, no corruption), I2 (corruption in transit, on vs off) | utility is identical when nothing is corrupted (by construction) |
| 7 | Poisoning defence (= trust rule) | R2, R2a (FedAvg under the same attacks and DP settings); DP2 at ε* = 4 (clean) | |
| – | Noise schedule | R1q (fixed σ inside the complete method); DP1 vs DP2 (inside FedAvg) | skipped if s* = fixed |
| – | Decomposing the DP cost | DP3 (DP settings without noise or clipping; clipping only) | |

**What may be claimed.**
- A component is claimed to help **only** through a pre-registered hypothesis (`03` §13: H1, H2, H2b, H3, HS), tested one-sided at α = 0.025 with Holm correction within its family.
- Every other comparison is **descriptive**: it reports the paired, seed-level difference with its 95 % interval and is never called significant. One run scoring higher is never evidence.

## 3. Block-level matrix

Datasets: ALL3 = FB15k-237, WN18RR and the third dataset (D5); FB = FB15k-237 only.

Seed sets:
- S_TUNE = {1001} (selection only);
- S1 = {42};
- S3 = {42, 123, 256} (descriptive blocks; a subset of S5, so still paired);
- S5 = {42, 123, 256, 512, 1024} (the roadmap seeds; every hypothesis block);
- S10x = {2048, 4096, 8192, 16384, 32768} (full-profile extension only);
- S10 = S5 ∪ S10x.

DP1h and DP2h run only the S10x seeds at ε* = 4, so that DP1 + DP1h and DP2 + DP2h give 10 seeds for the headline comparisons without repeating any run.

