"""GPU (Colab T4) pilot vs CPU pilot vs Phase B estimates. Reads only recorded CSV/JSON files; writes one derived CSV.

usage: python gpu_pilot_analysis.py <colab results_colab dir> <local results/phaseC dir> <phaseB data dir> <out dir>
"""
import json
import sys
from pathlib import Path

import pandas as pd

colab, local, pb, out = map(Path, sys.argv[1:5])
out.mkdir(parents=True, exist_ok=True)
g1 = pd.read_csv(colab / "pilot/pilot_measurements_20261104T164136Z.csv")
g2 = pd.read_csv(colab / "pilot/pilot_measurements_20261104T164854Z.csv")
c1 = pd.read_csv(local / "pilot/pilot_measurements_20261102T130753Z.csv")
c2 = pd.read_csv(local / "pilot/pilot_measurements_20261102T133807Z.csv")      # clean FB np_fed re-measurement
cpu = pd.concat([c1[~((c1.dataset == "fb15k237") & (c1.config == "np_fed"))], c2], ignore_index=True)
key = ["dataset", "config"]
assert (g1.status == "COMPLETE").all() and (g2.status == "COMPLETE").all() and (cpu.status == "COMPLETE").all()
assert (g1.device == "cuda").all() and (g2.device == "cuda").all() and (cpu.device == "cpu").all()

m = g1[key + ["per_round_s", "extrapolated_run_hours"]].merge(
    g2[key + ["planned_rounds", "num_params", "local_s_per_round", "agg_s_per_round", "integrity_s_per_round",
              "per_round_s", "val_eval_s_per_pass", "final_eval_s", "extrapolated_run_hours", "gpu_peak_allocated_mb",
              "peak_rss_mb", "run_dir_mb", "run_id"]], on=key, suffixes=("_g1", "_g2"))
m = m.merge(cpu[key + ["per_round_s", "extrapolated_run_hours", "run_id"]].rename(
    columns={"per_round_s": "per_round_s_cpu", "extrapolated_run_hours": "run_hours_cpu", "run_id": "run_id_cpu"}), on=key)
assert (m.run_id == m.run_id_cpu).all()                    # same configuration hash on both devices
m["per_round_s_gpu_max"] = m[["per_round_s_g1", "per_round_s_g2"]].max(axis=1)
m["run_hours_gpu_max"] = m[["extrapolated_run_hours_g1", "extrapolated_run_hours_g2"]].max(axis=1)
m["repeat_diff_pct"] = 100 * (m.per_round_s_g2 - m.per_round_s_g1) / m.per_round_s_g1
m["speedup_vs_cpu"] = m.per_round_s_cpu / m.per_round_s_gpu_max          # conservative: slower GPU run
m["integrity_share_pct"] = 100 * m.integrity_s_per_round / m.per_round_s_g2
mode = {"np_central": "np_central", "np_fed": "np_fed", "dp_fedA_B512": "dp_fedA",
        "dp_fed_q0.10": "dp_fed", "dp_fed_q0.02": "dp_fed", "complete_q0.10": "dp_fed"}
est = pd.read_csv(pb / "per_run_time_estimate.csv")
m["pb_mode"] = m.config.map(mode)
m = m.merge(est[["dataset", "mode", "minutes_LOW", "minutes_HIGH"]].rename(columns={"mode": "pb_mode"}),
            on=["dataset", "pb_mode"], how="left")
m["gpu_minutes_upper"] = 60 * m.run_hours_gpu_max
m["vs_phaseB"] = m.apply(lambda r: "below LOW" if r.gpu_minutes_upper < r.minutes_LOW else
                         ("above HIGH" if r.gpu_minutes_upper > r.minutes_HIGH else "inside"), axis=1)
m.to_csv(out / "gpu_pilot_per_config.csv", index=False)

print("| Dataset | Configuration | GPU s/round (run 1 / run 2) | of which integrity | CPU s/round | Speed-up | "
      "GPU min per run (upper) | Phase B min (LOW–HIGH) | GPU peak MB | Host RSS GB |")
print("|---|---|---|---|---|---|---|---|---|---|")
for r in m.itertuples():
    print(f"| {r.dataset} | {r.config} | {r.per_round_s_g1:.2f} / {r.per_round_s_g2:.2f} | {r.integrity_s_per_round:.2f} "
          f"({r.integrity_share_pct:.0f} %) | {r.per_round_s_cpu:.1f} | {r.speedup_vs_cpu:.1f}× | {r.gpu_minutes_upper:.1f} | "
          f"{r.minutes_LOW:.1f}–{r.minutes_HIGH:.1f} ({r.vs_phaseB}) | {r.gpu_peak_allocated_mb:,.0f} | {r.peak_rss_mb / 1024:.1f} |")
print()
print("speed-up range:", round(m.speedup_vs_cpu.min(), 1), "-", round(m.speedup_vs_cpu.max(), 1),
      "| median", round(m.speedup_vs_cpu.median(), 1))
print("repeat difference per config (%): min", round(m.repeat_diff_pct.min(), 1), "max", round(m.repeat_diff_pct.max(), 1),
      "| median abs", round(m.repeat_diff_pct.abs().median(), 1))
print("GPU peak allocated MB: min", round(m.gpu_peak_allocated_mb.min()), "max", round(m.gpu_peak_allocated_mb.max()))
print("host peak RSS GB: min", round(m.peak_rss_mb.min() / 1024, 2), "max", round(m.peak_rss_mb.max() / 1024, 2))
print("integrity share of a round (%): min", round(m.integrity_share_pct.min(), 1), "max", round(m.integrity_share_pct.max(), 1))
print("vs Phase B:", m.vs_phaseB.value_counts().to_dict())
print("GPU minutes per run (upper): min", round(m.gpu_minutes_upper.min(), 1), "max", round(m.gpu_minutes_upper.max(), 1))
# proposed-method overhead over DP-FedAvg at q = 0.10 (same dataset)
for ds in m.dataset.unique():
    a = m[(m.dataset == ds) & (m.config == "dp_fed_q0.10")].iloc[0]; b = m[(m.dataset == ds) & (m.config == "complete_q0.10")].iloc[0]
    print(f"{ds}: complete vs dp_q0.10 s/round run1 {b.per_round_s_g1 - a.per_round_s_g1:+.2f}, run2 {b.per_round_s_g2 - a.per_round_s_g2:+.2f}")
print()
rows = []
for tag, f in (("run 1", "164136Z"), ("run 2", "164854Z")):
    s = json.loads((colab / f"pilot/pilot_summary_20261104T{f}.json").read_text())
    for b in s["by_stage"]:
        rows.append({"run": tag, "plan": b["plan"], "stage": b["stage"], "runs": b["runs"], "gpu_h": b["hours_upper"]})
st = pd.DataFrame(rows).pivot_table(index=["plan", "stage", "runs"], columns="run", values="gpu_h").reset_index()
cpu_s = json.loads((local / "pilot/pilot_summary_20261102T134009Z.json").read_text())
cpu_by = {(b["plan"], b["stage"]): b["hours_upper"] for b in cpu_s["by_stage"]}
st["cpu_h"] = [cpu_by.get((p, s)) for p, s in zip(st.plan, st.stage)]
st["speedup"] = st.cpu_h / st[["run 1", "run 2"]].max(axis=1)
st.to_csv(out / "gpu_pilot_by_stage.csv", index=False)
print(st.to_string(index=False))
for t in ("tune", "confirm_reduced", "confirm_full"):
    x = st[st.plan == t]
    print(t, "runs", int(x.runs.sum()), "| GPU-h run1", round(x["run 1"].sum(), 1), "run2", round(x["run 2"].sum(), 1),
          "| CPU-h", round(x.cpu_h.sum(), 1))
