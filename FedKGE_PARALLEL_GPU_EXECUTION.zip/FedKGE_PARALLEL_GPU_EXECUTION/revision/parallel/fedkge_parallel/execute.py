"""Running ONE job inside ONE worker's private results root.

Every run is executed by fedkge.runner.run_entries - the function the sequential entry points call - on entries
produced by fedkge.runner.expand with the same arguments as scripts/run_plan.py and scripts/run_legacy_blocks.py.
A tuning chain is literally `scripts/run_plan.py --plan tune --datasets <ds>`. The only thing this module adds is the
filter "only the runs of this job", and the checks that the worker's expansion yields exactly the run ids the master
assigned (otherwise the worker would be running a different experiment, and the job is refused).

Resumption: run the same job again in the same worker root. COMPLETE runs are reused, an interrupted run resumes from
its atomic checkpoint (optimizer, accountant, trust state and RNG states are inside it - fedkge.federated), FAILED runs
are retried with their earlier traceback kept. The bundle written at the end always reflects what is COMPLETE.
"""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Dict, List, Optional

from .bundles import export_bundle, find_release, install_pack
from .cells import entry_cell_key, expand_plan
from .common import (CONFIG_DIR, EXIT_BUDGET, EXIT_CONTRACT, EXIT_ENV, EXIT_FAILED, EXIT_MANIFEST, EXIT_OK,
                     RESEARCH_TIERS, IntegrityError, JobLog, Layout, Paths, RunDir, atomic_write_json, read_json,
                     read_json_or, utc_now)


def job_spec_for(layout: Layout, job_id: str, log=print) -> Dict:
    """The job spec: from the newest release pack containing it (materialised by the master), otherwise from the plan
    (jobs whose run ids are known without selections). A job that requires a release refuses to start without one."""
    rel = find_release(layout, job_id)
    if rel is not None:
        pack, meta, spec = rel
        spec["_release_pack"] = str(pack)
        return spec
    p = layout.plan_dir / "jobs" / f"{job_id}.json"
    if not p.exists():
        raise SystemExit(f"job {job_id} is not in the plan ({p} missing): run phase 03 on the master first")
    spec = read_json(p)
    if spec.get("requires_release"):
        raise SystemExit(f"job {job_id} waits for its release by the master ({', '.join(spec['deps'])}): no release "
                         f"pack in {layout.packs} contains it yet")
    return spec


def _results_root(root: Path) -> Path:
    from _common import results_root          # scripts/_common.py: creates logs/, manifests/, ... as the scripts do
    return results_root(str(root))


def run_worker_job(layout: Layout, worker: str, job_id: str, device: Optional[str], max_hours: Optional[float],
                   max_runs: Optional[int] = None) -> int:
    root = _results_root(layout.worker(worker))
    log = JobLog(root / "parallel" / "logs" / f"{job_id}.log")
    spec = job_spec_for(layout, job_id, log)
    tier, ds = spec["tier"], spec["dataset"]
    log(f"job {job_id} ({spec['kind']}, tier {tier}, dataset {ds}) on worker {worker}, device {device}")
    if spec.get("_release_pack"):
        try:
            install_pack(Path(spec["_release_pack"]), root, log)
        except IntegrityError as e:
            log(f"STOP: {e}")
            return EXIT_CONTRACT
    t0 = time.time()
    if spec["kind"] == "TUNECHAIN":
        code, run_ids, extra = _run_chain(root, spec, device, max_hours, max_runs, log)
    else:
        code, run_ids = _run_runs(root, spec, device, max_hours, max_runs, log, layout)
        extra = {}
    paths = Paths(root, tier)
    extra.setdefault("worker/ENVIRONMENT_LOCK.json", paths.base / "ENVIRONMENT_LOCK.json")
    for idx in sorted((paths.base / "index").glob("*_runs_index.csv")) if (paths.base / "index").exists() else []:
        extra[f"worker/index/{idx.name}"] = idx
    extra[f"worker/logs/{job_id}.log"] = log.path
    receipt = {"job_id": job_id, "worker": worker, "exit_code": code, "finished_utc": utc_now(),
               "seconds": round(time.time() - t0, 1),
               "runs": {rid: (RunDir(paths.run(rid)).status() or {}).get("status", "NOT_STARTED") for rid in run_ids}}
    atomic_write_json(root / "parallel" / "receipts" / f"{job_id}.json", receipt)
    if code not in (EXIT_ENV, EXIT_MANIFEST, EXIT_CONTRACT):
        export_bundle(layout, worker, spec, code, run_ids, extra, log)
    log(f"job {job_id}: exit {code}")
    return code


def _run_chain(root: Path, spec: Dict, device, max_hours, max_runs, log):
    """Stage 3 for one dataset, in order, by the sequential entry point itself."""
    import run_plan
    argv = ["--results", str(root), "--plan", "tune", "--tier", spec["tier"], "--datasets", spec["dataset"]]
    if device:
        argv += ["--device", device]
    if max_hours:
        argv += ["--max-hours", f"{max_hours:.3f}"]
    if max_runs is not None:
        argv += ["--max-runs", str(max_runs)]
    code = run_plan.main(argv)
    paths = Paths(root, spec["tier"])
    rids = set()
    idx = paths.index("tune")
    if idx.exists():
        import pandas as pd
        df = pd.read_csv(idx)
        rids = set(df[df["dataset"] == spec["dataset"]]["run_id"].dropna())
    extra = {"worker/selection/tuning.json": paths.selection("tuning"),
             "worker/gates/sanity_gate.json": paths.base / "gates" / "sanity_gate.json",
             "worker/gates/SANITY_GATE_REPORT.md": paths.base / "gates" / "SANITY_GATE_REPORT.md",
             "worker/gates/d10_trigger.json": paths.base / "gates" / "d10_trigger.json"}
    return code, sorted(rids), extra


def _run_runs(root: Path, spec: Dict, device, max_hours, max_runs, log, layout: Optional[Layout] = None):
    from fedkge.config import load_yaml
    from fedkge.gates import EnvironmentMismatch, check_environment_lock
    from fedkge.manifest import check_entries_against_manifest, verify_frozen
    from fedkge.runner import run_entries, write_index
    from _common import Manifest
    from run_plan import ensure_partitions, order_entries, require_frozen_selections
    tier, ds, plan = spec["tier"], spec["dataset"], spec["plan"]
    paths = Paths(root, tier)
    want = {r["run_id"]: r["cell_keys"] for r in (spec.get("runs") or [])}
    man = Manifest(root, f"parallel_{spec['job_id']}")
    if not want:
        log("nothing to run: every run of this job is complete in the master store or re-used from another job")
        man.close("COMPLETE", note="no runs to execute")
        return EXIT_OK, []
    research = tier in RESEARCH_TIERS
    frozen = None
    try:
        if research:
            frozen = verify_frozen(CONFIG_DIR)
        man.rec["environment_lock"] = check_environment_lock(
            paths, [ds], device, load_yaml(CONFIG_DIR / "gates.yaml")["environment_lock"],
            session_note=f"parallel job {spec['job_id']}")
    except IntegrityError as e:
        man.close("MANIFEST_MISMATCH", reason=str(e)); log(f"STOP: {e}"); return EXIT_MANIFEST, list(want)
    except EnvironmentMismatch as e:
        man.close("ENVIRONMENT_MISMATCH", reason=str(e)); log(f"STOP: {e}"); return EXIT_ENV, list(want)
    try:
        if plan == "main" and tier == "final":
            require_frozen_selections(paths, [ds])
        entries = expand_plan(plan, tier, paths, [ds], stages=[spec["stage"]] if plan == "tune" else None)
        if frozen is not None:
            man.rec["manifest_check"] = check_entries_against_manifest(entries, frozen, plan,
                                                                       require_all=plan in ("main", "legacy"))
        got: Dict[str, str] = {entry_cell_key(plan, e): e["run_id"] for e in entries}
        wrong = [(k, rid, got.get(k)) for rid, ks in want.items() for k in ks if got.get(k) != rid]
        if wrong:
            raise IntegrityError(f"this worker's expansion differs from the master's for {len(wrong)} cell(s), e.g. "
                                 f"{wrong[:2]}: the selection files differ - install the job's release pack")
    except (IntegrityError, SystemExit) as e:
        man.close("CONTRACT_VIOLATED", reason=str(e)); log(f"STOP: {e}"); return EXIT_CONTRACT, list(want)
    in_master = set()
    if layout is not None and layout.master.exists():      # shared folder: never repeat a run the master already has
        mp = Paths(layout.master, tier)
        in_master = {rid for rid in want if RunDir(mp.run(rid)).is_complete_and_current()}
        if in_master:
            log(f"{len(in_master)} run(s) of this job are already COMPLETE in the master store and are not run again")
    todo, seen = [], set()
    for e in entries:
        if e["run_id"] in want and e["run_id"] not in seen and e["run_id"] not in in_master:
            todo.append(e); seen.add(e["run_id"])
    for ph in sorted({e["phase"] for e in entries}):
        write_index(paths, ph, [e for e in entries if e["phase"] == ph])
    built = ensure_partitions(todo, paths, man)
    todo = order_entries(todo, [ds])
    log(f"{len(todo)} run(s) of this job; {built} partition(s) built; other cells of the stage/plan are not run here")
    deadline = time.time() + 3600 * max_hours if max_hours else None
    st = run_entries(todo, paths, device, deadline=deadline, max_runs=max_runs)
    counts = st["status"].value_counts().to_dict() if len(st) else {}
    log(f"run statuses: {counts}")
    failed = len(st) and st["status"].astype(str).str.startswith("FAILED").any()
    pending = len(st) and (st["status"] == "PENDING").any()
    code = EXIT_FAILED if failed else (EXIT_BUDGET if pending else EXIT_OK)
    man.close({EXIT_OK: "COMPLETE", EXIT_FAILED: "RUN_FAILURES", EXIT_BUDGET: "PARTIAL_SESSION_BUDGET"}[code],
              statuses=counts)
    return code, [r for r in want if r not in in_master]
