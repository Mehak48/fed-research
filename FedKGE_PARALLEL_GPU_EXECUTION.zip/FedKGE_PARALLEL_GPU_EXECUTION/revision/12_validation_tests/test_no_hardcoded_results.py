"""Linter against the exact failure modes found in the old notebooks: hard-coded results, formula-generated
metrics, fabricated epsilon fallbacks, fake CIDs, stub result dictionaries. Scans the core package and every
notebook code cell of this delivery."""
import json
import re
from pathlib import Path

PKG = Path(__file__).resolve().parents[1]
CORE = PKG / "01_fedkge_core" / "fedkge"
NOTEBOOKS = sorted(PKG.glob("0[2-9]_*/*.ipynb"))

OLD_RESULT_LITERALS = ["0.2858", "0.0940", "3.04", "15.53", "0.0101", "0.0112", "0.0122", "0.009", "74.26", "30.56",
                       "0.2209", "0.3073"]
FORBIDDEN_PATTERNS = [
    (r"eps\w*\s*=\s*sigma\w*\s*\*", "epsilon derived from sigma by a formula"),
    (r"CENTRALI[SZ]ED_MRR\s*=\s*\d", "hard-coded baseline"),
    (r"['\"]Qm", "fake IPFS CIDv0 prefix"),
    (r"\b(mrr|hits|asr|attack_success|epsilon|eps)\w*\s*=\s*(P\d_)?\w*MRR\s*\*", "metric generated from another metric"),
    (r"\b(mrr|hits@?\d*|epsilon|eps|asr)['\"]?\s*[:=]\s*0\.\d{3,}", "numeric literal assigned to a result field"),
    (r"np\.exp\(\s*-\s*0\.\d+\s*\*\s*eps", "formula-generated attack success"),
    (r"\*\s*\(1\s*[+-]\s*0\.\d+\s*\*\s*round", "formula-generated learning curve"),
    (r"IMPLEMENTED['\"]", "hard-coded status string"),
    (r"WITHIN BUDGET", "hard-coded budget verdict"),
]
ALLOW_FILES = {"test_no_hardcoded_results.py"}


SCRIPTS = sorted((PKG / "scripts").glob("*.py"))
# final package: the primary Colab notebook lives next to revision/ (outside the git repository, see EXECUTION_GUIDE)
NOTEBOOKS = NOTEBOOKS + sorted(PKG.parent.glob("RUN_COMPLETE_FEDKGE_RESEARCH.ipynb")) + sorted((PKG / "colab").glob("*.ipynb"))


def _sources():
    for p in list(CORE.glob("*.py")) + SCRIPTS:
        yield p.name, p.read_text()
    for nb in NOTEBOOKS:
        cells = json.loads(nb.read_text())["cells"]
        yield nb.name, "\n".join("".join(c["source"]) for c in cells if c["cell_type"] == "code")


def test_notebooks_exist():
    names = {p.name for p in NOTEBOOKS}
    assert {"phase1_data.ipynb", "phase2_noniid.ipynb", "phase3_federated.ipynb", "phase4_dp.ipynb"} <= names


def test_no_old_result_literals():
    for name, src in _sources():
        code = re.sub(r"#.*", "", src)                      # comments may cite old numbers
        code = re.sub(r'"""[\s\S]*?"""', "", code)         # so may docstrings
        for lit in OLD_RESULT_LITERALS:
            assert not re.search(rf"(?<![\d.]){re.escape(lit)}(?!\d)", code), f"{name}: old result literal {lit}"


def test_no_forbidden_patterns():
    for name, src in _sources():
        code = re.sub(r"#.*", "", src)
        code = re.sub(r'"""[\s\S]*?"""', "", code)
        for pat, why in FORBIDDEN_PATTERNS:
            m = re.search(pat, code, flags=re.I)
            assert not m, f"{name}: {why}: {m.group(0) if m else ''}"


def test_no_silent_exception_fallbacks():
    """An except-block must not substitute a default value for a result (it must raise, log+raise, or skip a
    purely optional import)."""
    for p in CORE.glob("*.py"):
        src = p.read_text()
        for m in re.finditer(r"except[^\n]*:\n(\s+)([^\n]+)", src):
            body = m.group(2).strip()
            assert not re.match(r"(return|\w+\s*=)\s*[\d{\[]", body) or "info[" in body, f"{p.name}: fallback in except: {body}"
