> **Historical page (original package).** Thresholds of the revised study (tau with the B3 fallback, the G-B sanity gate, the D10 flag) are in FINAL_METHODOLOGY.md sections 7, 13 and 14. The current, frozen methodology is `13_documentation/FINAL_METHODOLOGY.md`; the execution procedure is `../EXECUTION_GUIDE.md` and the notebook `../RUN_COMPLETE_FEDKGE_RESEARCH.ipynb`. Kept unchanged below for the record.

# Operating points / thresholds in Phases 1–4 and how each is handled

Principle: every threshold-like parameter is either (a) fixed a priori with a stated reason, or (b) swept over an
a-priori range on all datasets × all seeds, with the **whole grid saved** and a **pre-registered, validation-only**
selection rule (`10_configs/selection_rules.yaml`). Test metrics are never read by a selection.

| Parameter | Where | Handling | Range / value | Rule |
|---|---|---|---|---|
| Clipping norm C | DP-SGD | **swept** (4B) | {0.25, 0.5, 1, 2, 4} (log-spaced, 16× span around the old C = 1) at ε* = 4, fixed σ | max mean validation MRR over seeds; ties → smaller C |
| Noise schedule shape & ρ | DP-SGD | **swept** (4C) | {linear, exponential, cosine} × ρ ∈ {0.25, 0.5}, plus fixed from 4B, all at ε* = 4, C = C_sel | max mean validation MRR; ties → fixed |
| Target ε* | accountant | **swept** (4D) | {1, 2, 4, 8} × {fixed, selected schedule} | not selected; ε* = 4 declared a priori as the operating point for later phases; full curve reported |
| δ | accountant | fixed a priori | 1e-6 (≪ 1/N for every client); 1e-5 also reported | — |
| σ update period | schedule | fixed a priori | every 5 rounds | design constant (exact accounting either way) |
| Expected DP batch B | DP-SGD | fixed a priori | 512 (same as non-DP batch) | — |
| R_max, eval period, patience | training | fixed a priori | 100, 5, 4 | ε is computed over executed rounds |
| Dirichlet α | partition | two settings, both reported | 1.0 and 0.1 (main) | not selected |
| Minimum client size | partition | fixed a priori | ≥ 20 % of mean client size and ≥ 1024 triples; re-draw until satisfied (attempts logged) | conditions the partition slightly towards balance (documented) |
| Legacy budget 15 / σ = 1 / C = 1 | replica & L1–L3 | reproduction only | old values | never used for new claims |

Thresholds of Phases 6–7 (trust τ, λ, Trimmed-Mean β, FLTrust root size, attack parameters) are documented in the
P5–P8 delivery; their rules will be *added* to `selection_rules.yaml` without editing the keys above.

## Completeness enforcement
`selection.select_clip / select_schedule` refuse to select unless every grid point has every tier seed. The
selection file stores the rule text, its SHA-256 and the full candidate table. A later rule change or a changed
selected value marks dependent runs `STALE_SELECTION`.
