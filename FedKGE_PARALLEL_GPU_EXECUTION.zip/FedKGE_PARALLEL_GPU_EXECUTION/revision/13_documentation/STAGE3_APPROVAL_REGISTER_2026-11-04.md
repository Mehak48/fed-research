# Stage 3 preparation — owner decision register (2026-11-04)

Status: methodology decisions B2–B5 approved by project owner; **GPU execution NOT authorized**.
This file records authorization only. It is not a claim that all agreed implementation changes have been completed, tested, or independently reproduced.

## Frozen decisions

- **B2 (budget):** reduced plan; 99 Stage 3 tuning runs, 756 Stage 4 main runs, 30 old-paper replications. Stage 5 postponed; prioritize essential hypotheses. Run Stage 3 before deciding the Stage 4 compute arrangements.
- **B3 (trust threshold tau):** when no candidate meets the honest-client false-positive-rate limit (<= 5%), use a deterministic controlled fallback with an explicit `rule not met` / constraint-violation flag and measured FPR. Validate the score/threshold monotonicity before choosing the implementation of fallback; keep the violated configurations in analysis. Calibration selection must use predefined data only.
- **B4 (V1):** remove the unstable client-size-group V1 backup *switch*; preserve the frozen primary trust rule. Retain descriptive FPR reporting for each client-size group.
- **B5 (methodology and reproducibility):** retain documented 25% DP utility review trigger, 95% clean-utility non-inferiority bound, and predeclared MIA settings, subject to correct statistical procedures and explicit privacy-scope qualifications. Preserve project folder layout. Create a local Git checkpoint before Stage 3.

## Research safeguards

1. A DP utility trigger must flag results, not silently initiate post-hoc tuning or change the privacy mechanism.
2. The non-inferiority claim requires a specified margin, a valid one-sided paired procedure, and multiplicity control where needed; a raw 95% metric ratio by itself is not proof.
3. Report per-run epsilon separately from the total privacy cost of data-reusing model selection; do not claim end-to-end DP without accounting for it.
4. Preserve attack threat model, splits, metrics, and MIA settings as predeclared, and report any departures.
5. Fully trained accuracy sanity check is a Stage 3 gating step; stop when it fails.
6. No GPU smoke, tuning, pilot, Stage 4, or Stage 5 training is authorized by these decisions.

## Work still required before Stage 3 GPU authorization

- Implement B3 fallback and explicit schema/reporting, with deterministic and boundary-condition regression tests.
- Remove B4 V1 switching from applicable workflow and configurations; preserve size-group diagnostics and regression coverage.
- Confirm B5 tests/configuration match exact documented statistical and MIA specifications.
- Run tests in the target environment; record package versions, outcomes, commit hash, and notebook behavior.
- Prepare the resumable Colab notebook with version checks and an up-front accuracy sanity gate, then obtain the owner's separate explicit permission to execute it.

## Checkpoint semantics

This Git commit captures the delivered Phase C package plus the owner's frozen decision register, **before** the B3/B4 code edits. It is not an implementation-complete Stage 3 release. There is no remote push.
