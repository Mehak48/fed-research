"""Per-example clipping must equal Opacus' per-sample gradients (including repeated entities inside one example);
noise must be dense; the DP trainer must be deterministic given the generator."""
import pytest
import torch

from fedkge.dp import add_gaussian_noise, dp_local_train, per_example_clipped_sum
from fedkge.model import margin_loss_per_example
from fedkge.sampling import sample_negatives

E, R, D, B, K = 12, 3, 5, 6, 4


def _batch(seed=0):
    g = torch.Generator().manual_seed(seed)
    h = torch.randint(0, E, (B,), generator=g); r = torch.randint(0, R, (B,), generator=g)
    t = torch.randint(0, E, (B,), generator=g)
    h[0] = t[0] = 3                                    # repeated entity inside one example
    nh, nt = sample_negatives(h, t, E, K, "correct", g)
    return h, r, t, nh, nt


@pytest.mark.parametrize("normalize", [True, False])
@pytest.mark.parametrize("clip", [0.05, 1.0, 100.0])
def test_matches_opacus(normalize, clip):
    opacus = pytest.importorskip("opacus")
    from opacus.grad_sample import GradSampleModule
    torch.manual_seed(0)

    class M(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.ent = torch.nn.Embedding(E, D); self.rel = torch.nn.Embedding(R, D)

        def forward(self, h, r, t, nh, nt):
            return margin_loss_per_example(self.ent(h), self.rel(r), self.ent(t), self.ent(nh), self.ent(nt), 1.0, normalize)

    m = M()
    ent0, rel0 = m.ent.weight.detach().clone(), m.rel.weight.detach().clone()
    gm = GradSampleModule(m, loss_reduction="sum")   # we differentiate the SUM of per-example losses
    h, r, t, nh, nt = _batch()
    gm(h, r, t, nh, nt).sum().backward()
    gs_e, gs_r = m.ent.weight.grad_sample, m.rel.weight.grad_sample        # (B,E,D), (B,R,D)
    norms = torch.sqrt((gs_e ** 2).sum((1, 2)) + (gs_r ** 2).sum((1, 2)))
    scale = torch.clamp(clip / (norms + 1e-6), max=1.0)
    ref_e = (gs_e * scale[:, None, None]).sum(0); ref_r = (gs_r * scale[:, None, None]).sum(0)
    Ge, Gr, our_norms, _ = per_example_clipped_sum(ent0, rel0, h, r, t, nh, nt, clip, 1.0, normalize)
    assert torch.allclose(our_norms, norms, atol=1e-5, rtol=1e-5)
    assert torch.allclose(Ge, ref_e, atol=1e-5) and torch.allclose(Gr, ref_r, atol=1e-5)


@pytest.mark.parametrize("normalize", [True, False])
def test_matches_bruteforce_per_example_autograd(normalize):
    torch.manual_seed(1)
    ent, rel = torch.randn(E, D), torch.randn(R, D)
    h, r, t, nh, nt = _batch(2)
    _, _, ours, _ = per_example_clipped_sum(ent, rel, h, r, t, nh, nt, 1.0, 1.0, normalize)
    for i in range(B):
        ee, rr = ent.clone().requires_grad_(), rel.clone().requires_grad_()
        l = margin_loss_per_example(ee[h[i:i + 1]], rr[r[i:i + 1]], ee[t[i:i + 1]], ee[nh[i:i + 1]], ee[nt[i:i + 1]],
                                    1.0, normalize).sum()
        ge, gr = torch.autograd.grad(l, [ee, rr])
        assert abs(float(torch.sqrt((ge ** 2).sum() + (gr ** 2).sum())) - float(ours[i])) < 1e-5


def test_each_example_norm_bounded():
    ent, rel = torch.randn(E, D) * 3, torch.randn(R, D) * 3
    h, r, t, nh, nt = _batch(1)
    for i in range(B):
        sl = slice(i, i + 1)
        Ge, Gr, _, _ = per_example_clipped_sum(ent, rel, h[sl], r[sl], t[sl], nh[sl], nt[sl], 0.1, 1.0, True)
        assert float(torch.sqrt((Ge ** 2).sum() + (Gr ** 2).sum())) <= 0.1 + 1e-6


def test_noise_is_dense_and_scaled():
    g = torch.Generator().manual_seed(0)
    G = add_gaussian_noise(torch.zeros(2000, 50), sigma=2.0, clip=0.5, gen=g)
    assert (G != 0).all()
    assert abs(float(G.std()) - 1.0) < 0.02                    # sigma * C = 1.0


def test_dp_trainer_deterministic():
    trip = torch.stack([torch.randint(0, E, (200,)), torch.randint(0, R, (200,)), torch.randint(0, E, (200,))], 1)
    p = {"ent": torch.randn(E, D), "rel": torch.randn(R, D)}
    tc = {"lr": 1e-2, "neg_samples": 4, "neg_mode": "correct"}
    a, sa = dp_local_train(p, trip, E, tc, True, 1.0, 1.0, 1.0, 5, 0.1, 20.0, torch.Generator().manual_seed(7))
    b, sb = dp_local_train(p, trip, E, tc, True, 1.0, 1.0, 1.0, 5, 0.1, 20.0, torch.Generator().manual_seed(7))
    assert torch.equal(a["ent"], b["ent"]) and sa == sb
    assert not torch.equal(a["ent"], p["ent"])
