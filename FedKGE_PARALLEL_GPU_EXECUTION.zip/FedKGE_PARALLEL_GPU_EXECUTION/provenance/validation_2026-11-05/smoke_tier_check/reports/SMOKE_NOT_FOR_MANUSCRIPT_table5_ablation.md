# Table 5 — ablation study

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| system | dataset | block | test.mrr | test.hits@10 |
|---|---|---|---|---|
| Complete method (DP + trust + integrity, s*) | FB15k-237 | R1p | 0.005 (n=1) | 0.007 (n=1) |
| - noise schedule (fixed sigma) | FB15k-237 | R1q | 0.005 (n=1) | 0.007 (n=1) |
| - trust (DP-FedAvg, s*) | FB15k-237 | DP2 | 0.005 (n=1) | 0.007 (n=1) |
| - DP (trust only, non-private) | FB15k-237 | R5 | 0.005 (n=1) | 0.007 (n=1) |
| - integrity verification (complete method, off) | FB15k-237 | I1 | 0.005 (n=1) | 0.007 (n=1) |
| DP training settings only (no clipping, no noise) | FB15k-237 | DP3 | 0.005 (n=1) | 0.008 (n=1) |
| DP training settings + clipping only | FB15k-237 | DP3 | 0.005 (n=1) | 0.008 (n=1) |
| Complete method (DP + trust + integrity, s*) | WN18RR | R1p | 0.001 (n=1) | 0.003 (n=1) |
| - noise schedule (fixed sigma) | WN18RR | R1q | 0.001 (n=1) | 0.003 (n=1) |
| - trust (DP-FedAvg, s*) | WN18RR | DP2 | 0.001 (n=1) | 0.003 (n=1) |
| - DP (trust only, non-private) | WN18RR | R5 | 0.001 (n=1) | 0.003 (n=1) |
| - integrity verification (complete method, off) | WN18RR | I1 | 0.001 (n=1) | 0.003 (n=1) |
| DP training settings only (no clipping, no noise) | WN18RR | DP3 | 0.001 (n=1) | 0.003 (n=1) |
| DP training settings + clipping only | WN18RR | DP3 | 0.001 (n=1) | 0.003 (n=1) |
| Complete method (DP + trust + integrity, s*) | CoDEx-M | R1p | 0.002 (n=1) | 0.003 (n=1) |
| - noise schedule (fixed sigma) | CoDEx-M | R1q | 0.002 (n=1) | 0.003 (n=1) |
| - trust (DP-FedAvg, s*) | CoDEx-M | DP2 | 0.002 (n=1) | 0.003 (n=1) |
| - DP (trust only, non-private) | CoDEx-M | R5 | 0.002 (n=1) | 0.003 (n=1) |
| - integrity verification (complete method, off) | CoDEx-M | I1 | 0.002 (n=1) | 0.003 (n=1) |
| DP training settings only (no clipping, no noise) | CoDEx-M | DP3 | 0.002 (n=1) | 0.003 (n=1) |
| DP training settings + clipping only | CoDEx-M | DP3 | 0.002 (n=1) | 0.003 (n=1) |
