# Researcher 2 — dataset `wn18rr`

**Project:** Privacy-Preserving Federated Knowledge Graph Embedding (revised study). This kit is one of three. Researcher 1 runs `fb15k237`, Researcher 2 runs `wn18rr`, Researcher 3 runs `codex_m` and merges everything.

> **You can start now. You need nothing from the other two researchers, and they need nothing from you** until the end, when you send one export file to Researcher 3.
> The methodology is frozen and identical in the three kits: same code commit, same frozen run list, same partitions, seeds, privacy parameters, trust settings and evaluation. Every notebook checks this before it runs.

## 1. Your work

- **16 unit notebooks**, at most **285 runs**, at most **38.5 T4 GPU-hours**.
- The hours are **upper bounds** from the T4 pilot of 2026-11-04 (old kernel, one process per GPU). This package has a faster kernel and can share the GPU between two processes, but **neither was timed on a T4**. Real hours should be lower; nobody knows yet by how much. Each notebook records its real time.

| Order | Notebook | What it runs | Runs (max) | T4 hours (upper bound) | Needs first | Writes |
|---|---|---|---|---|---|---|
| 1 | `U02_TUNE_wn18rr.ipynb` | Stage-3 tuning, selections, freeze | 33 | 4.39 | only the setup | `RESULT_U02.zip`, `SETTINGS_wn18rr.zip` |
| 2 | `U06_MAIN_wn18rr.ipynb` | Stage 4, priority 1 (timing reference) — blocks N2, R1p | 10 | 1.32 | `U02_TUNE_wn18rr.ipynb` finished | `RESULT_U06.zip` |
| 3 | `U07_MAIN_wn18rr.ipynb` | Stage 4, priority 1 — blocks DP1, DP2, N1 | 15 | 1.75 | `U02_TUNE_wn18rr.ipynb` finished | `RESULT_U07.zip` |
| 4 | `U14_MAIN_wn18rr.ipynb` | Stage 4, priority 2 — blocks R2, R3 | 20 | 2.80 | `U02_TUNE_wn18rr.ipynb` finished | `RESULT_U14.zip` |
| 5 | `U15_MAIN_wn18rr.ipynb` | Stage 4, priority 2 — blocks R2, R3 | 20 | 2.80 | `U02_TUNE_wn18rr.ipynb` finished | `RESULT_U15.zip` |
| 6 | `U16_MAIN_wn18rr.ipynb` | Stage 4, priority 2 — blocks R2, R3 | 20 | 2.80 | `U02_TUNE_wn18rr.ipynb` finished | `RESULT_U16.zip` |
| 7 | `U17_MAIN_wn18rr.ipynb` | Stage 4, priority 2 — blocks R2a, R3a | 10 | 1.40 | `U02_TUNE_wn18rr.ipynb` finished | `RESULT_U17.zip` |
| 8 | `U22_MAIN_wn18rr.ipynb` | Stage 4, priority 3 — blocks M1 | 20 | 2.72 | `U02_TUNE_wn18rr.ipynb` finished | `RESULT_U22.zip` |
| 9 | `U27_MAIN_wn18rr.ipynb` | Stage 4, priority 5 — blocks R1q | 5 | 0.70 | `U02_TUNE_wn18rr.ipynb` finished | `RESULT_U27.zip` |
| 10 | `U33_MAIN_wn18rr.ipynb` | Stage 4, priority 6 — blocks R1, R4, R5 | 20 | 2.74 | `U02_TUNE_wn18rr.ipynb` finished | `RESULT_U33.zip` |
| 11 | `U34_MAIN_wn18rr.ipynb` | Stage 4, priority 6 — blocks R1, R4, R5 | 20 | 2.74 | `U02_TUNE_wn18rr.ipynb` finished | `RESULT_U34.zip` |
| 12 | `U35_MAIN_wn18rr.ipynb` | Stage 4, priority 6 — blocks R1, R4, R5 | 22 | 2.95 | `U02_TUNE_wn18rr.ipynb` finished | `RESULT_U35.zip` |
| 13 | `U36_MAIN_wn18rr.ipynb` | Stage 4, priority 6 — blocks R1, R4, R5, R5a | 22 | 2.95 | `U02_TUNE_wn18rr.ipynb` finished | `RESULT_U36.zip` |
| 14 | `U44_MAIN_wn18rr.ipynb` | Stage 4, priority 7 (timing reference) — blocks I1 | 6 | 0.79 | `U02_TUNE_wn18rr.ipynb` finished | `RESULT_U44.zip` |
| 15 | `U45_MAIN_wn18rr.ipynb` | Stage 4, priority 7 — blocks DP1, DP3, I2, N3 | 21 | 2.83 | `U02_TUNE_wn18rr.ipynb` finished | `RESULT_U45.zip` |
| 16 | `U46_MAIN_wn18rr.ipynb` | Stage 4, priority 7 — blocks DP1, DP3, I2, N3 | 21 | 2.81 | `U02_TUNE_wn18rr.ipynb` finished | `RESULT_U46.zip` |

## 2. Execution order

1. `00_SETUP_ONCE_PER_ACCOUNT.ipynb` — once, CPU, a few minutes.
2. `01_OPTIONAL_T4_BENCHMARK.ipynb` — optional, T4, about 3 minutes by design (not yet timed on a T4). It measures the new kernel and GPU sharing on your T4.
3. `U02_TUNE_wn18rr.ipynb` — **must finish first.** It tunes `wn18rr`, makes the pre-registered selections, and writes `SETTINGS_wn18rr.zip`. All your Stage-4 notebooks need this file. They find it by themselves in the same account.
4. `U06_MAIN_wn18rr.ipynb` … `U46_MAIN_wn18rr.ipynb` — the 15 Stage-4 notebooks, **in the order of the table** (the order follows the approved priorities: hypothesis-critical runs first). Any order gives the same results.
5. `99_EXPORT_RESULTS_Researcher_2.ipynb` — CPU, about a minute. It writes the one file you send to Researcher 3.

**Sequential or simultaneous?**

- **Dependent:** every Stage-4 notebook depends on `U02_TUNE_wn18rr.ipynb`. This dependency is part of the method (Stage 4 uses the tuned values) and cannot be removed.
- **Independent of each other:** all Stage-4 notebooks. They may run one after another, or at the same time in different GPU sessions if you have them.
- **Never** run the same notebook in two sessions at the same time.
- Free Colab normally gives one GPU session at a time, so plan for one notebook after another.
- You do **not** depend on Researcher 1 or 3.
- U06, U44 always use one process on the GPU: their per-round times feed the integrity-overhead table.

## 3. Run it in Google Colab

1. In Google Drive, create the folder `MyDrive/FedKGE_T4/` and upload `FedKGE_T4_INDEPENDENT.zip` from this kit into it. **Do not unzip it and do not rename it.**
2. Open https://colab.research.google.com → File → Upload notebook → choose a notebook from the `notebooks/` folder of this kit.
3. For the unit notebooks and the benchmark: Runtime → Change runtime type → **T4 GPU**. Setup, export run on the CPU.
4. Runtime → **Run all**. Allow access to Google Drive when Colab asks. The notebook mounts Drive at `/content/drive` by itself.
5. Only the setup notebook needs editing: read the licence terms it prints, set the licence flag(s) to `True`, write who confirmed, and run it again. No other notebook needs editing. All paths are already set (`BASE = "/content/drive/MyDrive/FedKGE_T4"`).

**What is installed and checked automatically (setup cell of every notebook)**

- Python 3.10–3.13 and Colab's own PyTorch (not replaced).
- Pinned packages: numpy 2.5.3, scipy 1.18.1, pandas 3.0.5, PyYAML 6.0.3, jsonschema 4.26.0, matplotlib 3.11.2, dp-accounting 0.6.0, prv-accountant 0.2.0, opacus 1.6.0, pytest 9.1.1.
- The code commit, a clean code tree, the core code hash, the frozen run list and the unit plan. A changed or wrong zip is refused.
- **Dataset:** `wn18rr` is downloaded by the setup notebook after the licence confirmation and checked against pinned SHA-256 values. Dataset files never leave your account.
- **GPU:** NVIDIA T4. Use the same GPU type for all your notebooks (section 6).

## 4. If a session stops

Open the **same notebook** again and Run all. That is the whole recovery.

- Finished runs are kept and never run twice.
- An interrupted run resumes from its checkpoint: model, optimizer, privacy accountant, trust state and random-number states.
- The last line of the run cell tells you the state: `UNIT COMPLETE`, `PAUSED` (run again), `some runs FAILED` (run again; they are retried).
- `ACCURACY GATE G-B FAILED` in the tuning notebook means the protocol stops `wn18rr`. Do not run its Stage-4 notebooks; tell Researcher 3.

## 5. Where everything is saved (the same in the three kits)

```
MyDrive/FedKGE_T4/
├── FedKGE_T4_INDEPENDENT.zip     the package (code, configurations, frozen run list)
├── data_cache/                   your copy of the dataset (never shared)
├── units/Uxx/                    working folder of unit Uxx: every run, checkpoints, logs
├── results/RESULT_Uxx.zip        the finished result of unit Uxx
├── results/SETTINGS_wn18rr.zip   the tuned settings (written by the tuning notebook)
├── export/RESULTS_Researcher_2.zip   THE FILE YOU SEND
├── inbox/                        files you receive
└── benchmarks/                   output of the optional benchmark
```

**What a unit result contains.** For every run: `config.json`, `status.json`, `final.json` (metrics), `rounds.csv`, `accountant.json` (privacy), `trust_rounds.csv`, `weights_rounds.csv`, `attack.json`, `integrity.json`, `per_relation_test_mrr.json`, `env.json`, `log.txt`, and `final_weights.pt` where the protocol keeps the final model. Plus the job logs, the environment record and the unit record (processes used, sessions, hours). Every file is covered by SHA-256.

**What you must keep.** Keep the whole `MyDrive/FedKGE_T4/` folder until the paper is finished. Round checkpoints stay in `units/` and are not sent. Never edit, rename or delete files inside it by hand.

## 6. Rules that protect the results

- **One environment for your dataset.** The merge accepts one combination of GPU model, torch build, CUDA and Python version for tuning and one for Stage 4 of a dataset. Colab updates its image from time to time, so finish your Stage-4 notebooks within a short period, and always choose the T4. The setup cell prints these values. A mismatch is refused and reported, never mixed.
- **One account for a unit.** Resume a unit in the account where it started.
- **Colab's rules.** Colab does not allow several accounts to be used to get around its limits. Each researcher uses the account they are entitled to use.
- **Nothing is invented.** A missing run stays missing in every table.

## 7. What to send to Researcher 3

1. Run `99_EXPORT_RESULTS_Researcher_2.ipynb`. It prints a table: every unit must say **COMPLETE**.
2. Send **exactly one file**: `MyDrive/FedKGE_T4/export/RESULTS_Researcher_2.zip`. The notebook also downloads it through the browser.
3. The file can be large (final model weights of some runs are inside), so a Google Drive share link is the practical way.
4. Do not unzip or rename it. If you finish more notebooks later, run the export again and send the new file; the integration keeps each unit once.

You can also send a **partial** export at any time. Unfinished units are marked as unfinished; nothing is filled in.

## 8. If you finish early

You may help another researcher with Stage-4 notebooks of their dataset. This creates a real dependency, so do it only like this:

1. Get the notebook file and `SETTINGS_<their dataset>.zip` from them. Put the settings file into your `MyDrive/FedKGE_T4/inbox/`.
2. Compare the line the setup cell prints (GPU name, torch, CUDA build, Python). It must be **identical** to theirs. If not, do not help: the merge would refuse the mixed dataset.
3. Run the setup notebook once more with their dataset's licence flag (edit `DATASETS` and `LICENCE_CONFIRMED` in its first cell).
4. Tell them, so that they do not run the same notebook. Your export then contains that unit as well.

## 9. Hours of the three kits (upper bounds)

| Researcher | Dataset | Unit notebooks | Runs (max) | T4 GPU-hours (upper bound) |
|---|---|---|---|---|
| 1 | fb15k237 | 18 | 315 | 45.1 |
| 2 (you) | wn18rr | 16 | 285 | 38.5 |
| 3 | codex_m | 15 | 285 | 35.3 |
| **Total** | | **49** | **885** | **118.9** |

The split is by dataset, so the hours are close but not equal. An equal split would send one dataset's Stage-4 runs to two people. They would then wait for each other's tuning and would have to prove identical environments.

More detail: `DEPENDENCY_AND_EXECUTION_TABLE.md` in this kit; the package's own `README.md` and `T4_OPTIMISATION_REPORT.md` inside the package zip.
