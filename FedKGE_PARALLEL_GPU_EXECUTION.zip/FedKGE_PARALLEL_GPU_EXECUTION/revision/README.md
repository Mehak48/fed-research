# FedKGE revision — the code (complete executable methodology)

Federated TransE on FB15k-237, WN18RR and CoDEx-M with:

- triple-level DP per client (zero-out adjacency, RDP accounting with PLD and PRV cross-checks);
- trust-weighted aggregation (the frozen rule; variant V1 removed by B4) and robust baselines;
- seven poisoning attacks;
- SHA-256 integrity verification in the data path (**not** a poisoning defence; **no IPFS**);
- a membership-inference audit.

**Method:** `13_documentation/FINAL_METHODOLOGY.md`. **How to run it:** `../EXECUTION_GUIDE.md` (Colab: `../RUN_COMPLETE_FEDKGE_RESEARCH.ipynb`); on several GPUs at once: `../PARALLEL_EXECUTION_GUIDE.md`.

> **Status (2026-11-05): ready for execution; no research result exists yet.** Stage 3 (tuning) and Stage 4 (main experiments) have not run. Every smoke, pilot and fixture output is a software check, never evidence.

## Layout (the approved layout, B5)

```
01_fedkge_core/fedkge/    the package. Result-determining modules are hashed into every run (io.RESULT_MODULES);
                          analysis modules are hashed separately (gates, manifest, selection, hypotheses, paper,
                          figures, draft, reporting, context, fixtures, stats, analysis, runner, ...)
10_configs/               base.yaml, datasets/, tiers/, matrices/ (tune = Stage 3, confirm = Stage 4, p3/p4 = legacy),
                          selection_rules.yaml, gates.yaml, hypotheses.yaml, manifest/FROZEN_MANIFEST.* (the 885 runs)
11_experiment_schemas/    JSON schemas of every output
12_validation_tests/      pytest suite (legacy + Phase C + final-package tests)
13_documentation/         FINAL_METHODOLOGY.md, DP_MECHANISM.md, THREAT_MODEL.md, the approval register; older pages
                          are marked historical
scripts/                  entry points (below)
parallel/                 parallel GPU execution layer (2026-11-07): fedkge_parallel/ shared modules, phases/ entry
                          points 00-11, tests/, tools/; adds no methodology (../PARALLEL_ARCHITECTURE.md)
colab/                    make_notebook.py (writes ../RUN_COMPLETE_FEDKGE_RESEARCH.ipynb), make_parallel_notebooks.py
                          (writes ../FEDKGE_PARALLEL_WORKER.ipynb and ../FEDKGE_PARALLEL_MASTER.ipynb), the pilot notebook
02_ ... 09_               original Phase 1-4 notebooks (kept; superseded)
```

## Setup

```bash
python3 -m venv ../.venv && . ../.venv/bin/activate          # Python 3.10-3.13 (tested: 3.13)
pip install -r requirements-phaseC.txt                        # exact versions; on Colab keep the platform torch
```

The results root is `--results DIR` or `$FEDKGE_RESULTS` (default `results/phaseC/`). Use **one results root per environment**: a CPU root and a GPU root must never be mixed.

## Commands, in the required order

```bash
# 0. checks (every session)
python scripts/run_tests.py --name <label>                      # full test suite -> test_reports/summary_<label>.json
python scripts/build_manifest.py --check                        # configs + core code == the frozen manifest

# 1. data (licence-gated; the bytes must match the pinned SHA-256 values)
python scripts/prepare_data.py --dataset fb15k237 --data-dir ../data_cache                  # prints the terms only
python scripts/prepare_data.py --dataset fb15k237 --data-dir ../data_cache --i-confirm-licence --operator-note "who, when"
python scripts/build_artifacts.py --tier tune  --datasets fb15k237 wn18rr codex_m --data-dir ../data_cache --seeds 1001 --alphas 0.1 --central
python scripts/build_artifacts.py --tier final --datasets fb15k237 wn18rr codex_m --data-dir ../data_cache --seeds 42 123 256 512 1024 --alphas 0.1 --central

# 2. Stage 3: gate G-B first (stage 0), then the tuning chain (99 runs)
python scripts/run_plan.py --plan tune --tier tune --datasets fb15k237 wn18rr codex_m --device cuda --stages 0
python scripts/run_plan.py --plan tune --tier tune --datasets fb15k237 wn18rr codex_m --device cuda [--max-hours 10]

# 3. gate G-C
python scripts/freeze_selections.py

# 4. Stage 4 in priority order (756 runs) + legacy replicas (30 runs, priority 4)
python scripts/run_plan.py --plan confirm --tier final --datasets fb15k237 wn18rr codex_m --device cuda --priorities 1
python scripts/run_plan.py --plan confirm --tier final --datasets fb15k237 wn18rr codex_m --device cuda --priorities 2
python scripts/run_plan.py --plan confirm --tier final --datasets fb15k237 wn18rr codex_m --device cuda --priorities 3
python scripts/run_legacy_blocks.py --tier final --device cuda
python scripts/run_plan.py --plan confirm --tier final --datasets fb15k237 wn18rr codex_m --device cuda --priorities 5 6 7
python scripts/legacy_l0_eval.py --checkpoint /path/to/global_transe_final.pt --tier final   # optional (L0)

# 5. progress, analysis, figures, report, export (safe at any time; missing values stay PENDING)
python scripts/status.py --show-failed
python scripts/build_report.py --tier final --with-figures      # = analyze_results.py + make_figures.py + tables + draft
python scripts/export_artifacts.py
```

**Exit codes** of `run_plan.py` and `run_legacy_blocks.py`:

| Code | Meaning | What to do |
|---|---|---|
| 0 | complete | — |
| 1 | a run failed | see `status.py --show-failed`; the next call retries it |
| 3 | session budget reached | rerun the same command |
| 4 | gate G-B failed | stop; follow `tune/gates/SANITY_GATE_REPORT.md` |
| 5 | environment mismatch | see `../EXECUTION_GUIDE.md` |
| 6 | manifest mismatch | the configs or code changed after the freeze |

**Software checks** (never evidence; outputs are watermarked):

```bash
python scripts/run_plan.py --plan tune --tier smoke --datasets fb15k237 wn18rr codex_m
python scripts/run_plan.py --plan confirm --tier smoke --datasets fb15k237 wn18rr codex_m
python scripts/run_legacy_blocks.py --tier smoke
python scripts/validate_outputs.py --tier smoke
python scripts/build_report.py --tier smoke --with-figures
python scripts/build_report.py --fixture --out /tmp/fixture_check --with-figures     # labelled random numbers
```

## Rules the code enforces

- **Selection:**
  - selection reads validation data only, and the final tier refuses to select;
  - the τ rule has the pre-declared fallback B3 and is never extended;
  - selections are frozen append-only.
- **Gates:**
  - gate G-B runs before any other tuning stage and stops Stage 3 if it fails;
  - D10 is a flag only.
- **The approved schedule:**
  - the frozen manifest must match the configs and code;
  - every executed entry must be a manifest cell;
  - Stage 5 and the full profile are refused (B2).
- **Environment:** one environment per (tier, dataset), via the environment lock.
- **Data:**
  - synthetic data are refused on the tune and final tiers;
  - warm starts are refused;
  - V1 settings are refused (B4).
- **Runs:**
  - stale runs are archived, never deleted;
  - a forced rerun keeps the earlier folder (PC-6);
  - checkpoints are atomic, and interrupted runs resume;
  - failed runs keep their tracebacks;
  - completion is derived from the run folders.
- **Reporting:**
  - tables, figures and the draft use recorded runs only; missing values are shown as PENDING;
  - fixture and smoke outputs are watermarked.
