"""Execution-equivalence of the engineering optimisations (directive 2026-11-05, section 5) and the structure of the
mandatory notebook path (section 4). Software checks only: no research result is produced or used here."""
from __future__ import annotations

import ast
import importlib.util
import json
import struct
from pathlib import Path

import numpy as np
import pytest
import torch

from fedkge.integrity import IntegrityLayer, deserialize, object_id, parse, serialize

REPO = Path(__file__).resolve().parents[1]


# ----------------------------------------------------------------------------------------------- integrity fast path
def _serialize_reference(t: torch.Tensor, meta) -> bytes:
    """The implementation before the optimisation (two copies of the payload), kept verbatim as the reference."""
    arr = t.detach().to("cpu", torch.float32).contiguous().numpy().astype("<f4", copy=False)
    header = json.dumps({"dtype": "float32-le", "shape": list(arr.shape), **meta}, sort_keys=True).encode()
    return struct.pack("<I", len(header)) + header + arr.tobytes()


def _parse_reference(data: bytes):
    hl = struct.unpack("<I", data[:4])[0]
    header = json.loads(data[4:4 + hl])
    shape = [int(x) for x in header["shape"]]
    payload = data[4 + hl:]
    if len(payload) != 4 * int(np.prod(shape)):
        raise ValueError("payload size does not match the header shape")
    return header, np.frombuffer(payload, dtype="<f4").reshape(shape)


SHAPES = [(40943, 100), (14541, 100), (237, 100), (7,), (), (2, 0), (3, 1, 4)]


@pytest.mark.parametrize("shape", SHAPES)
def test_integrity_fast_path_is_byte_identical(shape):
    g = torch.Generator().manual_seed(7)
    t = torch.randn(shape, generator=g) if int(np.prod(shape)) else torch.zeros(shape)
    for meta in ({"name": "client3", "round": 17}, {"name": "global", "round": 1}):
        new, ref = serialize(t, meta), _serialize_reference(t, meta)
        assert new == ref                                   # same bytes ...
        assert object_id(new) == object_id(ref)             # ... so the same SHA-256 identifiers and manifest chain
        h_new, a_new = parse(new); h_ref, a_ref = _parse_reference(ref)
        assert h_new == h_ref and a_new.shape == a_ref.shape and np.array_equal(a_new, a_ref)
        assert not a_new.flags.writeable                    # a view on the received bytes, as before
        assert np.array_equal(deserialize(new), t.numpy())


def test_integrity_fast_path_non_contiguous_and_non_float32_inputs():
    t = torch.randn(30, 20, dtype=torch.float64).t()        # non-contiguous float64
    assert serialize(t, {"name": "x", "round": 1}) == _serialize_reference(t, {"name": "x", "round": 1})


def test_parse_still_rejects_malformed_and_truncated_objects():
    data = serialize(torch.randn(4, 5), {"name": "x", "round": 1})
    for bad in (data[:-1], data + b"\0", data[:3], struct.pack("<I", 10 ** 6) + data[4:]):
        with pytest.raises(ValueError):
            parse(bad)


def test_received_tensor_is_fresh_verified_and_corruption_is_still_caught():
    layer = IntegrityLayer("hash_only")
    layer.begin_round(1)
    x = torch.randn(50, 8)
    env = layer.send("client0", 1, x)
    y, rec = layer.receive(env, "server")
    assert rec.accepted and torch.equal(x, y)
    y += 1.0                                                # writable and independent of the stored bytes
    y2, _ = layer.receive(env, "server2")
    assert torch.equal(x, y2)
    layer.end_round()
    bad = IntegrityLayer("hash_only", corrupt_p=1.0, rng=np.random.default_rng(3))
    bad.begin_round(1)
    env = bad.send("client0", 1, x)
    z, rec = bad.receive(env, "server")
    assert z is None and not rec.accepted and rec.reason == "hash mismatch"
    bad.end_round()


# ----------------------------------------------------------------------------------------------- mandatory notebook path
def _notebook():
    spec = importlib.util.spec_from_file_location("make_notebook", REPO / "colab" / "make_notebook.py")
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod.build("0" * 40, "a" * 64, "b" * 64)


def test_notebook_cells_are_valid_python_and_follow_the_nine_steps():
    nb = _notebook()
    code = ["".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "code"]
    for src in code:
        ast.parse(src)                                      # syntactically valid
    md = ["".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "markdown"]
    order = [next((i for i, m in enumerate(md) if m.lstrip("# ").startswith(f"Step {k} ")), None) for k in range(1, 10)]
    assert None not in order and order == sorted(order), order


def test_mandatory_path_runs_no_cpu_test_training_and_no_smoke_or_pilot_tier():
    nb = _notebook()
    cells = [(c["cell_type"], "".join(c["source"])) for c in nb["cells"]]
    settings = next(src for kind, src in cells if kind == "code")
    assert 'TUNE_TIER, FINAL_TIER, DEVICE, REQUIRE_GPU = "tune", "final", "cuda", True' in settings
    assert "RUN_CPU_CHECKS = False" in settings
    code = [src for kind, src in cells if kind == "code"]
    test_cells = [src for src in code if "scripts/run_tests.py" in src]
    assert len(test_cells) == 1 and test_cells[0].lstrip().startswith("if RUN_CPU_CHECKS")
    assert code.index(test_cells[0]) == len(code) - 1      # an appendix cell after the export, never on the main path
    joined = "\n".join(code)
    for removed in ("pilot.py", "--tier smoke", '"smoke"', "stop_after_rounds", "timing pilot"):
        assert removed not in joined


def test_sanity_gate_is_the_only_preliminary_training_and_precedes_tuning():
    nb = _notebook()
    code = ["".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "code"]
    runs = [i for i, s in enumerate(code) if "scripts/run_plan.py" in s or "scripts/run_legacy_blocks.py" in s]
    gate = next(i for i in runs if '"--stages", "0"' in code[i])
    assert gate == runs[0]                                  # the first training the notebook starts is gate G-B
    assert "GATE G-B FAILED" in code[gate] and "raise SystemExit" in code[gate]
