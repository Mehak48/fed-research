#!/usr/bin/env python3
"""Phase B PLANNING: proposed experiment matrix, run counts, and an assumption-based compute/storage estimate.

Nothing here runs an experiment. Every count is derived from the block definitions below; every time estimate is
derived from the explicit cost assumptions in PARAMS (two bounds, LOW and HIGH), anchored on the one real timing we
have for the original trainer (legacy Phase 3: 1,204.4 s for 50 rounds x 3 local epochs on FB15k-237 on the
user's Colab GPU, GPU model not recorded). Labels: [Calculated - Phase B planning]. The Stage-2 pilot replaces these
assumptions with measured seconds-per-round (the revision package already has runner.estimate for that).

The cost bounds were chosen with that single measurement in view, so it is a consistency check, not a validation.

Two profiles
  full     headline hypothesis blocks with 10 seeds (S10); other hypothesis blocks with 5; descriptive blocks with 3-5
  reduced  every hypothesis block with 5 seeds (S5); descriptive blocks with 3; smaller sensitivity grids

Outputs (paths given on the command line)
  experiment_matrix.csv   one row per block: purpose, factors, seeds, run counts (full and reduced), table/claim mapping
  run_counts.csv          runs and GPU-hours per profile / third dataset / stage / tier
  cost_estimate.csv       GPU-hours LOW/HIGH per block, profile and third-dataset option (CoDEx-M or YAGO3-10)
  per_run_time_estimate.csv  minutes per run by dataset and training mode
  storage_estimate.csv    persistent storage per profile (run records + kept final weights)
  priority_cost.csv       runs and GPU-hours per Stage-4 priority group, with cumulative totals (07 section 6)
  experiment_matrix_draft.yaml  machine-readable draft for Phase C (NOT a runnable config of the revision package)
"""
from __future__ import annotations

import argparse
import csv
import sys

import yaml

# ----------------------------------------------------------------------------------------------- datasets
# Planning constants (verified sources in 04_dataset_benchmark.md). P = (entities + relations) * d.
DIM, K = 100, 10
DS = {
    "FB": {"name": "fb15k237", "n_train": 272_115, "n_ent": 14_505, "n_rel": 237, "n_valid": 17_535, "n_test": 20_466},
    "WN": {"name": "wn18rr", "n_train": 86_835, "n_ent": 40_943, "n_rel": 11, "n_valid": 3_034, "n_test": 3_134},
    "CX": {"name": "codex_m", "n_train": 185_584, "n_ent": 17_050, "n_rel": 51, "n_valid": 10_310, "n_test": 10_311},
    "YG": {"name": "yago310", "n_train": 1_079_040, "n_ent": 123_182, "n_rel": 37, "n_valid": 5_000, "n_test": 5_000},
    # candidates listed in 04 (per-run estimates only; never part of the matrix totals)
    "CL": {"name": "codex_l", "n_train": 551_193, "n_ent": 77_951, "n_rel": 69, "n_valid": 30_622, "n_test": 30_622},
    "CS": {"name": "codex_s", "n_train": 32_888, "n_ent": 2_034, "n_rel": 42, "n_valid": 1_827, "n_test": 1_828},
}
for d in DS.values():
    d["P"] = (d["n_ent"] + d["n_rel"]) * DIM

# ----------------------------------------------------------------------------------------------- seeds
SEEDS = {
    "S_TUNE": [1001],                                   # tuning / selection only (never reported as evidence)
    "S1": [42],
    "S3": [42, 123, 256],                               # sensitivity blocks (subset of S5 -> still paired)
    "S5": [42, 123, 256, 512, 1024],                    # roadmap seeds; main blocks
    "S10": [42, 123, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768],   # headline comparisons
    "S10x": [2048, 4096, 8192, 16384, 32768],           # the 5 extra headline seeds (completes S10 for S5 blocks)
}

# ----------------------------------------------------------------------------------------------- blocks
# cells = distinct configurations per dataset (excluding seeds). datasets: ALL3 (FB, WN, third) or FB only.
# mode drives the cost model: np_fed | np_central | dp_fed | dp_fedA | legacy_p3 | legacy_p4 | dp_legacy | eval_only
# extra: robust (sort-based aggregator), adaptive (81-point attacker search per round)
# red: overrides for the REDUCED profile ({} = same as full; "drop" = not run)
# "complete method" = DP at eps*=4 with the selected sampling design (D11), rate q*, clip C*, lr*, rounds R* and
#                     schedule s* + the proposed trust aggregation (frozen rule, D15 variant if triggered, tau*)
#                     + integrity verification in the data path.
B = []


def block(**kw):
    kw.setdefault("extra", "")
    kw.setdefault("datasets", "ALL3")
    kw.setdefault("tier", "core")
    kw.setdefault("rounds", 100)
    kw.setdefault("red", {})
    kw.setdefault("keep_weights", 0)   # 1 = keep final weights of every cell; 0 < x < 1 = only the eps*=4 cell
    B.append(kw)


# ---------- Stage 2: pilot / dev gate (1 seed). Timings, sanity, first look at DP utility.
block(id="P2.1", stage=2, name="pilot_nonprivate_reference", cells=2, seeds="S_TUNE", mode="np_fed", rounds=60,
      factors="centralised + FedAvg(alpha=0.1); revision defaults (lr 1e-3, B 512)",
      answers="seconds/round, memory, non-private sanity range", tables="11", claims="-")
block(id="P2.2", stage=2, name="pilot_dp_revision_default", cells=1, seeds="S_TUNE", mode="dp_fedA",
      factors="DP eps*=4, fixed sigma, design A (B=512, per-client sigma), C=1, lr 1e-3, R=100",
      answers="DP seconds/round; first look at DP utility with the revision's settings", tables="11", claims="-")
block(id="P2.3", stage=2, name="pilot_dp_common_rate", cells=2, seeds="S_TUNE", mode="dp_fed", datasets="FB",
      factors="DP eps*=4, design Q (common sampling rate) q in {0.02, 0.10}", answers="design A vs Q on FB",
      tables="11", claims="-")

# ---------- Stage 3: tuning / selection (validation metrics only; pre-registered rules; tuning seed only)
block(id="T1", stage=3, name="tune_nonprivate_optimizer", cells=12, seeds="S_TUNE", mode="np_fed", rounds=60,
      factors="{centralised, FedAvg alpha=0.1} x lr{1e-3,3e-3,1e-2} x B{512,4096}",
      answers="fair non-private settings (same tuning budget as DP)", tables="8", claims="H1 reference")
block(id="T2a", stage=3, name="tune_dp_rate_lr", cells=9, seeds="S_TUNE", mode="dp_fed",
      factors="eps*=4 fixed sigma; q{0.02,0.05,0.10} x lr{1e-3,3e-3,1e-2}; C=1; FedAvg alpha=0.1",
      answers="main legitimate DP-utility levers (sampling rate / batch, learning rate)", tables="8", claims="-")
block(id="T2b", stage=3, name="tune_dp_clip", cells=4, seeds="S_TUNE", mode="dp_fed",
      factors="C{0.25,0.5,2,4} at the selected (q, lr) (C=1 comes from T2a)", answers="clipping threshold",
      tables="8", claims="-")
block(id="T2c", stage=3, name="tune_dp_rounds", cells=1, seeds="S_TUNE", mode="dp_fed", rounds=50,
      factors="R=50 (sigma recalibrated) vs R=100 at the selected settings", answers="training length at fixed eps",
      tables="8", claims="-")
block(id="T2d", stage=3, name="tune_dp_designA_comparator", cells=1, seeds="S_TUNE", mode="dp_fedA",
      factors="design A (B=512, per-client sigma) at the selected lr and C", answers="sampling design (decision D11)",
      tables="8", claims="-")
block(id="T3", stage=3, name="tune_noise_schedule", cells=6, seeds="S_TUNE", mode="dp_fed",
      factors="{linear, exponential, cosine} x rho{0.25,0.5} at eps*=4; all R rounds executed",
      answers="schedule selection s* for the 'adaptive DP' claim", tables="8", claims="adaptive-DP")
# T4 (tau calibration) needs no extra runs: anomaly scores are logged in clean FedAvg DP runs (Phase C change).

# ---------- Stage 4: confirmatory core (selections frozen; evaluation seeds)
block(id="L0", stage=4, name="legacy_checkpoint_reevaluation", cells=1, seeds="S1", mode="eval_only", datasets="FB",
      factors="saved legacy Phase 3 model, corrected evaluation; no training",
      answers="old model under the new protocol", tables="13", claims="continuity")
block(id="L1", stage=4, name="legacy_replica_p3", cells=1, seeds="S5", mode="legacy_p3", datasets="FB", rounds=50,
      factors="exact old Phase 3 (5 relation-disjoint clients, 1 negative, 3 local epochs, 50 rounds)",
      answers="reproduce 0.2858 under the legacy protocol; spread across seeds", tables="13", claims="continuity")
block(id="L2", stage=4, name="legacy_partition_fixed_trainer", cells=1, seeds="S5", mode="np_fed", datasets="FB",
      rounds=60, factors="old 5-client partition, corrected trainer + evaluation",
      answers="partition effect vs trainer/evaluation effect", tables="13", claims="continuity")
block(id="L3", stage=4, name="legacy_replica_p4", cells=1, seeds="S5", mode="legacy_p4", datasets="FB", rounds=16,
      factors="exact old Phase 4 (sigma=1, B=256, naive-sum stop)", answers="reproduce 0.009", tables="13",
      claims="continuity")
block(id="L4", stage=4, name="dp_ladder_legacy_to_fixed", cells=3, seeds="S5", mode="dp_legacy", datasets="FB",
      rounds=60, factors="ladder L1 legacy mechanism, L2 trainer fixed, L3 formal accounting (main partition)",
      answers="why the old DP model collapsed", tables="6,13", claims="continuity")
block(id="N1", stage=4, name="central_nonprivate", cells=1, seeds="S10", red={"seeds": "S5"}, mode="np_central",
      rounds=60, factors="centralised TransE, selected non-private settings", answers="H1 reference",
      tables="3,4", claims="H1", keep_weights=1)
block(id="N2", stage=4, name="fedavg_nonprivate_main", cells=1, seeds="S10", red={"seeds": "S5"}, mode="np_fed",
      rounds=60, factors="FedAvg, Dirichlet alpha=0.1", answers="federation cost; DP-cost reference",
      tables="3,4,5", claims="descriptive", keep_weights=1)
block(id="N3", stage=4, name="fedavg_nonprivate_heterogeneity", cells=3, seeds="S5", mode="np_fed", rounds=60,
      factors="alpha{0.5,1.0} + IID", answers="heterogeneity effect", tables="2,3", claims="-")
block(id="DP1", stage=4, name="dp_privacy_regimes_fixed", cells=4, seeds="S5", mode="dp_fed",
      factors="FedAvg + DP, fixed sigma, eps*{1,2,4,8} (= 'DP without trust' baseline)",
      answers="privacy-utility curve; fixed arm of HS", tables="6,7", claims="HS (eps*=4 cell); descriptive",
      keep_weights=0.25)
block(id="DP1h", stage=4, name="dp_eps4_headline_extra_seeds", cells=1, seeds="S10x", red="drop", mode="dp_fed",
      factors="eps*=4 fixed sigma with seeds 2048..32768 (completes 10 seeds)", answers="headline HS fixed arm",
      tables="5,12", claims="HS", keep_weights=1)
block(id="DP2", stage=4, name="dp_selected_schedule", cells=4, seeds="S5", red={"cells": 1}, mode="dp_fed",
      factors="FedAvg + DP with the selected schedule s* at eps*{1,2,4,8} (reduced: eps*=4 only; equals DP1 if s* = fixed)",
      answers="schedule effect at equal eps; clean FedAvg reference of H2/H2b", tables="3,5,7",
      claims="HS; H2, H2b reference (eps*=4 cell)", keep_weights=0.25)
block(id="DP2h", stage=4, name="dp_schedule_headline_extra_seeds", cells=1, seeds="S10x", red="drop", mode="dp_fed",
      factors="s* at eps*=4 with seeds 2048..32768", answers="headline HS / H2 reference", tables="5,12",
      claims="HS; H2, H2b reference", keep_weights=1)
block(id="DP3", stage=4, name="dp_cost_decomposition", cells=2, seeds="S5", red={"seeds": "S3"}, mode="dp_fed",
      factors="DP training settings without noise or clipping; clipping only (sigma=0)",
      answers="settings vs clipping vs noise share of the DP cost", tables="5", claims="descriptive")
block(id="R1", stage=4, name="clean_aggregators_dp", cells=4, seeds="S5", red={"seeds": "S3"}, mode="dp_fed",
      extra="robust", factors="complete-method DP config, no attack: trimmed mean (beta 0.2), median, Krum (f 2), "
                              "FLTrust; robustness parameters at the design value f = 0.2",
      answers="clean utility and false-positive rate of baselines", tables="4,9", claims="descriptive (H2 context)")
block(id="R1p", stage=4, name="clean_complete_method", cells=1, seeds="S10", red={"seeds": "S5"}, mode="dp_fed",
      extra="robust", factors="complete method, no attack", answers="main result row; benign FPR",
      tables="3,4,5,9", claims="H1; H2; H2b", keep_weights=1)
block(id="R1q", stage=4, name="clean_complete_minus_schedule", cells=1, seeds="S5", mode="dp_fed", extra="robust",
      factors="complete method with fixed sigma (skipped if s* = fixed)", answers="schedule ablation inside the method",
      tables="5", claims="descriptive (HS inside the method)", keep_weights=1)
block(id="R2", stage=4, name="attacks_fedavg_dp", cells=6, seeds="S10", red={"seeds": "S5"}, mode="dp_fed",
      factors="complete-method DP config with FedAvg; f=0.2; gaussian, signflip, ALIE, IPM, KG-targeted, Sybil",
      answers="attack impact without defence (= complete method minus defence)", tables="5,9", claims="H2")
block(id="R2a", stage=4, name="adaptive_crafted_vs_fedavg", cells=1, seeds="S10", red={"seeds": "S5"}, mode="dp_fed",
      extra="robust,adaptive", factors="FedAvg receiving the adaptive update crafted against the proposed rule",
      answers="paired no-defence reference for the adaptive attack", tables="9", claims="H2")
block(id="R3", stage=4, name="attacks_complete_method", cells=6, seeds="S10", red={"seeds": "S5"}, mode="dp_fed",
      extra="robust", factors="complete method; the same 6 attacks", answers="defence effectiveness", tables="9",
      claims="H2")
block(id="R3a", stage=4, name="adaptive_attack_complete_method", cells=1, seeds="S10", red={"seeds": "S5"},
      mode="dp_fed", extra="robust,adaptive", factors="complete method; adaptive gray-box attack tailored to the rule",
      answers="robustness against an attacker who knows the rule", tables="9", claims="H2")
block(id="R4", stage=4, name="attacks_baselines_dp", cells=24, seeds="S5", red={"seeds": "S3", "cells": 16},
      mode="dp_fed", extra="robust",
      factors="{trimmed mean, median, Krum, FLTrust} x 6 attacks (reduced: signflip, ALIE, IPM, KG-targeted)",
      answers="comparison with established defences", tables="4,9", claims="descriptive (H2 context)")
block(id="R5", stage=4, name="attacks_nonprivate", cells=7, seeds="S5", red={"seeds": "S3"}, mode="np_fed",
      rounds=60, extra="robust",
      factors="no DP: FedAvg x{signflip, ALIE, KG-targeted}; proposed x{clean, signflip, ALIE, KG-targeted}",
      answers="trust without DP (ablation)", tables="5,9", claims="descriptive (ablation)")
block(id="R5a", stage=4, name="adaptive_attack_nonprivate", cells=1, seeds="S5", red={"seeds": "S3"}, mode="np_fed",
      rounds=60, extra="robust,adaptive", factors="no DP: proposed x adaptive", answers="trust without DP vs adaptive",
      tables="5,9", claims="descriptive (ablation)")
block(id="I1", stage=4, name="integrity_off_vs_on", cells=2, seeds="S3", mode="dp_fed",
      factors="integrity OFF for {non-private FedAvg, complete method} (ON runs exist in N2/R1p)",
      answers="integrity overhead; utility identical when nothing is tampered", tables="10,11", claims="descriptive (integrity)")
block(id="I2", stage=4, name="integrity_tamper_injection", cells=4, seeds="S3", red={"cells": 2}, mode="dp_fed",
      factors="complete method; transmitted bytes corrupted in transit, p_tamper{0.01,0.1} x integrity{on,off}",
      answers="what verification buys (rejects corrupted updates); NOT a poisoning defence", tables="10",
      claims="descriptive (integrity)")
block(id="M1", stage=4, name="mia_audit", cells=4, seeds="S5", mode="dp_fed", tier="decision-D6",
      factors="audit pool per client, each candidate included with probability 1/2; FedAvg non-private and eps*{1,4,8}",
      answers="empirical membership leakage (H3, only if retained); one-run audit", tables="6,7", claims="H3",
      keep_weights=1)

# ---------- Stage 5: extended / sensitivity (3 seeds; labelled sensitivity, never headline)
block(id="X1", stage=5, name="alpha_eps_surface", cells=12, seeds="S3", red={"cells": 6}, mode="dp_fed",
      tier="extended", factors="FedAvg + DP: alpha{0.5,1.0,IID} x eps*{1,2,4,8} (reduced: alpha{0.5,IID} x eps*{1,4,8})",
      answers="3D surface MRR(eps, alpha) per dataset", tables="7", claims="-")
block(id="X2", stage=5, name="tau_by_fraction_grid", cells=26, seeds="S3", red={"cells": 18}, mode="dp_fed",
      tier="extended", extra="robust",
      factors="complete method: tau{1.5,2,2.5,3,3.5,4,5} x {clean, ALIE f0.1, f0.2, f0.3} minus 2 core cells "
              "(reduced: tau{1.5,2.5,3.5,5} + selected)",
      answers="3D threshold-sensitivity surface MRR(tau, f)", tables="8", claims="-")
block(id="X2a", stage=5, name="tau_curve_adaptive", cells=6, seeds="S3", red={"cells": 4}, mode="dp_fed",
      tier="extended", extra="robust,adaptive", factors="complete method: non-selected tau x adaptive attack, f=0.2",
      answers="threshold sensitivity under the adaptive attacker", tables="8", claims="-")
block(id="X3", stage=5, name="lambda_sensitivity", cells=6, seeds="S3", mode="dp_fed", datasets="FB",
      tier="extended", extra="robust", factors="lambda{0,0.25,1.0} x {clean, ALIE}",
      answers="history-penalty sensitivity", tables="8", claims="-")
block(id="X4", stage=5, name="attacker_fraction_refs", cells=6, seeds="S3", red={"cells": 4}, mode="dp_fed",
      tier="extended", extra="robust",
      factors="FedAvg x{ALIE, signflip} x f{0.1,0.3}; proposed x signflip x f{0.1,0.3} (proposed x ALIE is in X2)",
      answers="degradation references for the (tau, f) surface", tables="9", claims="-")
block(id="X4a", stage=5, name="attacker_fraction_adaptive", cells=2, seeds="S3", mode="dp_fed", tier="extended",
      extra="robust,adaptive", factors="proposed x adaptive x f{0.1,0.3}", answers="adaptive attacker vs fraction",
      tables="9", claims="-")
block(id="X5", stage=5, name="noise_free_attackers", cells=4, seeds="S3", mode="dp_fed", tier="extended",
      extra="robust", factors="{FedAvg, proposed} x {KG-targeted, Sybil} without DP noise (revision behaviour)",
      answers="how much detection relies on missing noise", tables="9", claims="-")
block(id="X6", stage=5, name="local_only_training", cells=1, seeds="S3", mode="np_fed", rounds=60, tier="extended",
      factors="each client trains alone (alpha=0.1)", answers="value of federation", tables="4", claims="-")
block(id="X7a", stage=5, name="trust_across_eps_clean", cells=3, seeds="S3", mode="dp_fed", tier="extended",
      extra="robust", factors="proposed aggregation, no attack, eps*{1,2,8}",
      answers="does trust cost clean utility at other privacy levels", tables="5,7", claims="-")
block(id="X7b", stage=5, name="trust_across_eps_attack", cells=4, seeds="S3", mode="dp_fed", tier="extended",
      extra="robust", factors="{FedAvg, proposed} x ALIE f0.2 x eps*{2,8}",
      answers="robustness x privacy interaction", tables="9", claims="-")
block(id="O1", stage=5, name="validation_adaptive_sigma_rdp_filter", cells=1, seeds="S5", mode="dp_fed",
      tier="optional", factors="validation-triggered sigma decay with an RDP filter (DP-Flames-inspired policy)",
      answers="stronger 'adaptive DP' variant (decision D12)", tables="5,7", claims="adaptive-DP")


# ----------------------------------------------------------------------------------------------- priority order
# Stage-4 run order (07 section 6), so that partial completion still yields usable evidence. Each entry is
# (block, share): 1.0 = whole block; "eps4" = only its eps*=4 cell; "rest" = its other cells.
PRIORITY = [
    ("0", "Stages 2-3: pilot and tuning (must come first)",
     [(b, 1.0) for b in ("P2.1", "P2.2", "P2.3", "T1", "T2a", "T2b", "T2c", "T2d", "T3")]),
    ("1", "main table, H1, H2b, HS: N1, N2, DP1 and DP2 at eps*=4 (+DP1h, DP2h in full), R1p",
     [("N1", 1.0), ("N2", 1.0), ("DP1", "eps4"), ("DP2", "eps4"), ("DP1h", 1.0), ("DP2h", 1.0), ("R1p", 1.0)]),
    ("2", "H2: R2, R2a, R3, R3a", [(b, 1.0) for b in ("R2", "R2a", "R3", "R3a")]),
    ("3", "original vs revised: L0-L4", [(b, 1.0) for b in ("L0", "L1", "L2", "L3", "L4")]),
    ("4", "schedule inside the method: R1q", [("R1q", 1.0)]),
    ("5", "baselines and trust without DP: R1, R4, R5, R5a", [(b, 1.0) for b in ("R1", "R4", "R5", "R5a")]),
    ("6", "other eps levels, DP-cost decomposition, heterogeneity, integrity: DP1/DP2 other eps, DP3, N3, I1, I2",
     [("DP1", "rest"), ("DP2", "rest"), ("DP3", 1.0), ("N3", 1.0), ("I1", 1.0), ("I2", 1.0)]),
    ("7", "MIA audit M1 (only if D6 keeps H3)", [("M1", 1.0)]),
    ("8", "Stage 5 extended", [(b, 1.0) for b in ("X1", "X2", "X2a", "X3", "X4", "X4a", "X5", "X6", "X7a", "X7b")]),
    ("9", "optional O1", [("O1", 1.0)]),
]

# ----------------------------------------------------------------------------------------------- cost model
# Two bounds. t0 = fixed seconds per optimizer step (kernel launches, Python, sampling, unique). The legacy Phase 3
# measurement (1,204.4 s for 50 rounds x 3 epochs at B=512, 1 negative, incl. evaluation) lies between the bounds;
# the bounds were chosen with it in view, so this is a consistency check, not a validation.
PARAMS = {
    "LOW":  {"t0": 0.008, "c_ex": 1.5e-6, "c_P": 0.10e-9, "c_q": 0.5e-9, "sort": 0.002, "hash_Bps": 1.0e9,
             "overhead": 1.2, "q_dp": 0.10},
    "HIGH": {"t0": 0.020, "c_ex": 6.0e-6, "c_P": 0.40e-9, "c_q": 2.0e-9, "sort": 0.010, "hash_Bps": 0.3e9,
             "overhead": 1.5, "q_dp": 0.02},
}
EVAL_EVERY, ES_QUERIES, B_NP = 5, 4000, 512


def round_seconds(mode: str, d: dict, p: dict, extra: str) -> float:
    N, P = d["n_train"], d["P"]
    if mode == "np_central":
        steps = N / B_NP + 1
        t = steps * (p["t0"] + P * p["c_P"]) + N * p["c_ex"]
    elif mode == "np_fed":
        steps = N / B_NP + K
        t = steps * (p["t0"] + P * p["c_P"]) + N * p["c_ex"]
    elif mode == "dp_fed":                                   # design Q: K clients x 1/q steps, dense noise + Adam
        steps = K * round(1 / p["q_dp"])
        t = steps * (p["t0"] + 2 * P * p["c_P"]) + 1.5 * N * p["c_ex"]
    elif mode == "dp_fedA":                                  # design A: B=512 per client
        steps = N / 512 + K
        t = steps * (p["t0"] + 2 * P * p["c_P"]) + 1.5 * N * p["c_ex"]
    elif mode == "legacy_p3":                                # 3 local epochs, 1 negative, 5 clients
        steps = 3 * (N / 512 + 5)
        t = steps * (p["t0"] + P * p["c_P"]) + 3 * N * p["c_ex"] / 16
    elif mode in ("legacy_p4", "dp_legacy"):                 # B=256 Opacus-style sampling, 1 negative
        steps = N / 256
        t = steps * (p["t0"] + 2 * P * p["c_P"]) + 1.5 * N * p["c_ex"] / 16
    elif mode == "eval_only":
        return 0.0
    else:
        raise ValueError(mode)
    t += (K + 1) * 4 * P / p["hash_Bps"]                     # integrity hashing (on in almost every run)
    if "robust" in extra:
        t += (P / 1.47e6) * p["sort"]
    if "adaptive" in extra:
        t += 81 * (P / 1.47e6) * p["sort"]
    t += ES_QUERIES * d["n_ent"] * p["c_q"] / EVAL_EVERY     # periodic early-stopping / selection evaluation
    return t * p["overhead"]


def run_hours(blk: dict, d: dict, p: dict) -> float:
    if blk["mode"] == "eval_only":
        q = 2 * (d["n_valid"] + d["n_test"])
        return (q * d["n_ent"] * p["c_q"] + q * 20e-6) / 3600
    final_eval = 2 * (0.8 * d["n_valid"] + d["n_test"]) * (d["n_ent"] * p["c_q"] + 20e-6)
    return (blk["rounds"] * round_seconds(blk["mode"], d, p, blk["extra"]) + final_eval) / 3600


def resolve(blk: dict, profile: str):
    """Return (cells, seed_set) for the profile, or None if the block is dropped."""
    if profile == "full" or blk["red"] == {}:
        return blk["cells"], blk["seeds"]
    if blk["red"] == "drop":
        return None
    return blk["red"].get("cells", blk["cells"]), blk["red"].get("seeds", blk["seeds"])


def datasets_for(blk: dict, third: str):
    return ["FB"] if blk["datasets"] == "FB" else ["FB", "WN", third]


def legacy_anchor_check():
    d = DS["FB"]
    return {k: 50 * round_seconds("legacy_p3", d, {**p, "overhead": 1.0, "hash_Bps": float("inf"), "c_q": 0.0}, "")
            for k, p in PARAMS.items()}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--draft-yaml", required=True)
    a = ap.parse_args(argv)
    od = a.out_dir.rstrip("/")
    ids = [b["id"] for b in B]
    if len(ids) != len(set(ids)):
        raise SystemExit("duplicate block ids")

    rows = []
    for b in B:
        nds = 1 if b["datasets"] == "FB" else 3
        full, red = resolve(b, "full"), resolve(b, "reduced")
        rows.append({
            "block": b["id"], "stage": b["stage"], "tier": b["tier"], "name": b["name"], "datasets": b["datasets"],
            "cells_per_dataset": full[0], "seed_set": full[1], "n_seeds": len(SEEDS[full[1]]),
            "runs_per_dataset": full[0] * len(SEEDS[full[1]]),
            "runs_total": full[0] * len(SEEDS[full[1]]) * nds,
            "reduced_cells": red[0] if red else 0, "reduced_seed_set": red[1] if red else "dropped",
            "reduced_runs_total": (red[0] * len(SEEDS[red[1]]) * nds) if red else 0,
            "rounds_assumed": b["rounds"], "cost_mode": b["mode"], "extra": b["extra"],
            "factors": b["factors"], "answers": b["answers"], "tables": b["tables"], "claims": b["claims"],
        })
    with open(f"{od}/experiment_matrix.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)

    cost_rows = []
    for profile in ("full", "reduced"):
        for third in ("CX", "YG"):
            for b in B:
                res = resolve(b, profile)
                cells, sset = res if res else (0, "S1")
                n_seeds = len(SEEDS[sset])
                for lvl, p in PARAMS.items():
                    per_ds = {dk: cells * n_seeds * run_hours(b, DS[dk], p) for dk in datasets_for(b, third)}
                    cost_rows.append({"profile": profile, "third_dataset": DS[third]["name"], "block": b["id"],
                                      "stage": b["stage"], "tier": b["tier"], "bound": lvl,
                                      "runs": cells * n_seeds * len(per_ds), "gpu_hours": round(sum(per_ds.values()), 3),
                                      **{f"gpu_hours_{k}": round(v, 3) for k, v in per_ds.items()}})
    lead = ["profile", "third_dataset", "block", "stage", "tier", "bound", "runs", "gpu_hours"]
    keys = lead + sorted({k for r in cost_rows for k in r} - set(lead))
    with open(f"{od}/cost_estimate.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader(); w.writerows(cost_rows)

    per_run = []
    for d in DS.values():
        for mode, rounds in (("np_fed", 60), ("np_central", 60), ("dp_fed", 100), ("dp_fedA", 100)):
            fake = {"mode": mode, "rounds": rounds, "extra": ""}
            per_run.append({"dataset": d["name"], "mode": mode, "rounds": rounds,
                            "minutes_LOW": round(60 * run_hours(fake, d, PARAMS["LOW"]), 1),
                            "minutes_HIGH": round(60 * run_hours(fake, d, PARAMS["HIGH"]), 1),
                            "n_params": d["P"], "model_MB_fp32": round(4 * d["P"] / 1e6, 1),
                            "update_matrix_MB": round(4 * d["P"] * (K + 2) / 1e6, 1)})
    with open(f"{od}/per_run_time_estimate.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(per_run[0].keys()))
        w.writeheader(); w.writerows(per_run)

    # storage: final model weights kept only for blocks with keep_weights (main-table, HS and MIA runs)
    stor = []
    for profile in ("full", "reduced"):
        for third in ("CX", "YG"):
            w_bytes, n_models, n_runs = 0.0, 0, 0
            for b in B:
                res = resolve(b, profile)
                if not res:
                    continue
                cells, sset = res
                dss = datasets_for(b, third)
                n_runs += cells * len(SEEDS[sset]) * len(dss)
                kw = b["keep_weights"]
                kept = 0 if not kw else (cells if kw >= 1 else 1)
                for dk in dss:
                    n_models += kept * len(SEEDS[sset])
                    w_bytes += kept * len(SEEDS[sset]) * 4 * DS[dk]["P"]
            stor.append({"profile": profile, "third_dataset": DS[third]["name"], "runs_all_tiers": n_runs,
                         "records_GB_upper": round(n_runs * 0.5e6 / 1e9, 2), "kept_models": n_models,
                         "kept_weights_GB": round(w_bytes / 1e9, 2),
                         "total_persistent_GB_upper": round(n_runs * 0.5e6 / 1e9 + w_bytes / 1e9 + 0.2, 2)})
    with open(f"{od}/storage_estimate.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(stor[0].keys()))
        w.writeheader(); w.writerows(stor)

    summ = {}
    for r in cost_rows:
        k = (r["profile"], r["third_dataset"], r["stage"], r["tier"])
        e = summ.setdefault(k, {"runs": 0, "LOW": 0.0, "HIGH": 0.0})
        if r["bound"] == "LOW":
            e["runs"] += r["runs"]
        e[r["bound"]] += r["gpu_hours"]
    with open(f"{od}/run_counts.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["profile", "third_dataset", "stage", "tier", "runs", "gpu_hours_LOW", "gpu_hours_HIGH"])
        for k in sorted(summ):
            w.writerow([*k, summ[k]["runs"], round(summ[k]["LOW"], 1), round(summ[k]["HIGH"], 1)])

    # priority groups: runs and GPU-hours per group, cumulative; groups 0-6 must add up to the core total
    by_block = {}
    for r in cost_rows:
        e = by_block.setdefault((r["profile"], r["third_dataset"], r["block"]), {"runs": 0, "LOW": 0.0, "HIGH": 0.0})
        e[r["bound"]] += r["gpu_hours"]
        if r["bound"] == "LOW":
            e["runs"] += r["runs"]
    cells_of = {}
    for b in B:
        for profile in ("full", "reduced"):
            res = resolve(b, profile)
            cells_of[(profile, b["id"])] = res[0] if res else 0
    prio = []
    for profile in ("full", "reduced"):
        for third in ("CX", "YG"):
            tname = DS[third]["name"]
            cum = {"runs": 0, "LOW": 0.0, "HIGH": 0.0}
            for gid, label, members in PRIORITY:
                g = {"runs": 0.0, "LOW": 0.0, "HIGH": 0.0}
                for bid, share in members:
                    c = cells_of[(profile, bid)]
                    if c == 0:
                        continue
                    frac = share if isinstance(share, float) else (1 / c if share == "eps4" else 1 - 1 / c)
                    e = by_block[(profile, tname, bid)]
                    for k in g:
                        g[k] += frac * e[k]
                for k in cum:
                    cum[k] += g[k]
                prio.append({"profile": profile, "third_dataset": tname, "priority": gid, "group": label,
                             "runs": round(g["runs"]), "gpu_hours_LOW": round(g["LOW"], 1),
                             "gpu_hours_HIGH": round(g["HIGH"], 1), "cumulative_runs": round(cum["runs"]),
                             "cumulative_LOW": round(cum["LOW"], 1), "cumulative_HIGH": round(cum["HIGH"], 1)})
            core = [r for r in prio if r["profile"] == profile and r["third_dataset"] == tname
                    and r["priority"] == "6"][0]
            core_runs = sum(e["runs"] for (p_, t_, bid), e in by_block.items()
                            if p_ == profile and t_ == tname and next(b for b in B if b["id"] == bid)["tier"] == "core")
            if core["cumulative_runs"] != core_runs:
                raise SystemExit(f"priority groups 0-6 ({core['cumulative_runs']}) != core runs ({core_runs})")
    with open(f"{od}/priority_cost.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(prio[0].keys()))
        w.writeheader(); w.writerows(prio)

    draft = {"_status": "PHASE B DRAFT - design only; not runnable; selections and decisions pending approval",
             "seed_sets": SEEDS, "datasets": {k: v["name"] for k, v in DS.items()},
             "third_dataset_options": ["codex_m (recommended default)", "yago310 (alternative / extension)"],
             "profiles": {"full": "headline hypothesis blocks with 10 seeds (S10)",
                          "reduced": "every hypothesis block with 5 seeds (S5); descriptive blocks with 3; see 'red'"},
             "complete_method": "DP eps*=4 with the selected sampling design (D11), q*, C*, lr*, R* and schedule s* + "
                                "proposed trust aggregation (03 section 8.3; V1 only if the D15 trigger fires) with "
                                "tau* + integrity verification in the data path",
             "priority_order": [{"priority": g, "group": lbl} for g, lbl, _ in PRIORITY],
             "blocks": [{k: b[k] for k in ("id", "stage", "tier", "name", "datasets", "cells", "seeds", "red",
                                           "factors", "answers", "tables", "claims", "keep_weights")} for b in B]}
    with open(a.draft_yaml, "w") as f:
        yaml.safe_dump(draft, f, sort_keys=False, width=120)

    anchor = legacy_anchor_check()
    print("legacy Phase 3 anchor (measured 1204.4 s incl. evaluation): model",
          {k: round(v, 1) for k, v in anchor.items()})
    for k in sorted(summ):
        print(k, summ[k]["runs"], "runs", round(summ[k]["LOW"], 1), "-", round(summ[k]["HIGH"], 1), "GPU-h")
    for r in stor:
        print("storage", r)
    return 0


if __name__ == "__main__":
    sys.exit(main())
