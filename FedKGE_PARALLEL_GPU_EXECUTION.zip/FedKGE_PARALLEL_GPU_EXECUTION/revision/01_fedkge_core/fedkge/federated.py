"""Round-loop orchestrator: one call = one experiment run = one directory of machine-readable outputs.

One round (Phase C, every step traced in audit/phaseC/implementation_traceability.md):
  server broadcasts theta^{t-1} through the integrity layer
  -> every client fetches, VERIFIES and deserialises its copy; a client whose copy fails verification or contains
     a non-finite value skips the round (MN-22)
  -> local training from the client's verified copy [non-private | DP-SGD, design A or Q]
  -> malicious crafting (attack noise mode inherit / matched / none, D16)
  -> every client sends U_k = theta_k - theta_received through the integrity layer
  -> the server fetches, VERIFIES and deserialises every update; ONLY the deserialised verified tensors are
     aggregated (CR-13); rejected identities are dropped for the round
  -> anomaly scores of the frozen trust rule logged for every aggregator (tau rule D14; per-size-third benign
     false-positive diagnostics; variant V1 removed by owner decision B4)
  -> aggregation (FedAvg | trimmed mean | median | Krum | FLTrust | proposed trust rule)
  -> global update -> accountant (steps actually executed by each client) -> logging
  -> periodic validation on the fixed V_es subset -> checkpoint
DP runs execute all R rounds (no early stopping, C3); the best-validated checkpoint is selected afterwards, which is
post-processing of released models evaluated on server data.

Outputs in RESULTS_ROOT/<tier>/runs/<run_id>/:
  config.json, env.json, status.json, rounds.csv, weights_rounds.csv, trust_rounds.csv (anomaly scores, every
  aggregator), accountant.json (DP), attack.json (attacks), integrity.json, mia.json + mia_scores.csv (audit),
  final.json, log.txt, checkpoint.pt (resume; deleted at completion), final_weights.pt (only if requested)
Every number in final.json is computed here from the run itself; there are no defaults, stubs or fallbacks.

Session safety (final package): checkpoints are written atomically (temporary file + rename), so a disconnect can
never leave a half-written checkpoint; an unreadable checkpoint is moved aside (never deleted) and the run restarts
from round 1, which is the same computation. A run is COMPLETE only after every output file exists; status.json is
written last. A retried FAILED run keeps the earlier traceback as error_attempt<k>.txt and counts its attempts.
"""
from __future__ import annotations

import json
import os
import time
import traceback
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import torch

from . import accountant as acc
from .aggregators import aggregate, rejected_mask
from .attacks import (choose_malicious, craft, make_targets, make_targets_from_attacker_data, resolve_noise_mode)
from .config import config_hash, n_malicious, run_id, validate
from .data import load_artifact
from .dp import dp_local_train
from .evaluate import FilterIndex, evaluate, evaluate_legacy, targeted_success
from .integrity import IntegrityLayer, summarize_stats, tamper_test
from .io import (STATUS_COMPLETE, STATUS_FAILED, STATUS_RUNNING, Paths, RunDir, atomic_torch_save, code_hash,
                 environment, plain, read_json, write_csv, write_json)
from .model import flatten, init_params, num_params, unflatten
from .partition import canonical_spec, load_partition
from .train import local_train
from .trust import TrustState, anomaly_scores, size_thirds

PURPOSE = {"init": 1, "local": 2, "craft": 3, "root": 4, "targets": 5, "malicious": 6, "mia": 7, "legacy_eval": 8,
           "tamper": 9, "corrupt": 10, "audit_pool": 11, "sybil": 12}

METRIC_CONVENTION = {"ranking": "filtered (train+valid+test known-true removed), head and tail queries",
                     "ties": "realistic (expected rank under random tie-breaking); optimistic/pessimistic stored",
                     "averaging": "micro-average over 2*|split| queries"}


class RunLogger:
    def __init__(self, path: Path):
        self.f = open(path, "a")

    def __call__(self, msg: str):
        line = f"[{time.strftime('%H:%M:%S')}] {msg}"
        print(line, flush=True)
        self.f.write(line + "\n"); self.f.flush()

    def close(self):
        try:
            self.f.close()
        except Exception as e:  # closing a log file must never mask the run's own exception
            print(f"log close failed: {e!r}")


def _seed_int(seed: int, *ids: int) -> int:
    return int(np.random.SeedSequence([int(seed), *[int(i) for i in ids]]).generate_state(1)[0])


def _gen(device, seed: int, purpose: str, *ids: int) -> torch.Generator:
    g = torch.Generator(device=device)
    g.manual_seed(_seed_int(seed, PURPOSE[purpose], *ids))
    return g


def _calibration_cache(paths: Paths) -> Path:
    p = paths.cache() / "sigma_calibration.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def _calibrate_cached(paths: Paths, **kw) -> Dict:
    key = json.dumps({k: (repr(v) if isinstance(v, float) else v) for k, v in sorted(kw.items())})
    cp = _calibration_cache(paths)
    cache = json.loads(cp.read_text()) if cp.exists() else {}
    if key in cache:
        return cache[key]
    res = acc.calibrate_sigma0(**kw)
    cache[key] = res
    write_json(cp, cache)
    return res


def run_experiment(cfg: Dict, paths: Paths, device: Optional[str] = None, force: bool = False) -> Dict:
    cfg = validate(cfg)
    rid = run_id(cfg)
    rd = RunDir(paths.run(rid))
    if not force and rd.is_complete_and_current():
        return read_json(rd.path / "final.json")
    if rd.path.exists() and rd.is_stale():
        rd.archive_stale()
    elif force and (rd.status() or {}).get("status") == STATUS_COMPLETE:
        # Phase C fix (defect PC-6): a forced rerun (pilot, small runs) used to write over a completed run folder.
        # The earlier folder is now kept intact under <tier>/stale/. Interrupted or failed runs still resume in place.
        rd.archive_stale("forced_rerun")
    rd.path.mkdir(parents=True, exist_ok=True)
    if (rd.path / "config.json").exists():
        old = read_json(rd.path / "config.json")
        if run_id(old) != rid:
            raise RuntimeError(f"run directory {rd.path} holds a different config")
    prev = rd.status() or {}
    attempt = int(prev.get("attempt", 1)) + 1 if prev else 1
    if prev.get("status") == STATUS_FAILED and (rd.path / "error.txt").exists():
        # keep the earlier failure for the record (Table 14 reports retried runs); never silently forget it
        os.replace(rd.path / "error.txt", rd.path / f"error_attempt{attempt - 1}.txt")
    write_json(rd.path / "config.json", cfg)
    write_json(rd.path / "env.json", environment())
    rd.set_status(STATUS_RUNNING, attempt=attempt,
                  previous_status=prev.get("status"), previous_error=prev.get("error"))
    log = RunLogger(rd.path / "log.txt")
    try:
        final = _run(cfg, rid, rd, paths, device, log)
        rd.set_status(STATUS_COMPLETE, attempt=attempt)
        return final
    except Exception as e:
        (rd.path / "error.txt").write_text(traceback.format_exc())
        rd.set_status(STATUS_FAILED, error=repr(e), attempt=attempt)
        log(f"RUN FAILED: {e!r}")
        raise
    finally:
        log.close()


def _clip(dcfg: Dict) -> float:
    return float("inf") if dcfg.get("clip") is None else float(dcfg["clip"])


def _dp_plan(dcfg: Dict, public_size: int, R: int, paths: Paths) -> Dict:
    """Sampling design + noise schedule of one client. Uses only public quantities."""
    legacy_samp = bool(dcfg.get("legacy_opacus_sampling", False))
    if dcfg.get("sampling", "fixed_batch") == "common_rate":
        sr = acc.dp_steps_common_rate(int(public_size), float(dcfg["q"]))
    else:
        sr = acc.dp_steps_and_rate(int(public_size), int(dcfg["batch_size"]), legacy_samp)
    if dcfg["mode"] == "no_noise":
        return {**sr, "sigmas": [0.0] * R, "n": int(public_size)}
    if dcfg["mode"] == "calibrated":
        cal = _calibrate_cached(paths, q=sr["q"], steps_per_round=sr["steps"], rounds=R,
                                shape=dcfg["schedule"]["shape"], rho=float(dcfg["schedule"]["rho"]),
                                target_eps=float(dcfg["target_epsilon"]), delta=float(dcfg["delta"]),
                                update_every=int(dcfg["schedule"].get("update_every", 5)))
        sig = cal["sigmas"]
    else:
        sig = [float(dcfg["sigma"])] * R
    return {**sr, "sigmas": sig, "n": int(public_size)}


def _run(cfg: Dict, rid: str, rd: RunDir, paths: Paths, device: Optional[str], log) -> Dict:
    t_start = time.time()
    dev = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
    if dev.type == "cuda":
        torch.cuda.reset_peak_memory_stats(dev)              # peak GPU memory of THIS run (runtime block)
    seed = int(cfg["seed"])
    np.random.seed(seed); torch.manual_seed(seed)
    tcfg, mcfg, dcfg, acfg, atk, ecfg = cfg["train"], cfg["model"], cfg["dp"], cfg["aggregation"], cfg["attack"], cfg["eval"]
    normalize, margin = bool(mcfg["normalize"]), float(mcfg["margin"])
    dp_on = bool(dcfg["enabled"])
    accounted = dp_on and dcfg["mode"] != "no_noise"          # the DP3 ablation adds no noise: no guarantee
    stop_after = tcfg.get("stop_after_rounds")

    # ---------------------------------------------------------------- upstream artifacts (fail if missing/stale)
    data = load_artifact(paths.p1(cfg["dataset"]["name"]))
    part = load_partition(paths.p2(cfg["dataset"]["name"]), cfg["partition"], seed, data.content_hash)
    client_of = part["client"]
    if len(client_of) != len(data.train):
        raise RuntimeError("partition length does not match training data")
    n_real = int(cfg["partition"]["n_clients"])
    train_np = data.train
    client_idx = [np.flatnonzero(client_of == c) for c in range(n_real)]
    sizes = np.array([len(ix) for ix in client_idx], dtype=float)      # PUBLIC sizes N_k (declared before training)
    if (sizes == 0).any():
        raise RuntimeError("empty client in partition")
    n_ent, n_rel = data.num_entities, data.num_relations
    filt = FilterIndex(data.all_true)
    log(f"run {rid} | {cfg['dataset']['name']} | seed {seed} | clients {n_real} | device {dev}")

    # ---------------------------------------------------------------- membership-inference audit pool (zero-out)
    mcfg_mia = cfg.get("mia", {}) or {}
    mia_on = bool(mcfg_mia.get("enabled", False))
    audit = None
    train_rows = [ix for ix in client_idx]
    if mia_on:
        arng = np.random.default_rng(_seed_int(seed, PURPOSE["audit_pool"]))
        frac, p_in = float(mcfg_mia.get("pool_fraction", 0.1)), float(mcfg_mia.get("inclusion_p", 0.5))
        cand, member, owner = [], [], []
        for c in range(n_real):
            ix = client_idx[c]
            m = int(round(frac * len(ix)))
            pick = arng.choice(len(ix), size=m, replace=False)
            coins = arng.random(m) < p_in
            cand.append(ix[pick]); member.append(coins); owner.append(np.full(m, c))
            excluded = set(ix[pick][~coins].tolist())
            train_rows[c] = np.array([i for i in ix if i not in excluded], dtype=np.int64)
        audit = {"rows": np.concatenate(cand), "member": np.concatenate(member), "client": np.concatenate(owner)}
        log(f"MIA audit pool: {len(audit['rows'])} candidates, {int(audit['member'].sum())} included "
            f"(excluded candidates are null records: public sizes unchanged)")
    clients = [torch.as_tensor(train_np[ix], device=dev, dtype=torch.long) for ix in train_rows]

    # ---------------------------------------------------------------- attack plan
    f = n_malicious(cfg)
    atype = atk["type"]
    n_sybil = f if atype == "sybil" else 0
    n_total = n_real + n_sybil
    mal_rng = np.random.default_rng(_seed_int(seed, PURPOSE["malicious"]))
    f_place = f if atype not in ("none", "sybil") else int(round(float(acfg.get("f_design", 0.2)) * n_real))
    placed = choose_malicious(sizes, f_place, atk.get("placement", "random"), mal_rng) if f_place else []
    malicious = placed if atype not in ("none", "sybil") else []
    mal_rows = malicious + list(range(n_real, n_total))
    is_mal = np.zeros(n_total, bool); is_mal[mal_rows] = True
    sizes_total = np.concatenate([sizes, np.full(n_sybil, np.median(sizes))])
    thirds = size_thirds(sizes_total)
    noise_mode = resolve_noise_mode(atype, atk.get("noise_mode", "auto"), dp_on) if atype != "none" else "none"
    trng = np.random.default_rng(_seed_int(seed, PURPOSE["targets"]))
    if atk.get("target_source", "attacker_data") == "test_legacy":
        targets = make_targets(data.test, data.all_true, n_ent, int(ecfg.get("n_targets", 50)), trng)
        target_source = "test split (legacy behaviour, MN-21)"
    elif placed:
        targets = make_targets_from_attacker_data(train_np[np.concatenate([client_idx[c] for c in placed])],
                                                  data.all_true, n_ent, int(ecfg.get("n_targets", 50)), trng)
        target_source = f"training triples of the (would-be) malicious clients {placed}"
    else:
        targets, target_source = np.zeros((0, 3), dtype=np.int64), "none"
    poison = None
    if atype == "targeted":
        poison = torch.as_tensor(np.repeat(targets, int(atk.get("poison_copies", 50)), axis=0), device=dev)

    # ---------------------------------------------------------------- DP plan (per identity; public sizes only)
    R = int(tcfg["rounds_max"])
    dp_plan: List[Dict] = []
    orders = acc.MAIN_ORDERS
    if dp_on:
        for c in range(n_real):
            dp_plan.append(_dp_plan(dcfg, int(sizes[c]), R, paths))
        orders = acc.OPACUS_DEFAULT_ORDERS if dcfg.get("legacy_opacus_sampling") else acc.MAIN_ORDERS
        report_deltas = sorted(set([float(dcfg["delta"])] + [float(x) for x in dcfg.get("report_deltas", [])]))
        attacker_plan = {}
        for c in malicious:
            if atype == "targeted" and noise_mode == "inherit":
                attacker_plan[c] = _dp_plan(dcfg, int(len(clients[c]) + len(poison)), R, paths)
        sybil_plan = _dp_plan(dcfg, int(np.median(sizes)), R, paths) if (n_sybil and noise_mode == "matched") else None
    rdp_tot = [np.zeros(len(orders)) for _ in range(n_real)]
    steps_exec = [[0] * R for _ in range(n_real)]
    naive_sum = 0.0

    # ---------------------------------------------------------------- aggregation + integrity state
    trust = (TrustState(n_total, acfg["tau"], acfg["lam"], acfg.get("norm_bound", True))
             if acfg["method"] == "proposed" else None)
    root = None
    if acfg["method"] == "fltrust":
        rrng = np.random.default_rng(_seed_int(seed, PURPOSE["root"]))
        rs = min(int(acfg["root_size"]), len(data.vroot))
        root = torch.as_tensor(data.vroot[rrng.choice(len(data.vroot), rs, replace=False)], device=dev)
    icfg = cfg["integrity"]
    layer = IntegrityLayer(icfg["mode"], rd.path / "integrity_store", int(icfg.get("keep_last_k", 3)),
                           float(icfg.get("corrupt_p", 0.0)),
                           np.random.default_rng(_seed_int(seed, PURPOSE["corrupt"])))
    log_scores = bool(acfg.get("log_anomaly_scores", True))

    # ---------------------------------------------------------------- state (fresh or resumed)
    gparams = init_params(n_ent, n_rel, int(mcfg["dim"]), _gen(dev, seed, "init"), dev)   # random init, never warm-started
    P = num_params(gparams)
    es_on = bool(tcfg.get("early_stopping", True)) and not dp_on          # C3: DP runs execute all R rounds
    select_best = bool(tcfg.get("select_best", True))
    start_round, best, best_round, best_val, bad_evals = 1, None, 0, -1.0, 0
    rounds_log, weights_log, trust_log, attack_log = [], [], [], []
    eps_trace: List[List[float]] = []
    prev_update = torch.zeros(P, device=dev)
    ck = rd.path / "checkpoint.pt"
    s = None
    if ck.exists():
        try:
            s = torch.load(ck, map_location=dev, weights_only=True)
        except Exception as e:                 # unreadable (e.g. a pre-atomic partial write): keep it, restart cleanly
            bad = ck.with_name(f"checkpoint.unreadable-{time.strftime('%Y%m%dT%H%M%S', time.gmtime())}.pt")
            os.replace(ck, bad)
            log(f"checkpoint could not be read ({e!r}); moved to {bad.name}; the run restarts from round 1")
            s = None
    if s is not None:
        if s["run_id"] != rid or s["code_hash"] != code_hash():
            raise RuntimeError("checkpoint belongs to a different run/code version; delete it to restart")
        gparams, start_round = s["global"], s["round"] + 1
        best, best_round, best_val, bad_evals = s["best"], s["best_round"], s["best_val"], s["bad_evals"]
        rounds_log, weights_log, trust_log, attack_log = s["rounds_log"], s["weights_log"], s["trust_log"], s["attack_log"]
        prev_update, naive_sum = s["prev_update"], s["naive_sum"]
        eps_trace, steps_exec = s["eps_trace"], s["steps_exec"]
        rdp_tot = [np.array(x) for x in s["rdp_tot"]]
        if trust is not None:
            trust.load_state_dict(s["trust"])
        layer.load_state_dict(s["store"])
        log(f"resumed from round {s['round']}")

    stop_reason = "rounds_max"
    t_local_total = t_agg_total = t_eval_total = t_integrity_total = 0.0
    last_round = start_round - 1
    last_local: Dict[int, torch.Tensor] = {}
    last_start: Optional[torch.Tensor] = None
    non_finite_round = None
    for rnd in range(start_round, R + 1):
        # ---- pre-round budget check for fixed-sigma runs under a formal RDP budget (never overshoot)
        if dp_on and dcfg["stop_rule"] == "rdp_budget" and dcfg["mode"] == "fixed_sigma":
            proj = max(acc.eps_from_rdp(rdp_tot[c] + dp_plan[c]["steps"] * acc.rdp_vector(dp_plan[c]["q"], dp_plan[c]["sigmas"][rnd - 1], orders),
                                        float(dcfg["delta"]), orders) for c in range(n_real))
            if proj > float(dcfg["budget_epsilon"]):
                stop_reason = "rdp_budget_reached"; break
        gflat = flatten(gparams)
        if not bool(torch.isfinite(gflat).all()):
            non_finite_round = rnd
            stop_reason = "non_finite_global_model"
            log(f"round {rnd}: the global model contains non-finite values; every client would reject it - run stops")
            break
        t0 = time.time()
        layer.begin_round(rnd)
        ti0 = time.time()
        benv = layer.send("global", rnd, gflat)
        t_int = time.time() - ti0
        upd_by_id: Dict[int, torch.Tensor] = {}
        honest_mal, cstats, skipped = [], [], []
        start_by_id: Dict[int, torch.Tensor] = {}
        t_recv = 0.0
        for c in range(n_total):
            ti0 = time.time()
            got, rec = layer.receive(benv, f"client{c}", dev)
            t_recv += time.time() - ti0
            if got is None or not bool(torch.isfinite(got).all()):
                skipped.append(c)                       # MN-22 / CR-13: never train from an unverified/non-finite model
                continue
            start_by_id[c] = got
            if c >= n_real:
                continue                                # Sybil identity: crafted below
            start = unflatten(got, gparams)
            g = _gen(dev, seed, "local", rnd, c)
            pl = dp_plan[c] if dp_on else None
            if c in malicious and atype == "targeted":
                if dp_on and noise_mode == "inherit":
                    ap = attacker_plan[c]
                    data_c = torch.cat([clients[c], poison], 0)
                    newp, st = dp_local_train(start, data_c, n_ent, tcfg, normalize, margin, ap["sigmas"][rnd - 1],
                                              _clip(dcfg), ap["steps"], ap["q"], ap["expected_batch"], g,
                                              int(dcfg.get("physical_batch", 4096)))
                else:
                    newp, st = local_train(start, clients[c], n_ent, tcfg, normalize, margin, g, extra_triples=poison)
            elif dp_on and not (c in malicious and noise_mode == "none"):
                newp, st = dp_local_train(start, clients[c], n_ent, tcfg, normalize, margin, pl["sigmas"][rnd - 1],
                                          _clip(dcfg), pl["steps"], pl["q"], pl["expected_batch"], g,
                                          int(dcfg.get("physical_batch", 4096)))
                steps_exec[c][rnd - 1] = int(pl["steps"])
            else:
                newp, st = local_train(start, clients[c], n_ent, tcfg, normalize, margin, g)
            u = flatten(newp) - got
            upd_by_id[c] = u
            cstats.append(st)
            if c in malicious:
                honest_mal.append(u.clone())
        t_local = time.time() - t0 - t_recv
        t_int += t_recv
        ainfo = {}
        active_mal = [r for r in mal_rows if r in start_by_id]
        if active_mal:
            benign_idx = [i for i in range(n_real) if i not in malicious and i in upd_by_id]
            benign_U = torch.stack([upd_by_id[i] for i in benign_idx]) if benign_idx else prev_update[None, :]
            sybil_noise = None
            if atype == "sybil" and noise_mode == "matched":
                sybil_noise = []
                for c in active_mal:
                    z, _ = dp_local_train(unflatten(start_by_id[c], gparams), torch.zeros((0, 3), dtype=torch.long, device=dev),
                                          n_ent, tcfg, normalize, margin, sybil_plan["sigmas"][rnd - 1],
                                          _clip(dcfg), sybil_plan["steps"], sybil_plan["q"],
                                          sybil_plan["expected_batch"], _gen(dev, seed, "sybil", rnd, c),
                                          int(dcfg.get("physical_batch", 4096)))
                    sybil_noise.append(flatten(z) - start_by_id[c])
            cr = craft(atk, honest_mal if honest_mal else [prev_update], benign_U, prev_update, n_total,
                       len(active_mal), acfg, _gen(dev, seed, "craft", rnd), noise_mode=noise_mode,
                       sybil_noise=sybil_noise)
            for row, u in zip(active_mal, cr["updates"]):
                upd_by_id[row] = u
            ainfo = cr["info"]
        # ---- every identity sends its update; the server verifies and keeps ONLY verified, deserialised tensors
        ti0 = time.time()
        envs = {c: layer.send(f"client{c}", rnd, upd_by_id[c]) for c in sorted(upd_by_id)}
        verified, rejected_ids = {}, []
        for c, env in envs.items():
            got, rec = layer.receive(env, "server", dev)
            if got is None:
                rejected_ids.append(c)
            else:
                verified[c] = got
        del upd_by_id
        irec = layer.end_round()
        t_int += time.time() - ti0
        t_integrity_total += t_int
        idx = np.array(sorted(verified), dtype=np.int64)
        if len(idx) == 0:
            stop_reason = "no_verified_update"
            log(f"round {rnd}: no update passed verification - run stops")
            last_round = rnd
            break
        U = torch.stack([verified[c] for c in idx])
        if mia_on:
            last_local = {int(c): verified[c].detach().clone() for c in idx if c < n_real}
            last_start = gflat.detach().clone()
        del verified
        # ---- aggregation (on verified tensors only)
        t1 = time.time()
        root_update = None
        if root is not None:
            rp, _ = local_train(gparams, root, n_ent, {**tcfg, "local_epochs": 1}, normalize, margin, _gen(dev, seed, "root", rnd))
            root_update = flatten(rp) - gflat
        n_mal_present = int(sum(1 for c in idx if is_mal[c]))
        info = aggregate(acfg["method"], U, sizes_total[idx], acfg, n_mal_present, trust, root_update, idx=idx,
                         n_real=n_real)
        upd = info["update"]
        gparams = unflatten(gflat + upd, gparams)
        gparams = {k: v.clone() for k, v in gparams.items()}
        prev_update = upd.detach().clone()
        t_agg = time.time() - t1
        # ---- anomaly scores of the frozen rule logged in EVERY run (tau rule D14; per-size-third diagnostics, B4)
        sc_g = None
        if log_scores or acfg["method"] == "proposed":
            sc_g = anomaly_scores(U)
        # ---- accountant (steps actually executed by each real client this round)
        eps_now = {}
        if dp_on:
            per_round_legacy = []
            for c in range(n_real):
                pl = dp_plan[c]
                k = steps_exec[c][rnd - 1]
                if k and accounted:
                    rdp_tot[c] = rdp_tot[c] + k * acc.rdp_vector(pl["q"], pl["sigmas"][rnd - 1], orders)
                if dcfg["stop_rule"] == "legacy_naive_sum":
                    per_round_legacy.append(acc.legacy_round_epsilon(pl["q"], pl["steps"], pl["sigmas"][rnd - 1],
                                                                     float(dcfg["delta"])))
            eps_now = {c: ((acc.eps_from_rdp(rdp_tot[c], float(dcfg["delta"]), orders) if rdp_tot[c].any() else 0.0)
                           if accounted else float("nan")) for c in range(n_real)}
            if per_round_legacy:
                naive_sum += float(np.mean(per_round_legacy))
            eps_trace.append([eps_now[c] for c in range(n_real)])
        # ---- detection / influence diagnostics
        w_sub = np.asarray(info.get("weights", np.full(len(idx), np.nan)), float)
        w = np.full(n_total, np.nan); w[idx] = w_sub
        rej_sub = rejected_mask(acfg["method"], info, len(idx))
        row = {"round": rnd, "mean_client_loss": float(np.mean([s["loss"] for s in cstats])) if cstats else float("nan"),
               "update_norm": float(torch.linalg.vector_norm(upd)), "t_local_s": t_local, "t_agg_s": t_agg,
               "t_integrity_s": t_int,
               "bytes_up": int(len(envs) * (P * 4)), "bytes_down": int(n_total * P * 4),
               "n_participants": int(len(idx)), "n_skipped_broadcast": int(len(skipped)),
               "n_rejected_uploads": int(len(rejected_ids)),
               "malicious_weight_share": float(np.nansum(w[is_mal])) if mal_rows and not np.isnan(w_sub).all() else np.nan,
               "fallback": bool(info.get("fallback", False) or info.get("all_rejected", False))}
        if rej_sub is not None:
            rej = np.zeros(n_total, bool); rej[idx] = rej_sub
            present = np.zeros(n_total, bool); present[idx] = True
            if mal_rows and (is_mal & present).any():
                row["tpr"] = float(rej[is_mal & present].mean())
            if (~is_mal & present).any():
                row["fpr"] = float(rej[~is_mal & present].mean())
        if dp_on:
            row["eps_max"] = float(np.max(list(eps_now.values()))); row["eps_min"] = float(np.min(list(eps_now.values())))
            row["sigma_mean"] = float(np.mean([dp_plan[c]["sigmas"][rnd - 1] for c in range(n_real)]))
            dstats = [s for s in cstats if "clip_fraction" in s]
            row["clip_fraction"] = float(np.nanmean([s["clip_fraction"] for s in dstats])) if dstats else float("nan")
            row["grad_norm_q50"] = float(np.nanmean([s["grad_norm_q50"] for s in dstats])) if dstats else float("nan")
            row["n_nonfinite_examples_zeroed"] = int(sum(s.get("n_nonfinite_examples_zeroed", 0) for s in dstats))
            row["legacy_naive_eps_sum"] = naive_sum if dcfg["stop_rule"] == "legacy_naive_sum" else np.nan
        if irec.get("mode") != "off":
            row.update({"integrity_bytes": irec["bytes"], "integrity_hash_s": irec["hash_seconds"],
                        "integrity_verify_s": irec["verify_seconds"], "integrity_store_s": irec["store_seconds"],
                        "integrity_corrupted": irec["n_corrupted"], "integrity_rejected": irec["n_rejected"]})
        weights_log.append({"round": rnd, **{f"w{c}": float(w[c]) for c in range(n_total)}})
        if sc_g is not None:
            tau_cfg = float(acfg.get("tau", 3.0))
            for j, c in enumerate(idx.tolist()):
                rec_t = {"round": rnd, "client": c, "malicious": bool(is_mal[c]), "size_third": int(thirds[c]),
                         "data_share": float(sizes_total[c] / sizes_total.sum()),
                         "cos_to_ref": float(sc_g["cos"][j]), "a_dir": float(sc_g["a"][j]), "m_mag": float(sc_g["m"][j]),
                         "z_dir": float(sc_g["z_a"][j]), "z_mag": float(sc_g["z_m"][j]), "A": float(sc_g["A"][j]),
                         "norm": float(sc_g["norms"][j]), "tau": tau_cfg,
                         "flag_at_tau": bool(float(sc_g["A"][j]) > tau_cfg), "aggregator": acfg["method"]}
                if acfg["method"] == "proposed":
                    rec_t.update({"flag": bool(info["flags"][j]), "history": float(info["history"][j]),
                                  "trust": float(info["trust"][j]), "weight": float(info["weights"][j]),
                                  "fallback": bool(info["fallback"])})
                trust_log.append(rec_t)
        if ainfo:
            attack_log.append({"round": rnd, **ainfo})
        # ---- periodic validation on the fixed V_es subset (server data)
        t2 = time.time()
        if rnd % int(tcfg["eval_every"]) == 0 or rnd == R:
            ev = evaluate(gparams, data.es_subset, filt, normalize, dev)
            row["val_es_mrr"] = ev["mrr"]
            if ev["mrr"] > best_val:
                best_val, best_round, bad_evals = ev["mrr"], rnd, 0
                best = {k: v.detach().clone() for k, v in gparams.items()}
            else:
                bad_evals += 1
        t_eval_total += time.time() - t2
        t_local_total += t_local; t_agg_total += t_agg
        rounds_log.append(row)
        last_round = rnd
        log(f"round {rnd}/{R} loss={row['mean_client_loss']:.4f} "
            + (f"eps_max={row['eps_max']:.3f} " if accounted else "")
            + (f"val_es_mrr={row['val_es_mrr']:.4f} " if "val_es_mrr" in row else "")
            + (f"rejected={len(rejected_ids)} skipped={len(skipped)} " if (rejected_ids or skipped) else "")
            + f"({t_local + t_agg:.1f}s)")
        if int(tcfg.get("ckpt_every", 5)) and rnd % int(tcfg.get("ckpt_every", 5)) == 0:
            atomic_torch_save({"run_id": rid, "code_hash": code_hash(), "round": rnd, "global": gparams, "best": best,
                               "best_round": best_round, "best_val": best_val, "bad_evals": bad_evals,
                               "rounds_log": plain(rounds_log), "weights_log": plain(weights_log),
                               "trust_log": plain(trust_log), "attack_log": plain(attack_log),
                               "prev_update": prev_update, "naive_sum": float(naive_sum),
                               "rdp_tot": [x.tolist() for x in rdp_tot], "eps_trace": plain(eps_trace),
                               "steps_exec": plain(steps_exec), "trust": trust.state_dict() if trust else None,
                               "store": plain(layer.state_dict())}, ck)
        if dp_on and dcfg["stop_rule"] == "legacy_naive_sum" and naive_sum > float(dcfg["legacy_budget"]):
            stop_reason = "legacy_naive_budget_exceeded"; break
        if es_on and bad_evals >= int(tcfg["patience"]):
            stop_reason = "early_stopping"; break
        if stop_after is not None and rnd >= int(stop_after):
            stop_reason = "stop_after_rounds (timing pilot; NOT a complete run)"; break

    # ---------------------------------------------------------------- final evaluation (selected checkpoint)
    if last_round < 1:
        raise RuntimeError("no round was executed")
    if select_best:
        if best is None:
            raise RuntimeError("best-checkpoint selection enabled but no validation evaluation happened")
        final_params, selected_round = best, best_round
    else:
        final_params, selected_round = gparams, last_round
    if not all(bool(torch.isfinite(v).all()) for v in final_params.values()):
        raise RuntimeError("selected model contains non-finite values")
    t3 = time.time()
    val = evaluate(final_params, data.vsel, filt, normalize, dev, bootstrap=int(ecfg.get("bootstrap", 1000)), seed=seed)
    test = evaluate(final_params, data.test, filt, normalize, dev, bootstrap=int(ecfg.get("bootstrap", 1000)), seed=seed,
                    per_relation=True)
    tgt = targeted_success(final_params, targets, normalize, dev)
    t_final_eval = time.time() - t3
    final: Dict = {
        "run_id": rid, "config_hash": config_hash(cfg),
        "tier": cfg["tier"], "phase": cfg["phase"], "dataset": cfg["dataset"]["name"], "seed": seed,
        "status": "COMPLETE", "code_hash": code_hash(), "data_hash": data.content_hash,
        "partition_hash": part["content_hash"], "selection_refs": cfg.get("selection_refs", {}),
        "n_clients": n_real, "n_total_identities": n_total, "num_params": P,
        "partition": canonical_spec(cfg["partition"]),
        "config": cfg,
        "rounds_executed": last_round, "selected_round": selected_round, "stop_reason": stop_reason,
        "early_stopping_active": es_on, "best_checkpoint_selection": select_best,
        "non_finite_round": non_finite_round,
        "metric_convention": METRIC_CONVENTION,
        "val": {k: v for k, v in val.items() if k != "per_relation_mrr"},
        "test": {k: v for k, v in test.items() if k != "per_relation_mrr"},
        "targeted": {**tgt, "target_source": target_source},
        "runtime": {"total_s": time.time() - t_start, "local_training_s": t_local_total, "aggregation_s": t_agg_total,
                    "integrity_s": t_integrity_total, "es_eval_s": t_eval_total, "final_eval_s": t_final_eval,
                    "per_round_s": (t_local_total + t_agg_total) / max(len(rounds_log), 1),
                    "device": str(dev),
                    "gpu_peak_allocated_mb": (torch.cuda.max_memory_allocated(dev) / 1e6) if dev.type == "cuda" else None},
        "communication": {"bytes_per_update": int(P * 4), "bytes_up_total": int(sum(r["bytes_up"] for r in rounds_log)),
                          "bytes_down_total": int(sum(r["bytes_down"] for r in rounds_log)),
                          "note": "computed payload bytes (float32), not measured network traffic"},
    }
    if ecfg.get("legacy_protocol"):
        final["test_legacy_protocol"] = evaluate_legacy(final_params, data.test, data.all_true, normalize, dev,
                                                         int(ecfg.get("legacy_n", 300)), _seed_int(seed, PURPOSE["legacy_eval"]))
    write_json(rd.path / "per_relation_test_mrr.json", test.get("per_relation_mrr", {}))

    if stop_after is not None:
        final["partial_run"] = True
        final["partial_run_note"] = "timing pilot: executed fewer rounds than planned; metrics are NOT evidence"
    if dp_on and not accounted:
        final["privacy_ablation"] = {"mode": "no_noise", "clip": dcfg.get("clip"),
                                     "note": "DP3 cost-decomposition ablation: no noise, NO privacy guarantee"}
    if accounted:
        # Guarantee = composition over ALL steps each client actually executed (selection among iterates is
        # post-processing). Zero-out adjacency; see accountant.ADJACENCY.
        per_client = []
        for c in range(n_real):
            pl = dp_plan[c]
            ks = steps_exec[c][:last_round]
            sig = pl["sigmas"][:last_round]
            rdp = acc.composed_rdp(pl["q"], ks, sig, orders)
            e_main = acc.eps_from_rdp(rdp, float(dcfg["delta"]), orders) if rdp.any() else 0.0
            rec = {"client": c, "malicious": bool(is_mal[c]), "n": pl["n"], "q": pl["q"], "steps_per_round": pl["steps"],
                   "expected_batch": pl["expected_batch"], "steps_executed_per_round": ks,
                   "total_steps_executed": int(sum(ks)), "sigma0": sig[0], "sigma_last_executed": sig[-1],
                   "eps_rdp": e_main,
                   "eps_rdp_at": {repr(dl): (acc.eps_from_rdp(rdp, dl, orders) if rdp.any() else 0.0) for dl in report_deltas}}
            per_client.append(rec)
        worst = int(np.argmax([r["eps_rdp"] for r in per_client]))
        accrep = {"mechanism": "Poisson-subsampled Gaussian, per-example clipping (non-finite gradients zeroed), "
                               "dense noise on every coordinate, client-side (local DP-SGD)",
                  "privacy_unit": "one training triple of one client",
                  "adjacency": acc.ADJACENCY,
                  "sampling_design": dcfg.get("sampling", "fixed_batch"),
                  "accountant": "RDP (dp_accounting), orders=" + ("opacus_default" if dcfg.get("legacy_opacus_sampling") else "main"),
                  "delta": float(dcfg["delta"]), "clip": _clip(dcfg), "mode": dcfg["mode"],
                  "schedule": dcfg.get("schedule"), "target_epsilon": dcfg.get("target_epsilon"),
                  "rounds_planned": R, "rounds_executed": last_round, "per_client": per_client,
                  "eps_worst_client": per_client[worst]["eps_rdp"], "worst_client": worst,
                  "sigma_trace_worst_client": dp_plan[worst]["sigmas"][:last_round],
                  "sigma_schedule_per_client": [pl["sigmas"] for pl in dp_plan],
                  "eps_trace_per_round_per_client": eps_trace,
                  "orders_used": list(orders),
                  "public_sizes": sizes.tolist(), "delta_times_largest_size": float(dcfg["delta"]) * float(sizes.max()),
                  "not_covered": ["entity-level privacy (group privacy only)", "client-level privacy and participation",
                                  "client sizes N_k (public)", "dataset-level properties (which relations a client holds)",
                                  "duplicated or correlated facts", "privacy cost of hyperparameter tuning (disclosed)",
                                  "floating-point and PRNG side channels beyond the non-finite guard",
                                  "server validation data (assumed not client data)"]}
        wpl = dp_plan[worst]
        wks, wsig = steps_exec[worst][:last_round], wpl["sigmas"][:last_round]
        if any(wks):
            accrep["eps_rdp_public_api_worst_client"] = acc.rdp_epsilon_public_api(wpl["q"], wks, wsig, float(dcfg["delta"]), orders)
            if abs(accrep["eps_rdp_public_api_worst_client"] - accrep["eps_worst_client"]) > 1e-6 * max(1.0, accrep["eps_worst_client"]):
                raise RuntimeError("run-time RDP and public-API (zero-out) RDP disagree")
        if dcfg["mode"] == "calibrated":
            accrep["budget_ok"] = bool(accrep["eps_worst_client"] <= float(dcfg["target_epsilon"]) + 1e-9)
        if dcfg.get("budget_epsilon") is not None:
            accrep["budget_epsilon"] = float(dcfg["budget_epsilon"])
            accrep["budget_ok"] = bool(accrep["eps_worst_client"] <= float(dcfg["budget_epsilon"]) + 1e-9)
        if dcfg["stop_rule"] == "legacy_naive_sum":
            accrep["legacy_naive_sum_of_round_means"] = naive_sum
            accrep["legacy_note"] = ("sum over rounds of the mean per-round client epsilon: the OLD notebook's number. "
                                     "It is NOT a valid composition and is reported only to reproduce the old claim.")
        if dcfg.get("pld_crosscheck", False) and any(wks):
            accrep["eps_pld_worst_client"] = acc.pld_epsilon(wpl["q"], wks, wsig, float(dcfg["delta"]))
        if dcfg.get("prv_crosscheck", False) and any(wks):
            accrep["eps_prv_worst_client"] = acc.prv_epsilon(wpl["q"], wks, wsig, float(dcfg["delta"]))
        # assert the implemented schedule is the configured one (replaces the old hard-coded "IMPLEMENTED")
        if dcfg["mode"] == "calibrated":
            g = acc.schedule_multipliers(dcfg["schedule"]["shape"], float(dcfg["schedule"]["rho"]), R,
                                         int(dcfg["schedule"].get("update_every", 5)))
            obs = np.array(dp_plan[worst]["sigmas"]) / dp_plan[worst]["sigmas"][0]
            accrep["schedule_verified"] = bool(np.allclose(obs, g, rtol=1e-9))
            if not accrep["schedule_verified"]:
                raise RuntimeError("executed noise schedule differs from the configured schedule")
        write_json(rd.path / "accountant.json", accrep)
        final["privacy"] = {"eps": accrep["eps_worst_client"], "delta": float(dcfg["delta"]),
                            "eps_at": per_client[worst]["eps_rdp_at"], "budget_ok": accrep.get("budget_ok"),
                            "legacy_naive_sum": accrep.get("legacy_naive_sum_of_round_means"),
                            "eps_pld": accrep.get("eps_pld_worst_client"),
                            "eps_prv_upper": (accrep.get("eps_prv_worst_client") or {}).get("upper"),
                            "adjacency": acc.ADJACENCY, "sampling_design": accrep["sampling_design"],
                            "clip": _clip(dcfg), "sigma0_worst": per_client[worst]["sigma0"],
                            "q_worst": per_client[worst]["q"], "rounds_executed": last_round, "mode": dcfg["mode"],
                            "schedule": dcfg.get("schedule"),
                            "delta_times_largest_size": accrep["delta_times_largest_size"]}

    if mal_rows:
        write_json(rd.path / "attack.json", {"type": atype, "malicious_rows": mal_rows, "real_malicious": malicious,
                                             "n_sybil": n_sybil, "placement": atk.get("placement"),
                                             "knowledge": atk.get("knowledge"), "strength": atk.get("strength"),
                                             "fraction": atk.get("fraction"), "noise_mode": noise_mode,
                                             "target_source": target_source, "per_round": attack_log,
                                             "targets": targets.tolist()})
        mws = [r["malicious_weight_share"] for r in rounds_log if not np.isnan(r["malicious_weight_share"])]
        final["attack"] = {"type": atype, "n_malicious": len(mal_rows), "noise_mode": noise_mode,
                           "mean_malicious_weight_share": float(np.mean(mws)) if mws else None,
                           "mean_tpr": float(np.nanmean([r.get("tpr", np.nan) for r in rounds_log])) if any("tpr" in r for r in rounds_log) else None,
                           "mean_fpr": float(np.nanmean([r.get("fpr", np.nan) for r in rounds_log])) if any("fpr" in r for r in rounds_log) else None,
                           "adaptive_mean_gamma": float(np.mean([a["gamma"] for a in attack_log])) if attack_log and "gamma" in attack_log[0] else None}
    elif any("fpr" in r for r in rounds_log):
        final["benign_fpr"] = float(np.nanmean([r.get("fpr", np.nan) for r in rounds_log]))
    if trust_log:
        tl = pd.DataFrame(trust_log)
        ben = tl[~tl["malicious"]]
        final["anomaly_scores"] = {"benign_fpr_at_cfg_tau": float(ben["flag_at_tau"].mean()),
                                   "benign_fpr_at_cfg_tau_by_size_third": {int(k): float(v) for k, v in ben.groupby("size_third")["flag_at_tau"].mean().items()},
                                   "tau_cfg": float(acfg.get("tau", 3.0))}
    if icfg["mode"] != "off":
        irep = {"mode": icfg["mode"], "id_scheme": "sha256-<hex> of canonical serialisation (NOT an IPFS CID)",
                "verified_bytes_are_aggregated": icfg["mode"] in ("hash_only", "full_store_last_k"),
                "corrupt_p": float(icfg.get("corrupt_p", 0.0)), **summarize_stats(layer.stats)}
        if icfg["mode"] in ("hash_only", "full_store_last_k") and irep.get("n_corrupted"):
            if irep["n_corrupted_and_consumed"] != 0 or irep["detection_rate"] != 1.0:
                raise RuntimeError("integrity verification let a corrupted object through")
        if icfg["mode"] == "full_store_last_k" and icfg.get("tamper_p"):
            irep["tamper_tests"] = [tamper_test(rd.path / "integrity_store", float(p), np.random.default_rng(_seed_int(seed, PURPOSE["tamper"], i)))
                                    for i, p in enumerate(icfg["tamper_p"])]
            for tt in irep["tamper_tests"]:
                if tt["n_tampered"] and tt["detection_rate"] != 1.0:
                    raise RuntimeError("integrity simulation failed to detect a tampered object")
        write_json(rd.path / "integrity.json", irep)
        final["integrity"] = {k: irep.get(k) for k in ("mean_bytes_per_round", "mean_hash_s", "mean_verify_s",
                                                       "mean_store_s", "n_corrupted", "n_rejected",
                                                       "n_corrupted_and_consumed", "detection_rate")}
    if mia_on:
        from .mia import run_audit
        mres, mscores = run_audit(final_params, train_np[audit["rows"]], audit["member"], audit["client"],
                                  data.vroot, normalize, dev, last_local, last_start, gparams,
                                  eps_dp=(final.get("privacy") or {}).get("eps"), delta=float(dcfg.get("delta", 1e-6)),
                                  guesses=mcfg_mia.get("guesses", [100, 300, 1000]),
                                  confidence=float(mcfg_mia.get("confidence", 0.95)),
                                  inclusion_p=float(mcfg_mia.get("inclusion_p", 0.5)))
        if mres.get("lower_bound_exceeds_accountant"):
            log("WARNING: empirical epsilon lower bound exceeds the accountant's epsilon - investigate before use")
        write_json(rd.path / "mia.json", mres)
        write_csv(rd.path / "mia_scores.csv", mscores)
        final["mia"] = {k: mres.get(k) for k in ("primary_attack", "auc", "tpr_at_fpr_1pct", "tpr_at_fpr_0_1pct",
                                                 "fpr_resolvable_0_1pct", "eps_lower_bound", "n_candidates",
                                                 "lower_bound_exceeds_accountant")}

    if bool(tcfg.get("keep_final_weights", False)):
        atomic_torch_save({k: v.detach().cpu() for k, v in final_params.items()}, rd.path / "final_weights.pt")
    write_csv(rd.path / "rounds.csv", pd.DataFrame(rounds_log))
    write_csv(rd.path / "weights_rounds.csv", pd.DataFrame(weights_log))
    if trust_log:
        write_csv(rd.path / "trust_rounds.csv", pd.DataFrame(trust_log))
    write_json(rd.path / "final.json", final)
    if ck.exists():
        ck.unlink()
    log(f"DONE val_mrr={val['mrr']:.4f} test_mrr={test['mrr']:.4f} rounds={last_round} ({stop_reason})")
    return final
