# Superseded versions

The seven Phase C reports and the revision README as delivered on 2026-11-02 (evening), before the GPU pilot update of 2026-11-04. Kept for the record; the current versions are one folder up.
