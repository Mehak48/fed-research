# Table 10 — integrity overhead (operational; hardware named)

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| dataset | configuration | n_runs | training+aggregation s/round | integrity s/round | integrity share of round | integrity bytes/round | hardware | status | test.mrr | corrupted objects (mean) | rejected objects (mean) | corrupted and consumed (mean) | detection rate (mean) | note |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| FB15k-237 | FedAvg non-private, integrity ON (hash_only) | 1 | 0.07489 | 0.04172 | 0.3578 | 1.762e+07 | CPU | OK |  |  |  |  |  |  |
| FB15k-237 | FedAvg non-private, integrity OFF | 1 | 0.08804 | 0.0001835 | 0.00208 | 0 | CPU | OK |  |  |  |  |  |  |
| FB15k-237 | Complete method, integrity ON (hash_only) | 1 | 0.4036 | 0.03927 | 0.08867 | 1.762e+07 | CPU | OK |  |  |  |  |  |  |
| FB15k-237 | Complete method, integrity OFF | 1 | 0.491 | 0.0001926 | 0.000392 | 0 | CPU | OK |  |  |  |  |  |  |
| FB15k-237 | I2 corruption in transit p=0.1, hash_only |  |  |  |  |  |  | OK | 0.005 (n=1) | 4 | 4 | 0 | 1 | verification is not a poisoning defence; a poisoned update hashes correctly |
| FB15k-237 | I2 corruption in transit p=0.1, transport_only |  |  |  |  |  |  | OK | 0.005 (n=1) | 4 | 0 | 4 | 0 | verification is not a poisoning defence; a poisoned update hashes correctly |
| WN18RR | FedAvg non-private, integrity ON (hash_only) | 1 | 0.08933 | 0.05104 | 0.3636 | 2.257e+07 | CPU | OK |  |  |  |  |  |  |
| WN18RR | FedAvg non-private, integrity OFF | 1 | 0.0847 | 0.0001338 | 0.001577 | 0 | CPU | OK |  |  |  |  |  |  |
| WN18RR | Complete method, integrity ON (hash_only) | 1 | 0.4829 | 0.05196 | 0.09715 | 2.257e+07 | CPU | OK |  |  |  |  |  |  |
| WN18RR | Complete method, integrity OFF | 1 | 0.4661 | 0.0001323 | 0.0002838 | 0 | CPU | OK |  |  |  |  |  |  |
| WN18RR | I2 corruption in transit p=0.1, hash_only |  |  |  |  |  |  | OK | 0.001 (n=1) | 4 | 4 | 0 | 1 | verification is not a poisoning defence; a poisoned update hashes correctly |
| WN18RR | I2 corruption in transit p=0.1, transport_only |  |  |  |  |  |  | OK | 0.001 (n=1) | 4 | 0 | 4 | 0 | verification is not a poisoning defence; a poisoned update hashes correctly |
| CoDEx-M | FedAvg non-private, integrity ON (hash_only) | 1 | 0.07659 | 0.03572 | 0.3181 | 1.634e+07 | CPU | OK |  |  |  |  |  |  |
| CoDEx-M | FedAvg non-private, integrity OFF | 1 | 0.07051 | 0.0001068 | 0.001513 | 0 | CPU | OK |  |  |  |  |  |  |
| CoDEx-M | Complete method, integrity ON (hash_only) | 1 | 0.3805 | 0.03602 | 0.08648 | 1.634e+07 | CPU | OK |  |  |  |  |  |  |
| CoDEx-M | Complete method, integrity OFF | 1 | 0.4014 | 0.0001245 | 0.0003099 | 0 | CPU | OK |  |  |  |  |  |  |
| CoDEx-M | I2 corruption in transit p=0.1, hash_only |  |  |  |  |  |  | OK | 0.002 (n=1) | 4 | 4 | 0 | 1 | verification is not a poisoning defence; a poisoned update hashes correctly |
| CoDEx-M | I2 corruption in transit p=0.1, transport_only |  |  |  |  |  |  | OK | 0.002 (n=1) | 4 | 0 | 4 | 0 | verification is not a poisoning defence; a poisoned update hashes correctly |
