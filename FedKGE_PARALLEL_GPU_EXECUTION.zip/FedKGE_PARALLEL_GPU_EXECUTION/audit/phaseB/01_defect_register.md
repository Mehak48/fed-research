# 01 — Consolidated register of methodological defects (Phase B, item 1)

**Status:** Phase B planning document. Nothing here was implemented, executed or retrained.
**Machine-readable version:** `data/defect_register.csv`. The tables below are generated from the same list by `scripts/phaseB_defect_register.py`, so the two cannot disagree.

## How to read this register

- **Merged sources.**
  - Phase A defects: CR-1…12, MJ-1…14, MN-1…6, OP-1…8.
  - Phase A review of the revision package: G1–G15, MN-7…9.
  - New findings from the Phase B design review: CR-13, MJ-15…21, MN-10…20, OP-9…11.
  - Three more found by the independent review of the Phase B drafts: CR-14, MN-21, MN-22.
- **Contradictions.** X01–X24 are kept as evidence links in the `related` column, not as separate defects; the mapping is at the end.
- **Severity classes** follow master prompt §5: Critical correctness defect, Major experimental deficiency, Minor implementation issue, Optional improvement.
- **"Revision status"** describes the *design* of `fedkge_revision_P1-P4.zip` only.
  - "Addressed by design (unexecuted)" means the code contains a fix. No experiment has run it, and only 27 of 53 tests could be run in Phase A (no PyTorch available).
  - Nothing in this column is evidence of a result.
- **"Decision"** points to `02_design_decisions.md`. **"Phase"** is the phase that implements or verifies the fix (C repair, D datasets, E experiments, F tables and figures, G freeze).
- **Naming:** experiment blocks are named P2.x, T, L, N, DP, R, I, M, X, O (`06`). D1–D18 always refer to *decisions*.

## Counts

| Severity | Total | From Phase A | From the revision review | New in Phase B |
|---|---|---|---|---|
| Critical | 14 | 12 | 0 | 2 (CR-13, CR-14) |
| Major | 32 | 14 | 11 (G1–G4, G6–G10, G14–G15) | 7 (MJ-15…21) |
| Minor | 26 | 6 | 7 (MN-7…9, G5, G11–G13) | 13 (MN-10…22) |
| Optional | 11 | 8 | 0 | 3 (OP-9…11) |
| **Total** | **83** | **40** | **18** | **25** |

## The Phase B findings that matter most

1. **CR-14: the privacy statement as written was false.**
   - The revision declares add/remove-one-triple adjacency but publishes each client's exact size. The size sets the FedAvg weights and the gradient normalisation, and, in design A, also the sampling rate and the number of steps.
   - Neighbouring datasets have different sizes, so an adversary who knows the other triples can read membership off the size.
   - Fix: **zero-out adjacency**. One triple is replaced by a null record with zero gradient, so the size stays the same and stays public.
   - The Poisson-subsampled Gaussian bounds, and therefore every ε value, are unchanged. The guarantee then hides *which* triples a client holds, not *how many*.
2. **CR-13: integrity verification is not in the data path.**
   - In the revision's round loop, the server hashes each update and then re-hashes the same in-memory bytes. Aggregation then uses the in-memory tensors, not the verified bytes.
   - So verification can never fail during training, and an "integrity on/off" comparison would measure hashing time only.
   - Fix: aggregate only tensors deserialised from bytes that passed verification, and test it with injected corruption (block I2).
3. **MJ-15: the planned membership-inference audit compares two different distributions.**
   - FB15k-237's validation and test sets were built by *removing* triples whose entity pairs are directly linked in training (Toutanova & Chen 2015).
   - Using test triples as non-members therefore measures that construction difference as well as memorisation.
   - Fix: an audit pool drawn from each client's own training triples, each candidate included in training with probability ½.
4. **MJ-16 / MJ-17: the DP settings that decide utility were fixed in advance.**
   - The Phase B σ calculation (`data/phaseB_sigma_plan.csv`) shows the per-step noise-to-clip ratio at ε = 4, across the tuning grid q = 0.02–0.10, ranges from 1.3 (YAGO3-10) to 22.7 (WN18RR).
   - The sampling rate, learning rate and number of rounds must therefore be tuned under a pre-registered, validation-only rule, not fixed.
5. **MJ-18 / MJ-19: two sources of selection bias.**
   - The revision selects settings on the same seeds whose test results it reports.
   - It also tunes DP settings but not the non-private reference.
   - Both bias comparisons in the method's favour.
6. **MJ-20: DP-Flames already exists.**
   - DP-Flames (Hu et al., WWW 2023) already proposes triple-level DP for federated KGE, with validation-driven adaptive noise and triple-membership attacks.
   - The "adaptive DP" contribution must be repositioned and defined precisely (decision D12).
7. **MJ-21: YAGO3-10 has documented leakage.**
   - 2,561 of its 5,000 test triples have duplicates in training through two near-duplicate relations (Akrami et al. 2020).
   - This is why Phase B now recommends CoDEx-M as the default third dataset (decision D5).
8. **MN-11: client-level DP is infeasible with 10 clients.**
   - At ε = 4 over 100 rounds, the noise on the averaged update is about 1,540 times the clipping bound on FB15k-237 (`data/phaseB_sigma_plan.json`).
   - The Phase A suggestion to add it as an optional regime is withdrawn.

## Risks (not defects — outcomes the experiments may show and that must then be reported)

| ID | Risk | Why it is plausible | How the plan handles it |
|---|---|---|---|
| RK-1 | DP utility near zero at ε ≤ 4 on WN18RR | WN18RR has ≈ 47 parameters per training triple. Its noise-to-clip ratio at ε = 4 is 9.6–22.7 across the tuning grid (q = 0.10–0.02), versus 1.8–4.4 for FB15k-237 | Report it; no dataset is dropped for low MRR; D10 trigger |
| RK-2 | Trust-based detection loses power under DP noise | Dense noise dominates single-step updates. Per-round updates average it out only partly | H2 is tested under DP; trust without DP (R5) is reported; failure is reported |
| RK-3 | Non-IID and size-related false positives | At α = 0.1, honest clients hold very different relation mixes (median mean JS divergence ≈ 0.51 on FB15k-237, `data/phaseB_partition_feasibility.csv`). Smaller clients have noisier updates under both sampling designs | Benign FPR by client-size third; FPR-calibrated τ (D14); D15 trigger |
| RK-4 | Compute exceeds a free-tier budget | Core estimate 47–393 GPU-h (reduced profile, CoDEx-M; `07_compute_feasibility.md`) | Stage-2 pilot (1–4 GPU-h) measures real costs before committing |
| RK-5 | H3 not testable | A well-regularised TransE may show no measurable membership advantage even without DP | Pre-registered testability rule (03, §13.3) |
| RK-6 | FLTrust and Krum degenerate under DP | FLTrust's server update is noise-free while client updates are noisy, so cosine scores may all be near 0 | Report rejection and fallback rates; no tuning toward a win |
| RK-7 | Non-bit-reproducible GPU runs | `index_add_` and scatter operations are non-deterministic on GPUs | Record the device; keep a paired comparison on one platform where possible |
| RK-8 | Contribution judged incremental | The components are individually standard | Contribution framed as a rigorous, correctly accounted three-dataset evaluation (04, 02-D12) |

## Register

### Critical (14)

| ID | Area | Defect | Revision status | Resolution | Decision | Phase | Verification |
|---|---|---|---|---|---|---|---|
| CR-1 | Result provenance | Hard-coded, formula-derived and simulated numbers presented as findings | Partially addressed | Withdraw all; every table/figure generated only from saved run records; provenance label on every number | - | C-F | linter test_no_hardcoded_results; Table 14 completion status; provenance column in every table |
| CR-2 | Privacy | Invalid epsilon (sum of per-round client means, delta not composed) and invalid stop rule | Addressed by design (unexecuted) | Per-client RDP over all executed steps; worst-client eps; PLD cross-check; calibration to eps* | D3 | C | test_accountant; Phase B checks: same-library cross-check (within 0.2 %), own numerical quadrature (agrees to 1e-3), PRV accountant (different library) brackets the PLD value |
| CR-3 | Claims | Headline row combines non-private utility with mechanisms never active in that model | Addressed by design (unexecuted) | Complete-method runs (DP + trust + integrity active together, block R1p); separate rows for each configuration | D9 | E-F | Table 3 rows built from one run configuration each |
| CR-4 | Evaluation | Invalid protocol described as full-test evaluation | Addressed by design (unexecuted) | Full filtered head+tail ranking, realistic ties, selection on V_sel only, test evaluated once | - | C | test_filtered_head_tail_realistic_matches_bruteforce, test_ties_are_not_optimistic |
| CR-5 | Statistics | Statistics computed over rounds of single runs (pseudo-replication) | Addressed by design (unexecuted) | Seed-level paired statistics; per-seed values; Holm within families | D8,D9 | E-F | stats tests; Table 12 |
| CR-6 | Trust/robustness | Trust described as cosine of updates; implemented from un-noised client losses | Addressed in code; not executed | Update-based trust on transmitted (DP-noised) updates only; real attack experiments | D14,D15,D16 | C,E | R1-R5 blocks; detection TPR/FPR logged |
| CR-7 | Privacy | Warm start from the non-private checkpoint in DP code and claimed in tables | Addressed by design (unexecuted) | Config validation rejects warm_start | - | C | test_config_guards |
| CR-8 | Data/partition | Partition misreported (74.26 %, 'semantic clustering') | Addressed by design (unexecuted) | Report the partition actually trained, with measured per-client statistics | D4 | D | partition audit report (Table 2) |
| CR-9 | Integrity | 'IPFS integrity' stored random tensors, used fake CIDs and a literal latency | Addressed by design (unexecuted) | Honest SHA-256 content-addressed layer; measured overhead; no IPFS claim unless real IPFS is used | D7 | C,E | I1/I2 blocks; tamper tests |
| CR-10 | Privacy | 'Adaptive DP' claimed but never run; schedule ablation fabricated | Addressed in code (4C); not executed | Deterministic schedules calibrated to equal eps, executed for all R rounds; claim depends on decision D12 | D12,D13 | C,E | T3 + DP2/DP2h blocks; schedule_verified assertion |
| CR-11 | Implementation | Executed configuration differs from the stated one | Addressed by design (unexecuted) | One corrected trainer for all conditions; legacy behaviour only in labelled replica rows | - | C | test_correct_negatives_*, test_legacy_p4_bug_is_reproduced |
| CR-12 | Privacy | DP vs non-DP comparison confounded (model, negatives, epochs, batch, evaluation) | Addressed by design (unexecuted) | DP ladder on the same partition/trainer, paired by seed (L4, DP3) | - | E | L4 and DP3 blocks |
| CR-13 | Integrity | Integrity verification is not in the data path of the revision | Not addressed (verification can never fail during training) | serialize -> store -> fetch -> verify -> deserialize -> aggregate the verified tensor; reject on mismatch; tamper-injection experiment with integrity on/off | D7 | C,E | I2 block (detection rate must be 1.0; utility with/without verification under corruption); unit test that a corrupted object never reaches aggregate() |
| CR-14 | Privacy | Add/remove adjacency is inconsistent with publishing exact client sizes | Not addressed (statement as written is false) | Use zero-out adjacency (one triple replaced by a null record with zero gradient; size public and unchanged); the Poisson-subsampled Gaussian bounds and every eps value stay the same; the guarantee hides which triples a client holds, not how many | D2 | B,C | 03 section 7.2; accountant metadata states the adjacency |

### Major (32)

| ID | Area | Defect | Revision status | Resolution | Decision | Phase | Verification |
|---|---|---|---|---|---|---|---|
| MJ-1 | Benchmark | One dataset only (three required) | Partially addressed | FB15k-237 + WN18RR + third dataset (D5) under one pipeline | D5 | D | dataset cards + Table 1 |
| MJ-2 | Statistics | Single seed | Addressed by design (unexecuted) | 5 seeds; 10 for headline blocks | D8 | E | Table 12 |
| MJ-3 | Baselines | No measured centralised baseline, no real aggregation or DP baselines | Partially addressed | N1, N2, DP1, R1, R4 blocks | D17 | E | Table 4 |
| MJ-4 | Trust/robustness | No threat model, no real attacks, no success definitions, no benign FPR | Partially addressed | THREAT_MODEL (03a); 7 attacks with success metrics; benign FPR by client size | D16 | B,E | R2-R5 blocks; Table 9 |
| MJ-5 | Thresholds | No threshold sweeps with validation-only selection; no tau selection rule | Partially addressed | Threshold inventory; pre-registered rules incl. FPR-calibrated tau | D13,D14 | B,E | T2b, T3, X1-X4; selection files with rule hashes |
| MJ-6 | Ablations | No ablations (DP-only, trust-only, full, -integrity, -defence) | Partially addressed | Ablation set mapped to MP 13 items 1-9 (06_experiment_matrix.md) | - | E | Table 5 |
| MJ-7 | Data/partition | 'Non-IID' measured on the global graph, not across clients | Addressed by design (unexecuted) | Across-client statistics (JS, Hellinger, Gini of sizes) | D4 | D | Table 2 |
| MJ-8 | Data/partition | 5 relation-disjoint clients make robust aggregation ill-posed and leak relation ownership | Addressed by design (unexecuted) | 10 Dirichlet clients; legacy split kept for replicas only | D4 | D | Table 2 |
| MJ-9 | Privacy | Privacy claims under-specified (unit, adjacency, threat model, exclusions) | Partially addressed | Formal statement in 03 section 7 and 03a; exclusions listed | D2 | B | review of 03/03a |
| MJ-10 | Privacy | DP utility collapse not investigated | Partially addressed | DP ladder + pre-registered tuning of q, lr, C, R; decomposition (DP3) | D10,D11,D13 | E | T2a-T2d, DP3, L4 |
| MJ-11 | Claims | Hypotheses H1-H3 not formally defined | Partially addressed | Formal hypotheses with decision rules (03 section 13) | D9 | B | pre-registration before Stage 4 |
| MJ-12 | Overhead | Overheads hard-coded; no integrity on/off comparison | Addressed by design (unexecuted) | Measured hash/verify/store/aggregation times; I1/I2 blocks | D7 | E | Tables 10-11 |
| MJ-13 | Positioning | Contribution weakly positioned; prior-work numbers unverified and protocol-mismatched | Not addressed | Position against FedE, FedR, FedLU, DP-Flames; never mix protocols in one table | D12,D17 | manuscript phase | related-work check |
| MJ-14 | Planning | No experiment matrix or cost estimate for Phases 5-8; no 3D plots; most tables missing | Partially addressed | Full matrix + cost model (06, 07); table/figure traceability | D18 | B,F | experiment_matrix.csv |
| MJ-15 | Privacy (MIA) | MIA design compares training triples with official test triples | Not addressed (module disabled) | Audit pool drawn from each client's training triples, each candidate included in training with probability 1/2 (members and non-members from the same distribution); pre-registered primary attack and pooling; TPR at low FPR; one-run audit lower bound (Steinke, Nasr & Jagielski 2023); testability rule | D6 | C,E | M1 block; unit test that non-members are never trained on |
| MJ-16 | Privacy | Fixed-batch design fails for small clients when the batch is enlarged | Not addressed | Offer design Q (one shared sigma and sampling rate, no N_k >= B constraint) next to design A; T2d decides on validation MRR; benign FPR by client-size third measured for both | D11 | C,E | P2.3, T2d |
| MJ-17 | Privacy | DP utility levers (sampling rate, lr, rounds) fixed a priori | Not addressed | Pre-registered DP tuning on a tuning seed (T2a-T2d), validation only, disclosed | D13 | E | T2a-T2d blocks |
| MJ-18 | Statistics | Selection and final reporting use the same seeds | Not addressed | Separate tuning seed(s) from confirmatory seeds; freeze selections (hashes) before Stage 4 | D13 | E | selection files reference S_TUNE only |
| MJ-19 | Baselines | Asymmetric tuning budget: DP settings tuned, non-private settings fixed | Not addressed | Same grid for the shared optimiser settings (lr x batch) for centralised and FedAvg (T1); the remaining DP-specific tuning (21 cells vs 6 per dataset) is disclosed | D13 | E | T1 block |
| MJ-20 | Positioning | Closest prior work not addressed | Not addressed | Reposition the contribution; define 'adaptive' precisely (D12); do not compare numbers across protocols | D12,D17 | B, manuscript | related-work section check |
| MJ-21 | Benchmark | YAGO3-10 leakage and duplicated facts | n/a (dataset choice) | Default third dataset CoDEx-M; YAGO3-10 only as an extension with the leakage caveat | D5 | D | dataset card |
| G1 | Revision package | Revision never executed: no smoke, dev or final outputs | Gap in revision | Stage 0-4 execution plan with gates | D18 | C-E | Table 14 |
| G2 | Revision package | Phases 5-8 not delivered (no matrices for trust/attacks/baselines/integrity/MIA, no tau rule) | Gap in revision | Matrix blocks R*, I*, M1, X*; tau rule D14 | D14 | C,E | experiment_matrix.csv |
| G3 | Revision package | THREAT_MODEL.md referenced but missing | Gap in revision | Draft in 03a_threat_model.md | D16 | B | 03a |
| G4 | Revision package | alpha in {0.1, 1.0} only | Gap in revision | alpha {0.1,0.5,1.0} + IID | D4 | D | N3, X1 |
| G6 | Revision package | Early stopping vs calibrated schedules | Gap in revision | DP runs execute all R rounds; checkpoint selection is post-processing | D13 | C | rounds_executed = R in DP runs |
| G7 | Revision package | Attackers skip DP noise (targeted, Sybil) | Gap in revision | Noise modes inherit/matched (main), none (X5) | D16 | C,E | attack.json noise_mode |
| G8 | Revision package | Per-client sigma vs magnitude anomaly | Gap in revision | Benign FPR by client-size third measured for both sampling designs (P2.3, T2d); variant trigger (D15) | D11,D15 | E | trust_rounds.csv |
| G9 | Revision package | DP batch/optimiser/lr fixed a priori | Gap in revision | T2a-T2d tuning blocks | D13 | E | T2a-T2d blocks |
| G10 | Revision package | Tuning privacy cost not discussed | Gap in revision | Disclose (default) or account (OP-2) | D13 | B,G | limitations |
| G14 | Revision package | n = 5 cannot give exact p < 0.05 | Gap in revision | Effect sizes + CIs primary; 10 seeds for headline (full profile) | D8 | E | Table 12 |
| G15 | Revision package | WN18RR partition feasibility at alpha 0.1 | Gap in revision | Simulation with unverified WN18RR counts: feasible, but ~96 % of draws rejected; binding check in Phase D; fallback rule pre-approved | D4 | D | phaseB_partition_feasibility.csv |

### Minor (26)

| ID | Area | Defect | Revision status | Resolution | Decision | Phase | Verification |
|---|---|---|---|---|---|---|---|
| MN-1 | Data/partition | Legacy Gini formula slightly biased | Addressed by design (unexecuted) | Revision formula | - | C | unit test |
| MN-2 | Documentation | Phase 4 notebook header contradicts its configuration | Addressed by design (unexecuted) | Legacy frozen; new configs only | - | C | - |
| MN-3 | Documentation | Figure numbering collisions; captions describe what plots do not show | Not addressed | Regenerate all figures from records | - | F | figure manifest |
| MN-4 | Implementation | Silent fallbacks (eps = sigma*0.5; stub result dictionaries) | Addressed by design (unexecuted) | Failures raise; no defaults in except-blocks | - | C | linter |
| MN-5 | Evaluation | Legacy evaluation subsample drawn from the global RNG | Addressed by design (unexecuted) | Purpose-specific seeded generators | - | C | determinism test |
| MN-6 | Documentation | Manuscript wording errors | Not addressed | Manuscript phase | - | manuscript | - |
| MN-7 | Reporting | plotting.py imports a non-existent fedkge.tables; PNG at 200 dpi only | Not addressed | Fix import; PNG+PDF+SVG | - | C,F | plot smoke test |
| MN-8 | Reproducibility | Deprecated datetime.utcnow(); no scripts/ entry points; PyKEEN download without licence gate | Not addressed | Timezone-aware timestamps; scripts/; explicit licence confirmation flag | - | C | test for the gate |
| MN-9 | Data/partition | Re-drawing until the minimum size holds yields a truncated Dirichlet | Documented | Report attempts and acceptance rate; compare heterogeneity by measured statistics, not by alpha | D4 | D | phaseB_partition_feasibility.csv (WN18RR alpha 0.1: about 96 % of draws rejected) |
| MN-10 | Threat model | FedAvg weights use self-reported client sizes | Not addressed | Sizes declared and registered before training; misreporting is an attack parameter | D16 | B | 03a |
| MN-11 | Privacy | Client-level DP is not feasible with 10 clients | n/a | Do not run client-level DP; state as limitation (changes Phase A D2) | D2 | B | - |
| MN-12 | Data | 20 % of the official validation split is reserved as FLTrust root data | Documented in code | Disclose; V_sel = 80 % used for all selection | - | D | dataset card |
| MN-13 | Statistics | Query-bootstrap CI is within-run uncertainty only | Partially addressed | Label it as such; seed-level CI is the primary uncertainty | D8 | F | Table 12 column names |
| MN-14 | Privacy | Floating-point / PRNG side channels not addressed | Not addressed | Limitation statement; no side-channel claim | - | G | - |
| MN-15 | Evaluation | Metric averaging conventions not stated in outputs | Partially addressed | Explicit convention fields in final.json and tables | - | C | schema field |
| MN-16 | Implementation | Checkpoints loaded with torch.load(weights_only=False) | Not addressed | Save tensors/JSON so weights_only=True works | - | C | resume test |
| MN-17 | Data/partition | Dirichlet over relations models relation skew only | Documented | State scope; optional entity-community partition (OP-10) | D4 | D | - |
| MN-18 | Baselines | Robust-aggregator assumptions depend on f | Partially addressed | Robustness parameters at the design value f = 0.2 (beta 0.2, Krum f 2), also in clean runs; the true attacker count if larger; violations flagged | D16 | C | assumption flags |
| MN-19 | Attacks | One strength s = 3 for every attack, fixed a priori | Partially addressed | Keep s = 3 (fixed before any result) for the scaled attacks; ALIE's z and the adaptive gamma follow their own rules; justification recorded in attack.json; no strength is tuned after results | D16 | B,C | attack.json |
| MN-20 | Data | PyKEEN vocabularies differ from official counts | Documented in dataset card | Report before/after-loader counts and removed triples | D5 | D | Table 1 |
| MN-21 | Attacks | KG-targeted attack draws its target queries from the test set | Not addressed | Draw (h, r) target pairs from the attacker's own training triples; the evaluator still checks that t* is false | D16 | C | attack.json records the target source |
| MN-22 | Privacy/robustness | No guard against non-finite broadcasts or gradients | Not addressed | Clients reject non-finite broadcasts and zero any non-finite per-example gradient before clipping; behaviour on a failed broadcast verification specified | - | C | unit tests |
| G5 | Revision package | 2D plots only; PNG only | Gap in revision | Plot families A-E mapped to blocks | - | F | figure manifest |
| G11 | Revision package | Dataset-level leakage, logged losses, secure-mode RNG not discussed | Gap in revision | Exclusions listed in 03 section 7.6 and 03a | D2 | B | 03a |
| G12 | Revision package | Automatic PyKEEN download without a licence gate | Gap in revision | Explicit confirmation flag | D5 | C | unit test |
| G13 | Revision package | No scripts/ entry points; Colab-only README | Gap in revision | scripts/ + local commands | - | C,G | README |

### Optional (11)

| ID | Area | Defect | Revision status | Resolution | Decision | Phase | Verification |
|---|---|---|---|---|---|---|---|
| OP-1 | Privacy | Phase A proposed PLD epsilon as the primary figure | Addressed by design (unexecuted) | CHANGED in Phase B: RDP is primary (it drives calibration and the tested code), PLD and PRV are reported next to it | D3 | C | - |
| OP-2 | Privacy | Privacy-aware hyperparameter tuning (Papernot & Steinke 2022) | Not addressed | Disclose tuning cost (default) or account for it | D13 | B | - |
| OP-3 | Privacy | Design alternative if DP utility is unacceptable | Not addressed | Only via D10 trigger | D10 | E | - |
| OP-4 | Privacy | Client-level DP regime | Not addressed | Withdrawn: infeasible at K=10 (MN-11) | D2 | - | - |
| OP-5 | Integrity | Real IPFS CIDs or a local IPFS node | Not addressed | Only if D7 option (b) | D7 | C,E | - |
| OP-6 | Statistics | More seeds for headline comparisons | Not addressed | Full profile (10 seeds) | D8 | E | - |
| OP-7 | Model | Second KGE model (RotatE/ComplEx) | Not addressed | Not in core; possible extension | - | E | - |
| OP-8 | Continuity | Re-evaluate the saved legacy checkpoint under the corrected protocol | Not addressed | Block L0 (cheap) | - | C | - |
| OP-9 | Privacy | Validation-adaptive noise with an RDP filter (DP-Flames-inspired) | Not addressed | Block O1 if D12 option (b) | D12 | C,E | - |
| OP-10 | Data/partition | Entity-community partition as a second non-IID form | Not addressed | Possible extension | D4 | D | - |
| OP-11 | Privacy | Calibrate sigma with PLD instead of RDP | Not addressed | Not default (RDP is conservative and already tested) | D3 | C | - |

## Contradictions (Phase A, §11) mapped to the defects that resolve them

| Contradiction | Resolved by |
|---|---|
| X01 trust: cosine (paper) / loss deviation (code) / MAD rule (revision) | CR-6, D15 |
| X02 adaptive σ claimed / fixed σ run / header mismatch | CR-10, MN-2, D12 |
| X03, X04 Client-0 74.26 % and "semantic clusters" vs ID-order chunks | CR-8 |
| X05 "full test set" vs 300 random tail queries | CR-4 |
| X06 ε 15.53 vs worst-client RDP 1.98 | CR-2 |
| X07 Fig. 13 caption mixes two runs | MN-3 |
| X08 warm start claimed vs not loaded | CR-7 |
| X09, X11, X24 wording, round counts, runtime ratio | MN-6 |
| X10 δ, clients, partition (paper vs revision) | D3, D4 |
| X12 trained centralised reference vs constant 0.094 | CR-1, MJ-3 |
| X13, X15 IPFS objects; "IPFS-compatible" wording | CR-9, D7 |
| X14 methodology diagram (Flower, NELL-995, RotatE, cross-dataset clients) | D5, OP-7; cross-dataset clients excluded (master prompt §6) |
| X16 Wilcoxon with 5 seeds | G14, D8 |
| X17 "rerun Phase 6 with seeds" — Phase 6 had no experiment | G2 |
| X18 "highlight the Pareto-optimal point" vs "never choose a configuration because it looks good" | D3 (ε* = 4 declared in advance; the full frontier is reported) |
| X19 α grid | G4 |
| X20 missing THREAT_MODEL.md | G3 (draft in `03a_threat_model.md`) |
| X21 "Proprietary Learning Reveal" vs the supplied zip | `08_open_questions.md` §1 (unresolved) |
| X22 "all hypotheses confirmed" | CR-5, MJ-11 |
| X23 "recovers 0.2858 while private" | CR-3 |
