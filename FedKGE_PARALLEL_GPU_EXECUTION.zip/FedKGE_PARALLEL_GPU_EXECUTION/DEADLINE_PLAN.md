# Deadline plan — what can finish this week, honestly (2026-11-05)

**Bottom line:**
- **The full approved study (885 runs, ≈ 118 GPU-hours upper bound) cannot finish this week on one Colab T4.** That is about five days of non-stop GPU time, before reconnects, waiting for a GPU and session limits.
- **What can realistically finish with paid compute units:** Steps 3–4 plus Stage-4 priorities 1–3 (≈ 58 GPU-hours). After that, **all five pre-registered hypotheses** have complete evidence.
- **On free Colab:** probably Steps 3–4 and part of priority 1.

All hours below are **upper bounds** from the owner's measured T4 pilot (2-round measurements, 2026-11-04), not measurements of complete runs. Method and per-dataset numbers: `provenance/deadline_cost_model/`.

---

## 1. The run order and what each part makes reportable

| Order | Part | Runs | GPU-h (upper) | Cumulative | What you can report once it is complete |
|---|---|---|---|---|---|
| 1 | Step 3 — accuracy sanity gate G-B (mandatory) | 18 | 1.7 | 1.7 | the gate result (methods section) |
| 2 | Step 4 — tuning (Stage 3) + freeze | 81 | 10.8 | 12.5 | the selected settings, τ\* and its label, the D10 flag (methods / appendix) |
| 3 | Priority 1 — N1, N2, DP1 and DP2 at ε = 4, R1p | 75 | 9.4 | 21.9 | **main table**; **H1** (utility), **H2b** (non-inferiority), **HS** (noise schedule); federation and privacy cost |
| 4 | Priority 2 — R2, R2a, R3, R3a | 210 | 28.4 | 50.3 | **H2** (robustness under 7 attacks); attack tables |
| 5 | Priority 3 — M1 | 60 | 8.0 | **58.3** | **H3** (membership inference). **All five hypothesis families are now complete** |
| 6 | Priority 4 — replications L1–L4 | 30 | 5.4 | 63.7 | Table 13: original vs revised protocol |
| 7 | Priority 5 — R1q | 15 | 2.0 | 65.7 | schedule inside the method (descriptive) |
| 8 | Priority 6 — R1, R4, R5, R5a | 252 | 33.6 | 99.3 | other robust aggregators; trust without DP |
| 9 | Priority 7 — DP1 at ε ∈ {1, 2, 8}, DP3, N3, I1, I2 | 144 | 19.1 | 118.4 | privacy–utility curve over ε, DP-cost decomposition, heterogeneity, the corruption experiment |

**Change made for the deadline (RC-12).** M1 (H3) used to run last (priority 7). It now runs third, so every pre-registered hypothesis is decided before the replications, baselines and descriptive blocks.
- This changes only the execution order.
- All 900 manifest cells, their configurations, seeds and run identifiers are identical (proof: `provenance/validation_2026-11-05/rc12_priority_reorder/`).

---

## 2. Calendar arithmetic (assumptions, not a forecast)

| GPU time you get | By Sunday (≈ 3.5 days) you reach |
|---|---|
| Free Colab at 4–8 GPU-h per day (Colab publishes no quota; sessions ≤ 12 h) | 14–28 GPU-h → Steps 3–4, perhaps priority 1 |
| Paid compute units, sessions back to back, ≈ 20 GPU-h per day | ≈ 70 GPU-h → through priority 3 or 4, if nothing fails |
| The full study | ≈ 118 GPU-h → about 6 days at 20 GPU-h per day |

**Compute units.** A T4 was reported at about 1.19 compute units per hour (March 2026) and 1.58 (October 2024) (`audit/phaseC/pilot_plan.md` §6, checked 2026-11-04; check the rate in your account). At those rates:
- priorities 1–3 (58 GPU-h) need about 70–92 units;
- the full study needs about 141–187 units.

**Upper bounds only.** Early stopping usually ends non-private runs sooner, and a tuning result of q = 0.02 would make DP runs about 12–29 % slower. Do not plan on the bound being undercut.

---

## 3. Reporting a partial study honestly

The analysis already handles partial completion:
- Missing members enter their family with p = 1.
- Families with missing members are labelled **PROVISIONAL**.
- Table 14 lists completion block by block.
- Everything else stays ⟦PENDING⟧.

**Rules for the paper:**
1. Call a hypothesis decided only when Table 12 shows all its members complete. Holm uses the fixed family size, so a partial family is never "significant by subset".
2. State the completed fraction, for example: "Of the 885 pre-registered runs, N were completed; blocks … were not run and are reported as future work."
3. Do not show a curve or table for a block that has not run, for example the ε-sweep or the robust baselines. Do not extrapolate from completed blocks.
4. The per-run ε is a per-model guarantee. Never describe it as end-to-end for the tuning workflow.

---

## 4. Removable overhead vs unavoidable computation

| Item | Before | Now | Effect |
|---|---|---|---|
| CPU test suite in the notebook | ran once per new environment (≈ 3–5 min) | **opt-in appendix cell** (`RUN_CPU_CHECKS`) | removed from the mandatory path |
| Smoke tests, pilots, benchmarks, synthetic demos | never on the research path | none on the research path (a test enforces this) | — |
| Dataset download and preprocessing | only if missing | only if missing or not verifying | unchanged |
| Accuracy sanity gate (18 runs) | mandatory | mandatory; its runs are part of the 99 tuning runs | not overhead |
| Per-session setup (pip pins, checks, mount) | minutes | minutes | unavoidable |
| **Research computation** | 885 runs | 885 runs | **≈ 118 GPU-h, unavoidable** |

**Engineering optimisation made (execution-equivalent).**
- The integrity layer now serialises and parses each object with one copy of the payload instead of two. The bytes, SHA-256 identifiers and manifest chain are identical.
- Proof: `test_integrity_fast_path_is_byte_identical` and an identical manifest chain ID in `provenance/validation_2026-11-05/optimisation_equivalence/`.
- Measured gain: −9 % of integrity time per round on this CPU. Integrity is 12–52 % of a federated T4 round, so about **1–4 %** per federated round. The upper bounds above do **not** include this gain.

**Considered and rejected:**

| Option | Why it was rejected |
|---|---|
| fewer rounds, seeds, clients, negatives or dimensions | changes the science |
| one hash shared by the ten receivers of a broadcast | weakens the integrity mechanism and changes the reported overhead |
| hashing in parallel threads | changes the measured overhead |
| caching dataset artifacts across runs | < 1 s per run (measured) |
| dropping the final-round checkpoint | it protects the post-training MIA and evaluation phase |

The training loops already synchronise with the GPU only where the DP algorithm needs it (Poisson batch size, `unique`).

---

## 5. Getting more GPU time (your choice; the package runs as it is)

- **Paid Colab compute units** use the same notebook and the same environment lock.
- **One session at a time per results folder.** Selections and gate records are shared files, and Drive syncs between machines with a delay.
- **Do not use several Colab accounts to get around Colab's limits.** Colab's FAQ lists this as a disallowed activity.
- **Keep all runs of a dataset on one platform and in one results folder.** The analysis reads one results folder, and the environment lock refuses to mix GPU types or torch builds within a dataset.

Source: [Colab FAQ](https://research.google.com/colaboratory/faq.html) (disallowed activities; 12-hour free sessions; Pro+ up to 24 hours).
