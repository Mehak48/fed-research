> **Historical page (original package).** It describes the Phases 1-4 notebook matrix (p3/p4), not the revised study. The current, frozen methodology is `13_documentation/FINAL_METHODOLOGY.md`; the execution procedure is `../EXECUTION_GUIDE.md` and the notebook `../RUN_COMPLETE_FEDKGE_RESEARCH.ipynb`. Kept unchanged below for the record.

# Execution plan — Phases 1–4

## Experiment matrix (final tier: 3 datasets × 5 seeds unless noted)
| Phase | Block | What it isolates | Unique runs |
|---|---|---|---|
| P3 | P3_central | centralised TransE (replaces hard-coded 0.0940) | 15 |
| P3 | P3_iid | FedAvg, IID, 10 clients | 15 |
| P3 | P3_dir (α = 1.0, 0.1) | FedAvg, non-IID; α = 0.1 = **main baseline (L0)** | 30 |
| P3 | R3_legacy (FB only) | exact old Phase 3 (5 relation-disjoint clients, 1 negative, 3 local epochs, 50 rounds, last-round model, legacy + corrected evaluation) | 5 |
| P3 | R3_fixed (FB only) | legacy split, corrected trainer/eval | 5 |
| P4 s1 | L1_legacy | old mechanism (no normalisation, buggy negatives, σ = 1, C = 1, B = 256, naive-sum stop at 15) on the main partition | 15 |
| P4 s1 | L2_trainer_fixed | L1 + corrected trainer ⇒ effect of **trainer bugs** | 15 |
| P4 s1 | L3_accounting_fixed | L2 + formal RDP stop at the same nominal 15 (δ = 1e-5) ⇒ effect of **accounting** | 15 |
| P4 s1 | R4_legacy (FB only) | exact old Phase 4 run | 5 |
| P4 s1 | 4B_clip | C sweep at ε* = 4, fixed σ; C_sel point = **L4a** | 75 |
| P4 s2 | 4C_schedule | 3 shapes × 2 ρ at ε* = 4, C_sel; selected = **L4b** ⇒ **schedule effect** | 90 |
| P4 s3 | 4D_regimes | ε* ∈ {1, 2, 8} × {fixed, selected} ⇒ privacy-utility curve | 90 (45 if fixed is selected) |
| | | **L0 vs L4b = genuine DP cost at ε* = 4** | **Total ≈ 375** |

Ladder read-out (`reports/p4/p4_dp_ladder*.csv`): L1→L2 (trainer bugs), L2→L3 (accounting), L3→L4a
(calibrated mechanism at ε* = 4, δ = 1e-6), L4a→L4b (schedule), L4b vs L0 (genuine DP cost); every step is a paired
(by seed) difference with 95% CI.

## Order
P1 → P2 → P3 → P4 stage 1 → select C → P4 stage 2 → select schedule → P4 stage 3 → P4 validation/reports.
Each tier in turn: smoke (all datasets) → dev → final. Selections are per tier; dev selections are only a
correctness check (dev runs one grid point per block).

## Cost
Measure in the dev tier; the P3/P4 notebooks then print a GPU-hour estimate per block for the final tier
(`runner.estimate`, median seconds/round × planned rounds; early stopping makes it an upper bound). Expect
YAGO3-10 (123k entities: dense noise and dense Adam state over 12.3M parameters per local step) to dominate the
DP cost by a wide margin. Nothing mandatory is removed to save time; use `MAX_RUNS_THIS_SESSION` and re-run.
