"""Process-level interruption test: SIGKILL a real run (smoke-tier WN18RR subset, DP + proposed + integrity) right
after its round-10 checkpoint, check the folder is INCOMPLETE (never COMPLETE), resume, and compare with an
uninterrupted run of the same configuration in a separate results root. Software check only."""
import json, os, shutil, signal, subprocess, sys, time
from pathlib import Path
REPO = Path(sys.argv[1]); SRC = Path(sys.argv[2]); OUT = Path(sys.argv[3])
sys.path.insert(0, str(REPO / "01_fedkge_core"))
from fedkge.config import deep_merge, load_yaml, run_id, validate
from fedkge.io import Paths, read_json
base = load_yaml(REPO / "10_configs" / "base.yaml"); tier = load_yaml(REPO / "10_configs" / "tiers" / "smoke.yaml")
cfg = deep_merge(base, {k: v for k, v in tier["run_overrides"].items() if k != "train"})
cfg["train"].update({"rounds_max": 20, "ckpt_every": 5, "eval_every": 5, "neg_samples": 8})
cfg["dp"].update({"enabled": True, "sampling": "common_rate", "q": 0.1, "target_epsilon": 4.0, "clip": 1.0})
cfg["aggregation"].update({"method": "proposed", "tau": 3.0})
cfg.update({"tier": "smoke", "phase": "killtest", "seed": 42, "block": "KILL", "name": "k", "dataset": {"name": "wn18rr"}})
validate(cfg); rid = run_id(cfg)
roots = {}
for name in ("killed", "reference"):
    r = OUT / name; (r / "smoke" / "artifacts").mkdir(parents=True, exist_ok=True)
    for sub in ("p1", "p2"):
        dst = r / "smoke" / "artifacts" / sub / "wn18rr"
        if not dst.exists(): shutil.copytree(SRC / "smoke" / "artifacts" / sub / "wn18rr", dst)
    roots[name] = r
code = ("import sys, json; sys.path.insert(0, %r); from fedkge.federated import run_experiment; from fedkge.io import Paths; "
        "cfg = json.load(open(%r)); run_experiment(cfg, Paths(sys.argv[1], 'smoke'), 'cpu')") % (str(REPO / "01_fedkge_core"), str(OUT / "cfg.json"))
(OUT / "cfg.json").write_text(json.dumps(cfg))
t0 = time.time(); subprocess.run([sys.executable, "-c", code, str(roots["reference"])], check=True, capture_output=True)
ref = read_json(Paths(roots["reference"], "smoke").run(rid) / "final.json"); t_ref = time.time() - t0
rd = Paths(roots["killed"], "smoke").run(rid)
p = subprocess.Popen([sys.executable, "-c", code, str(roots["killed"])], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
killed_at = None
for line in p.stdout:
    if "round 11/" in line:                     # the round-10 checkpoint has been written
        os.kill(p.pid, signal.SIGKILL); killed_at = line.strip(); break
p.wait()
st = read_json(rd / "status.json")
sys.path.insert(0, str(REPO / "scripts"))
from fedkge.manifest import cell_status
mid = cell_status(Paths(roots["killed"], "smoke"), rid)
res = {"run_id": rid, "killed_after": killed_at, "status_after_kill": st["status"], "final_json_after_kill": (rd / "final.json").exists(),
       "checkpoint_after_kill": (rd / "checkpoint.pt").exists(), "derived_status_after_kill": mid["status"]}
subprocess.run([sys.executable, "-c", code, str(roots["killed"])], check=True, capture_output=True)
fin = read_json(rd / "final.json"); st2 = read_json(rd / "status.json"); log = (rd / "log.txt").read_text()
res.update({"status_after_resume": st2["status"], "attempt": st2.get("attempt"), "resumed_line": [l for l in log.splitlines() if "resumed from round" in l],
            "identical_to_uninterrupted": {k: (fin[k]["mrr"], ref[k]["mrr"]) for k in ("val", "test")},
            "eps_identical": (fin["privacy"]["eps"], ref["privacy"]["eps"]),
            "rounds": (fin["rounds_executed"], ref["rounds_executed"]), "reference_seconds": round(t_ref, 1)})
res["PASS"] = bool(res["status_after_kill"] == "RUNNING" and not res["final_json_after_kill"] and res["checkpoint_after_kill"]
                   and res["derived_status_after_kill"] == "INCOMPLETE" and res["status_after_resume"] == "COMPLETE"
                   and res["resumed_line"] and fin["val"]["mrr"] == ref["val"]["mrr"] and fin["test"]["mrr"] == ref["test"]["mrr"]
                   and fin["privacy"]["eps"] == ref["privacy"]["eps"])
(OUT / "kill_resume_result.json").write_text(json.dumps(res, indent=1, default=str)); print(json.dumps(res, indent=1, default=str))
