"""Formal privacy accounting for client-side DP-SGD (Poisson-subsampled Gaussian mechanism).

Privacy unit: one training triple in one client's local dataset.
Neighbouring relation (Phase B decision D2, defect CR-14): ZERO-OUT ("replace one record by a special null record").
  Two datasets of client k are neighbours if one is obtained from the other by replacing one triple with a null
  record whose loss and gradient are identically zero. The client's record count N_k is therefore the same for
  neighbours, which is what allows N_k to be public (it sets FedAvg weights, the normalisation q*N_k and, under
  design A, q_k and the step count). Under plain add/remove adjacency, publishing the exact N_k would reveal a
  removal, so add/remove is NOT the relation used here.
  For Poisson sampling the zero-out pair of output distributions is exactly the add/remove pair (the null record
  contributes nothing whether or not it is sampled), so the RDP/PLD bounds are the same; dp_accounting implements
  this explicitly (NeighboringRelation.REPLACE_SPECIAL is accepted for PoissonSampledDpEvent and composed with the
  same RDP as ADD_OR_REMOVE_ONE). `rdp_epsilon_public_api` uses that public API as a cross-check.
Mechanism per local step: Poisson sampling with rate q, per-example clipping to L2 norm C,
Gaussian noise N(0, sigma^2 C^2 I) added to the sum of clipped gradients.

Composition: RDP (Mironov 2017; Mironov, Talwar & Zhang 2019) summed over all steps of all rounds,
converted to (eps, delta) with the conversion implemented in dp_accounting.compute_epsilon.
Cross-checks: PLD accountant (dp_accounting.pld) and, if installed, the PRV accountant (Gopi et al. 2021).

Sampling designs (Phase B decision D11):
  A (fixed_batch):  expected batch B fixed; q_k = B / N_k; T_k = round(N_k / B) steps per round; sigma per client.
  Q (common_rate):  one sampling rate q for every client; T = round(1 / q) steps per round; expected batch q*N_k;
                    one sigma for every client (calibration depends only on q, T, R, the schedule and eps*).

Nothing in this module estimates, approximates or falls back to a heuristic epsilon.
Any failure raises.
"""
from __future__ import annotations

import math
from functools import lru_cache
from typing import Dict, List, Sequence

import logging
import numpy as np
import dp_accounting
from dp_accounting.rdp import rdp_privacy_accountant as _rdp

# dp_accounting logs a warning when a fractional order's series does not converge and then EXCLUDES that
# order. Excluding an order can only make the reported epsilon larger (never smaller), so it stays valid.
logging.getLogger("absl").setLevel(logging.ERROR)

# Opacus 1.x default orders (used ONLY for the legacy replica so the old log is reproduced exactly)
OPACUS_DEFAULT_ORDERS: List[float] = [1 + x / 10.0 for x in range(1, 100)] + list(range(12, 64))
# Extended orders for the main experiments (large sigma / small q need higher orders)
# Main orders: any set of orders yields a VALID bound (epsilon = min over the set); this set is chosen for speed
# while covering the optimal orders for 0.5 <= eps <= 16 at delta = 1e-6 (checked in test_accountant).
MAIN_ORDERS: List[float] = ([1.25, 1.5, 1.75, 2.0, 2.25, 2.5, 2.75, 3.0, 3.5, 4.0, 4.5]
                            + list(range(5, 64)) + [64, 80, 96, 128, 160, 192, 256])


class AccountantError(RuntimeError):
    pass


@lru_cache(maxsize=200_000)
def _rdp_vec_cached(q: float, sigma: float, orders: tuple) -> tuple:
    if not (0.0 < q <= 1.0):
        raise AccountantError(f"sampling rate q={q} outside (0,1]")
    if not (sigma > 0 and math.isfinite(sigma)):
        raise AccountantError(f"noise multiplier sigma={sigma} must be positive and finite")
    v = _rdp._compute_rdp_poisson_subsampled_gaussian(q, sigma, np.array(orders, dtype=float))
    v = np.atleast_1d(np.asarray(v, dtype=float))
    if v.shape[0] != len(orders):
        raise AccountantError("RDP vector length mismatch")
    return tuple(float(x) for x in v)


def rdp_vector(q: float, sigma: float, orders: Sequence[float] = MAIN_ORDERS) -> np.ndarray:
    """RDP of ONE step of the Poisson-subsampled Gaussian mechanism at each order."""
    return np.array(_rdp_vec_cached(float(q), float(sigma), tuple(orders)))


def eps_from_rdp(rdp: np.ndarray, delta: float, orders: Sequence[float] = MAIN_ORDERS) -> float:
    if not (0 < delta < 1):
        raise AccountantError(f"delta={delta} must be in (0,1)")
    eps, _order = _rdp.compute_epsilon(np.array(orders, dtype=float), np.asarray(rdp, dtype=float), delta)
    eps = float(eps)
    if not math.isfinite(eps) or eps < 0:
        raise AccountantError(f"accountant returned invalid epsilon {eps}")
    return eps


def composed_rdp(q: float, steps_per_round: Sequence[int], sigmas: Sequence[float],
                 orders: Sequence[float] = MAIN_ORDERS) -> np.ndarray:
    """RDP after composing rounds t=1..T, each with steps_per_round[t] steps at noise sigmas[t]."""
    if len(steps_per_round) != len(sigmas):
        raise AccountantError("steps_per_round and sigmas must have equal length")
    total = np.zeros(len(orders))
    for k, s in zip(steps_per_round, sigmas):
        if k < 0:
            raise AccountantError("negative step count")
        if k:
            total = total + k * rdp_vector(q, s, orders)
    return total


def cumulative_epsilons(q: float, steps_per_round: Sequence[int], sigmas: Sequence[float], delta: float,
                        orders: Sequence[float] = MAIN_ORDERS) -> List[float]:
    """epsilon after each round (RDP composition of all steps so far)."""
    out, total = [], np.zeros(len(orders))
    for k, s in zip(steps_per_round, sigmas):
        if k:
            total = total + k * rdp_vector(q, s, orders)
        out.append(eps_from_rdp(total, delta, orders) if total.any() else 0.0)
    return out


# ----------------------------------------------------------------------------- noise schedules
SCHEDULE_SHAPES = ("fixed", "linear", "exponential", "cosine")


def schedule_multipliers(shape: str, rho: float, rounds: int, update_every: int = 1) -> np.ndarray:
    """Deterministic, data-independent, piecewise-constant schedule g(t), t = 0..R-1.
    The noise multiplier is updated every `update_every` rounds (block b covers rounds b*u .. b*u+u-1).
    Block position x_b = b / (B-1) in [0,1]; g = 1 in the first block and g = rho in the last block.
    sigma_t = sigma_0 * g(t);  rho = sigma_last / sigma_0  (rho = 1 <=> fixed schedule)."""
    if shape not in SCHEDULE_SHAPES:
        raise ValueError(f"unknown schedule shape {shape}")
    if rounds < 1 or update_every < 1:
        raise ValueError("rounds and update_every must be >= 1")
    if shape == "fixed":
        return np.ones(rounds)
    if not (0 < rho <= 1):
        raise ValueError("rho must be in (0,1] for decaying schedules")
    n_blocks = int(math.ceil(rounds / update_every))
    xb = np.arange(n_blocks) / max(n_blocks - 1, 1)
    if shape == "linear":
        gb = 1.0 - (1.0 - rho) * xb
    elif shape == "exponential":
        gb = rho ** xb
    else:  # cosine
        gb = rho + (1.0 - rho) * 0.5 * (1.0 + np.cos(np.pi * xb))
    return np.repeat(gb, update_every)[:rounds]


def calibrate_sigma0(q: float, steps_per_round: int, rounds: int, shape: str, rho: float,
                     target_eps: float, delta: float, update_every: int = 1,
                     orders: Sequence[float] = MAIN_ORDERS, tol: float = 1e-3, max_iter: int = 200) -> Dict:
    """Smallest sigma_0 (up to relative tolerance `tol`, rounded UP => conservative) such that the RDP
    epsilon after `rounds` rounds is <= target_eps. Bisection in log-space (eps decreases in sigma_0)."""
    g = schedule_multipliers(shape, rho, rounds, update_every)
    ks = [steps_per_round] * rounds

    def eps_of(s0: float) -> float:
        return eps_from_rdp(composed_rdp(q, ks, s0 * g, orders), delta, orders)

    hi = 1.0
    while eps_of(hi) > target_eps:
        hi *= 2.0
        if hi > 1e4:
            raise AccountantError("could not reach target epsilon with sigma_0 <= 1e4")
    lo = hi / 2.0
    while eps_of(lo) <= target_eps:
        hi, lo = lo, lo / 2.0
        if lo < 0.05:
            raise AccountantError("target epsilon reachable with sigma_0 < 0.05; check configuration")
    for _ in range(max_iter):
        mid = math.sqrt(lo * hi)
        if eps_of(mid) > target_eps:
            lo = mid
        else:
            hi = mid
        if hi / lo - 1 < tol:
            break
    eps_final = eps_of(hi)
    if eps_final > target_eps + 1e-9:
        raise AccountantError("calibration failed to meet target")
    return {"sigma0": hi, "sigmas": (hi * g).tolist(), "eps_at_R": eps_final}


# ----------------------------------------------------------------------------- PLD cross-check
def pld_epsilon(q: float, steps_per_round: Sequence[int], sigmas: Sequence[float], delta: float,
                value_discretization_interval: float = 1e-3) -> float:
    acc = dp_accounting.pld.PLDAccountant(value_discretization_interval=value_discretization_interval)
    # Group identical sigmas to use fast self-composition
    groups: Dict[float, int] = {}
    for k, s in zip(steps_per_round, sigmas):
        groups[round(float(s), 12)] = groups.get(round(float(s), 12), 0) + int(k)
    for s, k in groups.items():
        if k:
            acc.compose(dp_accounting.PoissonSampledDpEvent(q, dp_accounting.GaussianDpEvent(s)), k)
    return float(acc.get_epsilon(delta))


ADJACENCY = ("zero-out: one training triple of one client is replaced by a null record with zero loss and "
             "gradient; the client's record count N_k is unchanged and public")
NEIGHBORING_RELATION = dp_accounting.NeighboringRelation.REPLACE_SPECIAL


def _grouped(steps_per_round: Sequence[int], sigmas: Sequence[float]) -> Dict[float, int]:
    if len(steps_per_round) != len(sigmas):
        raise AccountantError("steps_per_round and sigmas must have equal length")
    groups: Dict[float, int] = {}
    for k, s in zip(steps_per_round, sigmas):
        if int(k) < 0:
            raise AccountantError("negative step count")
        if int(k):
            groups[float(s)] = groups.get(float(s), 0) + int(k)
    return groups


def rdp_epsilon_public_api(q: float, steps_per_round: Sequence[int], sigmas: Sequence[float], delta: float,
                           orders: Sequence[float] = MAIN_ORDERS) -> float:
    """Same quantity as eps_from_rdp(composed_rdp(...)) but through dp_accounting's PUBLIC RdpAccountant with the
    zero-out neighbouring relation (REPLACE_SPECIAL). Used as a code-path cross-check of the run-time accountant."""
    acc = dp_accounting.rdp.RdpAccountant(list(orders), neighboring_relation=NEIGHBORING_RELATION)
    for s, k in _grouped(steps_per_round, sigmas).items():
        acc.compose(dp_accounting.PoissonSampledDpEvent(q, dp_accounting.GaussianDpEvent(s)), k)
    eps = float(acc.get_epsilon(delta))
    if not math.isfinite(eps) or eps < 0:
        raise AccountantError(f"public-API accountant returned invalid epsilon {eps}")
    return eps


def prv_epsilon(q: float, steps_per_round: Sequence[int], sigmas: Sequence[float], delta: float,
                eps_error: float = 0.01) -> Dict[str, float]:
    """Independent cross-check with the PRV accountant (Gopi, Lee & Wutschitz 2021; package `prv-accountant`).
    Returns {'lower', 'estimate', 'upper'}; the upper value is a valid bound up to the stated eps_error.
    Raises ImportError if the optional package is missing (never silently skipped by callers that require it)."""
    from prv_accountant import PRVAccountant
    from prv_accountant.privacy_random_variables import PoissonSubsampledGaussianMechanism
    groups = _grouped(steps_per_round, sigmas)
    prvs = [PoissonSubsampledGaussianMechanism(sampling_probability=float(q), noise_multiplier=float(s))
            for s in groups]
    counts = [int(k) for k in groups.values()]
    acc = PRVAccountant(prvs=prvs, max_self_compositions=counts, eps_error=eps_error, delta_error=delta * 1e-3)
    lo, est, hi = acc.compute_epsilon(delta=delta, num_self_compositions=counts)
    return {"lower": float(lo), "estimate": float(est), "upper": float(hi)}


def dp_steps_common_rate(public_size: int, q: float) -> Dict:
    """Design Q: one sampling rate q for every client; T = round(1/q) Poisson-sampled steps per round (about one
    local epoch); expected batch q * N_k computed from the PUBLIC size (data-independent normalisation)."""
    if not (0.0 < q < 1.0):
        raise AccountantError(f"common sampling rate q={q} must be in (0,1)")
    if public_size < 1:
        raise AccountantError("client public size must be >= 1")
    steps = max(1, int(round(1.0 / q)))
    return {"steps": steps, "q": float(q), "expected_batch": float(q * public_size)}


# ----------------------------------------------------------------------------- legacy (replica only)
def legacy_round_epsilon(q: float, steps: int, sigma: float, delta: float) -> float:
    """Per-round epsilon exactly as the OLD notebook obtained it (a fresh Opacus RDP accountant per round).
    Used ONLY to reproduce the old stopping rule; never reported as the privacy guarantee."""
    return eps_from_rdp(steps * rdp_vector(q, sigma, OPACUS_DEFAULT_ORDERS), delta, OPACUS_DEFAULT_ORDERS)


def dp_steps_and_rate(n_examples: int, batch_size: int, legacy_opacus: bool) -> Dict:
    """Steps per epoch and Poisson sampling rate.
    legacy_opacus=True reproduces Opacus with DataLoader(drop_last=True): steps=N//B, q=1/steps.
    Main: steps=round(N/B), q=B/N (expected batch = B)."""
    if n_examples < batch_size:
        raise AccountantError(f"client has {n_examples} examples < batch size {batch_size}; "
                              "DP sampling rate would exceed 1. Increase min_client_size or reduce batch.")
    if legacy_opacus:
        steps = n_examples // batch_size
        return {"steps": steps, "q": 1.0 / steps, "expected_batch": n_examples / steps}
    steps = max(1, int(round(n_examples / batch_size)))
    return {"steps": steps, "q": batch_size / n_examples, "expected_batch": float(batch_size)}
