"""Client partitioning (Phase 2 artifact) and heterogeneity statistics.

Schemes
  iid                       random equal split of training triples
  dirichlet_relation(alpha) for every relation r, its triples are split across clients with proportions
                            p_r ~ Dir(alpha * 1_n). alpha -> 0 approaches relation-disjoint (old idea),
                            alpha -> inf approaches IID. Works for datasets with few relations (WN18RR: 11).
                            Partitions violating the minimum client size are re-drawn from the same seeded
                            generator (attempt count is recorded); after max_attempts the run FAILS.
  relation_disjoint_legacy  exact reproduction of the old notebooks: relations sorted by id, np.array_split
  centralized               one client holding all training triples (reference)

The partition is a pure function of (train triples, scheme, parameters, seed) and is stored with a hash.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional

import numpy as np

from .io import IntegrityError, read_json, sha256_arrays, sha256_file, verify_artifact, write_json


def canonical_spec(p: Dict) -> Dict:
    """Only the keys that determine the partition for the given scheme (so irrelevant keys never cause
    spurious mismatches, and relevant ones always do)."""
    keys = {"centralized": ("scheme", "n_clients"), "iid": ("scheme", "n_clients"),
            "relation_disjoint_legacy": ("scheme", "n_clients"),
            "dirichlet_relation": ("scheme", "n_clients", "alpha", "min_client_frac", "min_client_abs", "max_attempts")}
    if p["scheme"] not in keys:
        raise ValueError(f"unknown scheme {p['scheme']}")
    return {k: p[k] for k in keys[p["scheme"]]}


def _min_size(n_train: int, n_clients: int, spec: Dict) -> int:
    return int(max(spec.get("min_client_abs", 0), spec.get("min_client_frac", 0.0) * n_train / n_clients))


def assign(train: np.ndarray, spec: Dict, seed: int) -> Dict:
    """Return {'client': (N,) int array of client ids, 'attempts': int, 'min_size': int}."""
    scheme, n = spec["scheme"], int(spec["n_clients"])
    N = len(train)
    rng = np.random.default_rng(np.random.SeedSequence([int(seed), 7_000_001]))
    if scheme == "centralized":
        return {"client": np.zeros(N, dtype=np.int64), "attempts": 1, "min_size": 0}
    if scheme == "iid":
        perm = rng.permutation(N)
        client = np.empty(N, dtype=np.int64)
        for c, chunk in enumerate(np.array_split(perm, n)):
            client[chunk] = c
        return {"client": client, "attempts": 1, "min_size": 0}
    if scheme == "relation_disjoint_legacy":
        rels = np.unique(train[:, 1])
        client = np.empty(N, dtype=np.int64)
        for c, chunk in enumerate(np.array_split(rels, n)):
            client[np.isin(train[:, 1], chunk)] = c
        return {"client": client, "attempts": 1, "min_size": 0}
    if scheme == "dirichlet_relation":
        alpha = float(spec["alpha"])
        m = _min_size(N, n, spec)
        rels = np.unique(train[:, 1])
        idx_by_rel = {r: np.flatnonzero(train[:, 1] == r) for r in rels}
        for attempt in range(1, int(spec.get("max_attempts", 5000)) + 1):
            client = np.empty(N, dtype=np.int64)
            for r in rels:
                idx = idx_by_rel[r][rng.permutation(len(idx_by_rel[r]))]
                p = rng.dirichlet(np.full(n, alpha))
                cuts = (np.cumsum(p)[:-1] * len(idx)).astype(int)
                for c, chunk in enumerate(np.split(idx, cuts)):
                    client[chunk] = c
            sizes = np.bincount(client, minlength=n)
            if sizes.min() >= m:
                return {"client": client, "attempts": attempt, "min_size": m}
        raise IntegrityError(f"dirichlet_relation(alpha={alpha}) could not satisfy min client size {m} "
                             f"with n={n} after {spec.get('max_attempts', 5000)} attempts; "
                             "revise min_client_frac/min_client_abs in the dataset config (documented decision).")
    raise ValueError(f"unknown scheme {scheme}")


def _js(p: np.ndarray, q: np.ndarray) -> float:
    p = p / p.sum(); q = q / q.sum(); m = 0.5 * (p + q)

    def kl(a, b):
        nz = a > 0
        return float(np.sum(a[nz] * np.log2(a[nz] / b[nz])))
    return 0.5 * kl(p, m) + 0.5 * kl(q, m)


def partition_stats(train: np.ndarray, client: np.ndarray, n_rel: int) -> Dict:
    from .data import gini
    n = int(client.max()) + 1
    glob = np.bincount(train[:, 1], minlength=n_rel).astype(float)
    rows, ent_sets = [], []
    for c in range(n):
        part = train[client == c]
        rc = np.bincount(part[:, 1], minlength=n_rel).astype(float)
        ents = set(part[:, 0].tolist()) | set(part[:, 2].tolist())
        ent_sets.append(ents)
        rows.append({"client": c, "n_triples": int(len(part)), "share": float(len(part) / len(train)),
                     "n_relations": int((rc > 0).sum()), "n_entities": len(ents),
                     "relation_js_vs_global": _js(rc, glob) if len(part) else float("nan"),
                     "relation_hellinger_vs_global": float(np.sqrt(0.5 * np.sum(
                         (np.sqrt(rc / max(rc.sum(), 1)) - np.sqrt(glob / glob.sum())) ** 2)))})
    jac = [len(ent_sets[i] & ent_sets[j]) / max(len(ent_sets[i] | ent_sets[j]), 1)
           for i in range(n) for j in range(i + 1, n)]
    sizes = np.array([r["n_triples"] for r in rows])
    summary = {"n_clients": n, "size_gini": gini(sizes), "size_max_share": float(sizes.max() / sizes.sum()),
               "size_max_min_ratio": float(sizes.max() / max(sizes.min(), 1)),
               "mean_relation_js": float(np.nanmean([r["relation_js_vs_global"] for r in rows])),
               "mean_pairwise_entity_jaccard": float(np.mean(jac)) if jac else float("nan"),
               "largest_client": int(sizes.argmax())}
    return {"clients": rows, "summary": summary}


def spec_key(spec: Dict) -> str:
    spec = canonical_spec(spec)
    if spec["scheme"] == "dirichlet_relation":
        return f"dirichlet_a{spec['alpha']}_n{spec['n_clients']}"
    return f"{spec['scheme']}_n{spec['n_clients']}"


def build_partition(train: np.ndarray, n_rel: int, spec: Dict, seed: int, out_dir: Path,
                    data_hash: str) -> Dict:
    spec = canonical_spec(spec)
    res = assign(train, spec, seed)
    client = res["client"]
    key = spec_key(spec)
    d = Path(out_dir) / key
    d.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(d / f"seed{seed}.npz", client=client)
    stats = partition_stats(train, client, n_rel)
    write_json(d / f"seed{seed}_stats.json", {**stats, "attempts": res["attempts"], "min_size": res["min_size"]})
    content_hash = sha256_arrays(client, np.frombuffer(data_hash.encode(), dtype=np.uint8))
    from .io import code_hash
    man = {"artifact": "p2_partition", "spec": spec, "seed": seed, "data_hash": data_hash,
           "content_hash": content_hash, "code_hash": code_hash(),
           "files": {f"seed{seed}.npz": sha256_file(d / f"seed{seed}.npz"),
                     f"seed{seed}_stats.json": sha256_file(d / f"seed{seed}_stats.json")}}
    write_json(d / f"seed{seed}_manifest.json", man)
    return man


def load_partition(p2_dir: Path, spec: Dict, seed: int, data_hash: str) -> Dict:
    spec = canonical_spec(spec)
    d = Path(p2_dir) / spec_key(spec)
    mpath = d / f"seed{seed}_manifest.json"
    if not mpath.exists():
        raise IntegrityError(f"partition artifact missing: {mpath}. Run Phase 2 for this dataset/scheme/seed.")
    man = verify_artifact(mpath)
    if man["data_hash"] != data_hash:
        raise IntegrityError(f"partition {mpath} was built from different Phase 1 data; rerun Phase 2")
    if man["spec"] != spec:
        raise IntegrityError(f"partition spec mismatch at {mpath}")
    client = np.load(d / f"seed{seed}.npz")["client"]
    return {"client": client, "content_hash": man["content_hash"],
            "stats": read_json(d / f"seed{seed}_stats.json")}
