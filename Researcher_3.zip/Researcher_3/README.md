# Researcher 3 — dataset `codex_m` — and the final integration

**Project:** Privacy-Preserving Federated Knowledge Graph Embedding (revised study). This kit is one of three. Researcher 1 runs `fb15k237`, Researcher 2 runs `wn18rr`, Researcher 3 runs `codex_m` and merges everything.

> **You can start now. You need nothing from the other two researchers, and they need nothing from you** until the end, when they send you their export files.
> The methodology is frozen and identical in the three kits: same code commit, same frozen run list, same partitions, seeds, privacy parameters, trust settings and evaluation. Every notebook checks this before it runs.

## 1. Your work

- **15 unit notebooks**, at most **285 runs**, at most **35.3 T4 GPU-hours**.
- The hours are **upper bounds** from the T4 pilot of 2026-11-04 (old kernel, one process per GPU). This package has a faster kernel and can share the GPU between two processes, but **neither was timed on a T4**. Real hours should be lower; nobody knows yet by how much. Each notebook records its real time.

| Order | Notebook | What it runs | Runs (max) | T4 hours (upper bound) | Needs first | Writes |
|---|---|---|---|---|---|---|
| 1 | `U03_TUNE_codex_m.ipynb` | Stage-3 tuning, selections, freeze | 33 | 4.05 | only the setup | `RESULT_U03.zip`, `SETTINGS_codex_m.zip` |
| 2 | `U08_MAIN_codex_m.ipynb` | Stage 4, priority 1 (timing reference) — blocks N2, R1p | 10 | 1.23 | `U03_TUNE_codex_m.ipynb` finished | `RESULT_U08.zip` |
| 3 | `U09_MAIN_codex_m.ipynb` | Stage 4, priority 1 — blocks DP1, DP2, N1 | 15 | 1.73 | `U03_TUNE_codex_m.ipynb` finished | `RESULT_U09.zip` |
| 4 | `U18_MAIN_codex_m.ipynb` | Stage 4, priority 2 — blocks R2, R2a, R3, R3a | 24 | 3.02 | `U03_TUNE_codex_m.ipynb` finished | `RESULT_U18.zip` |
| 5 | `U19_MAIN_codex_m.ipynb` | Stage 4, priority 2 — blocks R2, R2a, R3, R3a | 23 | 2.90 | `U03_TUNE_codex_m.ipynb` finished | `RESULT_U19.zip` |
| 6 | `U20_MAIN_codex_m.ipynb` | Stage 4, priority 2 — blocks R2, R2a, R3, R3a | 23 | 2.90 | `U03_TUNE_codex_m.ipynb` finished | `RESULT_U20.zip` |
| 7 | `U23_MAIN_codex_m.ipynb` | Stage 4, priority 3 — blocks M1 | 20 | 2.48 | `U03_TUNE_codex_m.ipynb` finished | `RESULT_U23.zip` |
| 8 | `U28_MAIN_codex_m.ipynb` | Stage 4, priority 5 — blocks R1q | 5 | 0.63 | `U03_TUNE_codex_m.ipynb` finished | `RESULT_U28.zip` |
| 9 | `U37_MAIN_codex_m.ipynb` | Stage 4, priority 6 — blocks R1, R4, R5 | 24 | 2.98 | `U03_TUNE_codex_m.ipynb` finished | `RESULT_U37.zip` |
| 10 | `U38_MAIN_codex_m.ipynb` | Stage 4, priority 6 — blocks R1, R4, R5 | 24 | 2.98 | `U03_TUNE_codex_m.ipynb` finished | `RESULT_U38.zip` |
| 11 | `U39_MAIN_codex_m.ipynb` | Stage 4, priority 6 — blocks R1, R4, R5, R5a | 24 | 2.97 | `U03_TUNE_codex_m.ipynb` finished | `RESULT_U39.zip` |
| 12 | `U40_MAIN_codex_m.ipynb` | Stage 4, priority 6 — blocks R1, R4, R5, R5a | 12 | 1.48 | `U03_TUNE_codex_m.ipynb` finished | `RESULT_U40.zip` |
| 13 | `U47_MAIN_codex_m.ipynb` | Stage 4, priority 7 (timing reference) — blocks I1 | 6 | 0.74 | `U03_TUNE_codex_m.ipynb` finished | `RESULT_U47.zip` |
| 14 | `U48_MAIN_codex_m.ipynb` | Stage 4, priority 7 — blocks DP1, DP3, I2, N3 | 21 | 2.59 | `U03_TUNE_codex_m.ipynb` finished | `RESULT_U48.zip` |
| 15 | `U49_MAIN_codex_m.ipynb` | Stage 4, priority 7 — blocks DP1, DP3, I2, N3 | 21 | 2.60 | `U03_TUNE_codex_m.ipynb` finished | `RESULT_U49.zip` |

## 2. Execution order

1. `00_SETUP_ONCE_PER_ACCOUNT.ipynb` — once, CPU, a few minutes.
2. `01_OPTIONAL_T4_BENCHMARK.ipynb` — optional, T4, about 3 minutes by design (not yet timed on a T4). It measures the new kernel and GPU sharing on your T4.
3. `U03_TUNE_codex_m.ipynb` — **must finish first.** It tunes `codex_m`, makes the pre-registered selections, and writes `SETTINGS_codex_m.zip`. All your Stage-4 notebooks need this file. They find it by themselves in the same account.
4. `U08_MAIN_codex_m.ipynb` … `U49_MAIN_codex_m.ipynb` — the 14 Stage-4 notebooks, **in the order of the table** (the order follows the approved priorities: hypothesis-critical runs first). Any order gives the same results.
5. `99_EXPORT_RESULTS_Researcher_3.ipynb` — CPU, about a minute. It writes the one file you keep as a backup.
6. `MERGE_AND_ANALYSE.ipynb` — CPU. The master integration (section 8).

**Sequential or simultaneous?**

- **Dependent:** every Stage-4 notebook depends on `U03_TUNE_codex_m.ipynb`. This dependency is part of the method (Stage 4 uses the tuned values) and cannot be removed.
- **Independent of each other:** all Stage-4 notebooks. They may run one after another, or at the same time in different GPU sessions if you have them.
- **Never** run the same notebook in two sessions at the same time.
- Free Colab normally gives one GPU session at a time, so plan for one notebook after another.
- You do **not** depend on Researcher 1 or 2.
- U08, U47 always use one process on the GPU: their per-round times feed the integrity-overhead table.

## 3. Run it in Google Colab

1. In Google Drive, create the folder `MyDrive/FedKGE_T4/` and upload `FedKGE_T4_INDEPENDENT.zip` from this kit into it. **Do not unzip it and do not rename it.**
2. Open https://colab.research.google.com → File → Upload notebook → choose a notebook from the `notebooks/` folder of this kit.
3. For the unit notebooks and the benchmark: Runtime → Change runtime type → **T4 GPU**. Setup, export and merge run on the CPU.
4. Runtime → **Run all**. Allow access to Google Drive when Colab asks. The notebook mounts Drive at `/content/drive` by itself.
5. Only the setup notebook needs editing: read the licence terms it prints, set the licence flag(s) to `True`, write who confirmed, and run it again. No other notebook needs editing. All paths are already set (`BASE = "/content/drive/MyDrive/FedKGE_T4"`).

**What is installed and checked automatically (setup cell of every notebook)**

- Python 3.10–3.13 and Colab's own PyTorch (not replaced).
- Pinned packages: numpy 2.5.3, scipy 1.18.1, pandas 3.0.5, PyYAML 6.0.3, jsonschema 4.26.0, matplotlib 3.11.2, dp-accounting 0.6.0, prv-accountant 0.2.0, opacus 1.6.0, pytest 9.1.1.
- The code commit, a clean code tree, the core code hash, the frozen run list and the unit plan. A changed or wrong zip is refused.
- **Dataset:** `codex_m` (and the other two, which the merge needs) is downloaded by the setup notebook after the licence confirmation and checked against pinned SHA-256 values. Dataset files never leave your account.
- **GPU:** NVIDIA T4. Use the same GPU type for all your notebooks (section 6).

## 4. If a session stops

Open the **same notebook** again and Run all. That is the whole recovery.

- Finished runs are kept and never run twice.
- An interrupted run resumes from its checkpoint: model, optimizer, privacy accountant, trust state and random-number states.
- The last line of the run cell tells you the state: `UNIT COMPLETE`, `PAUSED` (run again), `some runs FAILED` (run again; they are retried).
- `ACCURACY GATE G-B FAILED` in the tuning notebook means the protocol stops `codex_m`. Do not run its Stage-4 notebooks; the gate report is in `units/U03/master/results/tune/gates/`.

## 5. Where everything is saved (the same in the three kits)

```
MyDrive/FedKGE_T4/
├── FedKGE_T4_INDEPENDENT.zip     the package (code, configurations, frozen run list)
├── data_cache/                   your copy of the dataset (never shared)
├── units/Uxx/                    working folder of unit Uxx: every run, checkpoints, logs
├── results/RESULT_Uxx.zip        the finished result of unit Uxx
├── results/SETTINGS_codex_m.zip   the tuned settings (written by the tuning notebook)
├── export/RESULTS_Researcher_3.zip   your own export (backup)
├── inbox/                        files you receive (the other researchers' exports go here)
├── merge/                        the merged store, analysis tables, figures, report, final export
└── benchmarks/                   output of the optional benchmark
```

**What a unit result contains.** For every run: `config.json`, `status.json`, `final.json` (metrics), `rounds.csv`, `accountant.json` (privacy), `trust_rounds.csv`, `weights_rounds.csv`, `attack.json`, `integrity.json`, `per_relation_test_mrr.json`, `env.json`, `log.txt`, and `final_weights.pt` where the protocol keeps the final model. Plus the job logs, the environment record and the unit record (processes used, sessions, hours). Every file is covered by SHA-256.

**What you must keep.** Keep the whole `MyDrive/FedKGE_T4/` folder until the paper is finished. Round checkpoints stay in `units/` and are not sent. Never edit, rename or delete files inside it by hand.

## 6. Rules that protect the results

- **One environment for your dataset.** The merge accepts one combination of GPU model, torch build, CUDA and Python version for tuning and one for Stage 4 of a dataset. Colab updates its image from time to time, so finish your Stage-4 notebooks within a short period, and always choose the T4. The setup cell prints these values. A mismatch is refused and reported, never mixed.
- **One account for a unit.** Resume a unit in the account where it started.
- **Colab's rules.** Colab does not allow several accounts to be used to get around its limits. Each researcher uses the account they are entitled to use.
- **Nothing is invented.** A missing run stays missing in every table.

## 7. What you receive

- `RESULTS_Researcher_1.zip` and `RESULTS_Researcher_2.zip`. Put them, unchanged, into `MyDrive/FedKGE_T4/inbox/`.
- Your own results are already in `MyDrive/FedKGE_T4/results/`. You do not need to export them for the merge.

## 8. The master integration

1. Make sure the setup notebook of your account prepared **all three** datasets (it does: the merge rebuilds the deterministic partitions of every dataset to check the incoming results against them).
2. Put the two export files into `MyDrive/FedKGE_T4/inbox/`.
3. Open `MERGE_AND_ANALYSE.ipynb` (CPU) → Run all.
4. Read the three reports it prints:
   - **Collection** (`results/COLLECTION_REPORT.md`): which export was read, units complete / missing per researcher, anything refused.
   - **Merge summary** (`merge/master/results/parallel/MERGE_SUMMARY.md`): every unit, the verdict, and whether each `SETTINGS` file equals the merge's own replay of the selection.
   - **Validation report** (same folder): missing, duplicate or incompatible runs.
5. The verdict must be **COMPLETE AND COMPATIBLE**. Then the outputs are final: analysis tables (CSV, Markdown, LaTeX) in `merge/master/results/final/analysis/`, figures in `…/final/figures/`, the report in `…/final/reports/`, and one export zip `merge/fedkge_results_export_<time>.zip`.
6. If units are missing, the summary names the notebook and the researcher. Ask for a new export, put it into `inbox/`, and run the notebook again. You can run the integration as often as you like.

**How the integration keeps the science intact**

- **No overwriting.** A unit that arrives twice is kept once (a complete copy before an incomplete one, then the newer one). The other copy is moved to `results/_superseded/` and listed.
- **No duplicated experiments.** A run is identified by the hash of its configuration; the merged store holds each run once.
- **No mixed configurations.** An export made with another package version is refused as a whole. Every run is checked against the code hash, the frozen run list, the data and partition hashes, and one environment per stage and dataset.
- **Selections are replayed.** The merge re-derives every tuning selection from the imported tuning runs. It never copies a researcher's selection.
- **Nothing is filled in.** Missing units stay PENDING in every table.

## 9. Optional: take over the two replication notebooks from Researcher 1

Researcher 1 has the largest share (45.1 h against your 35.3 h, upper bounds). The two replication notebooks `U24_LEGACY_fb15k237.ipynb`, `U25_LEGACY_fb15k237.ipynb` (5.4 h) need no tuning, so you can run them. They are in `notebooks_optional_help_for_Researcher_1/`.

**Condition:** they are FB15k-237 runs, and the merge accepts one environment for FB15k-237 Stage 4. The line your setup cell prints (GPU name, torch, CUDA build, Python) must be identical to Researcher 1's. If it differs, leave them with Researcher 1. Your setup notebook already prepares FB15k-237, so nothing else is needed. Tell Researcher 1 not to run them.

## 10. Hours of the three kits (upper bounds)

| Researcher | Dataset | Unit notebooks | Runs (max) | T4 GPU-hours (upper bound) |
|---|---|---|---|---|
| 1 | fb15k237 | 18 | 315 | 45.1 |
| 2 | wn18rr | 16 | 285 | 38.5 |
| 3 (you) | codex_m | 15 | 285 | 35.3 |
| **Total** | | **49** | **885** | **118.9** |

The split is by dataset, so the hours are close but not equal. An equal split would send one dataset's Stage-4 runs to two people. They would then wait for each other's tuning and would have to prove identical environments.

More detail: `DEPENDENCY_AND_EXECUTION_TABLE.md` in this kit; the package's own `README.md` and `T4_OPTIMISATION_REPORT.md` inside the package zip.
