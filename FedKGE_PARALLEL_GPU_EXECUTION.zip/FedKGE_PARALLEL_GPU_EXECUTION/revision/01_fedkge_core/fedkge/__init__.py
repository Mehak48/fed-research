"""fedkge - federated knowledge-graph-embedding revision pipeline (Phases 1-4 delivery).

Modules used by Phases 1-4: config, io, data, partition, model, sampling, train, dp, accountant, evaluate,
federated (orchestrator), runner, analysis, stats, selection (DP operating points), reports, schemas, plotting.
Modules already present for the later phases (interfaces fixed now, exercised by the orchestrator with
aggregation.method = fedavg and attack.type = none in P3/P4): aggregators, trust, attacks, integrity, mia.
"""
__version__ = "1.1.0-phaseC"
