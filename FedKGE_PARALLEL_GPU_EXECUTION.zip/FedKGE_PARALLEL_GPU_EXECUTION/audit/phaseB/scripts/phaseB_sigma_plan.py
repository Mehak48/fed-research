#!/usr/bin/env python3
"""Phase B PLANNING calculation: noise multiplier sigma needed for each candidate privacy operating point.

What this is
  A pure accounting calculation (no data, no model, no training). For each candidate DP design it finds the
  smallest noise multiplier sigma such that the worst-case (epsilon, delta) after R rounds is <= the target,
  and reports how large that noise is relative to the clipped per-example signal for each candidate dataset.
  Every number written by this script is labelled [Calculated - Phase B planning]; none is an experimental result.

Independence (stated precisely)
  * Calibration uses Google's dp_accounting public API (RdpAccountant). The revision package also uses
    dp_accounting (private helper functions), so --crosscheck-revision is a check of the SAME LIBRARY through a
    DIFFERENT CODE PATH, not a library-independent check.
  * Method/library-independent checks (independent_checks in the JSON):
      - my own numerical integration of the Poisson-subsampled-Gaussian Renyi divergence (scipy quadrature on a
        grid, no dp_accounting), composed and converted with the same (Balle et al. 2020) formula;
      - the PRV accountant (Gopi, Lee & Wutschitz 2021; package prv-accountant), a different library and method;
      - the PLD accountant (dp_accounting; different method, same library).
  * PLD-based calibration for design Q (R = 100) shows how much noise a PLD-calibrated sigma would save.

Designs
  A  (revision default) fixed expected batch B per client: q_k = B / N_k, steps per round = round(N_k / B),
     one sigma per client calibrated so that client k reaches eps* after R rounds.
  Q  (proposed alternative) common sampling rate q for all clients: expected batch B_k = q * N_k,
     steps per round T = round(1 / q) (one expected local epoch), one sigma shared by all clients, so every
     client has exactly the same (eps, delta). Under design Q, sigma does not depend on the dataset.

Usage
  python3 -I phaseB_sigma_plan.py --out-csv ../data/phaseB_sigma_plan.csv --out-json ../data/phaseB_sigma_plan.json \
      [--crosscheck-revision /path/to/copy/of/accountant.py]
"""
from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import math
import platform
import sys
import time
from importlib import metadata

import dp_accounting

# Orders: Opacus defaults plus higher orders (any order set gives a valid upper bound; more orders = tighter).
ORDERS = sorted(set([1 + x / 10.0 for x in range(1, 100)] + list(range(12, 64))
                    + [64, 72, 80, 96, 112, 128, 160, 192, 256, 384, 512, 1024]))

# Planning constants. Sources: Toutanova & Chen 2015 (FB15k-237 train size); PyKEEN entity count as logged by the
# legacy Phase 3 run (14,505); Dettmers et al. 2018 / Akrami et al. 2020 (WN18RR, YAGO3-10); Safavi & Koutra 2020
# (CoDEx-M). Exact loaded counts are re-measured in Phase D; small differences do not change the conclusions.
DATASETS = {
    "fb15k237": {"n_train": 272_115, "n_entities": 14_505, "n_relations": 237},
    "wn18rr":   {"n_train": 86_835,  "n_entities": 40_943, "n_relations": 11},
    "codex_m":  {"n_train": 185_584, "n_entities": 17_050, "n_relations": 51},
    "yago310":  {"n_train": 1_079_040, "n_entities": 123_182, "n_relations": 37},
    "codex_l":  {"n_train": 551_193, "n_entities": 77_951, "n_relations": 69},   # candidate only (04)
    "codex_s":  {"n_train": 32_888,  "n_entities": 2_034,  "n_relations": 42},   # candidate only (04)
}
DIM = 100
K = 10                      # clients
MIN_FRAC, MIN_ABS = 0.2, 1024   # revision's minimum client size rule
DELTA = 1e-6
EPS_TARGETS = [1.0, 2.0, 4.0, 8.0]
ROUNDS = [50, 100]
Q_GRID = [0.01, 0.02, 0.05, 0.10]
B_FIXED = 512
CLIP = 1.0                  # noise ratios below are per unit of C (they scale out)


def rdp_eps(q: float, steps: int, sigma: float, delta: float) -> float:
    acc = dp_accounting.rdp.RdpAccountant(orders=ORDERS)
    acc.compose(dp_accounting.PoissonSampledDpEvent(q, dp_accounting.GaussianDpEvent(sigma)), int(steps))
    return float(acc.get_epsilon(delta))


def pld_eps(q: float, steps: int, sigma: float, delta: float, vdi: float = 1e-3) -> float:
    acc = dp_accounting.pld.PLDAccountant(value_discretization_interval=vdi)
    acc.compose(dp_accounting.PoissonSampledDpEvent(q, dp_accounting.GaussianDpEvent(sigma)), int(steps))
    return float(acc.get_epsilon(delta))


def rdp_eps_numeric(q: float, steps: int, sigma: float, delta: float, orders=None, n: int = 200_001) -> float:
    """Library-independent RDP epsilon: A_alpha = E_{z~N(0,s^2)}[(1-q + q exp((2z-1)/(2 s^2)))^alpha] by trapezoid
    quadrature in log space (Mironov, Talwar & Zhang 2019 quantity), composed over `steps`, converted with
    eps = rho + log((a-1)/a) - (log delta + log a)/(a-1) (Balle et al. 2020)."""
    import numpy as np
    from scipy.special import logsumexp
    orders = orders or [a for a in ORDERS if a <= 256]
    best = float("inf")
    for a in orders:
        z = np.linspace(-40 * sigma, a + 40 * sigma + 5, n)
        dz = z[1] - z[0]
        log_mu0 = -z ** 2 / (2 * sigma ** 2) - math.log(sigma * math.sqrt(2 * math.pi))
        log_inner = np.logaddexp(math.log1p(-q), math.log(q) + (2 * z - 1) / (2 * sigma ** 2))
        lw = np.full(n, math.log(dz)); lw[0] = lw[-1] = math.log(dz / 2)
        log_a = float(logsumexp(log_mu0 + a * log_inner + lw))
        rho = steps * log_a / (a - 1)
        eps = rho + math.log((a - 1) / a) - (math.log(delta) + math.log(a)) / (a - 1)
        best = min(best, eps)
    return best


def prv_eps(q: float, steps: int, sigma: float, delta: float):
    from prv_accountant import Accountant
    acc = Accountant(noise_multiplier=sigma, sampling_probability=q, delta=delta, eps_error=0.01,
                     max_compositions=int(steps))
    lo, est, up = acc.compute_epsilon(num_compositions=int(steps))
    return float(lo), float(est), float(up)


def calibrate(eps_fn, target: float, lo: float = 0.2, hi: float = 400.0, rel_tol: float = 1e-4) -> float:
    """Smallest sigma (rounded UP to rel_tol) with eps_fn(sigma) <= target. eps is decreasing in sigma."""
    if eps_fn(hi) > target:
        raise RuntimeError(f"target {target} not reachable with sigma <= {hi}")
    if eps_fn(lo) <= target:
        raise RuntimeError(f"target {target} already met at sigma = {lo}; widen the bracket")
    while hi / lo - 1.0 > rel_tol:
        mid = math.sqrt(lo * hi)
        if eps_fn(mid) > target:
            lo = mid
        else:
            hi = mid
    return hi


def client_sizes(ds: dict) -> dict:
    mean = ds["n_train"] / K
    return {"mean_client": mean, "min_allowed_client": max(MIN_ABS, MIN_FRAC * mean)}


def n_params(ds: dict) -> int:
    return (ds["n_entities"] + ds["n_relations"]) * DIM


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out-csv", required=True)
    ap.add_argument("--out-json", required=True)
    ap.add_argument("--no-pld", action="store_true", help="skip the PLD cross-check (faster)")
    ap.add_argument("--crosscheck-revision", default=None,
                    help="path to a COPY of the revision's accountant.py to compare calibrations")
    a = ap.parse_args(argv)
    t0 = time.time()
    rows = []

    # ---------------- design Q: common sampling rate, one sigma for every client (dataset-independent)
    for q in Q_GRID:
        T = int(round(1.0 / q))
        for R in ROUNDS:
            for eps in EPS_TARGETS:
                steps = T * R
                s_rdp = calibrate(lambda s: rdp_eps(q, steps, s, DELTA), eps)
                e_rdp = rdp_eps(q, steps, s_rdp, DELTA)
                e_pld = None if a.no_pld else pld_eps(q, steps, s_rdp, DELTA)
                s_pld = None
                if not a.no_pld and R == 100:
                    s_pld = calibrate(lambda s: pld_eps(q, steps, s, DELTA), eps, lo=0.2, hi=200.0, rel_tol=1e-3)
                for name, ds in DATASETS.items():
                    nbar = client_sizes(ds)["mean_client"]
                    nmin = client_sizes(ds)["min_allowed_client"]
                    P = n_params(ds)
                    rows.append({
                        "design": "Q_common_rate", "dataset": name, "client": "mean", "n_client": round(nbar),
                        "q": q, "steps_per_round": T, "rounds": R, "total_steps": steps,
                        "eps_target": eps, "delta": DELTA, "sigma_rdp": s_rdp, "eps_rdp_at_sigma": e_rdp,
                        "eps_pld_at_sigma": e_pld, "sigma_pld_calibrated": s_pld,
                        "pld_noise_saving_pct": (100 * (1 - s_pld / s_rdp)) if s_pld else None,
                        "expected_batch": q * nbar,
                        "noise_std_per_coord_over_C": s_rdp / (q * nbar),
                        "noise_norm_over_C": s_rdp * math.sqrt(P) / (q * nbar),
                        "smallest_client_expected_batch": q * nmin,
                        "smallest_client_noise_norm_over_C": s_rdp * math.sqrt(P) / (q * nmin),
                        "n_params": P,
                    })

    # ---------------- design A: fixed expected batch B per client, per-client sigma (revision default)
    for name, ds in DATASETS.items():
        P = n_params(ds)
        for label, n in client_sizes(ds).items():
            n = int(round(n))
            q = B_FIXED / n
            T = max(1, int(round(n / B_FIXED)))
            for R in ROUNDS:
                for eps in EPS_TARGETS:
                    steps = T * R
                    s_rdp = calibrate(lambda s: rdp_eps(q, steps, s, DELTA), eps)
                    e_rdp = rdp_eps(q, steps, s_rdp, DELTA)
                    e_pld = None if a.no_pld else pld_eps(q, steps, s_rdp, DELTA)
                    rows.append({
                        "design": "A_fixed_batch", "dataset": name, "client": label, "n_client": n,
                        "q": q, "steps_per_round": T, "rounds": R, "total_steps": steps,
                        "eps_target": eps, "delta": DELTA, "sigma_rdp": s_rdp, "eps_rdp_at_sigma": e_rdp,
                        "eps_pld_at_sigma": e_pld, "sigma_pld_calibrated": None, "pld_noise_saving_pct": None,
                        "expected_batch": float(B_FIXED),
                        "noise_std_per_coord_over_C": s_rdp / B_FIXED,
                        "noise_norm_over_C": s_rdp * math.sqrt(P) / B_FIXED,
                        "smallest_client_expected_batch": None, "smallest_client_noise_norm_over_C": None,
                        "n_params": P,
                    })

    # ---------------- reference: CLIENT-level DP-FedAvg with all K clients every round (no client subsampling)
    # Each round the server adds N(0, z^2 S^2) to the sum of K client updates clipped to norm S. RDP of R Gaussian
    # releases (sampling rate 1). Noise norm on the AVERAGED update relative to the clip S: z * sqrt(P) / K.
    client_level = []
    for R in ROUNDS:
        for eps in EPS_TARGETS:
            z = calibrate(lambda s: rdp_eps(1.0, R, s, DELTA), eps, lo=0.2, hi=5000.0)
            client_level.append({"rounds": R, "eps_target": eps, "delta": DELTA, "noise_multiplier_z": z,
                                 **{f"noise_norm_over_S_{n}": z * math.sqrt(n_params(ds)) / K
                                    for n, ds in DATASETS.items()}})

    # ---------------- library/method-independent checks at the RDP-calibrated sigma
    independent = []
    for q, R, eps in ((0.05, 100, 4.0), (0.02, 100, 1.0), (0.10, 100, 8.0), (0.05, 50, 2.0)):
        T = int(round(1.0 / q))
        steps = T * R
        s_rdp = calibrate(lambda s: rdp_eps(q, steps, s, DELTA), eps)
        rec = {"q": q, "rounds": R, "steps": steps, "eps_target": eps, "sigma_rdp_calibrated": s_rdp,
               "eps_dp_accounting_rdp": rdp_eps(q, steps, s_rdp, DELTA),
               "eps_numeric_rdp_quadrature": rdp_eps_numeric(q, steps, s_rdp, DELTA),
               "eps_dp_accounting_pld": pld_eps(q, steps, s_rdp, DELTA)}
        try:
            lo_, est_, up_ = prv_eps(q, steps, s_rdp, DELTA)
            rec.update({"eps_prv_lower": lo_, "eps_prv_estimate": est_, "eps_prv_upper": up_})
        except Exception as e:  # recorded, never silently ignored
            rec["prv_error"] = repr(e)
        independent.append(rec)

    # ---------------- cross-check against the revision's own calibrator (same library, different code path)
    cross = []
    if a.crosscheck_revision:
        spec = importlib.util.spec_from_file_location("rev_accountant", a.crosscheck_revision)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        checks = [(0.05, 20, 100, 4.0), (0.02, 50, 100, 1.0), (512 / 27212, int(round(27212 / 512)), 100, 4.0),
                  (512 / 5442, int(round(5442 / 512)), 100, 8.0)]
        for q, T, R, eps in checks:
            mine = calibrate(lambda s: rdp_eps(q, T * R, s, DELTA), eps)
            rev = mod.calibrate_sigma0(q=q, steps_per_round=T, rounds=R, shape="fixed", rho=1.0,
                                       target_eps=eps, delta=DELTA, update_every=5)
            cross.append({"q": q, "steps_per_round": T, "rounds": R, "eps_target": eps,
                          "sigma_this_script": mine, "sigma_revision": rev["sigma0"],
                          "eps_revision_at_its_sigma": rev["eps_at_R"],
                          "eps_this_script_at_revision_sigma": rdp_eps(q, T * R, rev["sigma0"], DELTA),
                          "relative_difference": rev["sigma0"] / mine - 1.0})

    cols = list(rows[0].keys())
    with open(a.out_csv, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)
    meta = {
        "label": "[Calculated - Phase B planning] accounting only; no data, no training; NOT an experimental result",
        "mechanism": ("Poisson-subsampled Gaussian (DP-SGD) per client; zero-out adjacency (one triple replaced by a "
                      "null record with zero gradient; client size public and unchanged). The RDP/PLD bounds used are "
                      "the standard ones for this mechanism and coincide with the add/remove analysis."),
        "accountant": "dp_accounting RdpAccountant (calibration) + PLDAccountant (cross-check, vdi=1e-3)",
        "orders": ORDERS, "delta": DELTA, "clients": K, "dim": DIM, "fixed_batch_design_B": B_FIXED,
        "min_client_rule": {"min_frac_of_mean": MIN_FRAC, "min_abs": MIN_ABS},
        "datasets_planning_constants": DATASETS,
        "versions": {"python": platform.python_version(), "dp_accounting": metadata.version("dp-accounting")},
        "seconds": round(time.time() - t0, 1), "n_rows": len(rows), "crosscheck_revision": cross,
        "client_level_dp_reference": client_level,
        "independent_checks": independent,
        "versions_extra": {"prv_accountant": metadata.version("prv-accountant"), "scipy": metadata.version("scipy")},
    }
    with open(a.out_json, "w") as f:
        json.dump(meta, f, indent=2)
    print(f"wrote {len(rows)} rows to {a.out_csv} in {meta['seconds']} s; cross-checks: {len(cross)}")
    for c in cross:
        print("  crosscheck", {k: (round(v, 5) if isinstance(v, float) else v) for k, v in c.items()})
    for c in independent:
        print("  independent", {k: (round(v, 4) if isinstance(v, float) else v) for k, v in c.items()})
    return 0


if __name__ == "__main__":
    sys.exit(main())
