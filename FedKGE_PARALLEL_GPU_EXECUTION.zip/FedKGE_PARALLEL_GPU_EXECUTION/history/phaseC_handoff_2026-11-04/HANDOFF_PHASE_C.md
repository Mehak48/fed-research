# FedKGE project — handoff brief for the next AI

**Snapshot:** 2026-11-04, after the GPU pilot. It supersedes the 2026-11-02 versions, which are kept as `HANDOFF_PHASE_C_2026-11-02_evening.md` and `…_morning.md`.
**Project owner:** Mehak Ramzan · **Prepared by:** Claude (the AI that did Phases A, B and C)

**Where the project stands:**

- Phases A (audit) and B (design) are **complete**.
- **Phase C (repair, test, prepare) is complete** and waits for the owner's review:
  - the code is repaired and tested: 133 / 133 tests pass;
  - the datasets are downloaded (with the owner's licence confirmation) and verified;
  - every block of the plan passed in smoke on the real data;
  - L0 is done;
  - the pilot was measured on CPU and on the owner's **Colab T4 GPU**;
  - all seven Phase C reports are updated.
- **Waiting for the owner:** her review of the Phase C report and her decisions B2–B5 in `audit/phaseC/remaining_blockers.md`.
- **Do not start tuning (Stage 3) or confirmatory runs (Stage 4) before she approves.**

---

## 0. Read this first (rules that override everything else)

The owner wants a **scientifically defensible IEEE paper, not one that only looks convincing**. She wants brutal honesty, scope creep flagged, and small verified steps. Her instructions are in `instructions/`; `4_phaseC_instructions.txt` is the active one.

1. **Never fabricate results.** Never fill gaps with estimates. Never claim that something ran when it did not. Never make tables or figures from invented values.
2. **Never overwrite or delete:**
   - the original code;
   - historical results (`files/`, `complete/`, read-only `audit/` from Phases A and B);
   - failed or inconvenient runs.

   Superseded items are moved aside, never deleted. Run folders go to `<tier>/stale/`, and old report versions to `_versions/`.
3. **Datasets.**
   - The owner confirmed research use of all three on 2026-11-02. Her words are stored in every `data_cache/<dataset>/source_manifest.json` (`operator_note`).
   - **Never put dataset files (or `triples.npz` / `labels.json` artifacts) into a deliverable.** This package contains none.
   - To re-download, use `scripts/prepare_data.py` with that recorded note.
4. **Do not launch tuning or the full matrix** before the owner has approved the budget and decisions B2–B5.
5. **Make no claims of:**
   - client-level DP;
   - IPFS (none exists);
   - SHA-256 integrity as a poisoning defence;
   - any result from smoke or pilot runs;
   - bitwise GPU reproducibility.

   ε is never hard-coded.
6. **Synthetic data is for software tests only.**
7. **Selection uses validation data only.** The final tier refuses to select.
8. **Keep the approved design.** If something is invalid or infeasible:
   - stop;
   - explain;
   - propose the smallest justified fix;
   - wait for approval.
9. **Do not invent the professor's review.** It was never supplied.
10. **Git:** nothing is committed yet. Commit only if the owner asks (B5 asks her).
11. **Never edit `revision/01_fedkge_core/fedkge/*.py` while tests or runs execute.** The code hash changes, and the runs become stale.
12. **One environment per comparison.** The run identity does not include the device. Keep CPU and GPU results in separate results roots, and never mix GPU types or torch versions inside a block.

---

## 1. Package contents

```
fedkge_phaseC_handoff/
├── HANDOFF_PHASE_C.md            ← this file (older versions next to it)
├── instructions/                 ← the owner's own messages (1 master prompt, 2 clarification, 3 Phase B, 4 Phase C)
├── audit/                        ← Phase A (read-only), Phase B design, and audit/phaseC/ (the 7 Phase C reports,
│                                   _versions/2026-11-02/, scripts/gpu_pilot_analysis.py)
├── revision/                     ← THE CODE (git repo, branch phaseC, tag baseline-revision-P1-P4; changes uncommitted)
│   ├── README.md                 ← exact commands and result paths
│   ├── scripts/, colab/          ← entry points; the free-Colab GPU pilot kit (already run)
│   └── results/phaseC/           ← official Phase C outputs (no dataset files, no model weights)
│       └── colab/session_20261104T163226Z/  ← the owner's GPU session, with PROVENANCE.md
├── colab_kit/                    ← the pilot kit exactly as the owner ran it (code zip 4fb27cf8…, notebook, SHA256SUMS)
├── phaseC_changes.patch, phaseC_git_status.txt
├── phaseC_dev_probes/            ← early synthetic probes (not results)
└── reference/legacy_code_extracted/  ← code cells of the original P3 / P4 notebooks
```

**Not included:**

- dataset files (re-download them with `prepare_data.py`);
- model weights;
- the venv (5.3 GB);
- the owner's original uploads, including `complete/global_transe_final.pt`. Ask her for it if L0 is needed again.

**The pilot kit's code zip predates fix PC-6.** It is kept because it is exactly what ran on Colab. The next kit must be built from the current code (core hash `f4de1447…`).

---

## 2. The project in brief

- **Original paper:** "Privacy-Preserving Federated Knowledge Graph Embedding with Adaptive Differential Privacy, IPFS-Based Model Integrity and Trust-Weighted Aggregation on Non-IID Distributed Data" (TransE, FB15k-237, 5 clients).
- **Phase A verdict:** not submittable.
  - Only two real experiments existed, both single-seed with a weak evaluation: a non-private one (MRR 0.2858) and a DP one (MRR 0.009).
  - The reported ε = 15.53 was invalid. The valid worst-client value is ε ≈ 1.98 at δ = 10⁻⁵.
  - Phases 5–8 numbers were hard-coded or simulated.
- **Revised study (Phase B, approved direction):**

| Area | Approved design |
|---|---|
| Datasets | FB15k-237, WN18RR, CoDEx-M |
| Clients and partitions | 10 clients; Dirichlet-over-relations partitions, α ∈ {0.1, 0.5, 1.0}; IID; centralised reference |
| Privacy | Triple-level DP per client, zero-out adjacency; ε ∈ {1, 2, 4, 8} (ε\* = 4), δ = 10⁻⁶ |
| Baselines | DP-FedAvg (main privacy baseline); robust baselines |
| Proposed method | Trust-weighted aggregation (frozen rule + variant V1) |
| Attacks | Main fraction f = 0.2 (0.1 / 0.3 sensitivity); attackers inherit or match the DP noise |
| Integrity | SHA-256 in the data path |
| H3 | MIA audit |
| Seeds | 5 / 10 |
| Selection | Validation-only, pre-registered |
| Order | Staged: tests → smoke → pilot → tuning → confirmatory |

---

## 3. Phases A and B — complete (do not redo)

**Phase A files:**

- `audit/initial_methodology_audit.md` (start with §0);
- `audit/artifact_inventory.md`;
- `audit/result_provenance.csv`.

**Phase B files** (in `audit/phaseB/`):

| File | Contents |
|---|---|
| `02_design_decisions.md` | D1–D18 and the approval sheet |
| `03_methodology_specification.md`, `03a_threat_model.md` | The method, privacy model and threat model |
| `05_privacy_utility_plan.md` | Hypotheses and tests |
| `06_experiment_matrix.md` | Every block with its run counts |
| `07_compute_feasibility.md` | GPU estimates (now superseded by measurements) and stage gates G-A…G-D |
| `08_open_questions.md` | Open questions for the owner |

The owner approved the D1–D18 direction in her Phase C instructions.

---

## 4. Phase C — what is done (details in `audit/phaseC/`)

| Report | Contents |
|---|---|
| `implementation_traceability.md` | 26 components: specification → code path → defect → repair → test → status (now including Pilot-GPU). Also covers Phase B changes C1–C17 |
| `code_changes.md` | Every changed file with its reason; new defects PC-1…PC-7 |
| `privacy_implementation_audit.md` | The 11-point privacy model, verified against the code; accountant validation; L0 and the gap analysis |
| `test_report.md` | Passed / failed / skipped / not-run, by group A–F; smoke, GPU and other executions |
| `environment_report.md` | Machine, versions, network; the owner's Colab T4; dataset sources, licences and measured statistics; partition feasibility |
| `pilot_plan.md` | CPU and GPU pilot measurements, plan-level GPU estimate, calendar arithmetic, gate G-B status, stage plan |
| `remaining_blockers.md` | B1–B18: who must act on what |

**Key facts established** (all measured or executed; none is a result of the revised method):

| Fact | Value |
|---|---|
| Datasets | Split counts equal the official counts (FB15k-237 272,115 / 17,535 / 20,466; WN18RR 86,835 / 3,034 / 3,134; CoDEx-M 185,584 / 10,310 / 10,311). After dropping triples with entities unseen in training: FB valid/test −9/−28, WN18RR −210/−210, CoDEx-M 0 |
| Partition acceptance at α = 0.1 (real counts) | FB15k-237 100 %, **WN18RR 3.1 %**, CoDEx-M 67 %. Feasible, so no fallback, but WN18RR is a heavily truncated Dirichlet that must be disclosed |
| **L0:** the legacy non-private model, re-evaluated | **Test MRR 0.197** (full filtered, head + tail; tail only 0.268, head 0.126). Under the legacy protocol (300 random test triples, tail only): 0.240–0.280. The reported **0.2858 is protocol-inflated** |
| Accountant | 96 operating points × 5 methods, 0 failed checks (run twice). ε is identical on CPU and GPU |
| Tests | Final suite on the final code: **133 passed, 0 failed, 0 errors, 0 skipped** (53 legacy + 80 Phase C). On Colab: 130 passed, 1 skipped as expected. All test inputs are synthetic or analytic |
| Real-data smoke (gate G-A) | 33 / 33 small runs. Tuning chain: all 6 stages, every pre-registered rule applied. Reduced confirmatory matrix: all 28 blocks. Legacy replicas L1–L4: 6 / 6. 0 failures. Schemas: 506 items, 0 failures |
| CPU pilot (full data, 2 rounds) | 18 / 18 (+1 clean re-measurement). Upper bounds on 2 cores: tuning 112 CPU-h, reduced Stage 4 874 CPU-h, so a GPU is required |
| **GPU pilot (owner's Colab T4, 2026-11-04)** | 9 / 9 GPU smoke runs, then 2 × 18 pilot configurations, 0 failures. 2.5–6.5 s per round; 4–17× faster than the CPU. **Upper bounds: tuning 12.4 GPU-h, reduced Stage 4 91.9, Stage 5 57.3, plus L1–L4 ≤ 5.4 (not measured).** Per run, everything falls inside Phase B's range or below its LOW end. GPU memory ≤ 1.35 GB. Integrity costs 12–52 % of a federated round on the GPU (≤ 3 % on CPU) |
| New defects found | **Fixed:** PC-1 (smoke subset cut training to 300 triples), PC-3 (`keep_final_weights` split shared runs), PC-6 (forced reruns wrote over completed run folders). **Closed:** PC-7 (the every-block smoke had missed L1–L4). **Own check and schema mistakes, fixed:** PC-4, PC-5. **Owner decision:** PC-2 (variant V1 statistically weak with 10 clients; B4) |

---

## 5. What is left (ordered)

**1. Owner: review Phase C and decide B2–B5** (`remaining_blockers.md`):

| Decision | Topic | Recommended default |
|---|---|---|
| B2 | Budget and profile | Reduced profile; defer Stage 5; Phase B priority order; Stage 3 on free Colab, then decide free vs paid for Stage 4 |
| B3 | Response if the τ rule has no feasible value | (ii) largest grid τ, labelled "rule not met", reported |
| B4 | Variant V1 | (b) remove the switch; report FPR per size third descriptively |
| B5 | D10 trigger 25 %, H2b 95 %, MIA settings, folder layout, git commit | Keep the proposed values; commit before Stage 3 |

**2. Claude: build the Stage 3 kit** from the current code, after the decisions are applied. It is a session-safe Colab notebook around `scripts/run_plan.py --plan tune --tier tune`, and it must:

- check the code zip's SHA-256;
- record the GPU type and torch version, and refuse to continue a dataset's stage in a different environment;
- resume interrupted runs and skip completed ones;
- keep results on Drive, in a fresh results root;
- stop before a session limit;
- run the G-B sanity check first (T1C, centralised non-private, validation MRR ≥ about ⅔ of the published TransE value). If that check fails, stop.

Re-run the test suite on the final code before building it.

**3. Stage 3 on Colab** (99 runs, ≤ 12.4 GPU-h). Then:

- `freeze_selections.py` (gate G-C);
- hypotheses frozen and the budget confirmed (gate G-D).

**4. Stage 4:**

- `run_plan.py --plan confirm --tier final --profile reduced`;
- `run_legacy_blocks.py --tier final`.

Implement the table and figure builders (B9) before the Stage 4 analysis, generating figures only from executed runs.

**5. Stage 5,** if the budget allows.

---

## 6. Glossary

**Defect IDs:**

- CR / MJ / MN / OP / G: Phase B register (`audit/phaseB/data/defect_register.csv`);
- PC-1…PC-7: found in Phase C (`code_changes.md` §7).

**Decisions:** D1–D18. **Gates:** G-A (tests and smoke), G-B (pilot), G-C (selections frozen), G-D (hypotheses frozen, budget).

**Blocks:**

- N: non-private;
- DP1–3: DP-FedAvg, the complete method, the no-noise ablation;
- R: robustness;
- I: integrity;
- M1: MIA;
- X: extended;
- L0–L4: legacy (L1–L4 = `p3` / `p4` blocks `R3_legacy`, `R3_fixed`, `R4_legacy`, `L1_legacy`, `L2_trainer_fixed`, `L3_accounting_fixed`);
- T1–T3, TAU: tuning.

**Sampling designs:**

- A: expected batch 512, per-client σ;
- Q: common q, T = 1/q, one σ.

**Tiers:** smoke (subsets, one seed per block), pilot (full data, timing), tune (seed 1001), final (confirmatory; selections frozen).
