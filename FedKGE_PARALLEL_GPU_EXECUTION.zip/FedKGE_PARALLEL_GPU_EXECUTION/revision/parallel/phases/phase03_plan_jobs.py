#!/usr/bin/env python3
"""PHASE 03 (master, CPU, seconds) - build the job graph from the approved cells and plan it on your workers.

  python parallel/phases/phase03_plan_jobs.py --base B [--tune-mode chain|stage] [--sync-hours 0.25]
         [--target-job-hours 3] [--measured]

Inputs : <base>/exchange/registry/worker_*.json (phase 00 of every GPU worker); the frozen manifest.
Outputs: <base>/exchange/plan/PLAN.json + PLAN.md (jobs, dependencies, waves, environment-group assignment, simulated
         timeline, critical path), jobs/<job>.json (one spec per job), QUEUE_<worker>.md (what to run, in order).
The job DEFINITIONS are frozen at the first call: later calls (e.g. after adding a worker, or with --measured run
times) only re-plan who runs which job that has not started. --tune-mode chain (default) runs each dataset's
Stage 3 on one worker in one go; stage splits every tuning stage over the workers of the class (more hand-overs).
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

from _cli import finish, layout, parser

from fedkge_parallel.cells import approved_cells
from fedkge_parallel.common import (EXIT_CONTRACT, EXIT_OK, Paths, atomic_write_json, atomic_write_text, read_json,
                                    read_json_or, signature_key, tiers_for, utc_now)
from fedkge_parallel.jobs import Job, build_jobs, check_graph, default_shard_policy, plan_hash
from fedkge_parallel.schedule import best_assignment, plan_summary

CMD = {"TUNECHAIN": "phase04_tuning.py", "TUNESTAGE": "phase04_tuning.py", "MAIN": "phase06_main_experiments.py",
       "LEGACY": "phase07_replications.py"}


def load_workers(L):
    ws = []
    for p in sorted(L.registry.glob("worker_*.json")):
        r = read_json(p)
        if r.get("role", "worker") == "worker":
            ws.append(r)
    return ws


def fixed_groups(L, mode, workers):
    """(tier, dataset) groups that already have a recorded environment in the master store stay in that class."""
    out = {}
    classes = {w["env_class"] for w in workers}
    for tier in sorted(set(tiers_for(mode).values())):
        lock = read_json_or(Paths(L.master, tier).base / "ENVIRONMENT_LOCK.json", {"datasets": {}})
        for ds, rec in (lock.get("datasets") or {}).items():
            k = signature_key(rec["signature"])
            if k not in classes:
                raise SystemExit(f"{tier}/{ds} already started on environment [{k}], but no registered worker has it. "
                                 "Register a worker of that class (phase 00), or the group cannot continue")
            out[f"{tier}/{ds}"] = k
    return out


def measured_hours(L, mode, jobs, cells):
    """Median measured hours per (plan, block, dataset) from COMPLETE runs in the master store (T4-equivalent is NOT
    assumed: the class that ran them is the class that will run the rest of the group)."""
    import pandas as pd
    by_key = {c.cell_key: c for c in cells}
    rec = {}
    for tier in sorted(set(tiers_for(mode).values())):
        runs = Paths(L.master, tier).base / "runs"
        if not runs.exists():
            continue
        for d in runs.iterdir():
            f = d / "final.json"
            if f.exists():
                fin = read_json(f); cfg = read_json(d / "config.json")
                plan = {"tune": "tune", "final": "main"}.get(cfg["phase"], "legacy")
                rec.setdefault((plan, cfg["block"], fin["dataset"]), []).append(fin["runtime"]["total_s"] / 3600)
    med = {k: float(pd.Series(v).median()) for k, v in rec.items()}
    out = {}
    for j in jobs:
        if j.is_worker and j.cells:
            hs = [med.get((by_key[k].plan, by_key[k].block, by_key[k].dataset)) for k in j.cells if not by_key[k].reuse]
            if hs and all(h is not None for h in hs):
                out[j.job_id] = sum(hs)
    return out


def main(argv=None) -> int:
    ap = parser(__doc__)
    ap.add_argument("--tune-mode", choices=["chain", "stage"], default="chain")
    ap.add_argument("--sync-hours", type=float, default=0.25, help="hours per master hand-over (estimate)")
    ap.add_argument("--target-job-hours", type=float, default=3.0, help="aim for jobs of about this many T4 hours")
    ap.add_argument("--measured", action="store_true", help="use measured run times from the master store")
    a = ap.parse_args(argv)
    L = layout(a)
    workers = load_workers(L)
    if not workers:
        print(f"STOP: no GPU worker registered in {L.registry} (run phase 00 on every GPU environment)")
        return finish(EXIT_CONTRACT)
    cells = approved_cells(a.mode)
    prev = read_json_or(L.plan_file, None)
    fixed = fixed_groups(L, a.mode, workers)
    if prev is not None:
        if prev["mode"] != a.mode:
            print(f"STOP: the existing plan is for mode {prev['mode']}"); return finish(EXIT_CONTRACT)
        jobs = [Job.from_dict(d) for d in prev["jobs"]]
        check_graph(jobs, cells)
        tune_mode = prev["tune_mode"]
        print(f"existing job definitions kept ({len(jobs)} jobs, plan hash {prev['plan_hash'][:12]}); re-planning "
              "who runs what")
    else:
        tune_mode = a.tune_mode
        provisional = build_jobs(cells, a.mode, tune_mode, master_sync_hours=a.sync_hours)
        assign, _ = best_assignment(provisional, workers, fixed)
        n_per_group = {}
        for g, cls in assign.items():
            n_per_group[g] = sum(1 for w in workers if w["env_class"] == cls)
        jobs = build_jobs(cells, a.mode, tune_mode, default_shard_policy(n_per_group, a.target_job_hours),
                          master_sync_hours=a.sync_hours)
    durations = measured_hours(L, a.mode, jobs, cells) if a.measured else None
    summ = plan_summary(jobs, workers, durations, fixed)
    plan = {"schema": 1, "mode": a.mode, "tune_mode": tune_mode, "created_utc": (prev or {}).get("created_utc", utc_now()),
            "replanned_utc": utc_now(), "plan_hash": plan_hash(jobs), "workers": workers,
            "jobs": [j.to_dict() for j in jobs], "schedule": summ, "measured_durations": bool(durations),
            "estimate_note": "T4 upper bounds (parallel/cost_table_T4_upper.csv) divided by each worker's declared speed; "
                             "master hand-overs cost --sync-hours; estimates, not measurements"}
    atomic_write_json(L.plan_file, plan)
    jd = L.plan_dir / "jobs"
    for j in jobs:
        p = jd / f"{j.job_id}.json"
        old = read_json_or(p, None)
        if old is not None and old.get("released_utc"):
            continue                                    # a released (materialised) spec is never overwritten
        atomic_write_json(p, j.to_dict())
    _write_markdown(L, plan, jobs, workers)
    print(f"PLAN: {len(jobs)} jobs ({sum(j.is_worker for j in jobs)} GPU jobs), {len(workers)} worker(s); "
          f"estimated makespan {summ['makespan_hours']:.1f} h (critical path {summ['critical_path']['hours']:.1f} h, "
          f"{summ['total_gpu_hours_T4']:.1f} T4 GPU-h in total)")
    print(f"see {L.plan_dir / 'PLAN.md'} and the QUEUE_<worker>.md files")
    return finish(EXIT_OK)


def _write_markdown(L, plan, jobs, workers):
    s = plan["schedule"]
    by = {j.job_id: j for j in jobs}
    lines = ["# FedKGE parallel execution plan", "",
             f"Mode **{plan['mode']}**, tuning **{plan['tune_mode']}** mode, {len(jobs)} jobs, plan hash "
             f"`{plan['plan_hash'][:16]}`. Re-planned {plan['replanned_utc']}.", "",
             f"**Estimates** ({plan['estimate_note']}): makespan **{s['makespan_hours']:.1f} h**, critical path "
             f"**{s['critical_path']['hours']:.1f} h**, total **{s['total_gpu_hours_T4']:.1f} T4 GPU-h**, lower bound "
             f"{s['lower_bound_hours']:.1f} h.", "", "## Environment groups -> worker classes (environment lock)", "",
             "| Group (tier/dataset) | Worker class | Workers |", "|---|---|---|"]
    for g, c in sorted(s["assignment"].items()):
        lines.append(f"| {g} | `{c}` | {', '.join(w['name'] for w in workers if w['env_class'] == c)} |")
    lines += ["", "## Critical path", "", " → ".join(s["critical_path"]["path"]), "", "## Waves (dependency depth)", "",
              "A job may start as soon as ITS OWN dependencies are done; it never waits for the rest of its wave.", ""]
    for i, w in enumerate(s["waves"]):
        lines.append(f"- **Wave {i}** ({len(w)} jobs): " + ", ".join(w[:40]) + (" …" if len(w) > 40 else ""))
    lines += ["", "## Jobs", "", "| Job | Kind | Group | Depends on | Cells | Est. T4 h | Planned worker | Est. start-end (h) |",
              "|---|---|---|---|---|---|---|---|"]
    for j in jobs:
        lines.append(f"| {j.job_id} | {j.kind} | {j.env_group or '-'} | {', '.join(j.deps[:3]) + (' …' if len(j.deps) > 3 else '') or '-'} | "
                     f"{len(j.cells)} | {j.est_hours:.2f} | {s['where'].get(j.job_id, '')} | "
                     f"{s['start'].get(j.job_id, 0):.1f}-{s['finish'].get(j.job_id, 0):.1f} |")
    atomic_write_text(L.plan_dir / "PLAN.md", "\n".join(lines) + "\n")
    for w in workers:
        q = s["queues"].get(w["name"], [])
        ql = [f"# Queue of worker `{w['name']}`", "", f"Class `{w['env_class']}`, declared speed {w['speed']}.", "",
              "Run the jobs in this order. Easiest: `python parallel/phases/run_worker_queue.py --base <B> --worker "
              f"{w['name']} --max-hours <H>` (it skips finished jobs and waits for releases). Or one job at a time:", "",
              "| # | Job | Needs | Command |", "|---|---|---|---|"]
        for i, jid in enumerate(q, 1):
            j = by[jid]
            need = ("release pack from " + ", ".join(j.deps)) if j.requires_release else "-"
            ql.append(f"| {i} | {jid} | {need} | `python parallel/phases/{CMD[j.kind]} --base <B> --worker {w['name']} "
                      f"--job {jid} --max-hours <H>` |")
        atomic_write_text(L.plan_dir / f"QUEUE_{w['name']}.md", "\n".join(ql) + "\n")
        atomic_write_json(L.plan_dir / f"QUEUE_{w['name']}.json", {"worker": w["name"], "jobs": q})


if __name__ == "__main__":
    sys.exit(main())
