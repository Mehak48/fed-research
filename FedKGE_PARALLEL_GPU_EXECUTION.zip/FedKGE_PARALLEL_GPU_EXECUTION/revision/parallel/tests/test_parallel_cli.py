"""Every phase entry point parses its options, and phase 03 plans the research study on registered workers."""
import json
import subprocess
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]
PH = REPO / "parallel" / "phases"
SCRIPTS = sorted(p.name for p in PH.glob("*.py") if p.name != "_cli.py")


@pytest.mark.parametrize("name", SCRIPTS)
def test_help(name):
    p = subprocess.run([sys.executable, str(PH / name), "--help"], cwd=REPO, capture_output=True, text=True,
                       env={"PATH": "/usr/bin:/bin", "FEDKGE_WORKER": "w"})
    assert p.returncode == 0, p.stderr[-2000:]
    assert "usage" in p.stdout.lower()


def _register(base, name, cls_gpu, torch="2.9.0+cu126", speed=1.0):
    sig = {"device_type": "cuda", "gpu_name": cls_gpu, "torch": torch, "cuda": "12.6", "python_minor": "3.12"}
    from fedkge_parallel.common import signature_key
    rec = {"name": name, "role": "worker", "signature": sig, "env_class": signature_key(sig), "speed": speed}
    d = base / "exchange" / "registry"
    d.mkdir(parents=True, exist_ok=True)
    (d / f"worker_{name}.json").write_text(json.dumps(rec))


def test_phase03_plans_research_and_freezes_job_definitions(tmp_path):
    sys.path.insert(0, str(REPO / "parallel"))
    _register(tmp_path, "t4a", "Tesla T4")
    _register(tmp_path, "t4b", "Tesla T4")
    _register(tmp_path, "l4", "NVIDIA L4", speed=1.5)
    run = lambda *a: subprocess.run([sys.executable, str(PH / "phase03_plan_jobs.py"), "--base", str(tmp_path), *a],
                                    cwd=REPO, capture_output=True, text=True)
    p = run()
    assert p.returncode == 0, p.stdout[-3000:] + p.stderr[-3000:]
    plan = json.loads((tmp_path / "exchange" / "plan" / "PLAN.json").read_text())
    assert plan["mode"] == "research" and plan["tune_mode"] == "chain"
    jobs = {j["job_id"]: j for j in plan["jobs"]}
    where = plan["schedule"]["where"]
    cls = {"t4a": "T4", "t4b": "T4", "l4": "L4"}
    by_group = {}
    for jid, j in jobs.items():
        if j["kind"] in ("TUNECHAIN", "MAIN", "LEGACY"):
            by_group.setdefault(j["env_group"], set()).add(cls[where[jid]])
    assert all(len(v) == 1 for v in by_group.values()), by_group          # one class per (tier, dataset)
    for w in cls:
        assert (tmp_path / "exchange" / "plan" / f"QUEUE_{w}.md").exists()
    assert len(list((tmp_path / "exchange" / "plan" / "jobs").glob("*.json"))) == len(jobs)
    h = plan["plan_hash"]
    _register(tmp_path, "t4c", "Tesla T4")
    p2 = run("--tune-mode", "stage")                                       # definitions are kept, only re-planned
    assert p2.returncode == 0 and "existing job definitions kept" in p2.stdout
    plan2 = json.loads((tmp_path / "exchange" / "plan" / "PLAN.json").read_text())
    assert plan2["plan_hash"] == h and plan2["tune_mode"] == "chain"
    assert "t4c" in plan2["schedule"]["queues"]
