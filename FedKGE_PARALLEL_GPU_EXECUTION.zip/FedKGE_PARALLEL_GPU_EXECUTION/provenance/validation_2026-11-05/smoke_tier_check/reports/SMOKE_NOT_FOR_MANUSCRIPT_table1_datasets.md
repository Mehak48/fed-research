# Table 1 — dataset statistics

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| dataset | entities | relations | train | valid (official) | test (official) | valid used | test used | V_sel | V_root | valid dropped (unseen entities) | test dropped (unseen entities) | counts match official | licence | citation | status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| FB15k-237 | 3785 | 219 | 3000 | 17535 | 20466 | 300 | 300 | 240 | 60 | 9 | 28 | True | Freebase-derived KB triples (Freebase data dumps: CC BY 2.5); Microsoft release page states no terms; research use, attribution, no redistribution | Toutanova & Chen 2015 (CVSC); Bordes et al. 2013; Google Freebase | OK |
| WN18RR | 5118 | 11 | 3000 | 3034 | 3134 | 159 | 160 | 127 | 32 | 210 | 210 | True | WordNet licence (Princeton), notice required | Dettmers et al. 2018 (AAAI); Miller 1995 (WordNet) | OK |
| CoDEx-M | 3672 | 41 | 3000 | 10310 | 10311 | 300 | 300 | 240 | 60 | 0 | 0 | True | repository MIT licence; triples from Wikidata (CC0) | Safavi & Koutra 2020 (EMNLP) | OK |
