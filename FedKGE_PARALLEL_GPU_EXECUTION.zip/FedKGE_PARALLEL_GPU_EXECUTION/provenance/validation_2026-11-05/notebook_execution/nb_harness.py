"""Execute RUN_COMPLETE_FEDKGE_RESEARCH.ipynb cell by cell, as written, in one namespace. After cell 1 only the
software-check switches are overridden: smoke tier, CPU, temp Drive folder, the recorded licence note. Records every
cell's outcome. Used only to validate the notebook; never a research run."""
import json, sys, time, traceback, types, io, contextlib
from pathlib import Path
nb_path, drive, zip_path, log_path = map(Path, sys.argv[1:5])
drive.mkdir(parents=True, exist_ok=True)
import shutil; shutil.copy2(zip_path, drive / zip_path.name)
nb = json.loads(nb_path.read_text())
ns = {"__name__": "__main__"}
OVR = {"DRIVE_ROOT": str(drive), "TUNE_TIER": "smoke", "FINAL_TIER": "smoke", "DEVICE": "cpu", "REQUIRE_GPU": False, "RUN_CPU_CHECKS": True,
       "LICENCE_CONFIRMED": {"fb15k237": True, "wn18rr": True, "codex_m": True},
       "LICENCE_NOTE": "Owner Mehak Ramzan confirmed research use of all three datasets on 2026-11-02 (recorded); notebook software check 2026-11-05"}
report = []
code_i = 0
for i, c in enumerate(nb["cells"]):
    if c["cell_type"] != "code": continue
    code_i += 1
    src = "".join(c["source"]); t0 = time.time()
    try:
        exec(compile(src, f"cell{code_i}", "exec"), ns)
        st = "OK"
    except SystemExit as e:
        st = f"SystemExit: {e}"
    except Exception as e:
        st = f"ERROR: {e!r}"; traceback.print_exc()
    if code_i == 1:
        ns.update(OVR)
    report.append({"code_cell": code_i, "status": st, "seconds": round(time.time() - t0, 1), "first_line": src.splitlines()[0][:90]})
    print(f"\n>>> code cell {code_i}: {st} ({report[-1]['seconds']} s)\n", flush=True)
    if st != "OK": break
log_path.write_text(json.dumps(report, indent=1))
print(json.dumps(report, indent=1))
