"""Run directories, atomic writes, status files, provenance, and stale-result detection.

Layout (RESULTS_ROOT is typically on Google Drive):
  RESULTS_ROOT/<tier>/artifacts/p1/<dataset>/...         Phase 1 artifacts
  RESULTS_ROOT/<tier>/artifacts/p2/<dataset>/...         Phase 2 partitions
  RESULTS_ROOT/<tier>/runs/<run_id>/...                  one directory per experiment run
  RESULTS_ROOT/<tier>/index/<phase>_runs_index.csv       block/name -> run_id mapping
  RESULTS_ROOT/<tier>/selection/*.json                   pre-registered selections (P5a, P7-tau)
  RESULTS_ROOT/<tier>/analysis/...                       Phase 5 outputs
  RESULTS_ROOT/final/locked/...                          Phase 8 locked evidence (final tier only)
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import os
import platform
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np

PKG_DIR = Path(__file__).resolve().parent

# Modules whose code determines experimental results. Changing any of them invalidates every run
# produced with the old code (runs record this hash; Phase 5/8 refuse mismatches).
RESULT_MODULES = ("config.py", "data.py", "partition.py", "model.py", "sampling.py", "train.py", "dp.py",
                  "accountant.py", "evaluate.py", "aggregators.py", "trust.py", "attacks.py",
                  "integrity.py", "federated.py", "mia.py", "io.py")
# Modules that only analyse locked outputs (hashed separately; recorded in analysis outputs).
ANALYSIS_MODULES = ("stats.py", "selection.py", "plotting.py", "analysis.py", "runner.py", "reports.py", "schemas.py",
                    # final package: gates, frozen manifest, hypotheses, paper tables, figures, draft, fixtures
                    "gates.py", "manifest.py", "hypotheses.py", "paper.py", "figures.py", "context.py", "draft.py",
                    "fixtures.py", "reporting.py")

STATUS_RUNNING, STATUS_COMPLETE, STATUS_FAILED = "RUNNING", "COMPLETE", "FAILED"


class IntegrityError(RuntimeError):
    """Raised when an upstream artifact is missing, stale, or its hash does not match."""


def utc_now() -> str:
    """Timezone-aware UTC timestamp (replaces the deprecated datetime.utcnow(); defect MN-8)."""
    return _dt.datetime.now(_dt.timezone.utc).isoformat().replace("+00:00", "Z")


def plain(obj: Any) -> Any:
    """Convert numpy scalars/arrays (recursively) to plain Python objects, so checkpoints can be loaded with
    torch.load(weights_only=True) (defect MN-16) and JSON stays portable."""
    if isinstance(obj, dict):
        return {k: plain(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [plain(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, np.bool_):
        return bool(obj)
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, np.floating):
        return float(obj)
    return obj


def _hash_files(names) -> str:
    h = hashlib.sha256()
    for n in sorted(names):
        p = PKG_DIR / n
        if not p.exists():
            raise IntegrityError(f"fedkge module missing: {p}")
        h.update(n.encode())
        h.update(p.read_bytes())
    return h.hexdigest()


def code_hash() -> str:
    return _hash_files(RESULT_MODULES)


def analysis_code_hash() -> str:
    return _hash_files(ANALYSIS_MODULES)


def git_commit() -> Optional[str]:
    try:
        out = subprocess.run(["git", "rev-parse", "HEAD"], cwd=PKG_DIR, capture_output=True, text=True, timeout=5)
        return out.stdout.strip() or None if out.returncode == 0 else None
    except Exception:
        return None


def environment() -> Dict[str, Any]:
    info: Dict[str, Any] = {
        "python": sys.version.split()[0], "platform": platform.platform(),
        "processor": platform.processor() or platform.machine(), "cpu_count": os.cpu_count(),
        "timestamp_utc": utc_now(), "code_hash": code_hash(),
        "git_commit": git_commit(),
    }
    try:
        import torch
        info["torch"] = torch.__version__
        info["cuda_available"] = bool(torch.cuda.is_available())
        info["torch_threads"] = torch.get_num_threads()
        if torch.cuda.is_available():
            info["gpu"] = torch.cuda.get_device_name(0)
            info["cuda"] = torch.version.cuda
    except Exception as e:  # torch is required for runs; recorded if absent in analysis-only sessions
        info["torch_error"] = repr(e)
    for mod in ("numpy", "scipy", "pandas", "dp_accounting", "prv_accountant", "pykeen"):
        try:
            info[mod] = __import__(mod).__version__
        except Exception:
            info[mod] = None
    return info


def _json_default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, Path):
        return str(o)
    raise TypeError(f"not JSON serialisable: {type(o)}")


def write_json(path: Path, obj: Any) -> None:
    """Atomic JSON write (temp file + rename) so a Colab disconnect never leaves a half-written file."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    with os.fdopen(fd, "w") as f:
        json.dump(obj, f, indent=2, default=_json_default, allow_nan=True)
    os.replace(tmp, path)


def read_json(path: Path) -> Any:
    path = Path(path)
    if not path.exists():
        raise IntegrityError(f"required file missing: {path}")
    with open(path) as f:
        return json.load(f)


def write_csv(path: Path, df) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    df.to_csv(tmp, index=False)
    os.replace(tmp, path)


def atomic_torch_save(obj: Any, path: Path) -> None:
    """torch.save through a temporary file in the same directory + rename (final package: a Colab disconnect during
    a checkpoint write can no longer leave a truncated checkpoint.pt; the previous checkpoint stays valid)."""
    import torch
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=path.name + ".", suffix=".tmp")
    os.close(fd)
    try:
        torch.save(obj, tmp)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_arrays(*arrays: np.ndarray) -> str:
    h = hashlib.sha256()
    for a in arrays:
        a = np.ascontiguousarray(a)
        h.update(str(a.dtype).encode()); h.update(str(a.shape).encode()); h.update(a.tobytes())
    return h.hexdigest()


class Paths:
    def __init__(self, results_root: str | Path, tier: str):
        self.root = Path(results_root)
        self.tier = tier
        self.base = self.root / tier

    def p1(self, ds: str) -> Path: return self.base / "artifacts" / "p1" / ds
    def p2(self, ds: str) -> Path: return self.base / "artifacts" / "p2" / ds
    def run(self, rid: str) -> Path: return self.base / "runs" / rid
    def index(self, phase: str) -> Path: return self.base / "index" / f"{phase}_runs_index.csv"
    def selection(self, name: str) -> Path: return self.base / "selection" / f"{name}.json"
    def analysis(self) -> Path: return self.base / "analysis"
    def cache(self) -> Path: return self.root / "_cache"
    def locked(self) -> Path: return self.root / "final" / "locked"


class RunDir:
    """One experiment run. Status transitions: (none) -> RUNNING -> COMPLETE | FAILED."""

    def __init__(self, path: Path):
        self.path = Path(path)

    @property
    def status_file(self) -> Path: return self.path / "status.json"

    def status(self) -> Optional[Dict[str, Any]]:
        return read_json(self.status_file) if self.status_file.exists() else None

    def set_status(self, status: str, **extra) -> None:
        write_json(self.status_file, {"status": status, "code_hash": code_hash(),
                                      "time_utc": utc_now(), **extra})

    def is_complete_and_current(self) -> bool:
        st = self.status()
        return bool(st and st["status"] == STATUS_COMPLETE and st.get("code_hash") == code_hash()
                    and (self.path / "final.json").exists())

    def is_stale(self) -> bool:
        st = self.status()
        return bool(st and st.get("code_hash") != code_hash())

    def archive_stale(self, reason: str = "stale") -> Path:
        """Move the run directory aside (never delete it): <tier>/stale/<run_id>.<reason>-<UTC stamp>."""
        stamp = _dt.datetime.now(_dt.timezone.utc).strftime("%Y%m%dT%H%M%S")
        dest = self.path.parent.parent / "stale" / f"{self.path.name}.{reason}-{stamp}"
        n = 1
        while dest.exists():                  # Phase C fix (PC-6): two archives in one second never collide
            dest = dest.with_name(f"{self.path.name}.{reason}-{stamp}-{n}")
            n += 1
        dest.parent.mkdir(parents=True, exist_ok=True)
        os.replace(self.path, dest)
        return dest


def verify_artifact(manifest_path: Path, expected_hash: Optional[str] = None) -> Dict[str, Any]:
    """Load an artifact manifest, re-hash the files it lists, fail on any mismatch."""
    man = read_json(manifest_path)
    for rel, h in man.get("files", {}).items():
        fp = manifest_path.parent / rel
        if not fp.exists():
            raise IntegrityError(f"artifact file missing: {fp}")
        if sha256_file(fp) != h:
            raise IntegrityError(f"artifact file modified since creation: {fp}")
    if expected_hash is not None and man.get("content_hash") != expected_hash:
        raise IntegrityError(f"upstream content hash changed for {manifest_path} "
                             f"(expected {expected_hash}, found {man.get('content_hash')}); rerun downstream")
    return man
