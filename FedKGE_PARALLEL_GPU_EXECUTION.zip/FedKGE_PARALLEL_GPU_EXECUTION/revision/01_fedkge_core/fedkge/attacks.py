"""Adversary implementations (see 13_documentation/THREAT_MODEL.md for the formal model).

Capabilities: a static set of f compromised clients (chosen before training: seeded-random or the largest client)
submit arbitrary updates each round and collude. Sybil: the adversary registers k extra identities without data.
The adversary cannot modify benign clients' updates, the server, or break SHA-256.

Knowledge levels
  black : own data + the global model each round (what any client sees)
  gray  : black + the aggregation rule and ALL its parameters (tau, lam, norm bound, reference definition);
          benign statistics are ESTIMATED from the colluders' own honestly computed updates plus the previous
          global update (observable by every client). No access to other clients' updates or DP noise.
  white : gray + the actual (DP-noised) updates of all benign clients in the current round (omniscient bound).

Attack types (strength parameter s)
  signflip  U_m = -s * U_m^honest                                              black
  gaussian  U_m ~ N(0, (s * ||U_m^honest|| / sqrt(P))^2 I)                      black
  alie      U_m = mu - z * sd  (coordinate-wise benign mean/std; z from n, f as in Baruch et al. 2019)   white
  ipm       U_m = -s * mean(benign)                (Xie et al. 2020)            white
  targeted  malicious clients add poison triples (h, r, t*) to their local data and boost the update by s
            (goal: make t* rank top-10 for (h, r, ?))                           black
  adaptive  tailored to the PROPOSED rule (AGR-tailored, Shejwalkar & Houmansadr 2021): U_m = mu_est - gamma*sd_est,
            gamma = the LARGEST value on a grid for which the attacker's own simulation of the proposed anomaly
            score keeps every malicious update below tau*(1 - margin)          gray | white
  sybil     k data-less identities submit -s * (previous global update) + small jitter, claiming the median
            benign client size                                                  black
"""
from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np
import torch
from scipy.stats import norm as _norm

from .trust import anomaly_scores


def choose_malicious(sizes: np.ndarray, f: int, placement: str, rng: np.random.Generator) -> List[int]:
    n = len(sizes)
    if f <= 0:
        return []
    if f >= n:
        raise ValueError("cannot corrupt all clients")
    if placement == "largest":
        return [int(i) for i in np.argsort(-sizes, kind="stable")[:f]]
    if placement == "random":
        return sorted(int(i) for i in rng.choice(n, size=f, replace=False))
    raise ValueError(f"unknown placement {placement}")


def make_targets(test: np.ndarray, all_true: np.ndarray, n_ent: int, m: int, rng: np.random.Generator) -> np.ndarray:
    """LEGACY (revision as delivered, defect MN-21): target queries drawn from the TEST split, which a black-box
    attacker cannot know. Kept only so the old behaviour can be reproduced; the pipeline uses
    make_targets_from_attacker_data."""
    return _targets_from_pairs(test, all_true, n_ent, m, rng)


def make_targets_from_attacker_data(attacker_triples: np.ndarray, all_true: np.ndarray, n_ent: int, m: int,
                                    rng: np.random.Generator) -> np.ndarray:
    """Phase C (MN-21): the m target queries (h, r) are drawn from the ATTACKERS' OWN training triples; t* is a
    uniformly drawn entity that the evaluator confirms is NOT a known true tail of (h, r) and differs from h.
    In clean runs the same function is called with the data of the clients that WOULD be malicious under the
    seeded placement, so clean and attacked runs of one seed share the same targets (paired damage)."""
    if len(attacker_triples) == 0:
        raise ValueError("no attacker data to draw targets from")
    pairs = np.unique(attacker_triples[:, :2], axis=0)
    return _targets_from_pairs(np.concatenate([pairs, np.zeros((len(pairs), 1), dtype=pairs.dtype)], 1),
                               all_true, n_ent, m, rng)


def _targets_from_pairs(trip: np.ndarray, all_true: np.ndarray, n_ent: int, m: int,
                        rng: np.random.Generator) -> np.ndarray:
    known = {}
    for h, r, t in all_true.tolist():
        known.setdefault((h, r), set()).add(t)
    idx = rng.choice(len(trip), size=min(m, len(trip)), replace=False)
    out = []
    for h, r, _t in trip[idx].tolist():
        bad = known.get((h, r), set())
        if len(bad) >= n_ent - 1:
            continue
        while True:
            ts = int(rng.integers(n_ent))
            if ts not in bad and ts != h:
                break
        out.append((h, r, ts))
    return np.array(out, dtype=np.int64).reshape(-1, 3)


# ----------------------------------------------------------------------------- DP noise handling (Phase B D16)
NOISE_FROM_HONEST = ("signflip", "gaussian", "targeted")       # built from the attacker's own (noisy) update
NOISE_CRAFTED = ("alie", "ipm", "adaptive", "sybil")            # crafted from statistics; noise must be added


def resolve_noise_mode(attack_type: str, mode: str, dp_on: bool) -> str:
    """auto -> 'inherit' for attacks built on the attacker's own DP update, 'matched' for crafted attacks, under DP;
    'none' without DP. 'none' under DP = the attacker skips DP (secondary check X5, the revision's behaviour)."""
    if not dp_on:
        return "none"
    if mode == "auto":
        return "inherit" if attack_type in NOISE_FROM_HONEST else "matched"
    if mode == "inherit" and attack_type not in NOISE_FROM_HONEST:
        raise ValueError(f"noise_mode 'inherit' is undefined for crafted attack {attack_type}")
    if mode == "matched" and attack_type in NOISE_FROM_HONEST:
        raise ValueError(f"noise_mode 'matched' is undefined for {attack_type} (use inherit)")
    if mode not in ("inherit", "matched", "none"):
        raise ValueError(f"unknown noise_mode {mode}")
    return mode


def match_norm(V: torch.Tensor, target_norm: float, xi: torch.Tensor) -> torch.Tensor:
    """Add c * xi (xi ~ N(0, I) drawn by the attacker) with c >= 0 chosen so that ||V + c xi|| = target_norm.
    If ||V|| >= target_norm no noise is added (noise cannot reduce the norm in expectation)."""
    v2 = float(V @ V)
    t2 = float(target_norm) ** 2
    if v2 >= t2:
        return V
    a, b, c0 = float(xi @ xi), 2.0 * float(V @ xi), v2 - t2
    c = (-b + np.sqrt(b * b - 4 * a * c0)) / (2 * a)
    return V + float(c) * xi


def alie_z(n: int, f: int) -> float:
    s = int(np.floor(n / 2 + 1)) - f
    return float(_norm.ppf((n - s) / n))


def _adaptive_search(mu: torch.Tensor, sd: torch.Tensor, surrogate: torch.Tensor, f: int, tau: float,
                     margin: float, gamma_max: float, grid: int, finish=None) -> Dict:
    """Largest gamma such that the simulated anomaly score of the malicious update is <= tau*(1-margin).
    finish(V) -> V' applies the attacker's own post-processing (e.g. matched DP noise) INSIDE the simulation, so
    the attacker optimises the update it will actually send."""
    finish = finish or (lambda V: V)
    best, feasible_any = 0.0, False
    best_update = finish(mu)
    for g in np.linspace(0.0, gamma_max, grid):
        V = finish(mu - float(g) * sd)
        Usim = torch.cat([surrogate, V.unsqueeze(0).expand(f, -1)], 0)
        A = anomaly_scores(Usim)["A"][-f:]
        if bool((A <= tau * (1 - margin)).all()):
            best, feasible_any, best_update = float(g), True, V
    return {"gamma": best, "feasible": feasible_any, "update": best_update}


def craft(attack: Dict, honest_mal: List[torch.Tensor], benign: torch.Tensor, prev_global_update: torch.Tensor,
          n_total: int, f: int, agg_cfg: Dict, gen: torch.Generator, noise_mode: str = "none",
          sybil_noise: Optional[List[torch.Tensor]] = None) -> Dict:
    """Return {'updates': [f tensors], 'info': {...}} for the malicious rows of this round.

    honest_mal : the attackers' own honestly computed updates (with DP noise when DP is on and noise_mode is
                 'inherit'/'matched'; without DP when noise_mode is 'none').
    noise_mode : 'inherit' (signflip/gaussian/targeted: noise comes from the honest DP update), 'matched'
                 (alie/ipm/adaptive: isotropic noise added so the norm equals the attacker's own honest DP update
                 norm; sybil: the pure-noise update of the DP client protocol run on empty data), 'none'.
    """
    typ, s = attack["type"], float(attack.get("strength", 1.0))
    P = benign.shape[1]
    dev = benign.device
    info: Dict = {"noise_mode": noise_mode}
    matched = noise_mode == "matched"
    if matched and typ in ("alie", "ipm", "adaptive") and not honest_mal:
        raise ValueError("matched noise needs the attackers' honest DP updates")
    xis = [torch.randn(P, generator=gen, device=dev) for _ in range(f)] if matched and typ != "sybil" else None
    tnorm = [float(torch.linalg.vector_norm(u)) for u in honest_mal]

    def finish(V, j=0):
        return match_norm(V, tnorm[j % len(tnorm)], xis[j]) if matched else V

    if typ in ("signflip", "targeted"):
        ups = [(-s if typ == "signflip" else s) * u for u in honest_mal]
    elif typ == "gaussian":
        ups = [torch.randn(P, generator=gen, device=u.device) * (s * torch.linalg.vector_norm(u) / P ** 0.5)
               for u in honest_mal]
    elif typ == "alie":
        mu, sd = benign.mean(0), benign.std(0, unbiased=True)
        z = alie_z(n_total, f) if attack.get("alie_z") is None else float(attack["alie_z"])
        info["alie_z"] = z
        ups = [finish(mu - z * sd, j) for j in range(f)]
    elif typ == "ipm":
        ups = [finish(-s * benign.mean(0), j) for j in range(f)]
    elif typ == "adaptive":
        if attack["knowledge"] == "white":
            surrogate = benign
        else:  # gray: colluders' honest updates + previous global update
            surrogate = torch.stack(list(honest_mal) + [prev_global_update], 0)
        mu, sd = surrogate.mean(0), surrogate.std(0, unbiased=True)
        res = _adaptive_search(mu, sd, surrogate, f, float(agg_cfg["tau"]), float(attack.get("margin", 0.05)),
                               float(attack.get("gamma_max", 20.0)), int(attack.get("gamma_grid", 81)),
                               finish=(lambda V: finish(V, 0)))
        info.update({"gamma": res["gamma"], "feasible": res["feasible"],
                     "gamma_at_max": bool(res["gamma"] >= float(attack.get("gamma_max", 20.0)) - 1e-12),
                     "crafted_against_tau": float(agg_cfg["tau"])})
        ups = [res["update"]] + [finish(mu - res["gamma"] * sd, j) for j in range(1, f)]
    elif typ == "sybil":
        base = -s * prev_global_update
        if matched:
            if sybil_noise is None or len(sybil_noise) != f:
                raise ValueError("matched Sybil needs one DP pure-noise update per identity")
            ups = [base + z for z in sybil_noise]
        else:
            scale = 0.01 * torch.linalg.vector_norm(base) / P ** 0.5 if float(torch.linalg.vector_norm(base)) > 0 \
                else torch.tensor(1e-6, device=dev)
            ups = [base + torch.randn(P, generator=gen, device=dev) * scale for _ in range(f)]
    else:
        raise ValueError(f"unknown attack {typ}")
    info["mean_malicious_norm"] = float(np.mean([float(torch.linalg.vector_norm(u)) for u in ups]))
    if tnorm:
        info["mean_attacker_honest_norm"] = float(np.mean(tnorm))
    return {"updates": ups, "info": info}
