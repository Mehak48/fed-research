"""Accountant correctness: reproduces the old log, monotonicity, calibration, RDP vs PLD, schedules."""
import numpy as np
import pytest

from fedkge import accountant as A

# client sizes of the old Phase 4 run (relation-disjoint FB15k-237, 5 clients) and the logged per-round epsilons
OLD_SIZES = [83830, 56322, 41261, 50033, 40669]
OLD_LOG = [0.8609, 0.9422, 1.0339, 0.9757, 1.0406]


def test_reproduces_old_per_round_log():
    for n, e in zip(OLD_SIZES, OLD_LOG):
        d = A.dp_steps_and_rate(n, 256, legacy_opacus=True)
        assert round(A.legacy_round_epsilon(d["q"], d["steps"], 1.0, 1e-5), 4) == e


def test_old_naive_sum_is_not_composition():
    """16 rounds: the naive sum of per-round means (old '15.53'-style number) greatly exceeds true RDP composition."""
    naive, worst = 0.0, 0.0
    for _ in range(16):
        naive += np.mean(OLD_LOG)
    for n in OLD_SIZES:
        d = A.dp_steps_and_rate(n, 256, legacy_opacus=True)
        worst = max(worst, A.eps_from_rdp(A.composed_rdp(d["q"], [d["steps"]] * 16, [1.0] * 16, A.OPACUS_DEFAULT_ORDERS),
                                          1e-5, A.OPACUS_DEFAULT_ORDERS))
    assert naive > 14 and worst < 3.0 and worst < naive / 5


def test_monotonicity():
    q, k = 0.02, 50
    e = [A.eps_from_rdp(A.composed_rdp(q, [k] * 10, [s] * 10), 1e-6) for s in (0.8, 1.2, 2.0, 4.0)]
    assert all(a > b for a, b in zip(e, e[1:]))
    e2 = [A.eps_from_rdp(A.composed_rdp(q, [k] * r, [1.5] * r), 1e-6) for r in (1, 5, 20)]
    assert all(a < b for a, b in zip(e2, e2[1:]))


@pytest.mark.parametrize("shape,rho", [("fixed", 1.0), ("linear", 0.5), ("exponential", 0.25), ("cosine", 0.5)])
def test_calibration_meets_target_tightly(shape, rho):
    q, k, R, target = 512 / 27000, 53, 40, 4.0
    c = A.calibrate_sigma0(q, k, R, shape, rho, target, 1e-6, update_every=5)
    assert c["eps_at_R"] <= target
    g = A.schedule_multipliers(shape, rho, R, 5)
    looser = A.eps_from_rdp(A.composed_rdp(q, [k] * R, list(0.99 * c["sigma0"] * g)), 1e-6)
    assert looser > target            # 1% less noise would violate the budget -> calibration is tight


def test_rdp_vs_pld_crosscheck():
    q, k, R = 0.02, 50, 30
    sig = list(1.5 * A.schedule_multipliers("cosine", 0.5, R, 5))
    rdp = A.eps_from_rdp(A.composed_rdp(q, [k] * R, sig), 1e-6)
    pld = A.pld_epsilon(q, [k] * R, sig, 1e-6)
    assert pld <= rdp * 1.01 and pld >= 0.6 * rdp   # PLD is tighter, same order of magnitude


def test_cumulative_equals_recomputation():
    q, ks, sig = 0.03, [20] * 8, [2.0, 2.0, 1.5, 1.5, 1.2, 1.2, 1.0, 1.0]
    cum = A.cumulative_epsilons(q, ks, sig, 1e-6)
    for t in range(1, 9):
        assert abs(cum[t - 1] - A.eps_from_rdp(A.composed_rdp(q, ks[:t], sig[:t]), 1e-6)) < 1e-12


def test_schedules():
    for shape, rho in (("linear", 0.25), ("exponential", 0.5), ("cosine", 0.25)):
        g = A.schedule_multipliers(shape, rho, 100, 5)
        assert g[0] == 1.0 and abs(g[-1] - rho) < 1e-12 and np.all(np.diff(g) <= 1e-12)
        assert len(set(np.round(g, 12))) == 20          # piecewise-constant, 20 blocks of 5 rounds
    assert np.all(A.schedule_multipliers("fixed", 1.0, 10) == 1)


def test_main_orders_cover_optimum():
    """The optimal RDP order must lie strictly inside MAIN_ORDERS for the regimes we use (else widen the set)."""
    from dp_accounting.rdp import rdp_privacy_accountant as R
    for n in (5000, 27000, 108000):
        d = A.dp_steps_and_rate(n, 512, False)
        for target in (1.0, 2.0, 4.0, 8.0):
            c = A.calibrate_sigma0(d["q"], d["steps"], 100, "fixed", 1.0, target, 1e-6)
            rdp = A.composed_rdp(d["q"], [d["steps"]] * 100, c["sigmas"])
            _, order = R.compute_epsilon(np.array(A.MAIN_ORDERS), rdp, 1e-6)
            assert min(A.MAIN_ORDERS) < order < max(A.MAIN_ORDERS)


def test_small_client_fails_loudly():
    with pytest.raises(A.AccountantError):
        A.dp_steps_and_rate(100, 512, False)
