# Table 8 — Stage 3 selection (T3); validation only

> **SMOKE TIER - SOFTWARE CHECK - NOT FOR MANUSCRIPT**

| dataset | dp.schedule.shape | dp.schedule.rho | val_mrr_mean | chosen | tied_within_tolerance |
|---|---|---|---|---|---|
| codex_m | cosine | 0.25 | 0.002009 | False | True |
| codex_m | cosine | 0.5 | 0.002015 | False | True |
| codex_m | exponential | 0.25 | 0.002009 | False | True |
| codex_m | exponential | 0.5 | 0.002015 | False | True |
| codex_m | fixed | 1 | 0.002018 | True | True |
| codex_m | linear | 0.25 | 0.00201 | False | True |
| codex_m | linear | 0.5 | 0.002015 | False | True |
| fb15k237 | cosine | 0.25 | 0.002598 | False | True |
| fb15k237 | cosine | 0.5 | 0.002598 | False | True |
| fb15k237 | exponential | 0.25 | 0.002598 | False | True |
| fb15k237 | exponential | 0.5 | 0.002598 | False | True |
| fb15k237 | fixed | 1 | 0.002599 | True | True |
| fb15k237 | linear | 0.25 | 0.002598 | False | True |
| fb15k237 | linear | 0.5 | 0.002598 | False | True |
| wn18rr | cosine | 0.25 | 0.0008415 | False | True |
| wn18rr | cosine | 0.5 | 0.0008414 | False | True |
| wn18rr | exponential | 0.25 | 0.0008415 | False | True |
| wn18rr | exponential | 0.5 | 0.0008415 | False | True |
| wn18rr | fixed | 1 | 0.0008418 | True | True |
| wn18rr | linear | 0.25 | 0.0008415 | False | True |
| wn18rr | linear | 0.5 | 0.0008412 | False | True |
