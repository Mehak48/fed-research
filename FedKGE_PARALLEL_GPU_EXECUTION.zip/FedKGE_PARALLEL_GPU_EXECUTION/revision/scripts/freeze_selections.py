#!/usr/bin/env python3
"""Gate G-C: freeze the Stage-3 selections for Stage 4 (decision D13).

Copies <results>/tune/selection/tuning.json to <results>/final/selection/tuning.json and writes FROZEN.json with its
SHA-256, the rule hashes, the gate G-B outcome, the tau outcome per dataset (B3 labels), the D10 flag (B5), and the
hashes of the frozen manifest and of the pre-registered hypotheses. Refuses to freeze when:
  * gate G-B has not passed for a dataset that is being frozen (the accuracy sanity check is a prerequisite);
  * a dataset has no tau selection yet (Stage 3 incomplete);
  * the configs or the core code differ from the frozen manifest;
  * a dataset that is already frozen would get a DIFFERENT value (frozen selections are append-only: datasets
    finished in later sessions may be added, nothing already frozen can change).
Only datasets whose Stage 3 is finished (a tau selection exists) are frozen; a dataset still being tuned is listed as
skipped and can be frozen later. The frozen file contains only the frozen datasets (and the rule records).

  python scripts/freeze_selections.py [--results R] [--datasets fb15k237 ...]
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time

from _common import CONFIG_DIR, Manifest, git_commit, results_root
from fedkge.io import IntegrityError, read_json, write_json
from fedkge.manifest import verify_frozen

DATASETS = ("fb15k237", "wn18rr", "codex_m")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(); ap.add_argument("--results")
    ap.add_argument("--datasets", nargs="*", help="freeze only these datasets (default: every dataset with a tau selection)")
    a = ap.parse_args(argv)
    root = results_root(a.results)
    man = Manifest(root, "freeze_selections")
    src, dst = root / "tune" / "selection" / "tuning.json", root / "final" / "selection" / "tuning.json"
    if not src.exists():
        raise SystemExit(f"no tuning selections at {src}: run Stage 3 first")
    try:
        frozen_manifest = verify_frozen(CONFIG_DIR)
    except IntegrityError as e:
        man.close("MANIFEST_MISMATCH", reason=str(e)); raise SystemExit(f"STOP: {e}")
    sel = read_json(src)
    wanted = [d for d in DATASETS if d in sel and (not a.datasets or d in a.datasets)]
    skipped = [d for d in wanted if "tau" not in sel[d] and not a.datasets]
    dsets = [d for d in wanted if d not in skipped]
    for d in skipped:
        print(f"{d}: Stage 3 not finished (no tau selection yet) - not frozen now; freeze it after its Stage 3")
    gate_p = root / "tune" / "gates" / "sanity_gate.json"
    gate = read_json(gate_p) if gate_p.exists() else {"datasets": {}}
    problems = []
    for ds in dsets:
        if not (gate["datasets"].get(ds) or {}).get("passed"):
            problems.append(f"{ds}: gate G-B has not passed ({(gate['datasets'].get(ds) or {}).get('status', 'NOT EVALUATED')})")
        if "tau" not in sel[ds]:
            problems.append(f"{ds}: no tau selection (Stage 3 stage 6 not finished)")
    if not dsets:
        problems.append("the tuning selection contains no dataset")
    if problems:
        man.close("REFUSED", problems=problems)
        raise SystemExit("freeze refused:\n  " + "\n  ".join(problems))
    frozen_sel = {k: v for k, v in sel.items() if k.startswith("_") or k in dsets}
    if dst.exists():
        old = read_json(dst)
        for ds in old:                                    # keep datasets frozen earlier (append-only)
            if not ds.startswith("_") and ds not in frozen_sel:
                frozen_sel[ds] = old[ds]
        changed = [ds for ds in old if not ds.startswith("_") and old[ds] != frozen_sel.get(ds)]
        if changed:
            man.close("REFUSED", changed=changed)
            raise SystemExit(f"a DIFFERENT frozen selection already exists for {changed}; refusing to overwrite "
                             "(frozen selections are append-only)")
    dst.parent.mkdir(parents=True, exist_ok=True)
    write_json(dst, frozen_sel)
    h = hashlib.sha256(dst.read_bytes()).hexdigest()
    dsets = sorted({d for d in frozen_sel if not d.startswith("_")}, key=DATASETS.index)
    d10_p = root / "tune" / "gates" / "d10_trigger.json"
    d10 = read_json(d10_p) if d10_p.exists() else {"status": "NOT_EVALUATED"}
    fz_p = dst.parent / "FROZEN.json"
    history = (read_json(fz_p).get("history", []) if fz_p.exists() else [])
    rec = {"sha256": h, "source": str(src), "frozen_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
           "datasets": dsets, "skipped_not_finished": skipped, "git_commit": git_commit(),
           "rule_hashes": {k: v.get("rule_sha256") for k, v in sel.items() if k.startswith("_")},
           "gate_G_B": {ds: gate["datasets"][ds]["status"] for ds in dsets},
           "tau": {ds: {"tau": frozen_sel[ds]["tau"]["aggregation"]["tau"], "status": frozen_sel[ds]["tau"]["status"],
                        "label": frozen_sel[ds]["tau"].get("label")} for ds in dsets},
           "d10_trigger": {k: d10.get(k) for k in ("status", "r", "threshold", "label")},
           "frozen_manifest_content_sha256": frozen_manifest["content_sha256"],
           "hypotheses_sha256": frozen_manifest["hypotheses_sha256"],
           "schedule_selected": {ds: frozen_sel[ds]["T3"]["dp"]["schedule"] for ds in dsets},
           "note": "HS is not testable for a dataset whose selected schedule is fixed (DP2 = DP1 and R1q = R1p)"}
    write_json(fz_p, {**rec, "history": history + [rec]})
    man.output(dst); man.output(fz_p); man.close("COMPLETE", sha256=h, datasets=dsets)
    print(json.dumps({k: rec[k] for k in ("sha256", "datasets", "gate_G_B", "tau", "d10_trigger")}, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
