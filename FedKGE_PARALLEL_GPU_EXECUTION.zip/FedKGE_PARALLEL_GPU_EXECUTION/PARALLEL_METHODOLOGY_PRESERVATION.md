# Methodology preservation: the parallel layer vs the sequential implementation

**Bottom line:**
- The parallel layer adds **no methodology** and changes **no file that determines a result**:
  - the core code hash is unchanged (`13b56d18…`);
  - the configs and the frozen manifest are unchanged (`f86054ff…`);
  - the 885 runs are unchanged.
- It only changes *who* executes a run, *when*, and *how* the result travels back.
- Verified **statically** (tests on the real frozen manifest) and **at runtime** on the smoke tier (CPU, real data subsets, several concurrent workers). It has **not** run on a GPU or on the research tiers. Those runs are the study itself, and you start them.

---

## 1. Preservation checklist

| # | Methodology component | Sequential implementation | Parallel implementation | Preserved? | How it is enforced / checked |
|---|---|---|---|---|---|
| 1 | Approved experiments | 900 cells, 885 unique runs (frozen manifest) | jobs are groups of those cells; each cell is in exactly one GPU job, and tuning re-statement cells belong to their stage's selection | ✅ | `jobs.check_graph`; `test_every_cell_exactly_once` (chain and stage, 1/2/4 workers) |
| 2 | Run configurations and identities | `runner.expand` → `run_id(cfg)` | the same function and arguments in the worker; the worker must reproduce the master's run ids (exit 7 otherwise); the master re-checks `run_id(config.json)` = folder name at import | ✅ | `execute._run_runs`; `store.import_bundle` |
| 3 | Datasets and preprocessing | pinned SHA-256, deterministic P1 | the same scripts in every environment; the master refuses any data hash different from its own | ✅ | `phase01`, `phase02`; import check |
| 4 | Non-IID partitions | `build_partition` (seeded) | the same function; the master rebuilds deterministically and requires an equal partition hash | ✅ | import check `STALE_PARTITION` |
| 5 | Seeds (S5, tuning seed 1001) | the seed sets of the matrices | unchanged (part of the cells) | ✅ | manifest cells |
| 6 | TransE model, training, early stopping, checkpoint selection | `fedkge.federated.run_experiment` | the same function (via `run_entries`) | ✅ | core code hash in every run and bundle |
| 7 | Differential privacy and RDP accounting | per run, from the executed steps | unchanged; parallel execution of *other* runs cannot affect a run's accountant | ✅ | core code hash; `accountant.json` per run |
| 8 | Trust-weighted aggregation and robust baselines | per run, sequential rounds | unchanged; rounds are never parallelised | ✅ | core code hash |
| 9 | Attacks, integrity verification, MIA audit | per run | unchanged | ✅ | core code hash |
| 10 | Gate G-B before any further tuning | `run_plan.py` stops Stage 3 for a failing dataset | chain mode: the same `run_plan.py`; stage mode: stage 1 is released only after the master's `SEL-<ds>-s0` shows PASSED | ✅ | `test_dependencies_are_scientific_only`; `master_flow` |
| 11 | Stage-3 selection rules (T1–T3), τ with fallback B3, D10 | `run_plan.tune_select` after each stage | the master calls the same `tune_select`, stage by stage, on the imported runs; in chain mode the worker's own selection must be reproduced exactly | ✅ | `store.select`; e2e check (selections identical) |
| 12 | Freeze G-C (append-only per dataset) | `scripts/freeze_selections.py` | the same script, on the master only; workers receive the frozen files byte for byte, append-only | ✅ | `bundles.install_pack`; `test_frozen_pack_install` |
| 13 | Stage-4 blocks, priorities, reduced profile | `run_plan --plan confirm` | the same expansion; within each worker queue the priority order 1, 2, 3, 5, 6, 7 is kept; a run shared by two cells (fixed-schedule case) is executed once | ✅ | `jobs.materialize`; `test_materialize_executes_shared_runs_once` |
| 14 | Legacy replications L1–L4 (+ optional L0) | `run_legacy_blocks.py` at priority 4 | the same cells and manifest check; they may start earlier (they need no selection). L0 uses the same script on the master | ✅ (execution order only) | manifest `legacy` plan check |
| 15 | One environment per (tier, dataset) | `check_environment_lock` per results root | the same check in every worker root **plus** a cross-worker lock in the master store (a bundle with another signature is refused); the planner never splits a group across classes | ✅ (stricter) | `store.env_check`; `test_master_environment_lock_across_workers`; `test_schedule_respects_environment_classes` |
| 16 | No test-set-based selection, no leakage | selections on validation only | workers cannot select; the master selects with the same rules on validation metrics; the test split is read only by each run's final evaluation | ✅ | code path (`execute` never calls a selection) |
| 17 | Statistical analysis (paired t, Holm over fixed families, CIs, d_z, non-inferiority) | `scripts/analyze_results.py` | the same script on the master store | ✅ | e2e: hypothesis table identical |
| 18 | Reports, figures, export | `build_report.py`, `export_artifacts.py` | the same scripts on the master store | ✅ | phase 11 |
| 19 | Missing values | ⟦PENDING⟧, p = 1, PROVISIONAL | unchanged; phase 09 lists the missing cells and the job that must run them | ✅ | phase 09 |
| 20 | Checkpointing and resumption | atomic checkpoints (model, optimizer, accountant, trust state, RNG states) | unchanged; the same job command resumes the same run | ✅ | core; receipts |
| 21 | Dataset files never redistributed | export excludes them | bundles and packs never contain dataset files or checkpoints | ✅ | `bundles.keep_run_file` |
| 22 | All metrics (MRR, Hits@1/3/10, privacy, robustness, integrity) | `final.json` | unchanged files, moved byte for byte (SHA-256 checked) | ✅ | import hash checks |

**Files changed:**
- **No file** under `01_fedkge_core/`, `10_configs/`, `11_experiment_schemas/` or `12_validation_tests/` was modified.
- New: `revision/parallel/` and `revision/colab/make_parallel_notebooks.py`; the two parallel notebooks; three documents.
- Edited: `revision/colab/make_notebook.py`, for the package zip name only. The main notebook was regenerated for the new commit, and the README and `EXECUTION_GUIDE.md` gained pointers.

### Execution-order differences (allowed, stated openly)

1. **Legacy replications may run first.** Their priority 4 was a reporting priority for the deadline (RC-12), not a dependency. Running them earlier on a GPU that would otherwise wait changes no configuration and no result.
2. **Priorities interleave across workers.** Every worker keeps 1 → 7 in its own queue, but two workers can be on different priorities at the same moment. Every hypothesis family is decided only when all its members are complete, as before.
3. **Tuning stage 1 still waits for gate G-B.** It is computationally independent (fixed run ids), but the pre-registered protocol requires the gate "before any further tuning", so the barrier is kept. This costs some parallelism in stage mode and was kept on purpose.

### Methodological defects found during this restructuring
None. No experiment had to be changed to make it parallel. Two limits are documented in `PARALLEL_ARCHITECTURE.md`; they are properties of the approved design, not defects:
- the environment lock limits how far one dataset can be spread across different GPU types;
- the rounds of a run are sequential.

---

## 2. Static verification (what the tests prove)

`python -m pytest -q revision/parallel/tests` ran on the CPU with the pinned packages. The core suite (`revision/12_validation_tests`) was re-run unchanged.

| Suite | Result | Report |
|---|---|---|
| parallel layer (`revision/parallel/tests`) | **35 passed, 0 failed** | `provenance/validation_2026-11-07_parallel/test_report_parallel.txt` |
| core suite, unchanged (`revision/12_validation_tests`) | **184 passed, 0 failed** (as on 2026-11-05) | `provenance/validation_2026-11-07_parallel/test_report_core.txt` |


| Test file | What it checks |
|---|---|
| `test_parallel_plan.py` | the real frozen manifest: 900 cells, every cell in exactly one job (chain/stage × 1/2/4 workers), the cost total, scientific dependencies only (datasets never wait for each other; stage k after k−1; stage 1 after the gate; Stage 4 after its own freeze; legacy free), acyclic, waves, critical path, schedule respects environment classes and dependencies, more workers never slower, deterministic balanced shards, shared runs executed once |
| `test_parallel_exchange.py` | atomic zips and sidecars, tamper detection, unsafe names refused, append-only selection and gate merges, the frozen-pack install (byte-exact, refuses a changed value), the cross-worker environment lock (enforced on research tiers, recorded on check tiers) |
| `test_parallel_cli.py` | every phase entry point parses its options; phase 03 plans the research study on a mixed registry (T4, T4, L4), keeps one class per group, writes the queues, and freezes the job definitions on re-planning |

---

## 3. Runtime verification (smoke tier, CPU, real data subsets; a software check, never evidence)

`revision/parallel/tests/e2e_smoke_equivalence.py` executes the complete smoke schedule twice:
1. **Reference:** the sequential entry points (`run_plan.py` tune, `run_plan.py` confirm, `run_legacy_blocks.py`, `analyze_results.py`) in one results root.
2. **Parallel:** phases 00 → 03, then **three workers running concurrently** in three separate results roots. They exchange nothing but bundles and packs. The master cycle (import → selections, freeze, releases → validation) repeats until complete, then phase 10.

The comparison is single-threaded (`OMP_NUM_THREADS=1`), so bit-identity is expected.

| Check | Chain mode | Stage mode |
|---|---|---|
| runs in the reference / in the parallel master store | 291 / 291 | 291 / 291 |
| runs only in one of them | 0 | 0 |
| runs whose `final.json` differs in any non-timing field | **0** (bit-identical) | **0** (bit-identical) |
| runs executed twice (worker roots: 97 + 97 + 97 / 103 + 94 + 94) | 0 | 0 |
| Stage-3 selections (all three datasets) | identical | identical |
| bundles imported / refused / conflicts | 54 / 0 / 0 | 93 / 0 / 0 |
| release packs | 3 | 18 |
| master cycles needed | 2 | 7 |
| phase-09 validation | COMPLETE AND COMPATIBLE | COMPLETE AND COMPATIBLE |
| hypothesis table of the analysis | identical | identical |

Evidence: `provenance/validation_2026-11-07_parallel/e2e_result_chain.json`, `e2e_result_stage.json` and the two validation reports.

**Notebooks:** `FEDKGE_PARALLEL_WORKER.ipynb` and `FEDKGE_PARALLEL_MASTER.ipynb` were executed from the delivered zip, cell by cell, in three sessions each (smoke mode, CPU, a local folder instead of Drive). The sessions covered registration, planning, a budgeted queue ending in PAUSED, imports, the chain replay and the releases. Every cell ran without error (`notebook_harness_parallel.json`).

**Timing (CPU, 2 cores, smoke tier; not a GPU estimate):**
- the sequential reference took ≈ 10.3 min of run time;
- three concurrent workers took ≈ 6.0 min (chain) and ≈ 6.4 min (stage).

Two cores limit this check. It shows that the jobs really ran at the same time without interfering, not what GPUs will gain.

**Defects found and fixed by this check (before the final runs above):**
- the master's first import failed because the `runs/` folder did not exist yet;
- a master step record mixed integer and text keys;
- the validation tool wrongly required `accountant.json` for the DP3 *no-noise* ablation (which has, by design, no privacy accountant).

All three were in the new layer, none in the methodology. Both modes were then re-run from scratch with the final code.


---

## 4. What was NOT verified (and cannot be from here)

| Not verified | Why | What covers it |
|---|---|---|
| Any GPU execution of the parallel layer | no GPU here | the core's GPU behaviour was measured in your Colab pilot (2026-11-04); the parallel layer only calls the core |
| The research tiers (tune/final) end to end | they are the study (≈ 119 GPU-h) | the same code paths ran on the smoke tier; the research-only branches (frozen-manifest checks, freeze, frozen packs, enforced lock) are covered by the unit tests and by the core's own tests |
| Real Google Drive sync between simultaneous Colab sessions | not reproducible here | designed for it: unique file names, `.part` + rename, sidecar written last, readers ignore anything without a matching sidecar |
| Whether your Colab plan allows simultaneous GPU sessions | account-specific | the guide says to count only environments you may really use |
| The speed-up | needs real GPUs | all time figures are labelled estimates; re-plan with `phase03 --measured` after the first jobs |
