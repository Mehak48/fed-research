# FedKGE — complete executable methodology, with parallel GPU execution

**Project:** Privacy-Preserving Federated Knowledge Graph Embedding (revised study). **Owner:** Mehak Ramzan. **Package date:** 2026-11-05; parallel execution layer added 2026-11-07 (the methodology, the 885 runs and the core code are unchanged).

This package runs the complete, approved study from one Colab notebook:

1. verified data preparation;
2. the mandatory accuracy sanity gate;
3. Stage 3 tuning;
4. the Stage 4 experiments, essential hypotheses first, with the original-paper replications;
5. statistics, figures, tables and a results draft for the paper.

The method is frozen: decisions D1–D18 and B2–B5 are implemented, and no further design decision is needed to run it.

> **Status: ready to execute. No research result exists yet.**
> - Nothing in this package is a result. Tuning (99 runs), the main experiments (756 runs) and the replications (30 runs) have **not** been run; you start them yourself.
> - The code was verified at code level only (tests, schemas, manifest, real-data subsets, an end-to-end notebook run on the CPU). See `VALIDATION_REPORT.md`.
> - **Deadline:** the full study is ≈ 118 GPU-hours (upper bound). It does not fit into this week on one T4. `DEADLINE_PLAN.md` shows what does fit and how to report it honestly.

## Start here

1. Upload **this zip** (unchanged) to `MyDrive/FedKGE/`.
2. Open `RUN_COMPLETE_FEDKGE_RESEARCH.ipynb` in Colab with a T4 GPU.
3. Edit the settings cell (Step 1a) once: the licence confirmation and your note.
4. Run Steps 1 → 9 in order. In every later session, run Step 1 → Step 2, then continue where you stopped.

Details, timings and the recovery playbook: `EXECUTION_GUIDE.md`.

## Two ways to run the same study

| You have | Use | Guide |
|---|---|---|
| one GPU environment | `RUN_COMPLETE_FEDKGE_RESEARCH.ipynb` (one notebook, Steps 1–9) | `EXECUTION_GUIDE.md` |
| two or more GPU environments you may use at the same time | `FEDKGE_PARALLEL_WORKER.ipynb` (one per GPU) + `FEDKGE_PARALLEL_MASTER.ipynb` (CPU) | `PARALLEL_EXECUTION_GUIDE.md` |

Both run the same 885 approved runs with the same unchanged code. The parallel route splits them into independent jobs that exchange only verified files. Estimates for identical T4s: ≈ 60 h with 2, ≈ 40 h with 3, ≈ 30 h with 4, against ≈ 119 h with one. Mixing GPU types or torch builds is allowed only between datasets (the environment lock). Design: `PARALLEL_ARCHITECTURE.md`. What was verified: `PARALLEL_METHODOLOGY_PRESERVATION.md`.

## The approved schedule (owner decision B2)

| Notebook step | Runs | T4 upper bound (estimate) |
|---|---|---|
| 3 — mandatory accuracy sanity gate G-B (part of Stage 3) | 18 | ≈ 1.7 GPU-h |
| 4 — Stage 3 tuning, validation only, then the freeze G-C | 81 more (99 in total) | ≈ 10.8 GPU-h |
| 5 — Stage 4 main experiments, priorities 1–7 | 756 | ≈ 100.5 GPU-h |
| 6 — replications L1–L4 (priority 4 of Step 5) + optional L0 | 30 | ≈ 5.4 GPU-h |
| Stage 5 — extended / sensitivity | deferred | — |
| **Total** | **885** | **≈ 118 GPU-h (upper bound)** |

The exact run list is frozen in `revision/10_configs/manifest/FROZEN_MANIFEST.csv`.

## What is inside

```
FedKGE_PARALLEL_GPU_EXECUTION/
├── README.md                             this file
├── EXECUTION_GUIDE.md                    operator guide (one GPU): setup, the exact sequence, commands, recovery
├── PARALLEL_EXECUTION_GUIDE.md           operator guide (several GPUs): phases, commands, 1-4 GPU plans, recovery
├── PARALLEL_ARCHITECTURE.md              audit, phases, dependency graph, parallel validity, contracts, estimates
├── PARALLEL_METHODOLOGY_PRESERVATION.md  preservation checklist; static and runtime verification
├── FEDKGE_PARALLEL_WORKER.ipynb          one per GPU environment (outside git: it checks the commit)
├── FEDKGE_PARALLEL_MASTER.ipynb          the master (CPU): plan, import, selections/freeze, validation, analysis
├── DEADLINE_PLAN.md                      what can finish when; what a partial study can honestly report
├── VALIDATION_REPORT.md                  what was verified (code level) and what was not (experiments)
├── RUN_COMPLETE_FEDKGE_RESEARCH.ipynb    the primary Colab notebook (outside git: it checks the commit)
├── revision/                             the code (git repository; approved layout)
│   ├── 01_fedkge_core/fedkge/            the package (training, DP, accounting, trust, attacks, integrity,
│   │                                     MIA, evaluation, statistics, figures, reports)
│   ├── 10_configs/                       base, datasets, tiers, matrices, selection rules, gates, hypotheses,
│   │                                     manifest/FROZEN_MANIFEST.*
│   ├── 11_experiment_schemas/            JSON schemas of every output
│   ├── 12_validation_tests/              the automated tests
│   ├── 13_documentation/                 FINAL_METHODOLOGY.md, DP_MECHANISM.md, THREAT_MODEL.md, approval register
│   ├── parallel/                         the parallel execution layer: fedkge_parallel/ (shared modules),
│   │                                     phases/phase00-11 + run_worker_queue + master_cycle, tests, tools,
│   │                                     cost_table_T4_upper.csv, setup_environment.sh, requirements-parallel.txt
│   ├── scripts/                          entry points (prepare_data, build_artifacts, run_plan, run_legacy_blocks,
│   │                                     freeze_selections, status, analyze_results, make_figures, build_report,
│   │                                     export_artifacts, ...)
│   ├── requirements-phaseC.txt           pinned dependencies
│   └── README.md                         commands and exit codes
├── audit/                                Phase A audit, Phase B design (D1–D18), Phase C reports, and
│   └── final/FINAL_IMPLEMENTATION_REPORT.md   what changed in this package and why
├── provenance/                           git checkpoint, checksums, build environment, validation evidence,
│                                         the deadline cost model, the owner's GPU pilot session (2026-11-04)
├── instructions/                         the owner's directives (Phase A … final)
├── reference/                            code cells of the original notebooks
└── history/                              superseded handoff material (kept, never deleted)
```

## What the package needs from you

| Item | Why | When |
|---|---|---|
| Confirm the three dataset licences in Step 1a (with a note) | nothing is downloaded without it | first session |
| GPU time: ≈ 118 GPU-hours upper bound | free Colab over several weeks, or paid compute units | Steps 3–6 |
| Optional: `complete/global_transe_final.pt` | L0 (re-evaluating the original model) | any time; without it L0 stays PENDING |

## Ground rules this package enforces

1. **Results come only from recorded runs.** Missing values appear as ⟦PENDING⟧ and are never invented, estimated or typed in. Software-check outputs are watermarked "NOT FOR MANUSCRIPT".
2. **Selection is validation-only and pre-registered.**
   - Gate G-B must pass before tuning continues.
   - The τ rule has a pre-declared fallback (B3) that is always labelled.
   - The D10 trigger is a flag only (B5).
3. **Hypotheses are decided by pre-registered tests.**
   - They use one-sided paired t-tests with Holm correction over the fixed family.
   - Non-inferiority (H2b) needs the confidence bound, never just the point estimate.
   - Missing members enter with p = 1.
4. **Privacy claims are per trained model.**
   - The worst-client RDP ε is the guarantee of one trained model.
   - **No end-to-end DP guarantee** is claimed for the tuning-and-evaluation workflow.
   - There is no IPFS, and SHA-256 integrity is not a poisoning defence.
5. **The schedule and the code are frozen.**
   - The run schedule is the frozen manifest.
   - The code is the committed version, checked every session.
   - One environment is used per comparison.
   - A completed run is never executed again.
6. **Data stay out of deliverables.** Dataset files and model weights never enter a deliverable or an export.

## Provenance

| Item | Value |
|---|---|
| Git commit, frozen manifest content hash and core code hash | `provenance/GIT_CHECKPOINT.md` |
| Checksum of every file in the package | `provenance/SHA256SUMS.txt` |
| Baseline | the owner's B2–B5 checkpoint (`6e2ea67`) |
