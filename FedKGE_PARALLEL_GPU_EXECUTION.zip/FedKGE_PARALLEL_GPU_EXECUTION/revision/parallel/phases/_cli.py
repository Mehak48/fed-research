"""Common command-line options of the phase entry points."""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

PARALLEL = Path(__file__).resolve().parents[1]
if str(PARALLEL) not in sys.path:
    sys.path.insert(0, str(PARALLEL))

from fedkge_parallel.common import EXIT_TEXT, Layout  # noqa: E402


def parser(desc: str, worker: bool = False, gpu: bool = False) -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description=desc, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--base", default=os.environ.get("FEDKGE_PARALLEL_BASE"),
                    help="the shared folder (e.g. /content/drive/MyDrive/FedKGE); default $FEDKGE_PARALLEL_BASE")
    ap.add_argument("--mode", default=os.environ.get("FEDKGE_PARALLEL_MODE", "research"),
                    choices=["research", "smoke", "dev"],
                    help="research = the approved study (tune + final tiers); smoke/dev = software checks only")
    if worker:
        ap.add_argument("--worker", default=os.environ.get("FEDKGE_WORKER"), required=os.environ.get("FEDKGE_WORKER") is None,
                        help="this environment's worker name (letters, digits, - _ .)")
    if gpu:
        ap.add_argument("--device", default=os.environ.get("FEDKGE_DEVICE", "cuda"))
        ap.add_argument("--max-hours", type=float, help="start no new run after this many hours (session limit)")
        ap.add_argument("--max-runs", type=int, help="start at most this many new runs")
    return ap


def layout(a) -> Layout:
    if not a.base:
        raise SystemExit("give --base (the shared folder) or set FEDKGE_PARALLEL_BASE")
    return Layout(a.base).ensure()


def finish(code: int) -> int:
    print(f"EXIT {code}: {EXIT_TEXT.get(code, '')}", flush=True)
    return code
