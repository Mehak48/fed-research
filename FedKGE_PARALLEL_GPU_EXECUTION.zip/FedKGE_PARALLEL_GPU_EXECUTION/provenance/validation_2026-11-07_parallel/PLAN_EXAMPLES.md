# Example plans (estimates)

T4 upper bounds from the owner's pilot (parallel/cost_table_T4_upper.csv); hand-over = the time to move a bundle or pack and run the master cycle. **Estimates, not measurements.**

| Workers | Tuning mode | Hand-over h | GPU jobs | Makespan h | Critical path h | Total T4 GPU-h | Mean busy workers |
|---|---|---|---|---|---|---|---|
| 1 identical T4 | chain | 0.25 | 47 | 119.1 | 8.0 | 118.9 | 1.00 |
| 1 identical T4 | chain | 1.0 | 47 | 119.9 | 9.5 | 118.9 | 0.99 |
| 1 identical T4 | stage | 0.25 | 62 | 119.1 | 9.2 | 118.9 | 1.00 |
| 1 identical T4 | stage | 1.0 | 62 | 120.0 | 14.5 | 118.9 | 0.99 |
| 2 identical T4 | chain | 0.25 | 54 | 59.7 | 8.0 | 118.9 | 1.99 |
| 2 identical T4 | chain | 1.0 | 54 | 60.5 | 9.5 | 118.9 | 1.97 |
| 2 identical T4 | stage | 0.25 | 81 | 59.8 | 7.1 | 118.9 | 1.99 |
| 2 identical T4 | stage | 1.0 | 81 | 63.2 | 12.4 | 118.9 | 1.88 |
| 3 identical T4 | chain | 0.25 | 65 | 40.1 | 8.0 | 118.9 | 2.97 |
| 3 identical T4 | chain | 1.0 | 65 | 40.8 | 9.5 | 118.9 | 2.91 |
| 3 identical T4 | stage | 0.25 | 104 | 40.3 | 6.5 | 118.9 | 2.95 |
| 3 identical T4 | stage | 1.0 | 104 | 44.0 | 11.7 | 118.9 | 2.70 |
| 4 identical T4 | chain | 0.25 | 79 | 30.0 | 8.0 | 118.9 | 3.96 |
| 4 identical T4 | chain | 1.0 | 79 | 31.3 | 9.5 | 118.9 | 3.80 |
| 4 identical T4 | stage | 0.25 | 130 | 30.2 | 6.2 | 118.9 | 3.93 |
| 4 identical T4 | stage | 1.0 | 130 | 34.3 | 11.4 | 118.9 | 3.46 |

## Unequal environments (chain mode, hand-over 0.25 h)

| Workers | Makespan h | Critical path h | Group → class | Jobs per worker |
|---|---|---|---|---|
| 2 T4 (same build) + 1 GPU at 2x (hypothetical) | 35.2 | 8.0 | {'final/codex_m': 'FAST', 'final/fb15k237': 'T4', 'final/wn18rr': 'FAST', 'tune/codex_m': 'FAST', 'tune/fb15k237': 'T4', 'tune/wn18rr': 'T4'} | {'T4-1': 10, 'T4-2': 11, 'fast': 28} |
| 1 T4 + 1 T4 with another torch build (2 classes) | 69.9 | 8.0 | {'final/codex_m': 'T4|torchA', 'final/fb15k237': 'T4|torchB', 'final/wn18rr': 'T4|torchA', 'tune/codex_m': 'T4|torchA', 'tune/fb15k237': 'T4|torchB', 'tune/wn18rr': 'T4|torchB'} | {'T4-a': 28, 'T4-b': 19} |
| 3 T4 + 1 slower GPU at 0.6x (hypothetical) | 38.5 | 11.0 | {'final/codex_m': 'T4', 'final/fb15k237': 'T4', 'final/wn18rr': 'T4', 'tune/codex_m': 'T4', 'tune/fb15k237': 'SLOW', 'tune/wn18rr': 'SLOW'} | {'T4-1': 20, 'T4-2': 23, 'T4-3': 20, 'slow': 2} |
