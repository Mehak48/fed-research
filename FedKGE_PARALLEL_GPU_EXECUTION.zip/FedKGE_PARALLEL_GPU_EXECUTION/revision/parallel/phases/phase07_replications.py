#!/usr/bin/env python3
"""PHASE 07 (GPU worker) - legacy replications L1-L4 (FB15k-237, 30 runs, frozen run ids).

  python parallel/phases/phase07_replications.py --base B --worker W --job L-fb15k237-1of2 --max-hours 10

These runs need no Stage-3 selection, so they may start right after phase 02, in parallel with the tuning. They
belong to the final/fb15k237 environment group: run them on the same worker class as the FB15k-237 Stage-4 jobs.
L0 (re-evaluating your original checkpoint) is not a GPU job: scripts/legacy_l0_eval.py on the master.
Outputs: COMPLETE run folders in <base>/workers/<W>/results/final/runs/, a result bundle in the outbox.
Success: EXIT 0. Next: master phase 08 (import)."""
from __future__ import annotations

import sys

from _cli import finish, layout, parser

from fedkge_parallel.common import EXIT_CONTRACT
from fedkge_parallel.execute import job_spec_for, run_worker_job

KINDS = ['LEGACY']


def main(argv=None) -> int:
    ap = parser(__doc__, worker=True, gpu=True)
    ap.add_argument("--job", required=True, help="a job id from the plan (see QUEUE_<worker>.md)")
    a = ap.parse_args(argv)
    L = layout(a)
    spec = job_spec_for(L, a.job)
    if spec["kind"] not in KINDS:
        print(f"STOP: {a.job} is a {spec['kind']} job; this entry point runs {KINDS}")
        return finish(EXIT_CONTRACT)
    return finish(run_worker_job(L, a.worker, a.job, a.device, a.max_hours, a.max_runs))


if __name__ == "__main__":
    sys.exit(main())
