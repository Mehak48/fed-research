"""Automated completeness and compatibility check of the master store (phase 10).

It answers: which approved cells are COMPLETE, which are missing and WHICH JOB (and which worker in the plan) must run
them, and whether anything in the store is incompatible (stale code/data/partition/selection, mixed environments,
missing required output files, quarantined conflicts). It never fills anything in and never deletes anything.
Exit codes: 0 = every approved cell COMPLETE and compatible; 2 = compatible but incomplete; 1 = incompatibility.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List

import pandas as pd

from .bundles import list_verified
from .cells import approved_cells
from .common import CONFIG_DIR, RESEARCH_TIERS, Layout, Paths, RunDir, atomic_write_json, atomic_write_text, \
    read_json, read_json_or, utc_now, write_csv
from .jobs import Job
from .store import Master

ALWAYS = ("config.json", "env.json", "status.json", "final.json", "log.txt", "rounds.csv", "weights_rounds.csv",
          "per_relation_test_mrr.json")


def required_files(cfg: Dict) -> List[str]:
    req = list(ALWAYS)
    dp = cfg.get("dp") or {}
    if dp.get("enabled") and dp.get("mode") != "no_noise":      # the DP3 no-noise ablation has no accountant
        req.append("accountant.json")
    if (cfg.get("integrity") or {}).get("mode", "off") != "off":
        req.append("integrity.json")
    if (cfg.get("mia") or {}).get("enabled"):
        req += ["mia.json", "mia_scores.csv"]
    if (cfg.get("train") or {}).get("keep_final_weights"):
        req.append("final_weights.pt")
    return req


def _index_lookup(paths: Paths) -> Dict[str, str]:
    m = {}
    idx = paths.base / "index"
    if idx.exists():
        for p in sorted(idx.glob("*_runs_index.csv")):
            for r in pd.read_csv(p).to_dict("records"):
                m[f"{r['block']}|{r['dataset']}|s{int(r['seed'])}|{r['name']}"] = r["run_id"]
    return m


def validate_store(layout: Layout, mode: str = "research") -> Dict:
    from fedkge.analysis import collect
    from fedkge.manifest import cell_status
    master = Master(layout, mode)
    root = master.root
    cells = approved_cells(mode)
    plan = read_json_or(layout.plan_file, None)
    jobs = [Job.from_dict(d) for d in plan["jobs"]] if plan else []
    owner = {k: j.job_id for j in jobs if j.is_worker for k in j.cells}
    where = (plan or {}).get("schedule", {}).get("where", {})
    lookups = {}
    rows = []
    for c in cells:
        paths = Paths(root, c.tier)
        if c.tier not in lookups:
            lookups[c.tier] = _index_lookup(paths)
        rid = c.run_id or lookups[c.tier].get(c.cell_key.split("|", 1)[1])
        st = cell_status(paths, rid)
        job = owner.get(c.cell_key)
        if job is None and c.reuse:
            job = f"(re-uses the winner of the previous tuning stage; selection step of {c.dataset})"
        rows.append({"cell_key": c.cell_key, "plan": c.plan, "tier": c.tier, "dataset": c.dataset, "block": c.block,
                     "seed": c.seed, "priority": c.priority, "stage": c.stage, "run_id": rid, "status": st["status"],
                     "job_id": job, "planned_worker": where.get(job, "") if job else ""})
    df = pd.DataFrame(rows)
    problems: List[Dict] = []
    # compatibility: the core's own validity checks (code, tier, data, partition, selections)
    for tier, phases in _tier_phases(mode).items():
        paths = Paths(root, tier)
        have = [ph for ph in phases if paths.index(ph).exists()]
        if not have:
            continue
        runs, probs = collect(paths, have)
        for r in probs.to_dict("records"):
            if r["problem"] not in ("NOT_RUN",):
                problems.append({"kind": "core_validity", "tier": tier, **{k: r.get(k) for k in
                                 ("block", "dataset", "seed", "run_id", "problem", "detail")}})
    # one environment per (tier, dataset), from every COMPLETE run's own env.json
    env_sets: Dict[tuple, set] = {}
    for r in df[df["status"] == "COMPLETE"].itertuples():
        rd = Paths(root, r.tier).run(r.run_id)
        env = read_json_or(rd / "env.json", {})
        fin = read_json_or(rd / "final.json", {})
        sig = ((fin.get("runtime") or {}).get("device"), env.get("gpu"), env.get("torch"), env.get("cuda"))
        env_sets.setdefault((r.tier, r.dataset), set()).add(sig)
        cfg = read_json_or(rd / "config.json", {})
        miss = [f for f in required_files(cfg) if not (rd / f).exists()]
        if miss:
            problems.append({"kind": "missing_output_files", "tier": r.tier, "dataset": r.dataset, "run_id": r.run_id,
                             "problem": "MISSING_FILES", "detail": ", ".join(miss)})
    from fedkge.config import load_yaml
    enforce = load_yaml(CONFIG_DIR / "gates.yaml")["environment_lock"].get("enforce_on_tiers", [])
    for (tier, ds), sigs in env_sets.items():
        if len(sigs) > 1 and tier in enforce:
            problems.append({"kind": "mixed_environments", "tier": tier, "dataset": ds, "problem": "MIXED_ENVIRONMENTS",
                             "detail": "; ".join(map(str, sorted(map(str, sigs))))})
    for tier in set(c.tier for c in cells):
        q = Paths(root, tier).base / "parallel_conflicts"
        if q.exists():
            for p in sorted(q.iterdir()):
                problems.append({"kind": "conflict", "tier": tier, "problem": "QUARANTINED_DUPLICATE_EXECUTION",
                                 "detail": f"{p.name}: the same run was executed twice; the first imported copy is "
                                           "used, the second is kept here for the record"})
    if mode == "research":
        fz = read_json_or(Paths(root, "final").base / "selection" / "FROZEN.json", {})
        for ds in sorted(set(df[(df["plan"] == "main") & (df["status"] == "COMPLETE")]["dataset"])):
            if ds not in fz.get("datasets", []):
                problems.append({"kind": "selection", "tier": "final", "dataset": ds, "problem": "NOT_FROZEN",
                                 "detail": "main runs exist for a dataset whose selections are not frozen"})
    led = read_json_or(master.ledger_path, {"bundles": {}})["bundles"]
    waiting = [p.name for p, sha in list_verified(layout.outbox) if sha not in led]
    refused = [r for r in led.values() if r.get("status") == "REFUSED"]
    incomplete = df[df["status"] != "COMPLETE"]
    reruns = (incomplete.groupby(["job_id", "planned_worker"], dropna=False)
              .agg(cells=("cell_key", "size"), statuses=("status", lambda s: ",".join(sorted(set(s)))))
              .reset_index()) if len(incomplete) else pd.DataFrame(columns=["job_id", "planned_worker", "cells", "statuses"])
    code = 1 if problems else (2 if len(incomplete) else 0)
    rep = {"checked_utc": utc_now(), "mode": mode, "master": str(root), "approved_cells": len(df),
           "cells_by_status": df["status"].value_counts().to_dict(),
           "cells_by_plan_status": {p: g["status"].value_counts().to_dict() for p, g in df.groupby("plan")},
           "problems": problems, "bundles_waiting_for_import": waiting, "bundles_refused": refused,
           "jobs_with_missing_cells": reruns.to_dict("records"), "exit_code": code,
           "verdict": {0: "COMPLETE AND COMPATIBLE", 1: "INCOMPATIBILITY FOUND - see problems",
                       2: "COMPATIBLE BUT INCOMPLETE - run the listed jobs"}[code]}
    out = root / "parallel"
    atomic_write_json(out / "VALIDATION_REPORT.json", rep)
    write_csv(out / "VALIDATION_CELLS.csv", df)
    write_csv(out / "RERUN_LIST.csv", reruns)
    atomic_write_text(out / "VALIDATION_REPORT.md", _markdown(rep, reruns))
    return rep


def _tier_phases(mode: str) -> Dict[str, List[str]]:
    if mode == "research":
        return {"tune": ["tune"], "final": ["final", "p3", "p4"]}
    return {mode: ["tune", "final", "p3", "p4"]}


def _markdown(rep: Dict, reruns: pd.DataFrame) -> str:
    L = [f"# Master store validation ({rep['mode']})", "", f"Checked {rep['checked_utc']}. **{rep['verdict']}**", "",
         f"Approved cells: {rep['approved_cells']} · by status: {rep['cells_by_status']}", "",
         "| Plan | Status counts |", "|---|---|"]
    L += [f"| {p} | {s} |" for p, s in rep["cells_by_plan_status"].items()]
    L += ["", f"## Problems ({len(rep['problems'])})", ""]
    if rep["problems"]:
        L += ["| Kind | Tier | Dataset | Run | Problem | Detail |", "|---|---|---|---|---|---|"]
        L += [f"| {p.get('kind')} | {p.get('tier')} | {p.get('dataset', '')} | {p.get('run_id', '')} | "
              f"{p.get('problem')} | {str(p.get('detail', ''))[:160]} |" for p in rep["problems"][:300]]
    else:
        L.append("None.")
    L += ["", "## Jobs that still have missing cells", ""]
    if len(reruns):
        L += ["| Job | Planned worker | Cells | Status of those cells |", "|---|---|---|---|"]
        L += [f"| {r.job_id} | {r.planned_worker} | {r.cells} | {r.statuses} |" for r in reruns.itertuples()]
    else:
        L.append("None.")
    L += ["", f"Bundles verified but not imported yet: {len(rep['bundles_waiting_for_import'])}; "
          f"refused bundles: {len(rep['bundles_refused'])} (see IMPORT_LEDGER.json)."]
    return "\n".join(L) + "\n"
